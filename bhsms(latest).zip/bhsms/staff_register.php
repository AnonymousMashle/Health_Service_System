<?php
/* Staff self-registration: the person chooses BHW or Nurse. The account stays PENDING until the System Administrator approves it. */
require __DIR__ . '/includes/init.php';

if (current_user()) {
    redirect(home_path());
}

// User types a person may register as
const STAFF_TYPES = [
    'bhw'   => 'Barangay Health Worker (BHW)',
    'nurse' => 'Barangay Health Center Nurse',
];

$f = ['role' => '', 'first_name' => '', 'last_name' => '', 'email' => '', 'contact_no' => '', 'id_number' => '', 'username' => ''];
$errors = [];
$done = false;

if (is_post()) {
    foreach (array_keys($f) as $k) { $f[$k] = input($k); }
    $password = (string)($_POST['password'] ?? '');
    $confirm = (string)($_POST['confirm_password'] ?? '');

    if (($_SESSION['registrations'] ?? 0) >= 3) $errors[] = 'Too many registrations from this browser. Please contact the administrator.';
    if (!isset(STAFF_TYPES[$f['role']])) $errors[] = 'Choose whether you are registering as a BHW or a Nurse.';
    if ($f['first_name'] === '' || $f['last_name'] === '') $errors[] = 'First and last name are required.';
    if (!filter_var($f['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
    if (!preg_match('/^(09\d{9}|\+639\d{9})$/', $f['contact_no'])) $errors[] = 'Enter a mobile number like 09171234567.';
    if ($f['id_number'] === '') {
        $errors[] = $f['role'] === 'nurse' ? 'Enter your PRC license number.' : 'Enter your BHW accreditation or employee ID number.';
    } elseif ($f['role'] === 'nurse' && !preg_match('/^\d{7}$/', $f['id_number'])) {
        $errors[] = 'PRC license number must be 7 digits.';
    }
    if (!preg_match('/^[a-zA-Z0-9_.]{4,50}$/', $f['username'])) $errors[] = 'Username must be 4–50 letters, numbers, dots or underscores.';
    if (strlen($password) < 8) $errors[] = 'Password must be at least 8 characters.';
    if ($password !== $confirm) $errors[] = 'Passwords do not match.';
    if (!isset($_POST['confirm_true'])) $errors[] = 'Please confirm that your information is true.';

    if (!$errors && q('SELECT 1 FROM users WHERE username = ?', [$f['username']])->fetchColumn()) $errors[] = 'That username is already taken.';
    if (!$errors && q('SELECT 1 FROM users WHERE email = ?', [$f['email']])->fetchColumn()) $errors[] = 'That email is already used by another account.';

    if (!$errors) {
        $fullName = $f['first_name'] . ' ' . $f['last_name'] . ($f['role'] === 'nurse' ? ', RN' : '');
        try {
            $uid = db_insert('users', [
                'username' => $f['username'], 'password_hash' => password_hash($password, PASSWORD_DEFAULT),
                'full_name' => $fullName, 'email' => $f['email'], 'contact_no' => $f['contact_no'], 'id_number' => $f['id_number'],
                'role' => $f['role'], 'status' => 'pending',
            ]);
            $_SESSION['registrations'] = ($_SESSION['registrations'] ?? 0) + 1;
            q('INSERT INTO activity_logs (user_id, action, table_name, record_id, details, ip_address) VALUES (?, ?, ?, ?, ?, ?)',
              [$uid, 'REGISTER', 'users', $uid, 'Registered online as ' . ROLE_LABELS[$f['role']], $_SERVER['REMOTE_ADDR'] ?? null]);
            notify_roles(['admin'], 'New staff registration', $fullName . ' registered as ' . ROLE_LABELS[$f['role']] . ' and needs your approval.', 'admin/staff_approvals.php');
            $done = true;
        } catch (PDOException $e) {
            if (!is_duplicate_error($e)) throw $e;
            $errors[] = 'That username or email was just taken. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Staff Registration | <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
</head>
<body>
<div class="login-page">
    <div class="login-card" style="max-width:640px">
        <div class="brand-logo">+</div>
        <h1>Staff Registration</h1>
        <p class="sub">For Barangay Health Workers and Health Center Nurses. Your account will be activated after the System Administrator approves it.</p>

    <?php if ($done): ?>
        <div class="alert alert-success">
            <strong>Registration submitted!</strong><br>
            Your <?= e(STAFF_TYPES[$f['role']]) ?> account <strong><?= e($f['username']) ?></strong> is waiting for approval by the System Administrator.
            You can log in once it is approved.
        </div>
        <a class="btn btn-primary" href="<?= e(url('login.php')) ?>">Back to staff login</a>
    <?php else: ?>
        <?= render_errors($errors) ?>
        <form method="post" autocomplete="off">
            <?= csrf_field() ?>
            <div class="field required">
                <label>Register as</label>
                <div class="role-choice">
                    <?php foreach (STAFF_TYPES as $value => $label): ?>
                        <label class="role-option">
                            <input type="radio" name="role" value="<?= e($value) ?>" required <?= $f['role'] === $value ? 'checked' : '' ?>>
                            <span><strong><?= e($label) ?></strong>
                                <small><?= $value === 'bhw' ? 'Registers residents, records intake, vaccinations, home visits, dispenses medicine' : 'Assessments and treatment, vaccinations, medicine inventory, approvals' ?></small></span>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="form-grid" style="margin-top:14px">
                <?= field('First name', 'first_name', $f['first_name'], 'text', 'required maxlength="70"') ?>
                <?= field('Last name', 'last_name', $f['last_name'], 'text', 'required maxlength="70"') ?>
                <?= field('Email', 'email', $f['email'], 'email', 'required maxlength="150"') ?>
                <?= field('Mobile number', 'contact_no', $f['contact_no'], 'tel', 'required maxlength="13" placeholder="09XXXXXXXXX"') ?>
                <div class="field required span-2">
                    <label for="f_id_number">PRC license no. (Nurse) / BHW accreditation or employee ID (BHW)</label>
                    <input id="f_id_number" type="text" name="id_number" value="<?= e($f['id_number']) ?>" required maxlength="50">
                    <div class="hint">The administrator uses this to confirm who you are.</div>
                </div>
                <?= field('Username', 'username', $f['username'], 'text', 'required maxlength="50" pattern="[a-zA-Z0-9_.]{4,50}"') ?>
                <div></div>
                <?= field('Password', 'password', '', 'password', 'required minlength="8" autocomplete="new-password"') ?>
                <?= field('Confirm password', 'confirm_password', '', 'password', 'required minlength="8" autocomplete="new-password"') ?>
            </div>
            <label class="check" style="align-items:flex-start;margin:14px 0">
                <input type="checkbox" name="confirm_true" value="1" required <?= isset($_POST['confirm_true']) ? 'checked' : '' ?>>
                <span class="small">I confirm that I work at this barangay health center and that the information above is true. I will keep patient information confidential (Data Privacy Act of 2012).</span>
            </label>
            <button class="btn btn-primary" type="submit">Submit registration</button>
        </form>
        <p class="small" style="text-align:center;margin-top:16px">Already have an account? <a href="<?= e(url('login.php')) ?>">Log in</a></p>
    <?php endif; ?>
    </div>
</div>
</body>
</html>
