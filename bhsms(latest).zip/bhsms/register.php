<?php
/* Resident self-registration. Creates a PENDING account that a BHW/Nurse must verify. */
require __DIR__ . '/includes/init.php';

if (current_user()) {
    redirect(home_path());
}

const CIVIL_STATUS = ['Single', 'Married', 'Widowed', 'Separated', 'Live-in'];

$f = ['first_name' => '', 'middle_name' => '', 'last_name' => '', 'suffix' => '', 'sex' => '', 'birthdate' => '',
      'civil_status' => 'Single', 'contact_no' => '', 'email' => '', 'street_address' => '', 'purok' => '', 'username' => ''];
$errors = [];
$done = false;
$matched = false;

if (is_post()) {
    foreach (array_keys($f) as $k) { $f[$k] = input($k); }
    $password = (string)($_POST['password'] ?? '');
    $confirm = (string)($_POST['confirm_password'] ?? '');

    if (($_SESSION['registrations'] ?? 0) >= 3) {
        $errors[] = 'Too many registrations from this browser. Please visit the health center.';
    }
    if ($f['first_name'] === '' || $f['last_name'] === '') $errors[] = 'First and last name are required.';
    if (!in_array($f['sex'], ['Male', 'Female'], true)) $errors[] = 'Select your sex.';
    if (!valid_date($f['birthdate']) || $f['birthdate'] > today()) {
        $errors[] = 'Enter a valid birthdate.';
    } elseif (age_years($f['birthdate']) < 18) {
        $errors[] = 'You must be 18 or older to register. A parent can view a child\'s records from their own account.';
    }
    if (!in_array($f['civil_status'], CIVIL_STATUS, true)) $errors[] = 'Select your civil status.';
    if (!preg_match('/^(09\d{9}|\+639\d{9})$/', $f['contact_no'])) $errors[] = 'Enter a mobile number like 09171234567.';
    if ($f['email'] !== '' && !filter_var($f['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Email address is not valid.';
    if ($f['street_address'] === '' || $f['purok'] === '') $errors[] = 'Enter your street address and purok.';
    if (!preg_match('/^[a-zA-Z0-9_.]{4,50}$/', $f['username'])) $errors[] = 'Username must be 4–50 letters, numbers, dots or underscores.';
    if (strlen($password) < 8) $errors[] = 'Password must be at least 8 characters.';
    if ($password !== $confirm) $errors[] = 'Passwords do not match.';
    if (!isset($_POST['consent'])) $errors[] = 'Please agree to the data privacy consent.';

    if (!$errors && q('SELECT 1 FROM users WHERE username = ?', [$f['username']])->fetchColumn()) {
        $errors[] = 'That username is already taken. Choose another one.';
    }
    if (!$errors && $f['email'] !== '' && q('SELECT 1 FROM users WHERE email = ?', [$f['email']])->fetchColumn()) {
        $errors[] = 'That email is already used by another account.';
    }

    // Is this person already in the barangay health registry?
    $existing = null;
    if (!$errors) {
        $existing = q("SELECT r.resident_id, (SELECT COUNT(*) FROM users u WHERE u.resident_id = r.resident_id) AS accounts
                       FROM residents r WHERE r.first_name = ? AND r.last_name = ? AND r.birthdate = ?
                         AND r.status IN ('active', 'pending') ORDER BY r.resident_id LIMIT 1",
                      [$f['first_name'], $f['last_name'], $f['birthdate']])->fetch();
        if ($existing && (int)$existing['accounts'] > 0) {
            $errors[] = 'An account already exists for this person. If you forgot your password, please visit the health center.';
        }
    }

    if (!$errors) {
        db()->beginTransaction();
        try {
            if ($existing) {
                $residentId = (int)$existing['resident_id'];   // link to the existing record (staff will verify)
                $matched = true;
            } else {
                $residentId = db_insert('residents', [
                    'first_name' => $f['first_name'], 'middle_name' => nullable($f['middle_name']), 'last_name' => $f['last_name'],
                    'suffix' => nullable($f['suffix']), 'sex' => $f['sex'], 'birthdate' => $f['birthdate'],
                    'civil_status' => $f['civil_status'], 'contact_no' => $f['contact_no'],
                    'is_senior' => age_years($f['birthdate']) >= 60 ? 1 : 0, 'status' => 'pending',
                ]);
            }
            $userId = db_insert('users', [
                'username' => $f['username'], 'password_hash' => password_hash($password, PASSWORD_DEFAULT),
                'full_name' => $f['first_name'] . ' ' . $f['last_name'], 'email' => nullable($f['email']),
                'role' => 'resident', 'resident_id' => $residentId,
                'registered_address' => $f['street_address'] . ', ' . $f['purok'], 'status' => 'pending',
            ]);
            db()->commit();
        } catch (PDOException $e) {
            db()->rollBack();
            if (!is_duplicate_error($e)) throw $e;
            $errors[] = 'That username or email was just taken. Please try again.';
        }

        if (!$errors) {
            $_SESSION['registrations'] = ($_SESSION['registrations'] ?? 0) + 1;
            q('INSERT INTO activity_logs (user_id, action, table_name, record_id, details, ip_address) VALUES (?, ?, ?, ?, ?, ?)',
              [$userId, 'REGISTER', 'users', $userId, 'Resident registered online' . ($matched ? ' (matched existing record)' : ''), $_SERVER['REMOTE_ADDR'] ?? null]);
            notify_roles(['bhw', 'nurse'], 'New resident registration',
                $f['first_name'] . ' ' . $f['last_name'] . ' registered online and is waiting for verification.', 'modules/residents/registrations.php', false);
            $done = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Resident Registration | <?= e(BARANGAY_NAME) ?></title>
    <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
</head>
<body class="public">
<header class="pub-nav">
    <div class="pub-wrap">
        <a class="pub-brand" href="<?= e(url('index.php')) ?>"><span class="brand-logo">+</span>
            <span><strong><?= e(BARANGAY_NAME) ?></strong><small>Resident Health Portal</small></span></a>
        <nav><a href="<?= e(url('index.php')) ?>">Home</a><a class="btn" href="<?= e(url('index.php#login')) ?>">Log in</a></nav>
    </div>
</header>

<main class="pub-wrap" style="max-width:860px;padding:32px 20px 60px">
<?php if ($done): ?>
    <div class="card" style="text-align:center;padding:40px">
        <div class="brand-logo" style="margin:0 auto 14px;width:56px;height:56px;font-size:30px">&#10003;</div>
        <h2>Registration received!</h2>
        <p>Thank you, <?= e($f['first_name']) ?>. Your account <strong><?= e($f['username']) ?></strong> is now <strong>waiting for verification</strong>.</p>
        <p class="muted">A barangay health worker will check your details<?= $matched ? ' and link your account to your existing health records' : '' ?>.
            You may be asked to visit the health center with a valid ID. You can log in once your account is approved.</p>
        <a class="btn btn-primary" href="<?= e(url('index.php')) ?>">Back to homepage</a>
    </div>
<?php else: ?>
    <h1 style="margin:0 0 4px">Create a resident account</h1>
    <p class="muted" style="margin-top:0">For residents 18 years old and above. Use your real name and birthdate so we can match you with your barangay health records.</p>
    <?= render_errors($errors) ?>

    <form method="post" class="card" autocomplete="off">
        <?= csrf_field() ?>
        <fieldset>
            <legend>Personal information</legend>
            <div class="form-grid">
                <?= field('First name', 'first_name', $f['first_name'], 'text', 'required maxlength="80"') ?>
                <?= field('Middle name', 'middle_name', $f['middle_name'], 'text', 'maxlength="80"') ?>
                <?= field('Last name', 'last_name', $f['last_name'], 'text', 'required maxlength="80"') ?>
                <?= field('Suffix', 'suffix', $f['suffix'], 'text', 'maxlength="10" placeholder="Jr., III"') ?>
                <?= select_field('Sex', 'sex', ['Male', 'Female'], $f['sex'], 'required') ?>
                <?= field('Birthdate', 'birthdate', $f['birthdate'], 'date', 'required max="' . date('Y-m-d', strtotime('-18 years')) . '"') ?>
                <?= select_field('Civil status', 'civil_status', CIVIL_STATUS, $f['civil_status'], 'required', false) ?>
            </div>
        </fieldset>
        <fieldset>
            <legend>Address &amp; contact</legend>
            <div class="form-grid">
                <?= field('House no. / Street', 'street_address', $f['street_address'], 'text', 'required maxlength="200"', 'span-2') ?>
                <?= field('Purok / Zone', 'purok', $f['purok'], 'text', 'required maxlength="50" placeholder="Purok 1"') ?>
                <?= field('Mobile number', 'contact_no', $f['contact_no'], 'tel', 'required maxlength="13" placeholder="09XXXXXXXXX"') ?>
                <?= field('Email (optional)', 'email', $f['email'], 'email', 'maxlength="150"') ?>
            </div>
        </fieldset>
        <fieldset>
            <legend>Login details</legend>
            <div class="form-grid">
                <?= field('Username', 'username', $f['username'], 'text', 'required maxlength="50" pattern="[a-zA-Z0-9_.]{4,50}"') ?>
                <?= field('Password', 'password', '', 'password', 'required minlength="8" autocomplete="new-password"') ?>
                <?= field('Confirm password', 'confirm_password', '', 'password', 'required minlength="8" autocomplete="new-password"') ?>
            </div>
            <p class="hint">At least 8 characters. Don't share your password with anyone.</p>
        </fieldset>
        <label class="check" style="align-items:flex-start">
            <input type="checkbox" name="consent" value="1" required <?= isset($_POST['consent']) ? 'checked' : '' ?>>
            <span>I confirm the information above is true, and I agree that the barangay health center may collect and process my
                personal and health information for health services, in accordance with the Data Privacy Act of 2012 (RA 10173).</span>
        </label>
        <div class="form-actions">
            <a class="btn" href="<?= e(url('index.php')) ?>">Cancel</a>
            <button class="btn btn-primary" type="submit">Register</button>
        </div>
    </form>
<?php endif; ?>
</main>
</body>
</html>
