<?php
/*
 * Admin: register and manage STAFF accounts.
 * BHWs and Nurses normally register themselves (staff_register.php) and are approved in Staff Approvals.
 * The admin can also create a BHW or Nurse account directly here. Residents register themselves on the homepage
 * and are approved in Residents > Account Verification. Here the admin can still
 * deactivate a resident account or reset its password.
 */
require __DIR__ . '/../includes/init.php';
require_perm('users', 'edit');

// Roles the admin may create. Add 'mho' here if the admin should also register Municipal Health Officers.
const CREATABLE_ROLES = ['bhw', 'nurse'];

$id = (int)get('id');
$u = ['username' => '', 'full_name' => '', 'email' => '', 'contact_no' => '', 'id_number' => '', 'role' => in_array(get('role'), CREATABLE_ROLES, true) ? get('role') : 'bhw',
      'resident_id' => null, 'status' => 'active'];
if ($id) {
    $u = q('SELECT * FROM users WHERE user_id = ?', [$id])->fetch();
    if (!$u) {
        flash('danger', 'User not found.');
        redirect('admin/users.php');
    }
}
$isSelf = $id === user_id();
$isResident = $u['role'] === 'resident';
// Role can be changed only between BHW and Nurse
$roleEditable = !$isSelf && in_array($u['role'], CREATABLE_ROLES, true);
$roleChoices = [];
foreach ($roleEditable ? CREATABLE_ROLES : [$u['role']] as $r) {
    $roleChoices[$r] = ROLE_LABELS[$r];
}
$statusChoices = ['active' => 'Active', 'inactive' => 'Inactive (cannot log in)'];
if (in_array($u['status'], ['pending', 'rejected'], true)) {
    $statusChoices = [$u['status'] => ucfirst($u['status'])] + $statusChoices;
}
$linked = $u['resident_id'] ? q('SELECT * FROM residents WHERE resident_id = ?', [$u['resident_id']])->fetch() : null;
$errors = [];

if (is_post()) {
    foreach (['username', 'full_name', 'email', 'contact_no', 'id_number', 'status'] as $f) { $u[$f] = input($f); }
    if ($roleEditable) {
        $u['role'] = input('role');
    }
    if ($isSelf) {
        $u['status'] = 'active';                     // admins cannot lock themselves out
    }
    $password = (string)($_POST['password'] ?? '');
    $confirm = (string)($_POST['confirm_password'] ?? '');

    if (!preg_match('/^[a-zA-Z0-9_.]{4,50}$/', $u['username'])) $errors[] = 'Username must be 4–50 letters, numbers, dots or underscores.';
    if ($u['full_name'] === '') $errors[] = 'Full name is required.';
    if ($u['email'] !== '' && !filter_var($u['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Email address is not valid.';
    if ($u['contact_no'] !== '' && !preg_match('/^(09\d{9}|\+639\d{9})$/', $u['contact_no'])) $errors[] = 'Contact number must look like 09171234567.';
    if (!isset($roleChoices[$u['role']])) $errors[] = 'Select a role.';
    if (!isset($statusChoices[$u['status']])) $errors[] = 'Select a status.';
    if ($isResident && $u['status'] === 'active' && $linked && $linked['status'] === 'pending') {
        $errors[] = 'Approve this resident in Residents → Account Verification first.';
    }
    if (!$id || $password !== '') {
        if (strlen($password) < 8) $errors[] = 'Password must be at least 8 characters.';
        if ($password !== $confirm) $errors[] = 'Passwords do not match.';
    }

    if (!$errors) {
        $data = ['username' => $u['username'], 'full_name' => $u['full_name'], 'email' => nullable($u['email']),
                 'contact_no' => nullable($u['contact_no']), 'id_number' => nullable($u['id_number']),
                 'role' => $u['role'], 'status' => $u['status']];
        if ($password !== '') {
            $data['password_hash'] = password_hash($password, PASSWORD_DEFAULT);
        }
        try {
            if ($id) {
                db_update('users', $data, 'user_id', $id);
                log_activity('UPDATE', 'users', $id, 'Updated account ' . $data['username'] . ($password !== '' ? ' (password reset)' : ''));
            } else {
                $id = db_insert('users', $data);
                log_activity('CREATE', 'users', $id, 'Registered ' . ROLE_LABELS[$data['role']] . ' account ' . $data['username']);
            }
            flash('success', 'Account ' . $data['username'] . ' saved.');
            redirect('admin/users.php');
        } catch (PDOException $e) {
            if (!is_duplicate_error($e)) throw $e;
            $errors[] = 'That username or email is already taken.';
        }
    }
}

$page_title = $id ? 'Edit Account' : 'Register Staff Account';
require __DIR__ . '/../includes/header.php';
?>
<?= render_errors($errors) ?>
<?php if ($isResident): ?>
    <div class="alert alert-info">This is a resident portal account<?= $linked ? ' linked to <strong>' . e(full_name($linked)) . '</strong>' : '' ?>.
        Residents register themselves; you can only update the login details, deactivate the account or reset its password here.
        <?php if ($u['status'] === 'pending'): ?><a href="<?= e(url('modules/residents/registrations.php')) ?>">Verify it in Account Verification.</a><?php endif; ?></div>
<?php endif; ?>
<form method="post" class="card" autocomplete="off">
    <?= csrf_field() ?>
    <div class="form-grid">
        <?= select_field('Role', 'role', $roleChoices, $u['role'], 'required' . ($roleEditable ? '' : ' disabled'), false) ?>
        <?= field('Full name', 'full_name', $u['full_name'], 'text', 'required maxlength="150"' . ($isResident ? ' readonly' : '')) ?>
        <?= field('Username', 'username', $u['username'], 'text', 'required maxlength="50" pattern="[a-zA-Z0-9_.]{4,50}"') ?>
        <?= field('Email', 'email', $u['email'], 'email', 'maxlength="150"') ?>
        <?= field('Contact number', 'contact_no', $u['contact_no'], 'tel', 'maxlength="13" placeholder="09XXXXXXXXX"') ?>
        <?php if (!$isResident): ?><?= field('ID / PRC license no.', 'id_number', $u['id_number'], 'text', 'maxlength="50"') ?><?php endif; ?>
        <?= select_field('Status', 'status', $statusChoices, $u['status'], $isSelf ? 'disabled' : '', false) ?>
    </div>
    <fieldset style="margin-top:18px">
        <legend><?= $id ? 'Reset password (leave blank to keep the current one)' : 'Password' ?></legend>
        <div class="form-grid">
            <?= field('Password', 'password', '', 'password', ($id ? '' : 'required ') . 'minlength="8" autocomplete="new-password"') ?>
            <?= field('Confirm password', 'confirm_password', '', 'password', ($id ? '' : 'required ') . 'minlength="8" autocomplete="new-password"') ?>
        </div>
        <?php if (!$id): ?><p class="hint">Give the password to the staff member privately. They can change it in My Account after logging in.</p><?php endif; ?>
    </fieldset>
    <?php if ($isSelf): ?><p class="hint">You cannot change your own role or deactivate your own account.</p><?php endif; ?>
    <div class="form-actions">
        <a class="btn" href="users.php">Cancel</a>
        <button class="btn btn-primary"><?= $id ? 'Save account' : 'Register account' ?></button>
    </div>
</form>
<?php require __DIR__ . '/../includes/footer.php'; ?>
