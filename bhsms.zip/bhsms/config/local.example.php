<?php
/*
 * YOUR OWN database settings.
 * 1. Copy this file and name the copy  local.php  (same folder).
 * 2. Change the values to match YOUR XAMPP.
 * local.php is ignored by Git, so it is never pushed to GitHub.
 */
return [
    'db_host'  => '127.0.0.1',
    'db_port'  => '3306',      // check the MySQL "Port(s)" column in the XAMPP Control Panel (e.g. 3308)
    'db_name'  => 'bhsms',
    'db_user'  => 'root',
    'db_pass'  => '',          // XAMPP default is empty
    'base_url' => '/bhsms',    // the folder name inside htdocs
];
