/* =========================================================
   BHSMS — UI behaviour (plain JavaScript, no libraries)

   1. Small helpers (sidebar, confirm, print, tabs, popups)
   2. Back / Close button + Esc key
   3. Searchable dropdowns (search households by the head's name)
   4. Form helpers (EDD, show-when, attendance, check-all, supplement defaults, MUAC hint)
   5. 3D tilt on tiles and cards
   6. 3D magnifier lens ("telescope") that follows the cursor
   7. 3D page transitions
   ========================================================= */
(function () {
    'use strict';

    var doc = document, body = doc.body, root = doc.documentElement;
    var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    var store = {
        get: function (k, d) { try { var v = localStorage.getItem('bhsms.' + k); return v === null ? d : v; } catch (e) { return d; } },
        set: function (k, v) { try { localStorage.setItem('bhsms.' + k, v); } catch (e) { /* private mode */ } }
    };
    function $(sel, ctx) { return (ctx || doc).querySelector(sel); }
    function $$(sel, ctx) { return Array.prototype.slice.call((ctx || doc).querySelectorAll(sel)); }
    function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

    /* ---------- 1. Small helpers ---------- */
    $$('[data-toggle-sidebar]').forEach(function (btn) {
        btn.addEventListener('click', function () { var s = doc.getElementById('sidebar'); if (s) { s.classList.toggle('open'); } });
    });

    doc.addEventListener('click', function (e) {
        var a = e.target.closest('a[data-confirm]');
        if (a && !window.confirm(a.getAttribute('data-confirm'))) { e.preventDefault(); e.stopImmediatePropagation(); return; }
        if (e.target.closest('[data-print]')) { window.print(); }
        // clicking outside an open popup closes it
        $$('details.pop[open]').forEach(function (d) { if (!d.contains(e.target) && !d.closest('#lens')) { d.removeAttribute('open'); } });
    }, true);

    // Close (x) button inside every popup
    $$('details.pop .pop-body').forEach(function (b) {
        var x = doc.createElement('button');
        x.type = 'button'; x.className = 'pop-close'; x.innerHTML = '&times;'; x.setAttribute('aria-label', 'Close');
        x.addEventListener('click', function () { b.closest('details').removeAttribute('open'); });
        b.insertBefore(x, b.firstChild);
    });

    // Popups inside a scrolling table would be cut off: place them on screen instead
    function placePop(d) {
        var b = $('.pop-body', d), s = $('summary', d);
        if (!b || !s) { return; }
        if (!d.closest('.table-wrap')) { b.style.position = ''; return; }
        var r = s.getBoundingClientRect(), w = b.offsetWidth || 320, h = b.offsetHeight || 200;
        var left = clamp(r.right - w, 8, window.innerWidth - w - 8);
        var top = r.bottom + 6;
        if (top + h > window.innerHeight - 8 && r.top - h - 6 > 8) { top = r.top - h - 6; }
        b.style.position = 'fixed'; b.style.left = left + 'px'; b.style.top = top + 'px'; b.style.right = 'auto';
    }
    doc.addEventListener('toggle', function (e) {
        var d = e.target;
        if (d.closest && d.closest('#lens')) { return; }              // ignore the copy shown inside the magnifier
        if (d.matches && d.matches('details.pop') && d.open) {
            openPops().forEach(function (o) { if (o !== d) { o.removeAttribute('open'); } });
            placePop(d);
            var f = $('input:not([type=hidden]), select, textarea', d);
            if (f) { setTimeout(function () { f.focus(); }, 30); }
        }
    }, true);
    function openPops() { return $$('details.pop[open]').filter(function (d) { return !d.closest('#lens'); }); }
    window.addEventListener('scroll', function () { openPops().forEach(placePop); }, { passive: true });
    window.addEventListener('resize', function () { openPops().forEach(placePop); });
    doc.addEventListener('scroll', function (e) { if (e.target !== doc && e.target.classList && e.target.classList.contains('table-wrap')) { openPops().forEach(placePop); } }, true);

    // Tabs: <div class="tabs" data-tabs><button data-tab="x"> ... <div class="tab-panel" id="tab-x">
    $$('[data-tabs]').forEach(function (tabs) {
        var scope = tabs.parentElement;
        function show(name) {
            $$('[data-tab]', tabs).forEach(function (b) { b.classList.toggle('active', b.getAttribute('data-tab') === name); });
            Array.prototype.forEach.call(scope.children, function (p) {
                if (p.classList.contains('tab-panel')) { p.classList.toggle('active', p.id === 'tab-' + name); }
            });
        }
        tabs.addEventListener('click', function (e) {
            var b = e.target.closest('[data-tab]');
            if (!b) { return; }
            e.preventDefault();
            show(b.getAttribute('data-tab'));
            history.replaceState(null, '', '#' + b.getAttribute('data-tab'));
        });
        var hash = location.hash.replace('#', '');
        if (hash && tabs.querySelector('[data-tab="' + hash + '"]')) { show(hash); }
    });

    /* ---------- 2. Back / Close button + Esc ---------- */
    // Goes back in the browser history when you came from another page of the system
    // (so filters and scroll position are kept), otherwise to the parent page.
    function sameApp(url) {
        try { var u = new URL(url, location.href); return u.origin === location.origin; } catch (e) { return false; }
    }
    function goBack(btn) {
        var ref = doc.referrer, here = location.pathname;
        var refPath = ref && sameApp(ref) ? new URL(ref).pathname : '';
        // Never go "back" into a form we just saved; use the parent page instead.
        if (refPath && refPath !== here && !/form\.php$/.test(refPath) && history.length > 1) {
            leave(function () { history.back(); }, btn ? 'Back' : '');
        } else if (btn) {
            navigate(btn.href, 'Back');
        }
    }
    doc.addEventListener('click', function (e) {
        var b = e.target.closest('[data-back]');
        if (!b || e.ctrlKey || e.metaKey || e.shiftKey) { return; }
        e.preventDefault();
        e.stopImmediatePropagation();
        goBack(b);
    }, true);

    doc.addEventListener('keydown', function (e) {
        if (e.key !== 'Escape') { return; }
        var openCombo = $$('.combo.open').filter(function (c) { return !c.closest('#lens'); })[0];
        if (openCombo) { return; }                       // the dropdown handles its own Esc
        var pop = $$('details.pop[open]').filter(function (d) { return !d.closest('#lens'); })[0];
        if (pop) { pop.removeAttribute('open'); return; }
        var side = doc.getElementById('sidebar');
        if (side && side.classList.contains('open')) { side.classList.remove('open'); return; }
        var t = e.target;
        if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) { t.blur(); return; }
        var close = $$('.btn-close, [data-back]').filter(function (c) { return !c.closest('#lens'); })[0];
        if (close) { close.click(); }
    });

    /* ---------- 3. Searchable dropdowns ---------- */
    // <select class="searchable"> becomes a type-to-search box with a result list.
    // The real <select> stays in the form (hidden), so saving works exactly as before.
    function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
    function highlight(text, terms) {
        var out = esc(text);
        terms.forEach(function (t) {
            if (!t) { return; }
            out = out.replace(new RegExp('(' + t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'ig'), '<mark>$1</mark>');
        });
        return out;
    }
    $$('select.searchable').forEach(function (sel) {
        var wrap = doc.createElement('div');
        wrap.className = 'combo';
        sel.parentNode.insertBefore(wrap, sel);
        var input = doc.createElement('input');
        input.type = 'text';
        input.className = 'combo-input';
        input.autocomplete = 'off';
        input.placeholder = sel.getAttribute('data-placeholder') || 'Type to search...';
        input.setAttribute('role', 'combobox');
        input.setAttribute('aria-expanded', 'false');
        if (sel.disabled) { input.disabled = true; }
        var list = doc.createElement('div');
        list.className = 'combo-list';
        list.setAttribute('role', 'listbox');
        wrap.appendChild(input);
        wrap.appendChild(list);
        wrap.appendChild(sel);
        sel.tabIndex = -1;

        var active = -1, shown = [];
        function labelOf(o) { return o.value ? o.text : ''; }
        function sync() {
            var o = sel.options[sel.selectedIndex];
            input.value = o && o.value ? labelOf(o) : '';
            input.classList.toggle('has-value', !!(o && o.value));
        }
        function render() {
            var q = input.value.trim().toLowerCase();
            var current = sel.options[sel.selectedIndex];
            if (current && current.value && input.value === labelOf(current)) { q = ''; }   // show everything when reopening
            var terms = q.split(/\s+/).filter(Boolean);
            shown = Array.prototype.filter.call(sel.options, function (o) {
                if (o.disabled) { return false; }
                if (!terms.length) { return true; }
                var t = o.text.toLowerCase();
                return o.value !== '' && terms.every(function (w) { return t.indexOf(w) !== -1; });
            }).slice(0, 80);
            list.innerHTML = shown.length ? shown.map(function (o, i) {
                // Split "HH-0001 — Head: Dela Cruz, Juan — 12 Pine St." into a title and a detail line
                var parts = o.text.split(' — ');
                var title = parts.shift(), rest = parts.join(' — ');
                return '<div class="combo-item' + (o.selected && o.value ? ' chosen' : '') + '" role="option" data-i="' + i + '">'
                    + highlight(title, terms) + (rest ? '<small>' + highlight(rest, terms) + '</small>' : '') + '</div>';
            }).join('') : '<div class="combo-empty">No match. Try the household head\'s last name or the household no.</div>';
            active = shown.length ? 0 : -1;
            paint();
        }
        function paint() {
            $$('.combo-item', list).forEach(function (el, i) { el.classList.toggle('active', i === active); });
            var a = list.children[active];
            if (a && a.scrollIntoView) { a.scrollIntoView({ block: 'nearest' }); }
        }
        function open() { if (input.disabled) { return; } wrap.classList.add('open'); input.setAttribute('aria-expanded', 'true'); render(); }
        function close() { wrap.classList.remove('open'); input.setAttribute('aria-expanded', 'false'); sync(); }
        function choose(i) {
            var o = shown[i];
            if (!o) { return; }
            sel.value = o.value;
            sel.dispatchEvent(new Event('change', { bubbles: true }));
            close();
        }
        input.addEventListener('focus', function () { input.select(); open(); });
        input.addEventListener('input', function () { wrap.classList.add('open'); render(); });
        input.addEventListener('keydown', function (e) {
            if (e.key === 'ArrowDown') { e.preventDefault(); if (!wrap.classList.contains('open')) { open(); } active = Math.min(shown.length - 1, active + 1); paint(); }
            else if (e.key === 'ArrowUp') { e.preventDefault(); active = Math.max(0, active - 1); paint(); }
            else if (e.key === 'Enter') { if (wrap.classList.contains('open')) { e.preventDefault(); choose(active); } }
            else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); input.blur(); }
            else if (e.key === 'Tab') { close(); }
        });
        input.addEventListener('blur', function () {
            setTimeout(function () {
                if (input.value.trim() === '' && sel.value !== '' && sel.querySelector('option[value=""]')) {   // cleared the box = no selection
                    sel.value = ''; sel.dispatchEvent(new Event('change', { bubbles: true }));
                }
                close();
            }, 160);
        });
        list.addEventListener('mousedown', function (e) {
            var it = e.target.closest('.combo-item');
            if (it) { e.preventDefault(); choose(+it.getAttribute('data-i')); }
        });
        sel.addEventListener('change', sync);
        sel.addEventListener('invalid', function () { input.focus(); });
        sync();

        // Household preview: head of the family, address and members of the chosen household
        var prevSel = sel.getAttribute('data-preview'), infoSel = sel.getAttribute('data-info');
        if (prevSel && infoSel && $(prevSel) && $(infoSel)) {
            var info = {};
            try { info = JSON.parse($(infoSel).textContent); } catch (e) { /* ignore */ }
            var box = $(prevSel);
            var show = function () {
                var h = info[sel.value];
                if (!h) { box.innerHTML = ''; return; }
                box.innerHTML = '<div class="head">' + esc(h.no) + ' &middot; ' + (h.head ? 'Head: ' + esc(h.head) : 'No household head set yet') + '</div>'
                    + '<div class="muted">' + esc(h.address) + '</div>'
                    + (h.members.length ? '<ul>' + h.members.map(function (m) { return '<li>' + esc(m) + '</li>'; }).join('') + '</ul>' : '<div class="small muted">No members yet.</div>');
                var rel = doc.querySelector('select[name="relationship_to_head"]');
                if (rel && !rel.value && !h.head) { rel.value = 'Head'; }
            };
            sel.addEventListener('change', show);
            show();
        }
    });

    /* ---------- 4. Form helpers ---------- */
    // Pregnancy form: EDD = LMP + 280 days (Naegele's rule)
    var lmp = $('input[name="lmp"]'), edd = $('input[name="edd"]');
    if (lmp && edd) {
        lmp.addEventListener('change', function () {
            if (!lmp.value) { return; }
            var d = new Date(lmp.value + 'T00:00:00');
            d.setDate(d.getDate() + 280);
            var p = function (n) { return String(n).padStart(2, '0'); };
            edd.value = d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
        });
    }

    // Show/hide blocks based on a select value: <div data-show-when="role=resident">
    $$('[data-show-when]').forEach(function (block) {
        var parts = block.getAttribute('data-show-when').split('=');
        var ctrl = $('[name="' + parts[0] + '"]');
        if (!ctrl) { return; }
        var values = parts[1].split('|');
        var shownDisplay = block.style.display === 'none' ? '' : block.style.display;
        function update() { block.style.display = values.indexOf(ctrl.value) !== -1 ? shownDisplay : 'none'; }
        ctrl.addEventListener('change', update);
        update();
    });

    // Attendance: mark everyone without a record as Present (08:00)
    $$('[data-fill-attendance]').forEach(function (b) {
        b.addEventListener('click', function () {
            var form = b.closest('form'), val = b.getAttribute('data-fill-attendance');
            $$('select[name^="status["]', form).forEach(function (s) {
                if (!s.value) {
                    s.value = val;
                    var t = form.querySelector('input[name="time_in[' + s.name.match(/\[(\d+)\]/)[1] + ']"]');
                    if (t && !t.value) { t.value = '08:00'; }
                }
            });
        });
    });

    // "All present" checkbox
    $$('[data-check-all]').forEach(function (all) {
        var name = all.getAttribute('data-check-all');
        all.addEventListener('change', function () {
            $$('input[name="' + name + '"]', all.closest('form')).forEach(function (c) { c.checked = all.checked; });
        });
    });

    // Supplement form: fill in the usual dose when the supplement changes
    $$('select[data-defaults]').forEach(function (s) {
        var defs = {};
        try { defs = JSON.parse(s.getAttribute('data-defaults')); } catch (e) { return; }
        var dose = s.form && s.form.querySelector('input[name="dose"]');
        s.addEventListener('change', function () { if (dose && defs[s.value]) { dose.value = defs[s.value][0] || ''; } });
    });

    // OPT form: live MUAC interpretation
    var muac = $('input[data-muac]'), muacHint = doc.getElementById('muac-hint');
    if (muac && muacHint) {
        var base = muacHint.innerHTML;
        muac.addEventListener('input', function () {
            var v = parseFloat(muac.value);
            if (isNaN(v)) { muacHint.innerHTML = base; return; }
            var r = v < 11.5 ? ['text-danger', 'Severe acute malnutrition (SAM) — refer'] : v < 12.5 ? ['text-danger', 'Moderate acute malnutrition (MAM)'] : ['text-success', 'Normal MUAC'];
            muacHint.innerHTML = '<strong class="' + r[0] + '">MUAC ' + v.toFixed(1) + ' cm: ' + r[1] + '</strong> (for children 6–59 months). ' + base;
        });
    }

    // Stagger index for entrance animations
    $$('.content > *').forEach(function (el, i) { el.style.setProperty('--i', Math.min(i, 5)); });

    /* ---------- 5. 3D tilt ---------- */
    if (finePointer && !reduceMotion) {
        $$('.stat, .tilt, .program-card, .feature, .step').forEach(function (el) {
            var glare = doc.createElement('span');
            glare.className = 'tilt-glare';
            el.appendChild(glare);
            var raf = 0;
            el.addEventListener('pointermove', function (e) {
                var r = el.getBoundingClientRect(), x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
                cancelAnimationFrame(raf);
                raf = requestAnimationFrame(function () {
                    el.classList.add('tilting');
                    el.style.transform = 'perspective(800px) rotateX(' + ((0.5 - y) * 12).toFixed(2) + 'deg) rotateY(' + ((x - 0.5) * 14).toFixed(2) + 'deg) translateZ(14px)';
                    el.style.setProperty('--gx', (x * 100).toFixed(1) + '%');
                    el.style.setProperty('--gy', (y * 100).toFixed(1) + '%');
                });
            });
            el.addEventListener('pointerleave', function () { cancelAnimationFrame(raf); el.classList.remove('tilting'); el.style.transform = ''; });
        });
    }

    /* ---------- 6. Magnifier lens (the view through a magnifying glass) ---------- */
    var lens = doc.getElementById('lens');
    var lensOn = store.get('lens', reduceMotion ? 'off' : 'on') === 'on';
    var toggle = $('[data-lens-toggle]');
    var Lens = null;

    function buildLens() {
        var stage = $('.lens-stage', lens);
        var zoom = parseFloat(store.get('zoom', '1.8')) || 1.8;
        var size = 120, r = size / 2;
        var mx = -999, my = -999, lx = -999, ly = -999, lastSx = -1, lastSy = -1;
        var visible = false, hide = false, dirty = true, cloneDoc = null, fixedPairs = [], scrollPairs = [], running = false;

        function setZoom(z) { zoom = clamp(Math.round(z * 10) / 10, 1.3, 3); store.set('zoom', zoom); lastSx = -1; start(); }

        // Static copy of the page, shown magnified inside the lens
        function rebuild() {
            dirty = false;
            var wrap = doc.createElement('div');
            wrap.className = 'lens-doc';
            wrap.style.width = root.clientWidth + 'px';
            fixedPairs = []; scrollPairs = [];
            Array.prototype.forEach.call(body.children, function (el) {
                if (el === lens || el.id === 'warp' || el.tagName === 'SCRIPT' || el.classList.contains('fx-backdrop')) { return; }
                var c = el.cloneNode(true);
                wrap.appendChild(c);
                pairUp(el, c);
            });
            $$('[id]', wrap).forEach(function (n) { n.removeAttribute('id'); });
            $$('[name]', wrap).forEach(function (n) { n.removeAttribute('name'); });
            $$('script', wrap).forEach(function (n) { n.remove(); });
            stage.innerHTML = '';
            stage.appendChild(wrap);
            cloneDoc = wrap;
            var wr = wrap.getBoundingClientRect(), sc = (wr.width / wrap.offsetWidth) || 1;
            fixedPairs.forEach(function (p) {
                p.pos = getComputedStyle(p[0]).position;
                if (p.pos === 'fixed') {
                    p[1].style.cssText += ';position:absolute;margin:0;transform:none;z-index:40;width:' + p[0].offsetWidth + 'px;height:' + p[0].offsetHeight + 'px';
                } else {
                    p[1].style.cssText += ';position:relative;top:0;z-index:30';
                    p.natural = (p[1].getBoundingClientRect().top - wr.top) / sc;
                }
            });
            scrollPairs.forEach(function (p) { p[1].scrollTop = p[0].scrollTop; p[1].scrollLeft = p[0].scrollLeft; });
            lastSx = -1;
        }
        function pairUp(orig, copy) {
            var o = [orig].concat($$('*', orig)), c = [copy].concat($$('*', copy));
            for (var i = 0; i < o.length && i < c.length; i++) {
                var oe = o[i], ce = c[i], tag = oe.tagName;
                if (oe.hasAttribute('data-lens-fixed')) { fixedPairs.push([oe, ce]); }
                if (tag === 'INPUT') {
                    if (oe.type === 'checkbox' || oe.type === 'radio') { ce.checked = oe.checked; } else { ce.setAttribute('value', oe.value); }
                } else if (tag === 'TEXTAREA') { ce.textContent = oe.value; }
                else if (tag === 'SELECT') { ce.selectedIndex = oe.selectedIndex; }
                else if (tag === 'CANVAS') { try { ce.getContext('2d').drawImage(oe, 0, 0); } catch (e) { /* ignore */ } }
                if ((oe.classList.contains('table-wrap') || oe.tagName === 'NAV') && (oe.scrollTop || oe.scrollLeft)) { scrollPairs.push([oe, ce]); }
            }
        }

        // Rebuild the copy only after the page has been quiet for a moment
        var rebuildTimer = 0;
        function scheduleRebuild() {
            dirty = true;
            clearTimeout(rebuildTimer);
            rebuildTimer = setTimeout(function () { if (visible && lensOn) { rebuild(); lastSx = -1; start(); } }, 450);
        }
        new MutationObserver(function (recs) {
            for (var i = 0; i < recs.length; i++) {
                var t = recs[i].target;
                if (t !== body && !lens.contains(t)) { scheduleRebuild(); return; }
            }
        }).observe(body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['class', 'open', 'hidden'] });
        doc.addEventListener('change', scheduleRebuild, true);
        doc.addEventListener('input', scheduleRebuild, true);
        window.addEventListener('resize', scheduleRebuild);
        doc.addEventListener('scroll', function (e) { if (e.target !== doc) { scheduleRebuild(); } else { start(); } }, true);

        function isTyping(t) { return t && t.closest && t.closest('input, textarea, select, .combo-list, [contenteditable="true"], .pop-body'); }
        function onMove(e) {
            if (e.pointerType && e.pointerType !== 'mouse') { return; }
            mx = e.clientX; my = e.clientY;
            if (lx < -900) { lx = mx; ly = my; }
            hide = !!isTyping(e.target);
            visible = true;
            if (!lensOn) { return; }
            if (dirty || !cloneDoc) { rebuild(); }
            start();
        }

        function frame() {
            running = false;
            if (!visible || !lensOn) { lens.classList.remove('on'); return; }
            lx += (mx - lx) * 0.45;              // quick, smooth follow
            ly += (my - ly) * 0.45;
            var sx = window.scrollX, sy = window.scrollY;
            lens.style.transform = 'translate3d(' + (lx - r).toFixed(1) + 'px,' + (ly - r).toFixed(1) + 'px,0)';
            if (cloneDoc) {
                stage.style.transform = 'translate3d(' + (r - (lx + sx) * zoom).toFixed(1) + 'px,' + (r - (ly + sy) * zoom).toFixed(1) + 'px,0) scale(' + zoom + ')';
                if (sx !== lastSx || sy !== lastSy) {      // only re-place the sidebar / top bar copies after scrolling
                    lastSx = sx; lastSy = sy;
                    fixedPairs.forEach(function (p) {
                        var r0 = p[0].getBoundingClientRect();
                        if (p.pos === 'fixed') { p[1].style.left = (r0.left + sx) + 'px'; p[1].style.top = (r0.top + sy) + 'px'; }
                        else { p[1].style.top = (r0.top + sy - (p.natural || 0)) + 'px'; }
                    });
                }
            }
            var off = hide || body.classList.contains('leaving');
            lens.classList.toggle('on', !off);
            lens.classList.toggle('shy', off);
            // keep animating only while the lens is still catching up with the mouse
            if (Math.abs(mx - lx) > 0.3 || Math.abs(my - ly) > 0.3) { start(); }
        }
        function start() { if (!running) { running = true; requestAnimationFrame(frame); } }

        doc.addEventListener('pointermove', onMove, { passive: true });
        root.addEventListener('mouseleave', function () { visible = false; lens.classList.remove('on'); });
        window.addEventListener('blur', function () { visible = false; lens.classList.remove('on'); });
        // Zoom: Alt + mouse wheel, or the [ and ] keys
        window.addEventListener('wheel', function (e) {
            if (!e.altKey || !lensOn) { return; }
            e.preventDefault();
            setZoom(zoom + (e.deltaY < 0 ? 0.1 : -0.1));
        }, { passive: false });
        doc.addEventListener('keydown', function (e) {
            if (isTyping(e.target) || e.ctrlKey || e.metaKey || e.altKey) { return; }
            if (e.key === ']') { setZoom(zoom + 0.1); }
            if (e.key === '[') { setZoom(zoom - 0.1); }
        });
        return {};
    }

    function setLens(on) {
        lensOn = on;
        store.set('lens', on ? 'on' : 'off');
        if (toggle) { toggle.setAttribute('aria-pressed', on ? 'true' : 'false'); }
        if (lens && !on) { lens.classList.remove('on'); }
        if (on && !Lens && lens) { Lens = buildLens(); }
    }
    if (lens && finePointer) {
        if (toggle) { toggle.addEventListener('click', function () { setLens(!lensOn); }); }
        doc.addEventListener('keydown', function (e) {
            var t = e.target;
            if ((e.key === 'l' || e.key === 'L') && !e.ctrlKey && !e.metaKey && !e.altKey && !(t && t.closest && t.closest('input, textarea, select, [contenteditable="true"]'))) {
                setLens(!lensOn);
            }
        });
        setLens(lensOn);
    } else if (toggle) {
        toggle.style.display = 'none';
    }

    /* ---------- 7. 3D page transitions ---------- */
    var warp = doc.getElementById('warp');
    var warpTitle = warp ? $('.warp-title span', warp) : null;
    var leavingNow = false;

    function leave(go, title) {
        if (reduceMotion) { go(); return; }
        if (leavingNow) { return; }
        leavingNow = true;
        body.classList.remove('entering');
        body.classList.add('leaving');
        setTimeout(go, 150);
        setTimeout(function () { body.classList.remove('leaving'); leavingNow = false; }, 4000);  // safety for downloads / slow pages
    }
    function navigate(href, title) { leave(function () { location.href = href; }, title); }

    doc.addEventListener('click', function (e) {
        if (e.defaultPrevented || e.button !== 0 || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) { return; }
        var a = e.target.closest('a[href]');
        if (!a || a.target === '_blank' || a.hasAttribute('download') || a.hasAttribute('data-no-warp')) { return; }
        var href = a.getAttribute('href');
        if (!href || href.charAt(0) === '#' || /^(javascript|mailto|tel):/i.test(href) || /export=/.test(href)) { return; }
        var url;
        try { url = new URL(a.href); } catch (err) { return; }
        if (url.origin !== location.origin) { return; }
        if (url.pathname === location.pathname && url.search === location.search && url.hash) { return; }   // same page anchor
        e.preventDefault();
        var label = a.getAttribute('data-title') || (a.querySelector('.nav-label') || a).textContent;
        navigate(a.href, label.replace(/\s+/g, ' '));
    });

    // Confirm prompts on forms, then a short exit animation when the form really submits
    doc.addEventListener('submit', function (e) {
        var f = e.target, msg = f.getAttribute('data-confirm');
        if (msg && !window.confirm(msg)) { e.preventDefault(); return; }
        if (e.defaultPrevented || reduceMotion || f.method.toLowerCase() === 'get' && /export/.test(f.action)) { return; }
        if (f.__warped) { return; }
        e.preventDefault();
        f.__warped = true;
        var submitter = e.submitter;
        leave(function () {
            // keep the clicked button's name/value (e.g. "Save & add another")
            if (submitter && submitter.name) {
                var h = doc.createElement('input');
                h.type = 'hidden'; h.name = submitter.name; h.value = submitter.value;
                f.appendChild(h);
            }
            HTMLFormElement.prototype.submit.call(f);
        }, '');
    });

    // Enter animation. <body class="entering"> is in the HTML so content never flashes before animating;
    // <html class="warp-in"> is set in <head> when we arrived through a warp.
    function finishEnter(delay) {
        setTimeout(function () {
            body.classList.remove('entering');
            root.classList.remove('warp-in');
            try { sessionStorage.removeItem('bhsms.warp'); } catch (e) { /* ignore */ }
        }, delay);
    }
    finishEnter(reduceMotion ? 0 : 600);
    window.addEventListener('pageshow', function (e) {
        if (!e.persisted) { return; }                   // restored from the back/forward cache
        body.classList.remove('leaving');
        leavingNow = false;
        $$('form').forEach(function (f) { f.__warped = false; });
        body.classList.add('entering');
        finishEnter(600);
    });
})();
