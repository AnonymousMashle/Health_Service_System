<?php
require __DIR__ . '/includes/init.php';

// Residents go back to the resident homepage, staff to the staff login
$target = user_role() === 'resident' ? 'index.php' : 'login.php';

if (current_user()) {
    log_activity('LOGOUT', 'users', user_id(), 'Logged out');
}
$_SESSION = [];
session_destroy();

session_start();
flash('success', 'You have been logged out.');
redirect($target);
