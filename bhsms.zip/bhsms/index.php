<?php
/* RESIDENT HOMEPAGE: public landing page with resident login. Staff use login.php. */
require __DIR__ . '/includes/init.php';

if (current_user()) {
    redirect(home_path());
}

$error = '';
$username = '';
if (is_post()) {
    $username = input('username');
    $error = attempt_login($username, (string)($_POST['password'] ?? ''), ['resident'],
        'This login is for residents. Health center staff, please use the staff login.');
    if ($error === null) {
        redirect('portal/index.php');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e(BARANGAY_NAME) ?> | Resident Health Portal</title>
    <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
    <?php require __DIR__ . '/includes/head_fx.php'; ?>
</head>
<body class="public entering">
<div class="fx-backdrop" aria-hidden="true"><span></span><span></span><span></span></div>

<header class="pub-nav" data-lens-fixed>
    <div class="pub-wrap">
        <a class="pub-brand" href="<?= e(url('index.php')) ?>"><span class="brand-logo">+</span>
            <span><strong><?= e(BARANGAY_NAME) ?></strong><small>Resident Health Portal</small></span></a>
        <nav>
            <a href="#services">Services</a>
            <a href="#how">How to register</a>
            <a href="#hours">Clinic hours</a>
            <a class="btn btn-primary" href="<?= e(url('register.php')) ?>">Register</a>
        </nav>
    </div>
</header>

<section class="pub-hero">
    <div class="pub-wrap hero-grid">
        <div>
            <h1>Your family's health records, <span>online.</span></h1>
            <p class="lead">View your consultations, vaccination cards and your children's check-ups, and request an appointment
                at the barangay health center without lining up.</p>
            <div class="btn-group">
                <a class="btn btn-primary btn-lg" href="<?= e(url('register.php')) ?>">Create a resident account</a>
                <a class="btn btn-lg btn-ghost" href="#how">How it works</a>
            </div>
        </div>

        <div class="login-card hero-login" id="login">
            <h2>Resident login</h2>
            <?= render_flash() ?>
            <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
            <form method="post" action="<?= e(url('index.php')) ?>#login" autocomplete="off">
                <?= csrf_field() ?>
                <?= field('Username', 'username', $username, 'text', 'required') ?>
                <?= field('Password', 'password', '', 'password', 'required') ?>
                <button class="btn btn-primary" type="submit">Log in</button>
            </form>
            <p class="small" style="text-align:center;margin:14px 0 0">No account yet? <a href="<?= e(url('register.php')) ?>">Register here</a></p>
            <?php if (DEMO_MODE): ?>
                <div class="demo-box">Sample resident: <code>res_juan</code> / <code>password123</code><br>
                    Waiting for verification: <code>res_grace</code>, <code>res_mark</code></div>
            <?php endif; ?>
        </div>
    </div>
</section>

<section class="pub-section" id="services">
    <div class="pub-wrap">
        <h2 class="section-title">What you can do online</h2>
        <div class="feature-grid">
            <div class="feature"><div class="feature-icon">&#128203;</div><h3>View health records</h3><p>See your consultation history, diagnoses, treatment advice and medicines received.</p></div>
            <div class="feature"><div class="feature-icon">&#128137;</div><h3>Vaccination card</h3><p>Check which vaccines are complete and when the next dose is due, for you and your children.</p></div>
            <div class="feature"><div class="feature-icon">&#128197;</div><h3>Request appointments</h3><p>Book a consultation, prenatal check-up, vaccination or medicine refill, and get notified once approved.</p></div>
            <div class="feature"><div class="feature-icon">&#128118;</div><h3>Mother &amp; child care</h3><p>Follow prenatal visits and your child's growth monitoring and check-up schedules.</p></div>
        </div>
        <h2 class="section-title" style="margin-top:40px">Services at the health center</h2>
        <div class="service-list">
            <span>General consultation</span><span>Immunization</span><span>Prenatal &amp; postnatal care</span>
            <span>Child growth monitoring</span><span>Family planning</span><span>Free medicines (when available)</span>
            <span>Blood pressure monitoring</span><span>Referral to hospitals</span>
        </div>
    </div>
</section>

<section class="pub-section alt" id="how">
    <div class="pub-wrap">
        <h2 class="section-title">How to register</h2>
        <div class="steps">
            <div class="step"><span>1</span><h3>Sign up online</h3><p>Fill in your name, birthdate, address and contact number, then choose a username and password.</p></div>
            <div class="step"><span>2</span><h3>Wait for verification</h3><p>A barangay health worker checks your details against the barangay records. You may be asked to show a valid ID at the health center.</p></div>
            <div class="step"><span>3</span><h3>Log in</h3><p>Once approved, log in here to see your records and your children's (under 18) records.</p></div>
        </div>
        <p class="muted small" style="margin-top:18px">Only residents 18 years old and above can register. Parents can view their children's records from their own account.</p>
    </div>
</section>

<section class="pub-section" id="hours">
    <div class="pub-wrap hours-grid">
        <div>
            <h2 class="section-title">Clinic hours</h2>
            <table class="table hours">
                <tr><td>Monday – Friday</td><td>8:00 AM – 5:00 PM</td></tr>
                <tr><td>Immunization day</td><td>Wednesday, 8:00 AM – 12:00 NN</td></tr>
                <tr><td>Prenatal day</td><td>Tuesday &amp; Thursday</td></tr>
                <tr><td>Saturday, Sunday &amp; holidays</td><td>Closed (emergencies: go to the nearest hospital)</td></tr>
            </table>
        </div>
        <div>
            <h2 class="section-title">Your data is protected</h2>
            <p>Your health information is confidential and handled in line with the <strong>Data Privacy Act of 2012 (RA 10173)</strong>.
                Only authorized health center staff can see your records, and you can only see your own and your minor children's records.</p>
        </div>
    </div>
</section>

<footer class="pub-footer">
    <div class="pub-wrap">
        <span>&copy; <?= date('Y') ?> <?= e(APP_FULL_NAME) ?></span>
        <a href="<?= e(url('login.php')) ?>">Health center staff login</a>
    </div>
</footer>
<?php require __DIR__ . '/includes/fx.php'; ?>
<script src="<?= e(url('assets/js/app.js')) ?>"></script>
</body>
</html>
