# BHSMS — Barangay Health Services and Community Health Monitoring System

PHP + MySQL web system for XAMPP. No frameworks, no Composer. Plain PHP (PDO), HTML, CSS and JavaScript.

## Setup (XAMPP)

1. Copy the `bhsms` folder into `C:\xampp\htdocs\` → `C:\xampp\htdocs\bhsms`
2. Start **Apache** and **MySQL** in the XAMPP Control Panel.
3. Open http://localhost/phpmyadmin → **Import** → choose `database/bhsms.sql` → **Go**.
   (Warning: this drops and recreates the `bhsms` database.)
4. Open http://localhost/bhsms (resident homepage) or http://localhost/bhsms/login.php (staff login)

**Your own settings:** copy `config/local.example.php` to `config/local.php` and set your MySQL port (e.g. 3308),
password and folder name there. `local.php` is ignored by Git, so each groupmate keeps their own settings.

**Already imported the database before?** Instead of re-importing everything, import the update files in order
(they keep your data): `database/update_01_registration.sql`, then `database/update_02_staff_registration.sql`,
then **`database/update_03_hr_nutrition.sql`** (new: Human Resource + Nutrition Action Officer).

## Sample accounts (password: `password123`)

| Username | Role |
|---|---|
| admin | System Administrator |
| bhw_maria | Barangay Health Worker |
| nurse_ana | Health Center Nurse |
| mho_reyes | Municipal Health Officer |
| hr_luz | Human Resource Officer |
| nao_ben | Nutrition Action Officer |
| res_juan | Resident (Juan Dela Cruz) |
| res_liza | Resident (Liza Santos, pregnant) |
| res_grace, res_mark | Residents who registered online, waiting for verification (cannot log in yet) |
| bhw_jose, nurse_carla | Staff who registered online, waiting for the admin's approval (cannot log in yet) |

Set `DEMO_MODE` to `false` in `config/db.php` to hide these on the login page.

## Folder structure

```
bhsms/
├── config/db.php            Database settings, db() and q() helpers
├── includes/
│   ├── init.php             Loaded by every page (session, helpers, auth)
│   ├── auth.php             Roles + PERMISSIONS table (who can do what)
│   ├── functions.php        Helpers: e(), flash, forms, pagination, logging, notifications
│   ├── header.php/footer.php  Layout and sidebar menu
│   └── partials/resident_records.php   Health record tabs (staff page + portal)
├── assets/css/style.css, assets/js/app.js
├── modules/
│   ├── residents/       1. Resident & household registration, health profile, emergency contacts
│   ├── consultations/   2. Consultation registration, vitals, assessment, history
│   ├── vaccinations/    3. Vaccination records, due/overdue list, vaccine list
│   ├── maternal/        4. Pregnancies, prenatal visits, child growth monitoring, scheduled visits
│   ├── inventory/       5. Medicines, stock-in, distribution (stock-out), adjustments, low stock
│   ├── appointments/    6. Approve/reject requests, schedules, booking
│   ├── reports/         7. Analytics with charts + CSV export
│   ├── hr/              8. Human Resource: personnel 201 files, attendance, leave, trainings, My Leave
│   └── nutrition/       9. Nutrition Action Officer: OPT+ masterlist, measurements, feeding programs, micronutrients
├── portal/              Resident portal: own/children's records, appointment requests
├── admin/               User accounts, activity logs
├── dashboard.php, login.php, logout.php, profile.php, notifications.php
└── database/bhsms.sql
```

## Roles

| Module | Admin | BHW | Nurse | MHO | Resident |
|---|---|---|---|---|---|
| Residents | Edit | Edit | Edit | View | Own record (portal) |
| Consultations | View | Intake (no assessment) | Full + assessment + delete | View | Own history |
| Vaccinations | View + manage vaccine list | Record | Record + manage | View | Own + children |
| Maternal & child | View | Record | Record | View | Own + children |
| Inventory | Stock-in, edit | Dispense | Everything | View | — |
| Appointments | View | Approve/reject | Approve/reject | — | Request/cancel |
| Reports | Yes | Yes | Yes | Yes | — |
| Users & logs | Yes | — | — | — | — |
| Human Resource | Edit + approve leave | My Leave only | My Leave only | View | — |
| Nutrition | View | Record | Record + manage programs | View | — |

The **HR Officer** (`hr`) manages personnel, attendance, leave and trainings but cannot open residents' health records (Data Privacy Act).
The **Nutrition Action Officer** (`nao`) can view residents and fully manage the Nutrition module (OPT+, feeding programs, micronutrients).

Change access in one place: `PERMISSIONS` in `includes/auth.php`.

## Main features

- **Security:** password_hash/password_verify, PDO prepared statements everywhere, CSRF token on every form,
  output escaping with `e()`, session regeneration on login, 30-minute idle logout, login lockout after 5 failed attempts,
  role check on every page, `.htaccess` blocks web access to `config/`, `includes/` and `database/`.
- **Inventory:** stock is dispensed from the batch that expires first (FEFO) inside a transaction. Expired batches are never dispensed.
  Low-stock and out-of-stock alerts go to nurses and the admin.
- **Automation:** next vaccination date is calculated from the vaccine interval, EDD from the LMP (+280 days),
  AOG weeks, senior citizen flag (60+), household numbers (HH-YYYY-0001).
- **Notifications:** appointment approvals/rejections, new requests, next vaccine/prenatal schedules, high-risk pregnancies,
  child malnutrition alerts, low stock.
- **Audit trail:** every create/update/delete/login/export goes to `activity_logs`.
- **Reports:** population by age/sex, monthly consultations, top complaints, vaccination coverage,
  fully immunized children (12–23 months), medicine distribution, maternal & child statistics. Print to PDF and CSV export.
  Charts use Chart.js from a CDN (needs internet). The tables still work offline.

## Two entry points

| Page | Who | What |
|---|---|---|
| `index.php` (homepage) | Residents | Public page: services, clinic hours, how to register, resident login |
| `register.php` | Residents | Online registration (18+ only, with data privacy consent) |
| `login.php` | Staff | Admin, BHW, Nurse, MHO login |
| `staff_register.php` | Staff | BHW / Nurse registration (chooses the user type) |

Each login only accepts its own users: a resident can't log in on the staff page, and staff can't log in on the homepage.

## Account registration

- **Staff (BHW / Nurse):** register on `staff_register.php` and choose their user type (BHW or Nurse), entering their
  BHW ID or PRC license number. The account stays **pending** until the **Admin** approves it in
  **Administration → Staff Approvals** (the admin can correct the user type) or rejects it with a reason.
  The admin can also still create a BHW/Nurse account directly in User Accounts.
  To let the admin create Municipal Health Officer accounts too, add `'mho'` to `CREATABLE_ROLES` in `admin/user_form.php`.
- **Residents:** register themselves on the homepage. The account starts as **pending**.
  - If the name + birthdate match an existing resident record, the account is linked to it (shown as *Existing record*).
  - Otherwise a new resident record is created with status *pending* (not counted in reports until approved).
  - A BHW or Nurse opens **Residents → Account Verification** and approves (optionally assigning a household) or rejects with a reason.
  - The resident sees the result when they try to log in. Approval also sends them a welcome notification.

A resident sees their own records and the records of household members under 18.

## What's new in this version

**Fixes**
- **Back / Close button** on every page (top bar, next to the title). It returns to the page you came from, or to the parent page.
  Press **Esc** to go back / close a popup. Popups (Approve, Reject…) also have an × button.
- **Newly registered residents are now easy to find.** The Residents list shows *Active + pending* by default (newest first), so residents who
  registered online appear right away with a *Pending* badge. Staff registrations show a clear success message with the resident number,
  and there is a **Save & add another** button. Saving a resident with the same name + birthdate asks you to confirm it is a different person.
  When approving an online registration you can choose **"+ New household from the address given"** so the typed address is stored as a household.
- **Edit user account** now shows the user you clicked (the page layout was overwriting the edited user with the logged-in admin).
  All layout variables now start with `$_` so this cannot happen again.
- **Household search shows the head of the family.** When registering a resident, type the head's name, household no., street or purok;
  the result list shows *HH-2026-0001 — Head: Dela Cruz, Juan — 12 Pine St.* and, after choosing, a card with the head, address and all members.

**New features**
- Human Resource Officer and Nutrition Action Officer user types (staff registration, admin approval, admin-created accounts).
- `modules/hr`: HR dashboard, Personnel 201 files (link to login account, licenses with expiry alerts, CSV export), daily attendance sheet +
  monthly summary, leave requests (approve/reject, weekdays counted, approved leave is written to attendance), trainings, and **My Leave** for every staff member.
- `modules/nutrition`: Nutrition dashboard (OPT+ coverage, status distribution, children needing intervention), OPT+ masterlist with CSV export,
  record measurements (WHO MUAC cut-offs suggest the status; severe cases notify the NAO and nurses), child nutrition profile with weight trend chart,
  feeding programs (beneficiaries with baseline/latest weight, sessions with attendance and weigh-ins, outcomes), micronutrient supplementation
  (Vitamin A, iron, MNP, deworming…) with automatic next-due dates.

**New look**
- "Obsidian Ember" dark theme with slanted, chamfered panels and 3D tilt on tiles (`assets/css/style.css`).
- **3D magnifier lens** that follows the cursor smoothly like a telescope. Turn it on/off with the magnifier button in the top bar or the **L** key;
  zoom with **Alt + mouse wheel** or the **[** and **]** keys. It hides while you type and is off on touch screens.
- **3D page transitions**: slanted panels sweep across and the page tilts away/in when you navigate.
  Both effects switch off automatically if Windows "Show animations" / reduced motion is turned off.
