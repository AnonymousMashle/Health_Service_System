<?php
/* Resident portal: rate the health center and send feedback; see the staff's response. */
require __DIR__ . '/common.php';

$errors = [];
$f = ['category' => 'Service', 'rating' => '', 'comments' => ''];
if (is_post()) {
    foreach (array_keys($f) as $k) { $f[$k] = input($k); }
    if (!in_array($f['category'], FEEDBACK_CATEGORIES, true)) $errors[] = 'Choose what your feedback is about.';
    if (!in_array($f['rating'], ['1', '2', '3', '4', '5'], true)) $errors[] = 'Choose a rating from 1 to 5 stars.';
    if (mb_strlen($f['comments']) < 5) $errors[] = 'Write your comments (at least a few words).';
    if (!$errors && q('SELECT COUNT(*) FROM feedback WHERE user_id = ? AND created_at >= NOW() - INTERVAL 1 DAY', [user_id()])->fetchColumn() >= 3) {
        $errors[] = 'You can send up to 3 feedback messages a day. Thank you for your patience.';
    }
    if (!$errors) {
        $ref = null;
        for ($try = 0; $try < 3 && !$ref; $try++) {
            $candidate = next_reference_no('FB', 'feedback', 'reference_no');
            try {
                $fid = db_insert('feedback', ['reference_no' => $candidate, 'resident_id' => $self_id, 'user_id' => user_id(), 'category' => $f['category'],
                                              'rating' => (int)$f['rating'], 'comments' => mb_substr($f['comments'], 0, 2000), 'status' => 'pending']);
                $ref = $candidate;
            } catch (PDOException $e) {
                if (!is_duplicate_error($e)) throw $e;
            }
        }
        if (!$ref) {
            throw new RuntimeException('Could not create a reference number. Please try again.');
        }
        notify_roles(['admin', 'nurse'], 'New feedback (' . (int)$f['rating'] . '★)', "$ref: {$f['category']} — " . mb_substr($f['comments'], 0, 120), 'modules/feedback/index.php?status=pending');
        log_activity('CREATE', 'feedback', $fid, "Resident sent feedback $ref");
        flash('success', "Thank you! Your feedback was sent. Reference number: $ref.");
        redirect('portal/feedback.php');
    }
}
$mine = q('SELECT f.*, u.full_name AS responder FROM feedback f LEFT JOIN users u ON u.user_id = f.responded_by
           WHERE f.user_id = ? ORDER BY f.created_at DESC', [user_id()])->fetchAll();

$page_title = 'Feedback';
require __DIR__ . '/../includes/header.php';
?>
<?= render_errors($errors) ?>
<div class="grid cols-3-1">
    <div class="card">
        <h3>My feedback</h3>
        <?php foreach ($mine as $m): ?>
            <div class="ann">
                <div class="meta"><span class="ref-no"><?= e($m['reference_no']) ?></span> <?= stars($m['rating']) ?> <span><?= e($m['category']) ?></span>
                    <span><?= fmt_datetime($m['created_at']) ?></span> <?= badge($m['status']) ?></div>
                <p><?= e($m['comments']) ?></p>
                <?php if ($m['response']): ?>
                    <div class="alert alert-info small" style="margin:10px 0 0"><strong>Health center response</strong> (<?= e($m['responder']) ?>, <?= fmt_datetime($m['responded_at']) ?>):<br><?= nl2br(e($m['response'])) ?></div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
        <?php if (!$mine): ?><p class="muted">You have not sent any feedback yet.</p><?php endif; ?>
    </div>
    <form method="post" class="card">
        <h3>Rate our service</h3>
        <?= csrf_field() ?>
        <div class="field required">
            <label>Rating</label>
            <div class="rating-input">
                <?php for ($i = 5; $i >= 1; $i--): ?>
                    <label><input type="radio" name="rating" value="<?= $i ?>" <?= $f['rating'] === (string)$i ? 'checked' : '' ?> required> <?= str_repeat('&#9733;', $i) ?></label>
                <?php endfor; ?>
            </div>
        </div>
        <?= select_field('About', 'category', FEEDBACK_CATEGORIES, $f['category'], 'required', false) ?>
        <?= field('Comments / suggestions', 'comments', $f['comments'], 'textarea', 'required maxlength="2000" placeholder="Tell us what went well or what we can improve"') ?>
        <button class="btn btn-primary">Send feedback</button>
        <p class="hint">Your feedback is seen by the health center nurse and the administrator.</p>
    </form>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
