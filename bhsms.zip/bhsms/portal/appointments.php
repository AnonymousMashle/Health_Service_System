<?php
/* Resident portal: request appointments for yourself or your children, follow their status, cancel. */
require __DIR__ . '/common.php';

$errors = [];
$f = ['resident_id' => (string)$self_id, 'service_type' => 'General Consultation', 'preferred_date' => '', 'preferred_time' => '', 'reason' => ''];

if (is_post()) {
    $action = input('action');
    if ($action === 'request') {
        foreach (array_keys($f) as $k) { $f[$k] = input($k); }
        if (!isset($members[(int)$f['resident_id']])) $errors[] = 'Choose who the appointment is for.';
        if (!in_array($f['service_type'], SERVICE_TYPES, true)) $errors[] = 'Choose the service.';
        if ($err = appointment_date_error($f['preferred_date'])) $errors[] = $err;
        if ($f['preferred_time'] !== '' && !preg_match('/^(0[7-9]|1[0-6]):[0-5]\d$/', $f['preferred_time'])) $errors[] = 'Choose a time from the list.';
        if ($f['reason'] === '') $errors[] = 'Tell us the reason for your visit.';
        if (!$errors && q("SELECT 1 FROM appointments WHERE resident_id = ? AND service_type = ? AND status IN ('pending', 'under review', 'approved')
                           AND COALESCE(scheduled_date, preferred_date) >= CURDATE()", [(int)$f['resident_id'], $f['service_type']])->fetchColumn()) {
            $errors[] = 'There is already an open ' . $f['service_type'] . ' request for this person. Cancel it first or wait for it to finish.';
        }
        if (!$errors) {
            [$aid, $ref] = create_appointment([
                'resident_id' => (int)$f['resident_id'], 'service_type' => $f['service_type'], 'preferred_date' => $f['preferred_date'],
                'preferred_time' => nullable($f['preferred_time']), 'reason' => mb_substr($f['reason'], 0, 255),
            ]);
            $who = $members[(int)$f['resident_id']];
            notify_roles(['bhw', 'nurse'], 'New appointment request', "$ref: {$f['service_type']} for {$who['first_name']} {$who['last_name']} on " . fmt_date($f['preferred_date']) . '.',
                         'modules/appointments/view.php?id=' . $aid);
            log_activity('CREATE', 'appointments', $aid, "Resident requested $ref");
            flash('success', "Your request was sent. Reference number: $ref. You will be notified when it is reviewed.");
            redirect('portal/appointments.php');
        }
    }
    if ($action === 'cancel') {
        $ids = array_keys($members);
        $in = implode(',', array_fill(0, count($ids), '?'));
        $a = q("SELECT * FROM appointments WHERE appointment_id = ? AND resident_id IN ($in) AND status IN ('pending', 'under review', 'approved')",
               array_merge([(int)input('appointment_id')], $ids))->fetch();
        if ($a) {
            q("UPDATE appointments SET status = 'cancelled', remarks = 'Cancelled by the resident' WHERE appointment_id = ?", [$a['appointment_id']]);
            log_appointment((int)$a['appointment_id'], 'cancelled', 'Cancelled by the resident' . (input('reason') !== '' ? ': ' . input('reason') : ''));
            if ($a['assigned_to']) {
                notify((int)$a['assigned_to'], 'Appointment cancelled', $a['reference_no'] . ' was cancelled by the resident.', 'modules/appointments/view.php?id=' . $a['appointment_id']);
            }
            log_activity('CANCEL', 'appointments', $a['appointment_id'], 'Resident cancelled ' . $a['reference_no']);
            flash('success', 'Appointment ' . $a['reference_no'] . ' cancelled.');
        }
        redirect('portal/appointments.php');
    }
}

$ids = array_keys($members);
$in = implode(',', array_fill(0, count($ids), '?'));
$appts = q("SELECT a.*, r.first_name FROM appointments a JOIN residents r ON r.resident_id = a.resident_id
            WHERE a.resident_id IN ($in) ORDER BY a.created_at DESC, a.appointment_id DESC", $ids)->fetchAll();
$logs = [];
if ($appts) {
    $aids = array_column($appts, 'appointment_id');
    $in2 = implode(',', array_fill(0, count($aids), '?'));
    foreach (q("SELECT * FROM appointment_logs WHERE appointment_id IN ($in2) ORDER BY changed_at, log_id", $aids)->fetchAll() as $l) {
        $logs[$l['appointment_id']][] = $l;
    }
}
$who = [];
foreach ($members as $mid => $m) {
    $who[$mid] = $mid === $self_id ? 'Me (' . $m['first_name'] . ')' : $m['first_name'] . ' (' . age_label($m['birthdate']) . ')';
}
$times = [];
for ($t = strtotime('08:00'); $t <= strtotime('16:30'); $t += 1800) {
    $times[date('H:i', $t)] = date('g:i A', $t);
}

$page_title = 'My Appointments';
require __DIR__ . '/../includes/header.php';
?>
<?= render_errors($errors) ?>
<div class="grid cols-3-1">
    <div class="card">
        <h3>My requests</h3>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Reference no.</th><th>For</th><th>Service</th><th>Date</th><th>Status</th><th>Remarks</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($appts as $a): ?>
                <tr>
                    <td class="ref-no"><?= e($a['reference_no']) ?></td>
                    <td><?= e($a['first_name']) ?></td>
                    <td><?= e($a['service_type']) ?><div class="small muted"><?= e($a['reason']) ?></div></td>
                    <td class="nowrap"><?php if ($a['scheduled_date']): ?><strong><?= fmt_date($a['scheduled_date']) ?></strong> <?= $a['scheduled_time'] ? fmt_time($a['scheduled_time']) : '' ?>
                        <?php else: ?><?= fmt_date($a['preferred_date']) ?> <span class="small muted">(requested)</span><?php endif; ?></td>
                    <td><?= badge($a['status']) ?></td>
                    <td class="small"><?= e($a['remarks']) ?>
                        <?php if (!empty($logs[$a['appointment_id']])): ?>
                            <details><summary class="small">History</summary>
                                <ol class="timeline">
                                    <?php foreach ($logs[$a['appointment_id']] as $l): ?>
                                        <li><?= badge($l['status']) ?> <?= e($l['remarks']) ?><div class="when"><?= fmt_datetime($l['changed_at']) ?></div></li>
                                    <?php endforeach; ?>
                                </ol>
                            </details>
                        <?php endif; ?></td>
                    <td class="actions">
                        <?php if (in_array($a['status'], APPOINTMENT_OPEN, true)): ?>
                            <?= post_button('appointments.php', 'Cancel', ['action' => 'cancel', 'appointment_id' => $a['appointment_id']], 'btn btn-sm', 'Cancel appointment ' . $a['reference_no'] . '?') ?>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$appts): ?><tr><td colspan="7" class="empty">No appointment requests yet.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
        <p class="hint">Status: <strong>Pending</strong> (sent) &rarr; <strong>Under review</strong> (a health worker is checking it) &rarr; <strong>Approved</strong> (with your schedule) or <strong>Rejected</strong> (with the reason) &rarr; <strong>Completed</strong>.</p>
    </div>

    <form method="post" class="card">
        <h3>Request an appointment</h3>
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="request">
        <div class="form-grid one">
            <?= select_field('For', 'resident_id', $who, $f['resident_id'], 'required', false) ?>
            <?= select_field('Service', 'service_type', SERVICE_TYPES, $f['service_type'], 'required', false) ?>
            <?= field('Preferred date (weekdays)', 'preferred_date', $f['preferred_date'], 'date', 'required min="' . today() . '" max="' . date('Y-m-d', strtotime('+90 days')) . '"') ?>
            <?= select_field('Preferred time', 'preferred_time', $times, $f['preferred_time'], '', '-- Any time --') ?>
            <?= field('Reason for visit', 'reason', $f['reason'], 'textarea', 'required maxlength="255" placeholder="e.g. Fever for 2 days, BP check, vaccine for my baby"') ?>
        </div>
        <button class="btn btn-primary">Send request</button>
    </form>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
