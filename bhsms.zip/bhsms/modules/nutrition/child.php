<?php
/* Nutrition profile of one child: weight trend, measurements, supplements, programs */
require __DIR__ . '/../../includes/init.php';
require_perm('nutrition');

$id = (int)get('id');
$c = q('SELECT r.*, h.household_no, h.purok, h.street_address, hh.first_name AS head_first, hh.last_name AS head_last
        FROM residents r LEFT JOIN households h ON h.household_id = r.household_id LEFT JOIN residents hh ON hh.resident_id = h.head_resident_id
        WHERE r.resident_id = ?', [$id])->fetch();
if (!$c) {
    flash('danger', 'Resident not found.');
    redirect('modules/nutrition/opt.php');
}
$measures = q('SELECT cm.*, u.full_name AS recorder FROM child_monitoring cm LEFT JOIN users u ON u.user_id = cm.recorded_by
               WHERE cm.resident_id = ? ORDER BY cm.visit_date DESC, cm.record_id DESC', [$id])->fetchAll();
$supps = q('SELECT s.*, u.full_name AS giver FROM micronutrient_supplements s LEFT JOIN users u ON u.user_id = s.given_by
            WHERE s.resident_id = ? ORDER BY s.date_given DESC', [$id])->fetchAll();
$programs = q('SELECT b.*, np.program_name, np.program_type, np.status AS program_status,
                      (SELECT COUNT(*) FROM session_attendance sa WHERE sa.beneficiary_id = b.beneficiary_id) AS attended
               FROM program_beneficiaries b JOIN nutrition_programs np ON np.program_id = b.program_id WHERE b.resident_id = ? ORDER BY b.enrolled_date DESC', [$id])->fetchAll();

// Weight trend (oldest -> newest) as a small inline SVG chart
$pts = array_reverse(array_values(array_filter($measures, function ($m) { return $m['weight_kg'] !== null; })));
$chart = '';
if (count($pts) >= 2) {
    $W = 560; $H = 170; $pad = 30;
    $ws = array_map('floatval', array_column($pts, 'weight_kg'));
    $t0 = strtotime($pts[0]['visit_date']); $t1 = max($t0 + 1, strtotime(end($pts)['visit_date']));
    $lo = floor(min($ws) - 0.5); $hi = ceil(max($ws) + 0.5);
    $xy = [];
    foreach ($pts as $i => $p) {
        $x = $pad + (strtotime($p['visit_date']) - $t0) / ($t1 - $t0) * ($W - 2 * $pad);
        $y = $H - $pad - ($ws[$i] - $lo) / max(0.1, $hi - $lo) * ($H - 2 * $pad);
        $xy[] = [round($x, 1), round($y, 1), $p];
    }
    $line = implode(' ', array_map(function ($q) { return $q[0] . ',' . $q[1]; }, $xy));
    $area = $line . ' ' . end($xy)[0] . ',' . ($H - $pad) . ' ' . $xy[0][0] . ',' . ($H - $pad);
    $chart = '<svg class="trend" viewBox="0 0 ' . $W . ' ' . $H . '" role="img" aria-label="Weight trend">'
        . '<defs><linearGradient id="tg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="currentColor" stop-opacity=".35"/><stop offset="1" stop-color="currentColor" stop-opacity="0"/></linearGradient></defs>'
        . '<line x1="' . $pad . '" y1="' . ($H - $pad) . '" x2="' . ($W - $pad) . '" y2="' . ($H - $pad) . '" class="axis"/>'
        . '<text x="4" y="' . ($pad + 4) . '" class="lbl">' . $hi . ' kg</text><text x="4" y="' . ($H - $pad + 4) . '" class="lbl">' . $lo . ' kg</text>'
        . '<polygon points="' . $area . '" fill="url(#tg)"/><polyline points="' . $line . '" class="ln"/>';
    foreach ($xy as $q) {
        $cls = $q[2]['nutrition_status'] && $q[2]['nutrition_status'] !== 'Normal' ? 'pt warn' : 'pt';
        $chart .= '<circle cx="' . $q[0] . '" cy="' . $q[1] . '" r="5" class="' . $cls . '"><title>' . e(fmt_date($q[2]['visit_date']) . ': ' . $q[2]['weight_kg'] . ' kg ' . ($q[2]['nutrition_status'] ?? '')) . '</title></circle>'
            . '<text x="' . $q[0] . '" y="' . ($H - 10) . '" class="lbl" text-anchor="middle">' . e(fmt_date($q[2]['visit_date'], 'M y')) . '</text>';
    }
    $chart .= '</svg>';
}
$latest = $measures[0] ?? null;

$page_title = 'Child Nutrition Profile';
$nav_active = 'modules/nutrition/opt.php';
$page_kicker = 'Nutrition';
$back_url = 'modules/nutrition/opt.php';
require __DIR__ . '/../../includes/header.php';
?>
<div class="profile-strip">
    <span class="avatar avatar-lg"><?= e(strtoupper(substr($c['first_name'], 0, 1))) ?></span>
    <div class="grow">
        <h2><?= e(full_name($c)) ?> <?= $latest && $latest['nutrition_status'] ? badge($latest['nutrition_status']) : '' ?></h2>
        <div class="muted"><?= e($c['sex']) ?> &middot; <?= e(age_label($c['birthdate'])) ?> (<?= age_months($c['birthdate']) ?> months) &middot; born <?= fmt_date($c['birthdate']) ?>
            <?php if ($c['household_no']): ?>&middot; <?= e($c['household_no']) ?>, <?= e($c['purok']) ?><?= $c['head_last'] ? ' &middot; Head: ' . e($c['head_last'] . ', ' . $c['head_first']) : '' ?><?php endif; ?></div>
    </div>
    <div class="btn-group no-print">
        <?php if (can('residents')): ?><a class="btn" href="<?= e(url('modules/residents/view.php?id=' . $id)) ?>">Full health record</a><?php endif; ?>
        <?php if (can('nutrition', 'edit')): ?>
            <a class="btn" href="supplements.php?resident_id=<?= $id ?>">+ Supplement</a>
            <a class="btn btn-primary" href="opt_form.php?resident_id=<?= $id ?>">+ Measurement</a>
        <?php endif; ?>
    </div>
</div>

<div class="grid cols-2 mb">
    <div class="card">
        <h3>Weight trend</h3>
        <?= $chart ?: '<p class="muted">At least two weighings are needed to draw the trend.</p>' ?>
    </div>
    <div class="card">
        <h3>Latest measurement</h3>
        <?php if ($latest): ?>
            <dl class="info">
                <dt>Date</dt><dd><?= fmt_date($latest['visit_date']) ?></dd>
                <dt>Weight / Height</dt><dd><?= e($latest['weight_kg'] ?? '—') ?> kg / <?= e($latest['height_cm'] ?? '—') ?> cm</dd>
                <dt>MUAC</dt><dd><?= $latest['muac_cm'] !== null ? e($latest['muac_cm']) . ' cm' : '—' ?>
                    <?php $mu = muac_assessment($latest['muac_cm'], age_months($c['birthdate'])); if ($mu): ?><span class="small muted">(MUAC: <?= e($mu) ?>)</span><?php endif; ?></dd>
                <dt>Status</dt><dd><?= $latest['nutrition_status'] ? badge($latest['nutrition_status']) : 'Not assessed' ?></dd>
                <dt>Next weighing</dt><dd><?= fmt_date($latest['next_visit']) ?></dd>
            </dl>
        <?php else: ?><p class="muted">Never measured.</p><?php endif; ?>
    </div>
</div>

<div class="card">
    <div class="tabs" data-tabs>
        <button class="active" data-tab="measures">Measurements (<?= count($measures) ?>)</button>
        <button data-tab="supps">Micronutrients (<?= count($supps) ?>)</button>
        <button data-tab="programs">Feeding programs (<?= count($programs) ?>)</button>
    </div>
    <div class="tab-panel active" id="tab-measures">
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Date</th><th>Age</th><th class="num">Wt (kg)</th><th class="num">Ht (cm)</th><th class="num">MUAC</th><th>Status</th><th>Remarks</th><th>By</th></tr></thead>
            <tbody>
            <?php foreach ($measures as $m): ?>
                <tr>
                    <td class="nowrap"><?= fmt_date($m['visit_date']) ?></td>
                    <td class="nowrap small"><?= (new DateTime($c['birthdate']))->diff(new DateTime($m['visit_date']))->y * 12 + (new DateTime($c['birthdate']))->diff(new DateTime($m['visit_date']))->m ?> mos</td>
                    <td class="num"><?= e($m['weight_kg'] ?? '—') ?></td>
                    <td class="num"><?= e($m['height_cm'] ?? '—') ?></td>
                    <td class="num"><?= e($m['muac_cm'] ?? '—') ?></td>
                    <td><?= $m['nutrition_status'] ? badge($m['nutrition_status']) : '—' ?></td>
                    <td class="small"><?= e(trim(($m['milestones'] ?? '') . ' ' . ($m['remarks'] ?? ''))) ?></td>
                    <td class="small"><?= e($m['recorder'] ?? '—') ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$measures): ?><tr><td colspan="8" class="empty">No measurements yet.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>
    <div class="tab-panel" id="tab-supps">
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Date</th><th>Supplement</th><th>Dose</th><th>Next due</th><th>Given by</th></tr></thead>
            <tbody>
            <?php foreach ($supps as $s): ?>
                <tr><td><?= fmt_date($s['date_given']) ?></td><td><?= e($s['supplement_type']) ?></td><td><?= e($s['dose'] ?: '—') ?></td>
                    <td><?= fmt_date($s['next_due']) ?></td><td class="small"><?= e($s['giver'] ?? '—') ?></td></tr>
            <?php endforeach; ?>
            <?php if (!$supps): ?><tr><td colspan="5" class="empty">No supplements recorded.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>
    <div class="tab-panel" id="tab-programs">
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Program</th><th>Enrolled</th><th>Baseline</th><th>Latest</th><th class="num">Sessions attended</th><th>Outcome</th></tr></thead>
            <tbody>
            <?php foreach ($programs as $p): ?>
                <tr>
                    <td><a href="program_view.php?id=<?= (int)$p['program_id'] ?>"><?= e($p['program_name']) ?></a> <?= badge($p['program_status']) ?></td>
                    <td><?= fmt_date($p['enrolled_date']) ?></td>
                    <td class="small"><?= e($p['baseline_weight_kg'] ?? '—') ?> kg <?= e($p['baseline_status']) ?></td>
                    <td class="small"><?= e($p['latest_weight_kg'] ?? '—') ?> kg <?= e($p['latest_status']) ?></td>
                    <td class="num"><?= (int)$p['attended'] ?></td>
                    <td><?= badge($p['outcome']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$programs): ?><tr><td colspan="6" class="empty">Not enrolled in any program.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
