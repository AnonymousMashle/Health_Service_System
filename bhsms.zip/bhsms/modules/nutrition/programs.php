<?php
/* Feeding / nutrition programs: list, add and edit */
require __DIR__ . '/../../includes/init.php';
require_perm('nutrition');

$canManage = can('nutrition', 'manage');
$editId = (int)get('edit');
$showForm = $canManage && ($editId || get('new') === '1');
$errors = [];
$fields = ['program_name', 'program_type', 'target_group', 'start_date', 'end_date', 'sessions_planned', 'venue', 'funding_source', 'description', 'status'];
$pr = array_fill_keys($fields, '');
$pr['program_type'] = 'Supplementary Feeding';
$pr['status'] = 'planned';
$pr['start_date'] = today();

if ($editId) {
    $pr = q('SELECT * FROM nutrition_programs WHERE program_id = ?', [$editId])->fetch();
    if (!$pr) {
        flash('danger', 'Program not found.');
        redirect('modules/nutrition/programs.php');
    }
}

if (is_post()) {
    require_perm('nutrition', 'manage');
    foreach ($fields as $f) { $pr[$f] = input($f); }
    if ($pr['program_name'] === '') $errors[] = 'Program name is required.';
    if (!in_array($pr['program_type'], PROGRAM_TYPES, true)) $errors[] = 'Choose a program type.';
    if (!valid_date($pr['start_date'])) $errors[] = 'Enter the start date.';
    if ($pr['end_date'] !== '' && (!valid_date($pr['end_date']) || $pr['end_date'] < $pr['start_date'])) $errors[] = 'End date must be after the start date.';
    if ($pr['sessions_planned'] !== '' && (!ctype_digit($pr['sessions_planned']) || (int)$pr['sessions_planned'] > 400)) $errors[] = 'Planned sessions must be a whole number.';
    if (!in_array($pr['status'], ['planned', 'ongoing', 'completed', 'cancelled'], true)) $errors[] = 'Choose a status.';
    if (!$errors) {
        $data = [];
        foreach ($fields as $f) { $data[$f] = nullable($pr[$f]); }
        if ($editId) {
            db_update('nutrition_programs', $data, 'program_id', $editId);
            log_activity('UPDATE', 'nutrition_programs', $editId, 'Updated program ' . $pr['program_name']);
        } else {
            $data['created_by'] = user_id();
            $editId = db_insert('nutrition_programs', $data);
            log_activity('CREATE', 'nutrition_programs', $editId, 'Created program ' . $pr['program_name']);
        }
        flash('success', 'Program "' . $pr['program_name'] . '" saved.');
        redirect('modules/nutrition/program_view.php?id=' . $editId);
    }
    $showForm = true;
}

$status = get('status');
$where = $status !== '' ? 'WHERE np.status = ?' : '';
$rows = q("SELECT np.*, (SELECT COUNT(*) FROM program_beneficiaries b WHERE b.program_id = np.program_id AND b.outcome <> 'dropped') AS enrolled,
                  (SELECT COUNT(*) FROM program_beneficiaries b WHERE b.program_id = np.program_id AND b.outcome IN ('improved', 'rehabilitated')) AS improved,
                  (SELECT COUNT(*) FROM program_sessions s WHERE s.program_id = np.program_id) AS sessions
           FROM nutrition_programs np $where ORDER BY FIELD(np.status, 'ongoing', 'planned', 'completed', 'cancelled'), np.start_date DESC",
          $status !== '' ? [$status] : [])->fetchAll();

$page_title = 'Feeding Programs';
$page_kicker = 'Nutrition';
if ($showForm) {
    $back_url = $editId ? 'modules/nutrition/program_view.php?id=' . $editId : 'modules/nutrition/programs.php';
}
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<?php if ($showForm): ?>
<div class="card">
    <div class="card-header">
        <h3><?= $editId ? 'Edit program' : 'New nutrition program' ?></h3>
        <a class="btn btn-sm btn-close" href="<?= e(url($back_url)) ?>" title="Close (Esc)">&times; Close</a>
    </div>
    <form method="post">
        <?= csrf_field() ?>
        <div class="form-grid">
            <?= field('Program name', 'program_name', $pr['program_name'], 'text', 'required maxlength="150" placeholder="e.g. Supplementary Feeding Program 2027"', 'span-2') ?>
            <?= select_field('Type', 'program_type', PROGRAM_TYPES, $pr['program_type'], 'required', false) ?>
            <?= field('Target group', 'target_group', $pr['target_group'], 'text', 'maxlength="100" placeholder="Underweight children 6–59 months"') ?>
            <?= field('Start date', 'start_date', $pr['start_date'], 'date', 'required') ?>
            <?= field('End date', 'end_date', $pr['end_date'], 'date') ?>
            <?= field('Planned sessions / feeding days', 'sessions_planned', $pr['sessions_planned'], 'number', 'min="1" max="400"') ?>
            <?= field('Venue', 'venue', $pr['venue'], 'text', 'maxlength="150"') ?>
            <?= field('Funding source', 'funding_source', $pr['funding_source'], 'text', 'maxlength="100" placeholder="LGU, DSWD, NGO..."') ?>
            <?= select_field('Status', 'status', ['planned' => 'Planned', 'ongoing' => 'Ongoing', 'completed' => 'Completed', 'cancelled' => 'Cancelled'], $pr['status'], 'required', false) ?>
            <?= field('Description', 'description', $pr['description'], 'textarea', '', 'full') ?>
        </div>
        <div class="form-actions"><button class="btn btn-primary">Save program</button></div>
    </form>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h3>Programs</h3>
        <div class="btn-group">
            <form method="get" class="inline"><select name="status" onchange="this.form.submit()"><?= options(['ongoing' => 'Ongoing', 'planned' => 'Planned', 'completed' => 'Completed', 'cancelled' => 'Cancelled'], $status, 'All statuses') ?></select></form>
            <?php if ($canManage): ?><a class="btn btn-primary" href="programs.php?new=1">+ New program</a><?php endif; ?>
        </div>
    </div>
    <div class="program-grid">
        <?php foreach ($rows as $p): $pct = $p['sessions_planned'] ? min(100, round($p['sessions'] / $p['sessions_planned'] * 100)) : null; ?>
            <a class="program-card tilt" href="program_view.php?id=<?= (int)$p['program_id'] ?>">
                <div class="program-top"><?= badge($p['status']) ?><span class="small muted"><?= e($p['program_type']) ?></span></div>
                <h3><?= e($p['program_name']) ?></h3>
                <p class="small muted"><?= e($p['target_group'] ?: 'No target group set') ?></p>
                <div class="program-stats">
                    <div><b><?= (int)$p['enrolled'] ?></b><span>enrolled</span></div>
                    <div><b><?= (int)$p['improved'] ?></b><span>improved</span></div>
                    <div><b><?= (int)$p['sessions'] ?></b><span>sessions</span></div>
                </div>
                <?php if ($pct !== null): ?><div class="bar"><i style="width:<?= $pct ?>%"></i></div><div class="small muted"><?= $pct ?>% of <?= (int)$p['sessions_planned'] ?> planned sessions</div><?php endif; ?>
                <div class="small muted"><?= fmt_date($p['start_date']) ?> – <?= fmt_date($p['end_date']) ?></div>
            </a>
        <?php endforeach; ?>
    </div>
    <?php if (!$rows): ?><p class="empty">No programs yet.</p><?php endif; ?>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
