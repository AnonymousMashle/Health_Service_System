<?php
/* Nutrition Action Officer dashboard: nutrition situation of children 0–59 months */
require __DIR__ . '/../../includes/init.php';
require_perm('nutrition');

$cutoff = date('Y-m-d', strtotime('-60 months'));
$yearStart = date('Y') . '-01-01';
$children = q("SELECT r.resident_id, r.first_name, r.middle_name, r.last_name, r.suffix, r.sex, r.birthdate, h.purok, h.household_no,
                      lm.visit_date, lm.weight_kg, lm.height_cm, lm.muac_cm, lm.nutrition_status
               FROM residents r LEFT JOIN households h ON h.household_id = r.household_id
               " . latest_measure_join('lm') . "
               WHERE r.status = 'active' AND r.birthdate > ?", [$cutoff])->fetchAll();

$total = count($children);
$measured = 0;
$byStatus = array_fill_keys(NUTRITION_STATUS, 0);
$atRisk = [];
foreach ($children as $c) {
    if ($c['visit_date'] && $c['visit_date'] >= $yearStart) {
        $measured++;
    }
    if ($c['nutrition_status']) {
        $byStatus[$c['nutrition_status']]++;
        if ($c['nutrition_status'] !== 'Normal') {
            $atRisk[] = $c;
        }
    }
}
usort($atRisk, function ($a, $b) {
    return (in_array($b['nutrition_status'], SEVERE_STATUS, true) <=> in_array($a['nutrition_status'], SEVERE_STATUS, true)) ?: strcmp($a['last_name'], $b['last_name']);
});
$coverage = $total ? round($measured / $total * 100) : 0;
$malnourished = count($atRisk);
$severe = count(array_filter($atRisk, function ($c) { return in_array($c['nutrition_status'], SEVERE_STATUS, true); }));
$programs = q("SELECT np.*, (SELECT COUNT(*) FROM program_beneficiaries b WHERE b.program_id = np.program_id AND b.outcome <> 'dropped') AS enrolled,
                      (SELECT COUNT(*) FROM program_sessions s WHERE s.program_id = np.program_id) AS sessions
               FROM nutrition_programs np WHERE np.status IN ('planned', 'ongoing') ORDER BY np.start_date DESC LIMIT 5")->fetchAll();
$dueSupp = q("SELECT s.*, r.first_name, r.middle_name, r.last_name, r.suffix, r.birthdate FROM micronutrient_supplements s
              JOIN residents r ON r.resident_id = s.resident_id
              WHERE s.next_due IS NOT NULL AND s.next_due <= ? AND r.status = 'active'
                AND NOT EXISTS (SELECT 1 FROM micronutrient_supplements s2 WHERE s2.resident_id = s.resident_id
                                AND s2.supplement_type = s.supplement_type AND s2.date_given > s.date_given)
              ORDER BY s.next_due LIMIT 8", [date('Y-m-d', strtotime('+30 days'))])->fetchAll();
$maxStatus = max(array_merge([1], array_values($byStatus)));
$statusColor = function ($s) {
    if ($s === 'Normal') return 'green';
    if (in_array($s, SEVERE_STATUS, true)) return 'red';
    if (in_array($s, ['Overweight', 'Obese'], true)) return 'purple';
    return 'amber';
};

$page_title = 'Nutrition Dashboard';
$page_kicker = 'Nutrition';
require __DIR__ . '/../../includes/header.php';
?>
<div class="page-head">
    <div>
        <h2>Nutrition situation — children 0–59 months</h2>
        <div class="muted">Based on each child's latest Operation Timbang Plus (OPT+) / growth monitoring measurement.</div>
    </div>
    <div class="btn-group">
        <a class="btn" href="opt.php?export=csv">Export OPT+ masterlist</a>
        <?php if (can('nutrition', 'edit')): ?><a class="btn btn-primary" href="opt_form.php">+ Record measurement</a><?php endif; ?>
    </div>
</div>

<div class="stats">
    <a class="stat" href="opt.php"><div class="label">Children 0–59 months</div><div class="value"><?= $total ?></div></a>
    <a class="stat blue" href="opt.php?measured=no"><div class="label">OPT+ coverage <?= date('Y') ?></div><div class="value"><?= $coverage ?>%</div><div class="sub"><?= $measured ?> of <?= $total ?> measured</div></a>
    <a class="stat amber" href="opt.php?status=malnourished"><div class="label">Malnourished (any form)</div><div class="value"><?= $malnourished ?></div></a>
    <a class="stat red" href="opt.php?status=severe"><div class="label">Severe cases</div><div class="value"><?= $severe ?></div></a>
    <a class="stat purple" href="programs.php"><div class="label">Active feeding programs</div><div class="value"><?= count($programs) ?></div></a>
</div>

<div class="grid cols-2">
    <div class="card">
        <h3>Nutritional status distribution</h3>
        <?php foreach ($byStatus as $st => $n): ?>
            <div class="bar-row">
                <span><?= e($st) ?></span>
                <div class="bar bar-<?= $statusColor($st) ?>"><i style="width:<?= round($n / $maxStatus * 100) ?>%"></i></div>
                <b><?= $n ?></b>
            </div>
        <?php endforeach; ?>
        <p class="hint"><?= $total - array_sum($byStatus) ?> child(ren) have no measurement yet.</p>
    </div>

    <div class="card">
        <div class="card-header"><h3>Children needing intervention</h3><a class="btn btn-sm" href="opt.php?status=malnourished">See all</a></div>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Child</th><th>Age</th><th>Purok</th><th>Status</th><th>Last weighed</th></tr></thead>
            <tbody>
            <?php foreach (array_slice($atRisk, 0, 8) as $c): ?>
                <tr class="<?= in_array($c['nutrition_status'], SEVERE_STATUS, true) ? 'row-danger' : '' ?>">
                    <td><a href="child.php?id=<?= (int)$c['resident_id'] ?>"><?= e(full_name($c)) ?></a></td>
                    <td class="nowrap"><?= e(age_label($c['birthdate'])) ?></td>
                    <td><?= e($c['purok'] ?? '—') ?></td>
                    <td><?= badge($c['nutrition_status']) ?></td>
                    <td class="small nowrap"><?= fmt_date($c['visit_date']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$atRisk): ?><tr><td colspan="5" class="empty">No malnourished children on record.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>

    <div class="card">
        <div class="card-header"><h3>Feeding &amp; nutrition programs</h3><a class="btn btn-sm" href="programs.php">Manage</a></div>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Program</th><th>Period</th><th class="num">Enrolled</th><th class="num">Sessions</th><th>Status</th></tr></thead>
            <tbody>
            <?php foreach ($programs as $pr): ?>
                <tr>
                    <td><a href="program_view.php?id=<?= (int)$pr['program_id'] ?>"><strong><?= e($pr['program_name']) ?></strong></a><div class="small muted"><?= e($pr['program_type']) ?></div></td>
                    <td class="small nowrap"><?= fmt_date($pr['start_date']) ?> – <?= fmt_date($pr['end_date']) ?></td>
                    <td class="num"><?= (int)$pr['enrolled'] ?></td>
                    <td class="num"><?= (int)$pr['sessions'] ?><?= $pr['sessions_planned'] ? ' / ' . (int)$pr['sessions_planned'] : '' ?></td>
                    <td><?= badge($pr['status']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$programs): ?><tr><td colspan="5" class="empty">No active programs.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>

    <div class="card">
        <div class="card-header"><h3>Micronutrients due (next 30 days / overdue)</h3><a class="btn btn-sm" href="supplements.php?due=1">See all</a></div>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Resident</th><th>Supplement</th><th>Due</th></tr></thead>
            <tbody>
            <?php foreach ($dueSupp as $s): ?>
                <tr class="<?= $s['next_due'] < today() ? 'row-danger' : '' ?>">
                    <td><?= e(full_name($s)) ?> <span class="small muted"><?= e(age_label($s['birthdate'])) ?></span></td>
                    <td><?= e($s['supplement_type']) ?></td>
                    <td class="nowrap"><?= fmt_date($s['next_due']) ?> <?= $s['next_due'] < today() ? badge('overdue') : '' ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$dueSupp): ?><tr><td colspan="3" class="empty">Nothing due.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
