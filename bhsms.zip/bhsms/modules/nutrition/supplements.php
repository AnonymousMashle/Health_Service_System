<?php
/* Micronutrient supplementation: Vitamin A, iron, MNP, deworming ... */
require __DIR__ . '/../../includes/init.php';
require_perm('nutrition');

// Usual dose and when the next one is due (months) — used to pre-fill the form; staff can change both
const SUPPLEMENT_DEFAULTS = [
    'Vitamin A'            => ['100,000 IU (6–11 mos) / 200,000 IU (12–59 mos)', 6],
    'Iron'                 => ['', 3],
    'Iron with Folic Acid' => ['60 mg elemental iron + 400 mcg folic acid', 1],
    'Micronutrient Powder' => ['1 sachet every other day', 2],
    'Deworming'            => ['Albendazole 400 mg', 6],
    'Iodized Oil'          => ['', 12],
    'Zinc'                 => ['', null],
    'Calcium'              => ['', 1],
    'Other'                => ['', null],
];

$errors = [];
$s = ['resident_id' => get('resident_id'), 'supplement_type' => 'Vitamin A', 'dose' => '', 'date_given' => today(), 'next_due' => '', 'remarks' => ''];

if (is_post()) {
    require_perm('nutrition', 'edit');
    if (input('action') === 'delete') {
        $sid = (int)input('supplement_id');
        q('DELETE FROM micronutrient_supplements WHERE supplement_id = ?', [$sid]);
        log_activity('DELETE', 'micronutrient_supplements', $sid, 'Deleted supplement record');
        flash('success', 'Record deleted.');
        redirect(back_url('modules/nutrition/supplements.php'));
    }
    foreach (array_keys($s) as $k) { $s[$k] = input($k); }
    $res = q("SELECT * FROM residents WHERE resident_id = ? AND status = 'active'", [(int)$s['resident_id']])->fetch();
    if (!$res) $errors[] = 'Choose a resident.';
    if (!in_array($s['supplement_type'], SUPPLEMENT_TYPES, true)) $errors[] = 'Choose a supplement.';
    if (!valid_date($s['date_given']) || $s['date_given'] > today()) $errors[] = 'Enter a valid date given (not in the future).';
    if ($s['next_due'] !== '' && (!valid_date($s['next_due']) || $s['next_due'] <= $s['date_given'])) $errors[] = 'Next due date must be after the date given.';
    if (!$errors) {
        if ($s['next_due'] === '' && ($months = SUPPLEMENT_DEFAULTS[$s['supplement_type']][1] ?? null)) {
            $s['next_due'] = date('Y-m-d', strtotime($s['date_given'] . " +$months months"));
        }
        $sid = db_insert('micronutrient_supplements', [
            'resident_id' => (int)$s['resident_id'], 'supplement_type' => $s['supplement_type'], 'dose' => nullable($s['dose']),
            'date_given' => $s['date_given'], 'next_due' => nullable($s['next_due']), 'remarks' => nullable($s['remarks']), 'given_by' => user_id(),
        ]);
        log_activity('CREATE', 'micronutrient_supplements', $sid, $s['supplement_type'] . ' given to ' . $res['first_name'] . ' ' . $res['last_name']);
        if ($s['next_due']) {
            notify_resident((int)$s['resident_id'], 'Next ' . $s['supplement_type'] . ' schedule',
                'The next ' . $s['supplement_type'] . ' for ' . $res['first_name'] . ' is due on ' . fmt_date($s['next_due']) . '.');
        }
        flash('success', $s['supplement_type'] . ' recorded for ' . $res['first_name'] . ' ' . $res['last_name'] . ($s['next_due'] ? '. Next due ' . fmt_date($s['next_due']) . '.' : '.'));
        redirect('modules/nutrition/supplements.php');
    }
}

$type = get('type');
$due = get('due') === '1';
$search = get('q');
$where = ["r.status = 'active'"];
$params = [];
if ($type !== '') { $where[] = 's.supplement_type = ?'; $params[] = $type; }
if ($search !== '') {
    $where[] = "(r.first_name LIKE ? OR r.last_name LIKE ? OR CONCAT(r.first_name, ' ', r.last_name) LIKE ?)";
    array_push($params, "%$search%", "%$search%", "%$search%");
}
if ($due) {
    $where[] = 's.next_due IS NOT NULL AND s.next_due <= ?';
    $params[] = date('Y-m-d', strtotime('+30 days'));
    $where[] = 'NOT EXISTS (SELECT 1 FROM micronutrient_supplements s2 WHERE s2.resident_id = s.resident_id AND s2.supplement_type = s.supplement_type AND s2.date_given > s.date_given)';
}
$w = implode(' AND ', $where);
$from = 'FROM micronutrient_supplements s JOIN residents r ON r.resident_id = s.resident_id LEFT JOIN users u ON u.user_id = s.given_by
         LEFT JOIN households h ON h.household_id = r.household_id';
$pg = paginate((int)q("SELECT COUNT(*) $from WHERE $w", $params)->fetchColumn(), 20);
$rows = q("SELECT s.*, r.first_name, r.middle_name, r.last_name, r.suffix, r.birthdate, h.purok, u.full_name AS giver
           $from WHERE $w ORDER BY " . ($due ? 's.next_due' : 's.date_given DESC, s.supplement_id DESC') . " LIMIT {$pg['per']} OFFSET {$pg['offset']}", $params)->fetchAll();
$people = resident_options();

$page_title = 'Micronutrient Supplementation';
$page_kicker = 'Nutrition';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<div class="tabs">
    <a class="<?= !$due ? 'active' : '' ?>" href="supplements.php">All records</a>
    <a class="<?= $due ? 'active' : '' ?>" href="supplements.php?due=1">Due &amp; overdue</a>
</div>
<div class="grid cols-3-1">
    <div class="card">
        <form class="toolbar" method="get">
            <?php if ($due): ?><input type="hidden" name="due" value="1"><?php endif; ?>
            <div class="grow"><label>Search</label><input type="search" name="q" value="<?= e($search) ?>" placeholder="Resident name"></div>
            <div><label>Supplement</label><select name="type"><?= options(SUPPLEMENT_TYPES, $type, 'All') ?></select></div>
            <button class="btn">Filter</button>
        </form>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Date given</th><th>Resident</th><th>Supplement</th><th>Dose</th><th>Next due</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): $late = $r['next_due'] && $r['next_due'] < today(); ?>
                <tr class="<?= $due && $late ? 'row-danger' : '' ?>">
                    <td class="nowrap"><?= fmt_date($r['date_given']) ?></td>
                    <td><a href="child.php?id=<?= (int)$r['resident_id'] ?>"><?= e(full_name($r)) ?></a><div class="small muted"><?= e(age_label($r['birthdate'])) ?><?= $r['purok'] ? ' &middot; ' . e($r['purok']) : '' ?></div></td>
                    <td><?= e($r['supplement_type']) ?></td>
                    <td class="small"><?= e($r['dose'] ?: '—') ?></td>
                    <td class="nowrap"><?= fmt_date($r['next_due']) ?> <?= $due && $late ? badge('overdue') : '' ?></td>
                    <td class="actions"><?php if (can('nutrition', 'edit')): ?><?= post_button('supplements.php', 'Delete', ['action' => 'delete', 'supplement_id' => $r['supplement_id']], 'btn btn-sm btn-danger', 'Delete this record?') ?><?php endif; ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$rows): ?><tr><td colspan="6" class="empty"><?= $due ? 'Nothing is due in the next 30 days.' : 'No supplements recorded.' ?></td></tr><?php endif; ?>
            </tbody>
        </table></div>
        <?= pagination_links($pg) ?>
    </div>
    <?php if (can('nutrition', 'edit')): ?>
    <div class="card">
        <h3>Give a supplement</h3>
        <form method="post">
            <?= csrf_field() ?>
            <div class="form-grid one">
                <?= select_field('Resident', 'resident_id', $people, $s['resident_id'], 'required class="searchable"') ?>
                <div class="field required">
                    <label for="f_supplement_type">Supplement</label>
                    <select id="f_supplement_type" name="supplement_type" required data-defaults='<?= e(json_encode(SUPPLEMENT_DEFAULTS)) ?>'><?= options(SUPPLEMENT_TYPES, $s['supplement_type'], false) ?></select>
                </div>
                <?= field('Dose', 'dose', $s['dose'] !== '' ? $s['dose'] : SUPPLEMENT_DEFAULTS[$s['supplement_type']][0], 'text', 'maxlength="60"') ?>
                <?= field('Date given', 'date_given', $s['date_given'], 'date', 'required max="' . today() . '"') ?>
                <?= field('Next due', 'next_due', $s['next_due'], 'date', 'placeholder="auto"') ?>
                <?= field('Remarks', 'remarks', $s['remarks'], 'text', 'maxlength="255" placeholder="e.g. Garantisadong Pambata"') ?>
            </div>
            <p class="hint">Leave <em>Next due</em> blank to fill it automatically (Vitamin A and deworming: every 6 months).</p>
            <div class="form-actions"><button class="btn btn-primary">Save</button></div>
        </form>
    </div>
    <?php endif; ?>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
