<?php
/* Operation Timbang Plus (OPT+) masterlist: every child 0–59 months with the latest measurement */
require __DIR__ . '/../../includes/init.php';
require_perm('nutrition');

$search = get('q');
$status = get('status');
$purok = get('purok');
$measured = get('measured');
$yearStart = date('Y') . '-01-01';

$where = ["r.status = 'active'", 'r.birthdate > ?'];
$params = [date('Y-m-d', strtotime('-60 months'))];
if ($search !== '') {
    $where[] = "(r.first_name LIKE ? OR r.last_name LIKE ? OR CONCAT(r.first_name, ' ', r.last_name) LIKE ? OR h.household_no LIKE ? OR hh.last_name LIKE ?)";
    $like = "%$search%";
    array_push($params, $like, $like, $like, $like, $like);
}
if ($status === 'malnourished') {
    $where[] = "lm.nutrition_status IS NOT NULL AND lm.nutrition_status <> 'Normal'";
} elseif ($status === 'severe') {
    $where[] = "lm.nutrition_status IN ('" . implode("','", SEVERE_STATUS) . "')";
} elseif (in_array($status, NUTRITION_STATUS, true)) {
    $where[] = 'lm.nutrition_status = ?';
    $params[] = $status;
}
if ($purok !== '') { $where[] = 'h.purok = ?'; $params[] = $purok; }
if ($measured === 'yes') { $where[] = 'lm.visit_date >= ?'; $params[] = $yearStart; }
if ($measured === 'no')  { $where[] = '(lm.visit_date IS NULL OR lm.visit_date < ?)'; $params[] = $yearStart; }
$w = implode(' AND ', $where);
$from = "FROM residents r LEFT JOIN households h ON h.household_id = r.household_id
         LEFT JOIN residents hh ON hh.resident_id = h.head_resident_id " . latest_measure_join('lm');
$select = "SELECT r.resident_id, r.first_name, r.middle_name, r.last_name, r.suffix, r.sex, r.birthdate, h.household_no, h.purok,
                  hh.first_name AS head_first, hh.last_name AS head_last,
                  lm.visit_date, lm.weight_kg, lm.height_cm, lm.muac_cm, lm.nutrition_status,
                  (SELECT COUNT(*) FROM program_beneficiaries b JOIN nutrition_programs np ON np.program_id = b.program_id
                    WHERE b.resident_id = r.resident_id AND np.status = 'ongoing' AND b.outcome <> 'dropped') AS in_program";

if (get('export') === 'csv') {
    $rows = q("$select $from WHERE $w ORDER BY h.purok, r.last_name, r.first_name", $params)->fetchAll();
    log_activity('EXPORT', 'child_monitoring', null, 'Exported OPT+ masterlist');
    send_csv('opt_masterlist_' . date('Ymd') . '.csv',
        ['Name', 'Sex', 'Birthdate', 'Age (months)', 'Purok', 'Household', 'Household head', 'Date measured', 'Weight (kg)', 'Height (cm)', 'MUAC (cm)', 'Nutritional status', 'In feeding program'],
        array_map(function ($r) {
            return [full_name($r), $r['sex'], $r['birthdate'], age_months($r['birthdate']), $r['purok'], $r['household_no'],
                    $r['head_last'] ? $r['head_last'] . ', ' . $r['head_first'] : '', $r['visit_date'], $r['weight_kg'], $r['height_cm'], $r['muac_cm'],
                    $r['nutrition_status'], $r['in_program'] ? 'Yes' : 'No'];
        }, $rows));
}

$pg = paginate((int)q("SELECT COUNT(*) $from WHERE $w", $params)->fetchColumn(), 20);
$rows = q("$select $from WHERE $w ORDER BY r.last_name, r.first_name LIMIT {$pg['per']} OFFSET {$pg['offset']}", $params)->fetchAll();
$puroks = q('SELECT DISTINCT purok FROM households ORDER BY purok')->fetchAll(PDO::FETCH_COLUMN);

$page_title = 'Operation Timbang Plus';
$page_kicker = 'Nutrition';
require __DIR__ . '/../../includes/header.php';
?>
<div class="card">
    <div class="card-header">
        <h3>OPT+ masterlist <span class="muted small">children 0–59 months</span></h3>
        <div class="btn-group">
            <a class="btn btn-sm" href="?<?= e(http_build_query(array_merge($_GET, ['export' => 'csv']))) ?>">Export CSV</a>
            <?php if (can('nutrition', 'edit')): ?><a class="btn btn-primary" href="opt_form.php">+ Record measurement</a><?php endif; ?>
        </div>
    </div>
    <form class="toolbar" method="get">
        <div class="grow"><label>Search</label><input type="search" name="q" value="<?= e($search) ?>" placeholder="Child, household head or household no."></div>
        <div><label>Status</label><select name="status"><?= options(['malnourished' => 'Any malnutrition', 'severe' => 'Severe only'] + array_combine(NUTRITION_STATUS, NUTRITION_STATUS), $status, 'All') ?></select></div>
        <div><label>Purok</label><select name="purok"><?= options($puroks, $purok, 'All') ?></select></div>
        <div><label>Measured in <?= date('Y') ?></label><select name="measured"><?= options(['yes' => 'Yes', 'no' => 'Not yet'], $measured, 'All') ?></select></div>
        <button class="btn">Filter</button>
        <a class="btn" href="opt.php">Reset</a>
    </form>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Child</th><th>Sex</th><th>Age</th><th>Household</th><th>Last measured</th><th class="num">Wt (kg)</th><th class="num">Ht (cm)</th><th class="num">MUAC</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $c): ?>
            <tr class="<?= in_array($c['nutrition_status'], SEVERE_STATUS, true) ? 'row-danger' : '' ?>">
                <td><a href="child.php?id=<?= (int)$c['resident_id'] ?>"><strong><?= e(full_name($c)) ?></strong></a>
                    <?= $c['in_program'] ? '<span class="badge badge-blue">In program</span>' : '' ?></td>
                <td><?= e($c['sex']) ?></td>
                <td class="nowrap"><?= age_months($c['birthdate']) ?> mos</td>
                <td class="small"><?= e($c['household_no'] ?: '—') ?><?= $c['purok'] ? ' &middot; ' . e($c['purok']) : '' ?>
                    <?php if ($c['head_last']): ?><div class="muted">Head: <?= e($c['head_last'] . ', ' . $c['head_first']) ?></div><?php endif; ?></td>
                <td class="small nowrap"><?= $c['visit_date'] ? fmt_date($c['visit_date']) : '<span class="text-danger">Never</span>' ?></td>
                <td class="num"><?= e($c['weight_kg'] ?? '—') ?></td>
                <td class="num"><?= e($c['height_cm'] ?? '—') ?></td>
                <td class="num"><?= e($c['muac_cm'] ?? '—') ?></td>
                <td><?= $c['nutrition_status'] ? badge($c['nutrition_status']) : '—' ?></td>
                <td class="actions"><?php if (can('nutrition', 'edit')): ?><a class="btn btn-sm" href="opt_form.php?resident_id=<?= (int)$c['resident_id'] ?>">Measure</a><?php endif; ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="10" class="empty">No children match.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
    <?= pagination_links($pg) ?>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
