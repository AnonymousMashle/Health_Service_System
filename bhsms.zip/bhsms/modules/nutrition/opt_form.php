<?php
/* Record one OPT+ / growth monitoring measurement (saved in child_monitoring, shared with Child Health) */
require __DIR__ . '/../../includes/init.php';
require_perm('nutrition', 'edit');

$m = ['resident_id' => get('resident_id'), 'visit_date' => today(), 'weight_kg' => '', 'height_cm' => '', 'muac_cm' => '',
      'nutrition_status' => '', 'milestones' => '', 'remarks' => '', 'next_visit' => ''];
$errors = [];
$children = child_options();

if (is_post()) {
    foreach (array_keys($m) as $k) { $m[$k] = input($k); }
    $child = q("SELECT * FROM residents WHERE resident_id = ? AND status = 'active'", [(int)$m['resident_id']])->fetch();
    if (!$child) {
        $errors[] = 'Choose a child.';
    }
    if (!valid_date($m['visit_date']) || $m['visit_date'] > today()) {
        $errors[] = 'Enter a valid measurement date (not in the future).';
    } elseif ($child && $m['visit_date'] < $child['birthdate']) {
        $errors[] = 'The measurement date is before the child was born.';
    }
    foreach (['weight_kg' => [0.5, 40, 'Weight'], 'height_cm' => [30, 130, 'Height / length'], 'muac_cm' => [6, 25, 'MUAC']] as $f => [$min, $max, $label]) {
        if ($m[$f] !== '' && (!is_numeric($m[$f]) || $m[$f] < $min || $m[$f] > $max)) {
            $errors[] = "$label must be between $min and $max.";
        }
    }
    if ($m['weight_kg'] === '') $errors[] = 'Weight is required for Operation Timbang.';
    if ($m['nutrition_status'] !== '' && !in_array($m['nutrition_status'], NUTRITION_STATUS, true)) $errors[] = 'Select a nutritional status.';
    if ($m['next_visit'] !== '' && (!valid_date($m['next_visit']) || $m['next_visit'] <= $m['visit_date'])) $errors[] = 'Next visit must be after the measurement date.';

    if (!$errors) {
        $data = [];
        foreach ($m as $k => $v) { $data[$k] = nullable($v); }
        $data['resident_id'] = (int)$m['resident_id'];
        $data['recorded_by'] = user_id();
        if ($data['nutrition_status'] === null) {
            $data['nutrition_status'] = muac_assessment($m['muac_cm'], age_months($child['birthdate']));
        }
        $rid = db_insert('child_monitoring', $data);
        $name = $child['first_name'] . ' ' . $child['last_name'];

        // Keep feeding-program beneficiaries up to date with the latest weight and status
        q("UPDATE program_beneficiaries SET latest_weight_kg = ?, latest_status = COALESCE(?, latest_status)
           WHERE resident_id = ? AND program_id IN (SELECT program_id FROM nutrition_programs WHERE status = 'ongoing')",
          [$data['weight_kg'], $data['nutrition_status'], $data['resident_id']]);

        if (in_array($data['nutrition_status'], SEVERE_STATUS, true)) {
            notify_roles(['nao', 'nurse'], 'Severe malnutrition', $name . ' (' . age_label($child['birthdate']) . ') was assessed as '
                . $data['nutrition_status'] . '. Refer for management.', 'modules/nutrition/child.php?id=' . $data['resident_id'], true);
        }
        log_activity('CREATE', 'child_monitoring', $rid, 'Recorded OPT measurement of ' . $name);
        flash('success', 'Measurement saved for ' . $name . ($data['nutrition_status'] ? ' — ' . $data['nutrition_status'] : '') . '.');
        redirect(input('next') === 'another' ? 'modules/nutrition/opt_form.php' : 'modules/nutrition/child.php?id=' . $data['resident_id']);
    }
}

$last = $m['resident_id'] !== '' ? q('SELECT * FROM child_monitoring WHERE resident_id = ? ORDER BY visit_date DESC, record_id DESC LIMIT 1', [(int)$m['resident_id']])->fetch() : null;

$page_title = 'Record Measurement';
$nav_active = 'modules/nutrition/opt.php';
$page_kicker = 'Operation Timbang Plus';
$back_url = $m['resident_id'] !== '' ? 'modules/nutrition/child.php?id=' . (int)$m['resident_id'] : 'modules/nutrition/opt.php';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<form method="post" class="card">
    <?= csrf_field() ?>
    <fieldset>
        <legend>Child</legend>
        <div class="form-grid">
            <?= select_field('Child (0–59 months)', 'resident_id', $children, $m['resident_id'], 'required class="searchable" data-placeholder="Search the child or the household head"', '-- Select --', 'span-2') ?>
            <?= field('Date measured', 'visit_date', $m['visit_date'], 'date', 'required max="' . today() . '"') ?>
        </div>
        <?php if ($last): ?><p class="hint">Last measurement: <?= fmt_date($last['visit_date']) ?> — <?= e($last['weight_kg']) ?> kg, <?= e($last['height_cm'] ?? '—') ?> cm<?= $last['nutrition_status'] ? ', ' . e($last['nutrition_status']) : '' ?>.</p><?php endif; ?>
        <?php if (!$children): ?><p class="alert alert-info">No children 0–59 months are registered. <a href="<?= e(url('modules/residents/form.php')) ?>">Register a resident</a> first.</p><?php endif; ?>
    </fieldset>
    <fieldset>
        <legend>Anthropometry</legend>
        <div class="form-grid">
            <?= field('Weight (kg)', 'weight_kg', $m['weight_kg'], 'number', 'required step="0.01" min="0.5" max="40"') ?>
            <?= field('Height / length (cm)', 'height_cm', $m['height_cm'], 'number', 'step="0.1" min="30" max="130"') ?>
            <?= field('MUAC (cm)', 'muac_cm', $m['muac_cm'], 'number', 'step="0.1" min="6" max="25" data-muac') ?>
            <?= select_field('Nutritional status', 'nutrition_status', array_combine(NUTRITION_STATUS, NUTRITION_STATUS), $m['nutrition_status'], '', '-- From MUAC / assess later --') ?>
        </div>
        <div class="muac-hint hint" id="muac-hint">MUAC cut-offs (6–59 months, WHO): below 11.5 cm = severe acute malnutrition, 11.5–12.4 cm = moderate, 12.5 cm and above = normal.
            Use the WHO Child Growth Standards chart for weight-for-age, height-for-age and weight-for-height.</div>
    </fieldset>
    <fieldset>
        <legend>Notes &amp; follow-up</legend>
        <div class="form-grid">
            <?= field('Milestones', 'milestones', $m['milestones'], 'text', 'maxlength="255"') ?>
            <?= field('Next weighing', 'next_visit', $m['next_visit'], 'date') ?>
            <?= field('Remarks / intervention', 'remarks', $m['remarks'], 'textarea', 'placeholder="e.g. Referred to RHU, enrolled in feeding program, counseling on complementary feeding"', 'full') ?>
        </div>
    </fieldset>
    <div class="form-actions">
        <a class="btn" href="<?= e(url($back_url)) ?>">Cancel</a>
        <button class="btn" name="next" value="another">Save &amp; measure another</button>
        <button class="btn btn-primary" name="next" value="view">Save measurement</button>
    </div>
</form>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
