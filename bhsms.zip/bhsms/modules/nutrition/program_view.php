<?php
/* One nutrition program: beneficiaries, feeding sessions and attendance */
require __DIR__ . '/../../includes/init.php';
require_perm('nutrition');

$id = (int)get('id');
$pr = q('SELECT np.*, u.full_name AS creator FROM nutrition_programs np LEFT JOIN users u ON u.user_id = np.created_by WHERE np.program_id = ?', [$id])->fetch();
if (!$pr) {
    flash('danger', 'Program not found.');
    redirect('modules/nutrition/programs.php');
}
$canEdit = can('nutrition', 'edit');
$here = 'modules/nutrition/program_view.php?id=' . $id;

if (is_post()) {
    require_perm('nutrition', 'edit');
    $action = input('action');

    if ($action === 'enrol') {
        $rid = (int)input('resident_id');
        $child = q("SELECT * FROM residents WHERE resident_id = ? AND status = 'active'", [$rid])->fetch();
        if (!$child) {
            flash('danger', 'Choose a resident to enrol.');
        } elseif (q('SELECT 1 FROM program_beneficiaries WHERE program_id = ? AND resident_id = ?', [$id, $rid])->fetchColumn()) {
            flash('warning', $child['first_name'] . ' is already enrolled in this program.');
        } else {
            $lm = q('SELECT * FROM child_monitoring WHERE resident_id = ? ORDER BY visit_date DESC, record_id DESC LIMIT 1', [$rid])->fetch();
            $bid = db_insert('program_beneficiaries', [
                'program_id' => $id, 'resident_id' => $rid, 'enrolled_date' => valid_date(input('enrolled_date')) ? input('enrolled_date') : today(),
                'baseline_weight_kg' => $lm['weight_kg'] ?? null, 'baseline_height_cm' => $lm['height_cm'] ?? null, 'baseline_status' => $lm['nutrition_status'] ?? null,
                'latest_weight_kg' => $lm['weight_kg'] ?? null, 'latest_status' => $lm['nutrition_status'] ?? null, 'created_by' => user_id(),
            ]);
            log_activity('CREATE', 'program_beneficiaries', $bid, 'Enrolled ' . $child['first_name'] . ' ' . $child['last_name'] . ' in ' . $pr['program_name']);
            flash('success', $child['first_name'] . ' ' . $child['last_name'] . ' enrolled' . ($lm ? ' (baseline from the ' . fmt_date($lm['visit_date']) . ' weighing).' : '. No weighing on record yet — record a baseline in OPT+.'));
        }
        redirect($here . '#beneficiaries');
    }

    if ($action === 'outcome') {
        $bid = (int)input('beneficiary_id');
        $outcome = input('outcome');
        if (in_array($outcome, ['enrolled', 'improved', 'rehabilitated', 'no change', 'worsened', 'dropped'], true)) {
            q('UPDATE program_beneficiaries SET outcome = ?, remarks = ? WHERE beneficiary_id = ? AND program_id = ?',
              [$outcome, nullable(mb_substr(input('remarks'), 0, 255)), $bid, $id]);
            log_activity('UPDATE', 'program_beneficiaries', $bid, 'Set outcome to ' . $outcome);
            flash('success', 'Outcome updated.');
        }
        redirect($here . '#beneficiaries');
    }

    if ($action === 'session') {
        $date = input('session_date');
        if (!valid_date($date) || $date > today()) {
            flash('danger', 'Enter a valid session date (not in the future).');
            redirect($here . '#sessions');
        }
        $existing = q('SELECT session_id FROM program_sessions WHERE program_id = ? AND session_date = ?', [$id, $date])->fetchColumn();
        db()->beginTransaction();
        if ($existing) {
            $sid = (int)$existing;
            q('UPDATE program_sessions SET menu = ?, notes = ? WHERE session_id = ?', [nullable(input('menu')), nullable(input('notes')), $sid]);
            q('DELETE FROM session_attendance WHERE session_id = ?', [$sid]);
        } else {
            $sid = db_insert('program_sessions', ['program_id' => $id, 'session_date' => $date, 'menu' => nullable(input('menu')),
                                                  'notes' => nullable(input('notes')), 'recorded_by' => user_id()]);
        }
        $valid = q('SELECT beneficiary_id FROM program_beneficiaries WHERE program_id = ?', [$id])->fetchAll(PDO::FETCH_COLUMN);
        $n = 0;
        foreach ((array)($_POST['present'] ?? []) as $bid) {
            $bid = (int)$bid;
            if (!in_array($bid, array_map('intval', $valid), true)) continue;
            $w = trim((string)($_POST['weight'][$bid] ?? ''));
            $w = (is_numeric($w) && $w > 0.5 && $w < 40) ? $w : null;
            db_insert('session_attendance', ['session_id' => $sid, 'beneficiary_id' => $bid, 'weight_kg' => $w]);
            if ($w !== null) {
                q('UPDATE program_beneficiaries SET latest_weight_kg = ? WHERE beneficiary_id = ?', [$w, $bid]);
            }
            $n++;
        }
        db()->commit();
        log_activity($existing ? 'UPDATE' : 'CREATE', 'program_sessions', $sid, 'Recorded session ' . $date . " ($n attended)");
        flash('success', 'Session on ' . fmt_date($date) . " saved — $n attended.");
        redirect($here . '#sessions');
    }
}

$benef = q('SELECT b.*, r.first_name, r.middle_name, r.last_name, r.suffix, r.birthdate, r.sex, h.purok,
                   (SELECT COUNT(*) FROM session_attendance sa WHERE sa.beneficiary_id = b.beneficiary_id) AS attended
            FROM program_beneficiaries b JOIN residents r ON r.resident_id = b.resident_id
            LEFT JOIN households h ON h.household_id = r.household_id
            WHERE b.program_id = ? ORDER BY b.outcome = \'dropped\', r.last_name, r.first_name', [$id])->fetchAll();
$sessions = q('SELECT s.*, (SELECT COUNT(*) FROM session_attendance sa WHERE sa.session_id = s.session_id) AS attendees
               FROM program_sessions s WHERE s.program_id = ? ORDER BY s.session_date DESC', [$id])->fetchAll();
$active = array_values(array_filter($benef, function ($b) { return $b['outcome'] !== 'dropped'; }));
$gain = [];
foreach ($active as $b) {
    if ($b['baseline_weight_kg'] !== null && $b['latest_weight_kg'] !== null) {
        $gain[] = $b['latest_weight_kg'] - $b['baseline_weight_kg'];
    }
}
$avgGain = $gain ? array_sum($gain) / count($gain) : null;
$enrolledIds = array_column($benef, 'resident_id');
$candidates = array_diff_key(child_options(), array_flip($enrolledIds));

$page_title = $pr['program_name'];
$nav_active = 'modules/nutrition/programs.php';
$page_kicker = 'Feeding Program';
$back_url = 'modules/nutrition/programs.php';
require __DIR__ . '/../../includes/header.php';
?>
<div class="page-head">
    <div>
        <h2><?= e($pr['program_name']) ?> <?= badge($pr['status']) ?></h2>
        <div class="muted"><?= e($pr['program_type']) ?> &middot; <?= fmt_date($pr['start_date']) ?> – <?= fmt_date($pr['end_date']) ?>
            <?= $pr['venue'] ? ' &middot; ' . e($pr['venue']) : '' ?><?= $pr['funding_source'] ? ' &middot; Funded by ' . e($pr['funding_source']) : '' ?></div>
        <?php if ($pr['description']): ?><p class="small"><?= nl2br(e($pr['description'])) ?></p><?php endif; ?>
    </div>
    <div class="btn-group no-print">
        <?php if (can('nutrition', 'manage')): ?><a class="btn" href="programs.php?edit=<?= $id ?>">Edit program</a><?php endif; ?>
        <button class="btn" data-print>Print</button>
    </div>
</div>

<div class="stats">
    <div class="stat"><div class="label">Beneficiaries</div><div class="value"><?= count($active) ?></div><div class="sub"><?= e($pr['target_group'] ?: '') ?></div></div>
    <div class="stat blue"><div class="label">Sessions held</div><div class="value"><?= count($sessions) ?><?= $pr['sessions_planned'] ? '<small> / ' . (int)$pr['sessions_planned'] . '</small>' : '' ?></div></div>
    <div class="stat purple"><div class="label">Improved / rehabilitated</div><div class="value"><?= count(array_filter($active, function ($b) { return in_array($b['outcome'], ['improved', 'rehabilitated'], true); })) ?></div></div>
    <div class="stat amber"><div class="label">Average weight gain</div><div class="value"><?= $avgGain === null ? '—' : sprintf('%+.2f', $avgGain) . '<small> kg</small>' ?></div></div>
</div>

<div class="card" id="beneficiaries">
    <div class="card-header">
        <h3>Beneficiaries</h3>
        <?php if ($canEdit): ?>
        <form method="post" class="toolbar" style="margin:0">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="enrol">
            <div class="grow" style="min-width:300px"><select name="resident_id" class="searchable" required data-placeholder="Search a child or household head"><?= options($candidates, '', '-- Choose child to enrol --') ?></select></div>
            <input type="date" name="enrolled_date" value="<?= today() ?>" max="<?= today() ?>">
            <button class="btn btn-primary">Enrol</button>
        </form>
        <?php endif; ?>
    </div>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Child</th><th>Age</th><th>Enrolled</th><th>Baseline</th><th>Latest</th><th class="num">Change</th><th class="num">Attended</th><th>Outcome</th></tr></thead>
        <tbody>
        <?php foreach ($benef as $b): $d = ($b['baseline_weight_kg'] !== null && $b['latest_weight_kg'] !== null) ? $b['latest_weight_kg'] - $b['baseline_weight_kg'] : null; ?>
            <tr class="<?= $b['outcome'] === 'dropped' ? 'row-muted' : '' ?>">
                <td><a href="child.php?id=<?= (int)$b['resident_id'] ?>"><strong><?= e(full_name($b)) ?></strong></a><div class="small muted"><?= e($b['purok'] ?? '') ?></div></td>
                <td class="nowrap small"><?= e(age_label($b['birthdate'])) ?></td>
                <td class="small nowrap"><?= fmt_date($b['enrolled_date']) ?></td>
                <td class="small"><?= e($b['baseline_weight_kg'] ?? '—') ?> kg<br><?= $b['baseline_status'] ? badge($b['baseline_status']) : '' ?></td>
                <td class="small"><?= e($b['latest_weight_kg'] ?? '—') ?> kg<br><?= $b['latest_status'] ? badge($b['latest_status']) : '' ?></td>
                <td class="num <?= $d === null ? '' : ($d >= 0 ? 'text-success' : 'text-danger') ?>"><?= $d === null ? '—' : sprintf('%+.2f', $d) ?></td>
                <td class="num"><?= (int)$b['attended'] ?></td>
                <td>
                    <?php if ($canEdit): ?>
                        <form method="post" class="inline-form">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="outcome"><input type="hidden" name="beneficiary_id" value="<?= (int)$b['beneficiary_id'] ?>">
                            <input type="hidden" name="remarks" value="<?= e($b['remarks']) ?>">
                            <select name="outcome" onchange="this.form.submit()"><?= options(['enrolled' => 'Enrolled', 'improved' => 'Improved', 'rehabilitated' => 'Rehabilitated', 'no change' => 'No change', 'worsened' => 'Worsened', 'dropped' => 'Dropped'], $b['outcome'], false) ?></select>
                        </form>
                    <?php else: ?><?= badge($b['outcome']) ?><?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$benef): ?><tr><td colspan="8" class="empty">No beneficiaries yet. Enrol children from the OPT+ list (underweight, wasted or stunted).</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div>

<div class="grid <?= $canEdit && $active ? 'cols-3-1' : '' ?>" id="sessions">
    <div class="card">
        <h3>Sessions</h3>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Date</th><th>Menu / topic</th><th class="num">Attended</th><th>Notes</th></tr></thead>
            <tbody>
            <?php foreach ($sessions as $s): ?>
                <tr>
                    <td class="nowrap"><?= fmt_date($s['session_date'], 'D, M j, Y') ?></td>
                    <td><?= e($s['menu'] ?: '—') ?></td>
                    <td class="num"><?= (int)$s['attendees'] ?> / <?= count($active) ?></td>
                    <td class="small"><?= e($s['notes']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$sessions): ?><tr><td colspan="4" class="empty">No sessions recorded yet.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>
    <?php if ($canEdit && $active): ?>
    <div class="card">
        <h3>Record a session</h3>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="session">
            <div class="form-grid one">
                <?= field('Date', 'session_date', today(), 'date', 'required max="' . today() . '"') ?>
                <?= field('Menu / topic', 'menu', '', 'text', 'maxlength="255" placeholder="e.g. Arroz caldo with egg, banana"') ?>
                <?= field('Notes', 'notes', '', 'text', 'maxlength="255"') ?>
            </div>
            <div class="attend-list">
                <label class="check"><input type="checkbox" data-check-all="present[]" checked> <strong>All present</strong></label>
                <?php foreach ($active as $b): ?>
                    <div class="attend-row">
                        <label class="check"><input type="checkbox" name="present[]" value="<?= (int)$b['beneficiary_id'] ?>" checked> <?= e($b['first_name'] . ' ' . $b['last_name']) ?></label>
                        <input type="number" name="weight[<?= (int)$b['beneficiary_id'] ?>]" step="0.01" min="0.5" max="40" placeholder="kg">
                    </div>
                <?php endforeach; ?>
            </div>
            <p class="hint">Weight is optional. Saving a date that already has a session replaces its attendance.</p>
            <div class="form-actions"><button class="btn btn-primary">Save session</button></div>
        </form>
    </div>
    <?php endif; ?>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
