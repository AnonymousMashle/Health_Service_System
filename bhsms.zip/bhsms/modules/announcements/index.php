<?php
/*
 * Announcements & health advisories. Published ones appear on the public homepage (with category and month filters)
 * and on the resident portal. Admin, nurse and MHO can post; other staff can read.
 */
require __DIR__ . '/../../includes/init.php';
require_perm('announcements');

$errors = [];
$edit = null;
$id = (int)get('edit');
$blank = ['announcement_id' => 0, 'title' => '', 'category' => 'Health Advisory', 'body' => '', 'publish_date' => today(), 'expiry_date' => '', 'is_published' => 1, 'is_pinned' => 0];

if (is_post()) {
    require_perm('announcements', 'edit');
    $action = input('action');
    if ($action === 'save') {
        $edit = $blank;
        foreach (['announcement_id', 'title', 'category', 'body', 'publish_date', 'expiry_date'] as $k) { $edit[$k] = input($k); }
        $edit['is_published'] = isset($_POST['is_published']) ? 1 : 0;
        $edit['is_pinned'] = isset($_POST['is_pinned']) ? 1 : 0;
        if ($edit['title'] === '') $errors[] = 'Enter a title.';
        if (!in_array($edit['category'], ANNOUNCEMENT_CATEGORIES, true)) $errors[] = 'Choose a category.';
        if (mb_strlen($edit['body']) < 10) $errors[] = 'Write the announcement text.';
        if (!valid_date($edit['publish_date'])) $errors[] = 'Enter the publish date.';
        if ($edit['expiry_date'] !== '' && (!valid_date($edit['expiry_date']) || $edit['expiry_date'] < $edit['publish_date'])) $errors[] = 'The end date must be on or after the publish date.';
        if (!$errors) {
            $data = ['title' => mb_substr($edit['title'], 0, 150), 'category' => $edit['category'], 'body' => $edit['body'], 'publish_date' => $edit['publish_date'],
                     'expiry_date' => nullable($edit['expiry_date']), 'is_published' => $edit['is_published'], 'is_pinned' => $edit['is_pinned']];
            $aid = (int)$edit['announcement_id'];
            if ($aid) {
                db_update('announcements', $data, 'announcement_id', $aid);
                log_activity('UPDATE', 'announcements', $aid, 'Updated announcement: ' . $data['title']);
            } else {
                $aid = db_insert('announcements', $data + ['created_by' => user_id()]);
                log_activity('CREATE', 'announcements', $aid, 'Posted announcement: ' . $data['title']);
                // Health advisories and vaccination drives also go to every resident's notifications
                if ($data['is_published'] && $data['publish_date'] <= today() && in_array($data['category'], ['Health Advisory', 'Vaccination Drive', 'Schedule Change'], true)) {
                    notify_roles(['resident'], $data['category'], $data['title'], 'portal/index.php');
                }
            }
            flash('success', 'Announcement saved' . ($data['is_published'] ? ' and published on the homepage.' : ' as a draft.'));
            redirect('modules/announcements/index.php');
        }
    }
    if ($action === 'toggle' || $action === 'delete') {
        $a = q('SELECT * FROM announcements WHERE announcement_id = ?', [(int)input('announcement_id')])->fetch();
        if ($a && $action === 'toggle') {
            q('UPDATE announcements SET is_published = 1 - is_published WHERE announcement_id = ?', [$a['announcement_id']]);
            log_activity('UPDATE', 'announcements', $a['announcement_id'], ($a['is_published'] ? 'Unpublished: ' : 'Published: ') . $a['title']);
            flash('success', $a['is_published'] ? 'Announcement hidden from the homepage.' : 'Announcement published.');
        }
        if ($a && $action === 'delete') {
            q('DELETE FROM announcements WHERE announcement_id = ?', [$a['announcement_id']]);
            log_activity('DELETE', 'announcements', $a['announcement_id'], 'Deleted announcement: ' . $a['title']);
            flash('success', 'Announcement deleted.');
        }
        redirect('modules/announcements/index.php');
    }
}
if (!$edit && $id) {
    $edit = q('SELECT * FROM announcements WHERE announcement_id = ?', [$id])->fetch() ?: null;
    if ($edit) $edit = array_map(function ($x) { return $x ?? ''; }, $edit);
}
$edit = $edit ?? $blank;

$category = get('category');
$state = get('state');
$where = ['1=1'];
$params = [];
if (in_array($category, ANNOUNCEMENT_CATEGORIES, true)) { $where[] = 'a.category = ?'; $params[] = $category; }
if ($state === 'live') $where[] = 'a.is_published = 1 AND a.publish_date <= CURDATE() AND (a.expiry_date IS NULL OR a.expiry_date >= CURDATE())';
if ($state === 'draft') $where[] = 'a.is_published = 0';
if ($state === 'ended') $where[] = 'a.expiry_date < CURDATE()';
$rows = q('SELECT a.*, u.full_name AS author FROM announcements a LEFT JOIN users u ON u.user_id = a.created_by WHERE ' . implode(' AND ', $where)
          . ' ORDER BY a.is_pinned DESC, a.publish_date DESC, a.announcement_id DESC LIMIT 200', $params)->fetchAll();

$page_title = 'Announcements & Advisories';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<div class="grid <?= can('announcements', 'edit') ? 'cols-3-1' : '' ?>">
    <div class="card">
        <div class="card-header"><h3>Posted announcements</h3><a class="btn btn-sm" href="<?= e(url('index.php#news')) ?>" target="_blank">View homepage</a></div>
        <form class="toolbar" method="get">
            <div><label>Category</label><select name="category"><?= options(ANNOUNCEMENT_CATEGORIES, $category, 'All') ?></select></div>
            <div><label>Show</label><select name="state"><?= options(['live' => 'Live on homepage', 'draft' => 'Drafts (hidden)', 'ended' => 'Ended'], $state, 'All') ?></select></div>
            <button class="btn">Filter</button><a class="btn" href="index.php">Reset</a>
        </form>
        <div class="ann-list">
        <?php foreach ($rows as $a):
            $live = $a['is_published'] && $a['publish_date'] <= today() && (!$a['expiry_date'] || $a['expiry_date'] >= today()); ?>
            <div class="ann <?= $a['is_pinned'] ? 'pinned' : '' ?>">
                <div class="meta"><span class="badge badge-blue"><?= e($a['category']) ?></span>
                    <?= $live ? badge('published') : ($a['is_published'] ? '<span class="badge badge-gray">' . ($a['publish_date'] > today() ? 'Scheduled' : 'Ended') . '</span>' : badge('draft')) ?>
                    <?= $a['is_pinned'] ? badge('pinned') : '' ?>
                    <span><?= fmt_date($a['publish_date']) ?><?= $a['expiry_date'] ? ' – ' . fmt_date($a['expiry_date']) : '' ?></span><span>by <?= e($a['author'] ?: '—') ?></span></div>
                <h3><?= e($a['title']) ?></h3>
                <p><?= e($a['body']) ?></p>
                <?php if (can('announcements', 'edit')): ?>
                    <div class="btn-group" style="margin-top:10px">
                        <a class="btn btn-sm" href="?edit=<?= (int)$a['announcement_id'] ?>">Edit</a>
                        <?= post_button('index.php', $a['is_published'] ? 'Unpublish' : 'Publish', ['action' => 'toggle', 'announcement_id' => $a['announcement_id']]) ?>
                        <?= post_button('index.php', 'Delete', ['action' => 'delete', 'announcement_id' => $a['announcement_id']], 'btn btn-sm btn-danger', 'Delete this announcement?') ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
        <?php if (!$rows): ?><p class="muted">No announcements found.</p><?php endif; ?>
        </div>
    </div>
    <?php if (can('announcements', 'edit')): ?>
    <form method="post" class="card">
        <h3><?= $edit['announcement_id'] ? 'Edit announcement' : 'New announcement' ?></h3>
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="announcement_id" value="<?= (int)$edit['announcement_id'] ?>">
        <div class="form-grid one">
            <?= field('Title', 'title', $edit['title'], 'text', 'required maxlength="150"') ?>
            <?= select_field('Category', 'category', ANNOUNCEMENT_CATEGORIES, $edit['category'], 'required', false) ?>
            <?= field('Message', 'body', $edit['body'], 'textarea', 'required rows="6"') ?>
            <?= field('Publish date', 'publish_date', $edit['publish_date'], 'date', 'required') ?>
            <?= field('Show until (optional)', 'expiry_date', $edit['expiry_date'], 'date') ?>
            <?= checkbox('Published (visible on the homepage)', 'is_published', $edit['is_published']) ?>
            <?= checkbox('Pin to the top', 'is_pinned', $edit['is_pinned']) ?>
        </div>
        <p class="hint">New health advisories, vaccination drives and schedule changes are also sent to residents' notifications.</p>
        <div class="form-actions">
            <?php if ($edit['announcement_id']): ?><a class="btn" href="index.php">Cancel</a><?php endif; ?>
            <button class="btn btn-primary">Save</button>
        </div>
    </form>
    <?php endif; ?>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
