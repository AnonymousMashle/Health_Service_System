<?php
require __DIR__ . '/../../includes/init.php';
require_perm('vaccinations');

const TARGET_GROUPS = ['Infant', 'Child', 'Adult', 'Pregnant', 'Senior', 'All'];

// ----- Vaccine master list (nurse / admin) -----
$errors = [];
$editVaccine = null;
if (is_post() && input('action') === 'save_vaccine') {
    require_perm('vaccinations', 'manage');
    $vid = (int)input('vaccine_id');
    $v = [
        'vaccine_name' => input('vaccine_name'), 'description' => input('description'), 'target_group' => input('target_group'),
        'doses_required' => input('doses_required'), 'interval_days' => input('interval_days'), 'is_active' => isset($_POST['is_active']) ? 1 : 0,
    ];
    if ($v['vaccine_name'] === '') $errors[] = 'Enter the vaccine name.';
    if (!in_array($v['target_group'], TARGET_GROUPS, true)) $errors[] = 'Choose the target group.';
    if (!ctype_digit((string)$v['doses_required']) || $v['doses_required'] < 1 || $v['doses_required'] > 10) $errors[] = 'Doses required must be 1 to 10.';
    if ($v['interval_days'] !== '' && (!ctype_digit((string)$v['interval_days']) || $v['interval_days'] < 1 || $v['interval_days'] > 3650)) $errors[] = 'Interval must be 1 to 3650 days.';
    if (!$errors) {
        $v['description'] = nullable($v['description']);
        $v['interval_days'] = nullable($v['interval_days']);
        try {
            if ($vid) {
                db_update('vaccines', $v, 'vaccine_id', $vid);
                log_activity('UPDATE', 'vaccines', $vid, 'Updated vaccine ' . $v['vaccine_name']);
            } else {
                $vid = db_insert('vaccines', $v);
                log_activity('CREATE', 'vaccines', $vid, 'Added vaccine ' . $v['vaccine_name']);
            }
            flash('success', 'Vaccine saved: ' . $v['vaccine_name'] . '.');
            redirect('modules/vaccinations/index.php?tab=vaccines');
        } catch (PDOException $e) {
            if (!is_duplicate_error($e)) throw $e;
            $errors[] = 'A vaccine with that name already exists.';
        }
    }
    $editVaccine = $v + ['vaccine_id' => $vid];
}

$tab = in_array(get('tab'), ['records', 'due', 'vaccines'], true) ? get('tab') : 'records';
if ($errors) $tab = 'vaccines';

// Counts for the tiles
$dueBase = due_vaccinations_sql();
$overdue = (int)q("SELECT COUNT(*) FROM ($dueBase AND v.next_schedule < CURDATE()) x")->fetchColumn();
$due7 = (int)q("SELECT COUNT(*) FROM ($dueBase AND v.next_schedule BETWEEN CURDATE() AND CURDATE() + INTERVAL 7 DAY) x")->fetchColumn();
$month = (int)q("SELECT COUNT(*) FROM vaccinations WHERE DATE_FORMAT(date_given, '%Y-%m') = DATE_FORMAT(CURDATE(), '%Y-%m')")->fetchColumn();

$rows = [];
$pg = null;
if ($tab === 'records') {
    $search = get('q');
    $vaccineId = get('vaccine_id');
    [$from, $to] = [get('from'), get('to')];
    $where = ['1=1'];
    $params = [];
    if ($search !== '') { $where[] = "CONCAT(r.first_name, ' ', r.last_name) LIKE ?"; $params[] = '%' . $search . '%'; }
    if ($vaccineId !== '') { $where[] = 'v.vaccine_id = ?'; $params[] = (int)$vaccineId; }
    if (valid_date($from)) { $where[] = 'v.date_given >= ?'; $params[] = $from; }
    if (valid_date($to)) { $where[] = 'v.date_given <= ?'; $params[] = $to; }
    $w = implode(' AND ', $where);
    $base = 'FROM vaccinations v JOIN vaccines vc ON vc.vaccine_id = v.vaccine_id JOIN residents r ON r.resident_id = v.resident_id LEFT JOIN users u ON u.user_id = v.administered_by';
    $pg = paginate((int)q("SELECT COUNT(*) $base WHERE $w", $params)->fetchColumn());
    $rows = q("SELECT v.*, vc.vaccine_name, vc.doses_required, r.first_name, r.middle_name, r.last_name, r.suffix, r.birthdate, u.full_name AS giver
               $base WHERE $w ORDER BY v.date_given DESC, v.vaccination_id DESC LIMIT {$pg['per']} OFFSET {$pg['offset']}", $params)->fetchAll();
} elseif ($tab === 'due') {
    $range = get('range', '30');
    $cond = $range === 'overdue' ? 'AND v.next_schedule < CURDATE()' : 'AND v.next_schedule <= CURDATE() + INTERVAL ' . ($range === '7' ? 7 : 30) . ' DAY';
    $rows = q("$dueBase $cond ORDER BY v.next_schedule")->fetchAll();
}
$vaccines = q('SELECT vc.*, (SELECT COUNT(*) FROM vaccinations v WHERE v.vaccine_id = vc.vaccine_id) AS given FROM vaccines vc ORDER BY vc.is_active DESC, vc.vaccine_name')->fetchAll();
if (!$editVaccine && get('edit_vaccine') !== '') {
    foreach ($vaccines as $vc) {
        if ((int)$vc['vaccine_id'] === (int)get('edit_vaccine')) $editVaccine = $vc;
    }
    $tab = 'vaccines';
}

$page_title = 'Vaccinations';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<div class="stats">
    <a class="stat <?= $overdue ? 'red' : '' ?>" href="?tab=due&amp;range=overdue"><div class="label">Overdue doses</div><div class="value"><?= $overdue ?></div></a>
    <a class="stat amber" href="?tab=due&amp;range=7"><div class="label">Due in 7 days</div><div class="value"><?= $due7 ?></div></a>
    <div class="stat blue"><div class="label">Doses given this month</div><div class="value"><?= $month ?></div></div>
</div>

<div class="tabs">
    <a class="<?= $tab === 'records' ? 'active' : '' ?>" href="?tab=records">Vaccination records</a>
    <a class="<?= $tab === 'due' ? 'active' : '' ?>" href="?tab=due">Due &amp; overdue</a>
    <a class="<?= $tab === 'vaccines' ? 'active' : '' ?>" href="?tab=vaccines">Vaccine list</a>
</div>

<?php if ($tab === 'records'): ?>
<div class="card">
    <div class="card-header"><h3>Doses given</h3>
        <?php if (can('vaccinations', 'edit')): ?><a class="btn btn-primary" href="form.php">+ Record vaccination</a><?php endif; ?></div>
    <form class="toolbar" method="get">
        <input type="hidden" name="tab" value="records">
        <div class="grow"><label>Search</label><input type="search" name="q" value="<?= e($search) ?>" placeholder="Resident name"></div>
        <div><label>Vaccine</label><select name="vaccine_id"><?= options(array_column($vaccines, 'vaccine_name', 'vaccine_id'), $vaccineId, 'All') ?></select></div>
        <div><label>From</label><input type="date" name="from" value="<?= e($from) ?>"></div>
        <div><label>To</label><input type="date" name="to" value="<?= e($to) ?>"></div>
        <button class="btn">Filter</button><a class="btn" href="?tab=records">Reset</a>
    </form>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Date given</th><th>Resident</th><th>Vaccine</th><th>Dose</th><th>Lot no.</th><th>Next schedule</th><th>Given by</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $v): ?>
            <tr>
                <td class="nowrap"><?= fmt_date($v['date_given']) ?></td>
                <td><a href="<?= e(url('modules/residents/view.php?id=' . $v['resident_id'] . '#vaccinations')) ?>"><?= e(full_name($v)) ?></a> <span class="small muted"><?= e(age_label($v['birthdate'])) ?></span></td>
                <td><?= e($v['vaccine_name']) ?></td>
                <td><?= (int)$v['dose_no'] ?> of <?= (int)$v['doses_required'] ?></td>
                <td class="small"><?= e($v['batch_lot_no'] ?: '—') ?></td>
                <td class="nowrap"><?= $v['next_schedule'] ? fmt_date($v['next_schedule']) : '<span class="muted">—</span>' ?></td>
                <td class="small"><?= e($v['giver'] ?: '—') ?></td>
                <td class="actions"><?php if (can('vaccinations', 'edit')): ?><a class="btn btn-sm" href="form.php?id=<?= (int)$v['vaccination_id'] ?>">Edit</a><?php endif; ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="8" class="empty">No vaccinations found.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
    <?= pagination_links($pg) ?>
</div>

<?php elseif ($tab === 'due'): ?>
<div class="card">
    <div class="card-header"><h3>Next doses not yet given</h3>
        <div class="btn-group">
            <a class="btn btn-sm <?= $range === 'overdue' ? 'btn-primary' : '' ?>" href="?tab=due&amp;range=overdue">Overdue</a>
            <a class="btn btn-sm <?= $range === '7' ? 'btn-primary' : '' ?>" href="?tab=due&amp;range=7">Next 7 days</a>
            <a class="btn btn-sm <?= !in_array($range, ['overdue', '7'], true) ? 'btn-primary' : '' ?>" href="?tab=due&amp;range=30">Next 30 days + overdue</a>
            <button class="btn btn-sm" data-print>Print list</button>
        </div></div>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Due date</th><th>Resident</th><th>Age</th><th>Contact</th><th>Vaccine</th><th>Next dose</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $v): $late = $v['next_schedule'] < today(); ?>
            <tr class="<?= $late ? 'row-danger' : '' ?>">
                <td class="nowrap"><?= fmt_date($v['next_schedule']) ?> <?= $late ? badge('overdue') : '' ?></td>
                <td><a href="<?= e(url('modules/residents/view.php?id=' . $v['resident_id'])) ?>"><?= e(full_name($v)) ?></a></td>
                <td class="nowrap"><?= e(age_label($v['birthdate'])) ?></td>
                <td><?= e($v['contact_no'] ?: '—') ?></td>
                <td><?= e($v['vaccine_name']) ?></td>
                <td><?= (int)$v['dose_no'] + 1 ?> of <?= (int)$v['doses_required'] ?></td>
                <td class="actions"><?php if (can('vaccinations', 'edit')): ?><a class="btn btn-sm btn-primary" href="form.php?resident_id=<?= (int)$v['resident_id'] ?>&amp;vaccine_id=<?= (int)$v['vaccine_id'] ?>">Record dose</a><?php endif; ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="7" class="empty">Nothing due.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div>

<?php else: ?>
<div class="grid <?= can('vaccinations', 'manage') ? 'cols-3-1' : '' ?>">
    <div class="card">
        <h3>Vaccines (DOH immunization program)</h3>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Vaccine</th><th>Target</th><th class="num">Doses</th><th class="num">Interval</th><th class="num">Given</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($vaccines as $vc): ?>
                <tr class="<?= $vc['is_active'] ? '' : 'row-muted' ?>">
                    <td><strong><?= e($vc['vaccine_name']) ?></strong><div class="small muted"><?= e($vc['description']) ?></div></td>
                    <td><?= e($vc['target_group']) ?></td>
                    <td class="num"><?= (int)$vc['doses_required'] ?></td>
                    <td class="num"><?= $vc['interval_days'] ? (int)$vc['interval_days'] . ' days' : '—' ?></td>
                    <td class="num"><?= (int)$vc['given'] ?></td>
                    <td><?= badge($vc['is_active'] ? 'active' : 'inactive') ?></td>
                    <td class="actions"><?php if (can('vaccinations', 'manage')): ?><a class="btn btn-sm" href="?tab=vaccines&amp;edit_vaccine=<?= (int)$vc['vaccine_id'] ?>">Edit</a><?php endif; ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
    </div>
    <?php if (can('vaccinations', 'manage')): $ev = $editVaccine ?? ['vaccine_id' => 0, 'vaccine_name' => '', 'description' => '', 'target_group' => 'Infant', 'doses_required' => 1, 'interval_days' => '', 'is_active' => 1]; ?>
    <form method="post" class="card">
        <h3><?= $ev['vaccine_id'] ? 'Edit vaccine' : 'Add vaccine' ?></h3>
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save_vaccine">
        <input type="hidden" name="vaccine_id" value="<?= (int)$ev['vaccine_id'] ?>">
        <div class="form-grid one">
            <?= field('Vaccine name', 'vaccine_name', $ev['vaccine_name'], 'text', 'required maxlength="100"') ?>
            <?= field('Description', 'description', $ev['description'], 'text', 'maxlength="255"') ?>
            <?= select_field('Target group', 'target_group', TARGET_GROUPS, $ev['target_group'], 'required', false) ?>
            <?= field('Doses required', 'doses_required', $ev['doses_required'], 'number', 'required min="1" max="10"') ?>
            <?= field('Days between doses', 'interval_days', $ev['interval_days'], 'number', 'min="1" max="3650" placeholder="Used to compute the next schedule"') ?>
            <?= checkbox('Active (can be recorded)', 'is_active', $ev['is_active']) ?>
        </div>
        <div class="form-actions">
            <?php if ($ev['vaccine_id']): ?><a class="btn" href="?tab=vaccines">Cancel</a><?php endif; ?>
            <button class="btn btn-primary">Save vaccine</button>
        </div>
    </form>
    <?php endif; ?>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
