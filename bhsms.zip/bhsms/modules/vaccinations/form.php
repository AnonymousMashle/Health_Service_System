<?php
/*
 * Record (or edit) a vaccine dose.
 * Automatic: dose number = last dose + 1; next schedule = date given + the vaccine's interval
 * while the series is not complete. The resident is notified of the next schedule.
 */
require __DIR__ . '/../../includes/init.php';
require_perm('vaccinations', 'edit');

$id = (int)get('id');
$v = ['resident_id' => get('resident_id'), 'vaccine_id' => get('vaccine_id'), 'dose_no' => '', 'date_given' => today(),
      'next_schedule' => '', 'batch_lot_no' => '', 'site_given' => '', 'remarks' => ''];
if ($id) {
    $row = q('SELECT * FROM vaccinations WHERE vaccination_id = ?', [$id])->fetch();
    if (!$row) {
        flash('danger', 'Vaccination record not found.');
        redirect('modules/vaccinations/index.php');
    }
    $v = array_map(function ($x) { return $x ?? ''; }, $row);
}

if (is_post() && $id && input('action') === 'delete') {
    require_perm('vaccinations', 'manage');
    q('DELETE FROM vaccinations WHERE vaccination_id = ?', [$id]);
    log_activity('DELETE', 'vaccinations', $id, 'Deleted vaccination record');
    flash('success', 'Vaccination record deleted.');
    redirect('modules/residents/view.php?id=' . (int)$v['resident_id'] . '#vaccinations');
}

$errors = [];
if (is_post()) {
    foreach (array_keys($v) as $k) {
        if (array_key_exists($k, $_POST)) $v[$k] = input($k);
    }
    $vaccine = q('SELECT * FROM vaccines WHERE vaccine_id = ?', [(int)$v['vaccine_id']])->fetch();
    if (!q("SELECT 1 FROM residents WHERE resident_id = ? AND status = 'active'", [(int)$v['resident_id']])->fetchColumn()) $errors[] = 'Choose the resident.';
    if (!$vaccine) $errors[] = 'Choose the vaccine.';
    if (!valid_date($v['date_given'])) {
        $errors[] = 'Enter the date given.';
    } elseif ($v['date_given'] > today()) {
        $errors[] = 'The date given cannot be in the future.';
    }
    if ($v['dose_no'] !== '' && (!ctype_digit((string)$v['dose_no']) || $v['dose_no'] < 1 || $v['dose_no'] > 20)) $errors[] = 'Dose number must be 1 to 20.';
    if ($v['next_schedule'] !== '' && (!valid_date($v['next_schedule']) || ($v['date_given'] !== '' && $v['next_schedule'] <= $v['date_given']))) {
        $errors[] = 'The next schedule must be a date after the date given.';
    }

    if (!$errors) {
        // Automatic dose number
        if ($v['dose_no'] === '') {
            $v['dose_no'] = (int)q('SELECT COALESCE(MAX(dose_no), 0) + 1 FROM vaccinations WHERE resident_id = ? AND vaccine_id = ? AND vaccination_id <> ?',
                                   [(int)$v['resident_id'], (int)$v['vaccine_id'], $id])->fetchColumn();
        }
        // Automatic next schedule while the series is incomplete
        $auto = false;
        if ($v['next_schedule'] === '' && (int)$v['dose_no'] < (int)$vaccine['doses_required'] && $vaccine['interval_days']) {
            $v['next_schedule'] = date('Y-m-d', strtotime($v['date_given'] . ' +' . (int)$vaccine['interval_days'] . ' days'));
            $auto = true;
        }
        $data = [
            'resident_id' => (int)$v['resident_id'], 'vaccine_id' => (int)$v['vaccine_id'], 'dose_no' => (int)$v['dose_no'], 'date_given' => $v['date_given'],
            'next_schedule' => nullable($v['next_schedule']), 'batch_lot_no' => nullable($v['batch_lot_no']), 'site_given' => nullable($v['site_given']),
            'remarks' => nullable($v['remarks']),
        ];
        try {
            if ($id) {
                db_update('vaccinations', $data, 'vaccination_id', $id);
                log_activity('UPDATE', 'vaccinations', $id, 'Updated ' . $vaccine['vaccine_name'] . ' dose ' . $data['dose_no']);
            } else {
                $data['administered_by'] = user_id();
                $id = db_insert('vaccinations', $data);
                log_activity('CREATE', 'vaccinations', $id, 'Gave ' . $vaccine['vaccine_name'] . ' dose ' . $data['dose_no']);
                if ($data['next_schedule']) {
                    notify_resident($data['resident_id'], 'Next vaccine schedule',
                        $vaccine['vaccine_name'] . ' dose ' . ($data['dose_no'] + 1) . ' is due on ' . fmt_date($data['next_schedule']) . '.');
                }
            }
            $msg = $vaccine['vaccine_name'] . ' dose ' . $data['dose_no'] . ' saved.';
            if ($data['next_schedule']) {
                $msg .= ' Next dose: ' . fmt_date($data['next_schedule']) . ($auto ? ' (computed automatically).' : '.');
            } elseif ($data['dose_no'] >= (int)$vaccine['doses_required']) {
                $msg .= ' The series is complete.';
            }
            flash('success', $msg);
            redirect('modules/residents/view.php?id=' . $data['resident_id'] . '#vaccinations');
        } catch (PDOException $e) {
            if (!is_duplicate_error($e)) throw $e;
            $errors[] = 'Dose ' . $data['dose_no'] . ' of this vaccine is already recorded for this resident.';
        }
    }
}

$vaccineList = [];
foreach (q('SELECT * FROM vaccines WHERE is_active = 1 OR vaccine_id = ? ORDER BY vaccine_name', [(int)$v['vaccine_id']])->fetchAll() as $vc) {
    $vaccineList[$vc['vaccine_id']] = $vc['vaccine_name'] . ' (' . $vc['doses_required'] . ' dose' . ($vc['doses_required'] > 1 ? 's' : '')
        . ($vc['interval_days'] ? ', every ' . $vc['interval_days'] . ' days' : '') . ')';
}
// Doses already given for the chosen resident (helps the health worker)
$history = ($v['resident_id'] !== '')
    ? q('SELECT v.dose_no, v.date_given, vc.vaccine_name FROM vaccinations v JOIN vaccines vc ON vc.vaccine_id = v.vaccine_id
         WHERE v.resident_id = ? ORDER BY vc.vaccine_name, v.dose_no', [(int)$v['resident_id']])->fetchAll()
    : [];

$page_title = $id ? 'Edit Vaccination' : 'Record Vaccination';
$nav_active = 'modules/vaccinations/index.php';
$page_kicker = 'Vaccinations';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<div class="grid cols-3-1">
    <form method="post" class="card">
        <?= csrf_field() ?>
        <div class="form-grid">
            <div class="field required span-2">
                <label for="f_resident_id">Resident</label>
                <select id="f_resident_id" name="resident_id" class="searchable" data-placeholder="Type the resident's name" required>
                    <?= options(resident_options(), $v['resident_id']) ?>
                </select>
            </div>
            <?= select_field('Vaccine', 'vaccine_id', $vaccineList, $v['vaccine_id'], 'required', '-- Select --', 'span-2') ?>
            <?= field('Dose number', 'dose_no', $v['dose_no'], 'number', 'min="1" max="20" placeholder="Leave blank = next dose"') ?>
            <?= field('Date given', 'date_given', $v['date_given'], 'date', 'required max="' . today() . '"') ?>
            <?= field('Next schedule', 'next_schedule', $v['next_schedule'], 'date', 'placeholder="Automatic"') ?>
            <?= field('Batch / lot no.', 'batch_lot_no', $v['batch_lot_no'], 'text', 'maxlength="50"') ?>
            <?= field('Site given', 'site_given', $v['site_given'], 'text', 'maxlength="50" placeholder="e.g. Left thigh, Oral"') ?>
            <?= field('Remarks', 'remarks', $v['remarks'], 'text', 'maxlength="255"') ?>
        </div>
        <p class="hint">Leave <strong>Dose number</strong> and <strong>Next schedule</strong> blank to compute them from the resident's previous doses and the vaccine's interval.</p>
        <div class="form-actions">
            <?php if ($id && can('vaccinations', 'manage')): ?>
                <button class="btn btn-danger" name="action" value="delete" formnovalidate data-confirm="Delete this vaccination record?">Delete</button>
            <?php endif; ?>
            <a class="btn" href="<?= e(url('modules/vaccinations/index.php')) ?>">Cancel</a>
            <button class="btn btn-primary" name="action" value="save">Save vaccination</button>
        </div>
    </form>
    <div class="card">
        <h3>Doses already given</h3>
        <?php foreach ($history as $h): ?>
            <div class="small"><?= e($h['vaccine_name']) ?> — dose <?= (int)$h['dose_no'] ?> <span class="muted">(<?= fmt_date($h['date_given']) ?>)</span></div>
        <?php endforeach; ?>
        <?php if (!$history): ?><p class="muted small"><?= $v['resident_id'] !== '' ? 'No doses recorded yet.' : 'Choose a resident and reload to see their doses, or open this page from the resident\'s profile.' ?></p><?php endif; ?>
    </div>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
