<?php
/* Trainings and seminars attended by personnel */
require __DIR__ . '/../../includes/init.php';
require_perm('hr');

$errors = [];
$t = ['personnel_id' => get('personnel_id'), 'title' => '', 'provider' => '', 'date_from' => '', 'date_to' => '', 'hours' => '', 'certificate_no' => ''];

if (is_post()) {
    require_perm('hr', 'edit');
    if (input('action') === 'delete') {
        $tid = (int)input('training_id');
        q('DELETE FROM personnel_trainings WHERE training_id = ?', [$tid]);
        log_activity('DELETE', 'personnel_trainings', $tid, 'Deleted training record');
        flash('success', 'Training record deleted.');
        redirect(back_url('modules/hr/trainings.php'));
    }
    foreach (array_keys($t) as $k) { $t[$k] = input($k); }
    if (!q('SELECT 1 FROM personnel WHERE personnel_id = ?', [(int)$t['personnel_id']])->fetchColumn()) $errors[] = 'Choose an employee.';
    if ($t['title'] === '') $errors[] = 'Enter the training title.';
    if (!valid_date($t['date_from'])) $errors[] = 'Enter the start date.';
    if ($t['date_to'] !== '' && (!valid_date($t['date_to']) || $t['date_to'] < $t['date_from'])) $errors[] = 'The end date is not valid.';
    if ($t['hours'] !== '' && (!is_numeric($t['hours']) || $t['hours'] <= 0 || $t['hours'] > 999)) $errors[] = 'Hours must be a positive number.';
    if (!$errors) {
        $tid = db_insert('personnel_trainings', [
            'personnel_id' => (int)$t['personnel_id'], 'title' => $t['title'], 'provider' => nullable($t['provider']), 'date_from' => $t['date_from'],
            'date_to' => nullable($t['date_to']), 'hours' => nullable($t['hours']), 'certificate_no' => nullable($t['certificate_no']), 'created_by' => user_id(),
        ]);
        log_activity('CREATE', 'personnel_trainings', $tid, 'Added training ' . $t['title']);
        flash('success', 'Training saved.');
        redirect('modules/hr/trainings.php');
    }
}

$search = get('q');
$where = ['1=1'];
$params = [];
if ($search !== '') {
    $where[] = "(t.title LIKE ? OR t.provider LIKE ? OR p.last_name LIKE ? OR p.first_name LIKE ?)";
    array_push($params, "%$search%", "%$search%", "%$search%", "%$search%");
}
$w = implode(' AND ', $where);
$pg = paginate((int)q("SELECT COUNT(*) FROM personnel_trainings t JOIN personnel p ON p.personnel_id = t.personnel_id WHERE $w", $params)->fetchColumn());
$rows = q("SELECT t.*, p.first_name, p.middle_name, p.last_name, p.suffix, p.position FROM personnel_trainings t
           JOIN personnel p ON p.personnel_id = t.personnel_id WHERE $w ORDER BY t.date_from DESC LIMIT {$pg['per']} OFFSET {$pg['offset']}", $params)->fetchAll();
$totalHours = (float)q('SELECT COALESCE(SUM(hours), 0) FROM personnel_trainings WHERE YEAR(date_from) = ?', [(int)date('Y')])->fetchColumn();

$page_title = 'Trainings';
$page_kicker = 'Human Resource';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<div class="grid cols-3-1">
    <div class="card">
        <div class="card-header"><h3>Trainings &amp; seminars</h3><span class="chip"><?= date('Y') ?> training hours <b><?= $totalHours + 0 ?></b></span></div>
        <form class="toolbar" method="get">
            <div class="grow"><label>Search</label><input type="search" name="q" value="<?= e($search) ?>" placeholder="Title, provider or employee"></div>
            <button class="btn">Search</button>
        </form>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Date</th><th>Employee</th><th>Training</th><th class="num">Hours</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td class="nowrap small"><?= fmt_date($r['date_from']) ?><?= $r['date_to'] && $r['date_to'] !== $r['date_from'] ? '<br>– ' . fmt_date($r['date_to']) : '' ?></td>
                    <td><a href="personnel_view.php?id=<?= (int)$r['personnel_id'] ?>#trainings"><?= e(full_name($r)) ?></a><div class="small muted"><?= e($r['position']) ?></div></td>
                    <td><strong><?= e($r['title']) ?></strong><div class="small muted"><?= e($r['provider']) ?><?= $r['certificate_no'] ? ' &middot; Cert. ' . e($r['certificate_no']) : '' ?></div></td>
                    <td class="num"><?= $r['hours'] !== null ? $r['hours'] + 0 : '—' ?></td>
                    <td class="actions"><?php if (can('hr', 'edit')): ?><?= post_button('trainings.php', 'Delete', ['action' => 'delete', 'training_id' => $r['training_id']], 'btn btn-sm btn-danger', 'Delete this training record?') ?><?php endif; ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$rows): ?><tr><td colspan="5" class="empty">No trainings recorded.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
        <?= pagination_links($pg) ?>
    </div>
    <?php if (can('hr', 'edit')): ?>
    <div class="card">
        <h3>Add training</h3>
        <form method="post">
            <?= csrf_field() ?>
            <div class="form-grid one">
                <?= select_field('Employee', 'personnel_id', personnel_options(false), $t['personnel_id'], 'required class="searchable"') ?>
                <?= field('Title', 'title', $t['title'], 'text', 'required maxlength="200" placeholder="e.g. Basic Life Support"') ?>
                <?= field('Provider', 'provider', $t['provider'], 'text', 'maxlength="150" placeholder="DOH, NNC, MHO..."') ?>
                <?= field('From', 'date_from', $t['date_from'], 'date', 'required') ?>
                <?= field('To', 'date_to', $t['date_to'], 'date') ?>
                <?= field('Hours', 'hours', $t['hours'], 'number', 'step="0.5" min="0.5"') ?>
                <?= field('Certificate no.', 'certificate_no', $t['certificate_no'], 'text', 'maxlength="50"') ?>
            </div>
            <div class="form-actions"><button class="btn btn-primary">Save training</button></div>
        </form>
    </div>
    <?php endif; ?>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
