<?php
/* Add / edit a personnel 201 file */
require __DIR__ . '/../../includes/init.php';
require_perm('hr', 'edit');

$fields = ['employee_no', 'user_id', 'first_name', 'middle_name', 'last_name', 'suffix', 'sex', 'birthdate', 'civil_status',
           'position', 'employment_status', 'date_hired', 'assigned_area', 'monthly_rate', 'contact_no', 'email', 'address',
           'tin_no', 'philhealth_no', 'license_no', 'license_expiry', 'emergency_contact', 'emergency_contact_no', 'status', 'remarks'];
$dates = ['birthdate', 'date_hired', 'license_expiry'];

$id = (int)get('id');
$p = array_fill_keys($fields, '');
$p['employment_status'] = 'Volunteer';
$p['status'] = 'active';
$p['user_id'] = get('user_id');
if ($id) {
    $p = q('SELECT * FROM personnel WHERE personnel_id = ?', [$id])->fetch();
    if (!$p) {
        flash('danger', 'Personnel record not found.');
        redirect('modules/hr/personnel.php');
    }
}

// Pre-fill from a login account (Add 201 file for an existing user)
if (!$id && $p['user_id'] !== '' && !is_post()) {
    $acct = q('SELECT * FROM users WHERE user_id = ?', [$p['user_id']])->fetch();
    if ($acct) {
        $parts = preg_split('/\s+/', trim(preg_replace('/,.*$/', '', $acct['full_name'])));
        $p['last_name'] = count($parts) > 1 ? array_pop($parts) : '';
        $p['first_name'] = implode(' ', $parts);
        $p['email'] = $acct['email'];
        $p['contact_no'] = $acct['contact_no'];
        $p['license_no'] = $acct['id_number'];
        $p['position'] = ['bhw' => 'Barangay Health Worker', 'nurse' => 'Nurse I', 'mho' => 'Municipal Health Officer',
                          'hr' => 'Human Resource Officer', 'nao' => 'Nutrition Action Officer'][$acct['role']] ?? '';
    }
}

// Login accounts that are not yet linked to another 201 file
$accounts = [];
foreach (q("SELECT u.user_id, u.username, u.full_name, u.role FROM users u
            WHERE u.role <> 'resident' AND (u.user_id NOT IN (SELECT user_id FROM personnel WHERE user_id IS NOT NULL AND personnel_id <> ?))
            ORDER BY u.full_name", [$id])->fetchAll() as $a) {
    $accounts[$a['user_id']] = $a['full_name'] . ' (@' . $a['username'] . ', ' . (ROLE_LABELS[$a['role']] ?? $a['role']) . ')';
}

$errors = [];
if (is_post()) {
    foreach ($fields as $f) { $p[$f] = input($f); }

    if ($p['first_name'] === '' || $p['last_name'] === '') $errors[] = 'First and last name are required.';
    if (!in_array($p['sex'], ['Male', 'Female'], true)) $errors[] = 'Select a sex.';
    if ($p['position'] === '') $errors[] = 'Position is required.';
    if (!in_array($p['employment_status'], EMPLOYMENT_STATUS, true)) $errors[] = 'Select an employment status.';
    if (!in_array($p['status'], PERSONNEL_STATUS, true)) $errors[] = 'Select a status.';
    if ($p['civil_status'] !== '' && !in_array($p['civil_status'], ['Single', 'Married', 'Widowed', 'Separated', 'Live-in'], true)) $errors[] = 'Select a civil status.';
    foreach ($dates as $d) {
        if ($p[$d] !== '' && !valid_date($p[$d])) $errors[] = 'Enter a valid date for ' . str_replace('_', ' ', $d) . '.';
    }
    if ($p['birthdate'] !== '' && valid_date($p['birthdate']) && age_years($p['birthdate']) < 15) $errors[] = 'Birthdate looks wrong (younger than 15).';
    if ($p['contact_no'] !== '' && !preg_match('/^(09\d{9}|\+639\d{9})$/', $p['contact_no'])) $errors[] = 'Contact number must look like 09171234567.';
    if ($p['email'] !== '' && !filter_var($p['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Email address is not valid.';
    if ($p['monthly_rate'] !== '' && (!is_numeric($p['monthly_rate']) || $p['monthly_rate'] < 0)) $errors[] = 'Monthly rate must be a number.';
    if ($p['user_id'] !== '' && !isset($accounts[$p['user_id']])) $errors[] = 'That login account is already linked to another 201 file.';
    if ($p['employee_no'] === '') {
        $p['employee_no'] = next_employee_no();
    }

    if (!$errors) {
        $data = [];
        foreach ($fields as $f) { $data[$f] = nullable($p[$f]); }
        $data['employee_no'] = $p['employee_no'];
        try {
            if ($id) {
                db_update('personnel', $data, 'personnel_id', $id);
                log_activity('UPDATE', 'personnel', $id, 'Updated 201 file of ' . $p['first_name'] . ' ' . $p['last_name']);
            } else {
                $data['created_by'] = user_id();
                $id = db_insert('personnel', $data);
                log_activity('CREATE', 'personnel', $id, 'Added 201 file of ' . $p['first_name'] . ' ' . $p['last_name']);
            }
            flash('success', '201 file of ' . $p['first_name'] . ' ' . $p['last_name'] . ' saved.');
            redirect('modules/hr/personnel_view.php?id=' . $id);
        } catch (PDOException $e) {
            if (!is_duplicate_error($e)) throw $e;
            $errors[] = 'Employee number ' . $p['employee_no'] . ' is already used.';
            if (!(int)get('id')) { $id = 0; }
        }
    }
}

$positions = array_values(array_unique(array_merge(POSITIONS, q('SELECT DISTINCT position FROM personnel')->fetchAll(PDO::FETCH_COLUMN))));
$page_title = $id ? 'Edit 201 File' : 'Add Personnel';
$nav_active = 'modules/hr/personnel.php';
$page_kicker = 'Human Resource';
$back_url = $id ? 'modules/hr/personnel_view.php?id=' . $id : 'modules/hr/personnel.php';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<form method="post" class="card">
    <?= csrf_field() ?>
    <fieldset>
        <legend>Personal information</legend>
        <div class="form-grid">
            <?= field('First name', 'first_name', $p['first_name'], 'text', 'required maxlength="80"') ?>
            <?= field('Middle name', 'middle_name', $p['middle_name'], 'text', 'maxlength="80"') ?>
            <?= field('Last name', 'last_name', $p['last_name'], 'text', 'required maxlength="80"') ?>
            <?= field('Suffix', 'suffix', $p['suffix'], 'text', 'maxlength="10"') ?>
            <?= select_field('Sex', 'sex', ['Male', 'Female'], $p['sex'], 'required') ?>
            <?= field('Birthdate', 'birthdate', $p['birthdate'], 'date', 'max="' . today() . '"') ?>
            <?= select_field('Civil status', 'civil_status', ['Single', 'Married', 'Widowed', 'Separated', 'Live-in'], $p['civil_status']) ?>
            <?= field('Contact number', 'contact_no', $p['contact_no'], 'tel', 'maxlength="13" placeholder="09XXXXXXXXX"') ?>
            <?= field('Email', 'email', $p['email'], 'email', 'maxlength="150"') ?>
            <?= field('Home address', 'address', $p['address'], 'text', 'maxlength="255"', 'span-2') ?>
        </div>
    </fieldset>
    <fieldset>
        <legend>Employment</legend>
        <div class="form-grid">
            <?= field('Employee no.', 'employee_no', $p['employee_no'], 'text', 'maxlength="30" placeholder="Leave blank to auto-number"') ?>
            <div class="field required">
                <label for="f_position">Position</label>
                <input id="f_position" name="position" list="position-list" value="<?= e($p['position']) ?>" required maxlength="100">
                <datalist id="position-list"><?php foreach ($positions as $pos): ?><option value="<?= e($pos) ?>"><?php endforeach; ?></datalist>
            </div>
            <?= select_field('Employment status', 'employment_status', EMPLOYMENT_STATUS, $p['employment_status'], 'required', false) ?>
            <?= field('Date hired / started', 'date_hired', $p['date_hired'], 'date') ?>
            <?= field('Assigned area (purok / unit)', 'assigned_area', $p['assigned_area'], 'text', 'maxlength="100"') ?>
            <?= field('Monthly salary / honorarium (₱)', 'monthly_rate', $p['monthly_rate'], 'number', 'step="0.01" min="0"') ?>
            <?= select_field('Status', 'status', array_combine(PERSONNEL_STATUS, array_map('ucfirst', PERSONNEL_STATUS)), $p['status'], 'required', false) ?>
            <?= select_field('Login account', 'user_id', $accounts, $p['user_id'], 'class="searchable"', '-- No login account --', 'span-2') ?>
        </div>
        <p class="hint">Linking the login account lets the employee file leave in <strong>My Leave</strong>.</p>
    </fieldset>
    <fieldset>
        <legend>Government IDs &amp; license</legend>
        <div class="form-grid">
            <?= field('TIN', 'tin_no', $p['tin_no'], 'text', 'maxlength="20"') ?>
            <?= field('PhilHealth no.', 'philhealth_no', $p['philhealth_no'], 'text', 'maxlength="20"') ?>
            <?= field('PRC license / accreditation no.', 'license_no', $p['license_no'], 'text', 'maxlength="30"') ?>
            <?= field('License valid until', 'license_expiry', $p['license_expiry'], 'date') ?>
        </div>
    </fieldset>
    <fieldset>
        <legend>In case of emergency</legend>
        <div class="form-grid">
            <?= field('Contact person', 'emergency_contact', $p['emergency_contact'], 'text', 'maxlength="150"') ?>
            <?= field('Contact number', 'emergency_contact_no', $p['emergency_contact_no'], 'tel', 'maxlength="20"') ?>
            <?= field('Remarks', 'remarks', $p['remarks'], 'textarea', '', 'full') ?>
        </div>
    </fieldset>
    <div class="form-actions">
        <a class="btn" href="<?= e(url($back_url)) ?>">Cancel</a>
        <button class="btn btn-primary">Save 201 file</button>
    </div>
</form>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
