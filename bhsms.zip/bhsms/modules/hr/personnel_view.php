<?php
/* One employee's 201 file: details, attendance this month, leave history, trainings */
require __DIR__ . '/../../includes/init.php';
require_perm('hr');

$id = (int)get('id');
$p = q('SELECT p.*, u.username, u.role, u.status AS account_status FROM personnel p LEFT JOIN users u ON u.user_id = p.user_id
        WHERE p.personnel_id = ?', [$id])->fetch();
if (!$p) {
    flash('danger', 'Personnel record not found.');
    redirect('modules/hr/personnel.php');
}

$month = preg_match('/^\d{4}-\d{2}$/', get('month')) ? get('month') : date('Y-m');
$attendance = q('SELECT * FROM personnel_attendance WHERE personnel_id = ? AND work_date BETWEEN ? AND ? ORDER BY work_date DESC',
                [$id, $month . '-01', date('Y-m-t', strtotime($month . '-01'))])->fetchAll();
$summary = array_fill_keys(ATTENDANCE_STATUS, 0);
foreach ($attendance as $a) {
    $summary[$a['status']] = ($summary[$a['status']] ?? 0) + 1;
}
$leaves = q('SELECT l.*, r.full_name AS reviewer FROM leave_requests l LEFT JOIN users r ON r.user_id = l.reviewed_by
             WHERE l.personnel_id = ? ORDER BY l.date_from DESC', [$id])->fetchAll();
$leaveUsed = (float)q("SELECT COALESCE(SUM(days), 0) FROM leave_requests WHERE personnel_id = ? AND status = 'approved' AND YEAR(date_from) = ?",
                      [$id, (int)date('Y')])->fetchColumn();
$trainings = q('SELECT * FROM personnel_trainings WHERE personnel_id = ? ORDER BY date_from DESC', [$id])->fetchAll();
$years = $p['date_hired'] ? (new DateTime($p['date_hired']))->diff(new DateTime('today'))->y : null;

$page_title = '201 File';
$nav_active = 'modules/hr/personnel.php';
$page_kicker = 'Human Resource';
$back_url = 'modules/hr/personnel.php';
require __DIR__ . '/../../includes/header.php';
?>
<div class="profile-strip">
    <span class="avatar avatar-lg"><?= e(strtoupper(substr($p['first_name'], 0, 1) . substr($p['last_name'], 0, 1))) ?></span>
    <div class="grow">
        <h2><?= e(full_name($p)) ?> <?= badge($p['status']) ?></h2>
        <div class="muted"><?= e($p['position']) ?> &middot; <?= e($p['employment_status']) ?> &middot; <?= e($p['employee_no']) ?>
            <?= $years !== null ? ' &middot; ' . $years . ' yr' . ($years === 1 ? '' : 's') . ' of service' : '' ?></div>
    </div>
    <div class="btn-group no-print">
        <?php if (can('hr', 'edit')): ?>
            <a class="btn" href="leaves.php?file=<?= $id ?>">+ File leave</a>
            <a class="btn" href="trainings.php?personnel_id=<?= $id ?>">+ Training</a>
            <a class="btn btn-primary" href="personnel_form.php?id=<?= $id ?>">Edit</a>
        <?php endif; ?>
        <button class="btn" data-print>Print</button>
    </div>
</div>

<div class="grid cols-2 mb">
    <div class="card">
        <h3>Personal information</h3>
        <dl class="info">
            <dt>Sex</dt><dd><?= e($p['sex']) ?></dd>
            <dt>Birthdate</dt><dd><?= fmt_date($p['birthdate']) ?><?= $p['birthdate'] ? ' (' . age_years($p['birthdate']) . ' yrs)' : '' ?></dd>
            <dt>Civil status</dt><dd><?= e($p['civil_status'] ?: '—') ?></dd>
            <dt>Contact</dt><dd><?= e($p['contact_no'] ?: '—') ?><?= $p['email'] ? ' &middot; ' . e($p['email']) : '' ?></dd>
            <dt>Address</dt><dd><?= e($p['address'] ?: '—') ?></dd>
            <dt>Emergency contact</dt><dd><?= e($p['emergency_contact'] ?: '—') ?> <?= e($p['emergency_contact_no']) ?></dd>
        </dl>
    </div>
    <div class="card">
        <h3>Employment</h3>
        <dl class="info">
            <dt>Date hired</dt><dd><?= fmt_date($p['date_hired']) ?></dd>
            <dt>Assigned area</dt><dd><?= e($p['assigned_area'] ?: '—') ?></dd>
            <dt>Monthly rate</dt><dd><?= $p['monthly_rate'] !== null ? '₱' . number_format((float)$p['monthly_rate'], 2) : '—' ?></dd>
            <dt>TIN / PhilHealth</dt><dd><?= e($p['tin_no'] ?: '—') ?> / <?= e($p['philhealth_no'] ?: '—') ?></dd>
            <dt>License no.</dt><dd><?= e($p['license_no'] ?: '—') ?>
                <?php if ($p['license_expiry']): ?><span class="<?= $p['license_expiry'] < today() ? 'text-danger' : 'muted' ?> small">valid until <?= fmt_date($p['license_expiry']) ?></span><?php endif; ?></dd>
            <dt>Login account</dt><dd><?= $p['username'] ? '@' . e($p['username']) . ' (' . e(ROLE_LABELS[$p['role']] ?? $p['role']) . ') ' . badge($p['account_status']) : 'None' ?></dd>
            <dt>Leave used (<?= date('Y') ?>)</dt><dd><?= $leaveUsed + 0 ?> day(s)</dd>
        </dl>
        <?php if ($p['remarks']): ?><p class="small muted"><?= nl2br(e($p['remarks'])) ?></p><?php endif; ?>
    </div>
</div>

<div class="card">
    <div class="tabs" data-tabs>
        <button class="active" data-tab="attendance">Attendance (<?= e(date('F Y', strtotime($month . '-01'))) ?>)</button>
        <button data-tab="leave">Leave (<?= count($leaves) ?>)</button>
        <button data-tab="trainings">Trainings (<?= count($trainings) ?>)</button>
    </div>
    <div class="tab-panel active" id="tab-attendance">
        <form class="toolbar" method="get">
            <input type="hidden" name="id" value="<?= $id ?>">
            <div><label>Month</label><input type="month" name="month" value="<?= e($month) ?>"></div>
            <button class="btn">Show</button>
        </form>
        <div class="chips mb">
            <?php foreach ($summary as $k => $n): if (!$n) continue; ?><span class="chip"><?= e($k) ?> <b><?= $n ?></b></span><?php endforeach; ?>
        </div>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Date</th><th>Time in</th><th>Time out</th><th>Status</th><th>Remarks</th></tr></thead>
            <tbody>
            <?php foreach ($attendance as $a): ?>
                <tr>
                    <td class="nowrap"><?= fmt_date($a['work_date'], 'D, M j') ?></td>
                    <td><?= fmt_time($a['time_in']) ?></td>
                    <td><?= fmt_time($a['time_out']) ?></td>
                    <td><?= badge($a['status']) ?></td>
                    <td class="small"><?= e($a['remarks']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$attendance): ?><tr><td colspan="5" class="empty">No attendance recorded this month.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>
    <div class="tab-panel" id="tab-leave">
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Filed</th><th>Type</th><th>Dates</th><th class="num">Days</th><th>Reason</th><th>Status</th><th>Reviewed by</th></tr></thead>
            <tbody>
            <?php foreach ($leaves as $l): ?>
                <tr>
                    <td class="small nowrap"><?= fmt_date($l['created_at']) ?></td>
                    <td><?= e($l['leave_type']) ?></td>
                    <td class="nowrap small"><?= fmt_date($l['date_from']) ?> – <?= fmt_date($l['date_to']) ?></td>
                    <td class="num"><?= $l['days'] + 0 ?></td>
                    <td class="small"><?= e($l['reason']) ?></td>
                    <td><?= badge($l['status']) ?><?= $l['remarks'] ? '<div class="small muted">' . e($l['remarks']) . '</div>' : '' ?></td>
                    <td class="small"><?= e($l['reviewer'] ?: '—') ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$leaves): ?><tr><td colspan="7" class="empty">No leave filed.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>
    <div class="tab-panel" id="tab-trainings">
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Date</th><th>Training / seminar</th><th>Provider</th><th class="num">Hours</th><th>Certificate</th></tr></thead>
            <tbody>
            <?php foreach ($trainings as $t): ?>
                <tr>
                    <td class="nowrap small"><?= fmt_date($t['date_from']) ?><?= $t['date_to'] && $t['date_to'] !== $t['date_from'] ? ' – ' . fmt_date($t['date_to']) : '' ?></td>
                    <td><?= e($t['title']) ?></td>
                    <td><?= e($t['provider'] ?: '—') ?></td>
                    <td class="num"><?= $t['hours'] !== null ? $t['hours'] + 0 : '—' ?></td>
                    <td><?= e($t['certificate_no'] ?: '—') ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$trainings): ?><tr><td colspan="5" class="empty">No trainings recorded.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
