<?php
/* Self-service: any staff member files and tracks their own leave */
require __DIR__ . '/../../includes/init.php';
require_perm('hr', 'file_leave');

$me = my_personnel();
$errors = [];
$f = ['personnel_id' => $me['personnel_id'] ?? '', 'leave_type' => 'Vacation', 'date_from' => '', 'date_to' => '', 'reason' => ''];

if ($me && is_post()) {
    $action = input('action');
    if ($action === 'file') {
        foreach (['leave_type', 'date_from', 'date_to', 'reason'] as $k) { $f[$k] = input($k); }
        $f['personnel_id'] = $me['personnel_id'];      // always your own record
        if (valid_date($f['date_from']) && $f['date_from'] < date('Y-m-d', strtotime('-30 days'))) {
            $errors[] = 'Leave older than 30 days must be filed through the HR office.';
        }
        $errors = array_merge($errors, validate_leave($f));
        if (!$errors) {
            $lid = db_insert('leave_requests', [
                'personnel_id' => $me['personnel_id'], 'leave_type' => $f['leave_type'], 'date_from' => $f['date_from'], 'date_to' => $f['date_to'],
                'days' => working_days($f['date_from'], $f['date_to']), 'reason' => $f['reason'], 'status' => 'pending', 'filed_by' => user_id(),
            ]);
            log_activity('CREATE', 'leave_requests', $lid, 'Filed own ' . $f['leave_type'] . ' leave');
            notify_roles(['hr'], 'New leave request', $me['first_name'] . ' ' . $me['last_name'] . ' filed ' . $f['leave_type'] . ' leave ('
                . fmt_date($f['date_from']) . ' – ' . fmt_date($f['date_to']) . ').', 'modules/hr/leaves.php?status=pending');
            flash('success', 'Leave request sent to the HR office.');
            redirect('modules/hr/my_leave.php');
        }
    }
    if ($action === 'cancel') {
        $lid = (int)input('leave_id');
        q("UPDATE leave_requests SET status = 'cancelled' WHERE leave_id = ? AND personnel_id = ? AND status = 'pending'", [$lid, $me['personnel_id']]);
        log_activity('UPDATE', 'leave_requests', $lid, 'Cancelled own leave request');
        flash('success', 'Leave request cancelled.');
        redirect('modules/hr/my_leave.php');
    }
}

$rows = $me ? q('SELECT l.*, r.full_name AS reviewer FROM leave_requests l LEFT JOIN users r ON r.user_id = l.reviewed_by
                 WHERE l.personnel_id = ? ORDER BY l.date_from DESC', [$me['personnel_id']])->fetchAll() : [];
$used = $me ? (float)q("SELECT COALESCE(SUM(days), 0) FROM leave_requests WHERE personnel_id = ? AND status = 'approved' AND YEAR(date_from) = ?",
                       [$me['personnel_id'], (int)date('Y')])->fetchColumn() : 0;

$page_title = 'My Leave';
$page_kicker = 'Human Resource';
require __DIR__ . '/../../includes/header.php';
?>
<?php if (!$me): ?>
    <div class="card">
        <h3>You don't have a 201 file yet</h3>
        <p>Ask the Human Resource Officer to create your personnel record and link it to your login account (<strong>@<?= e(current_user()['username']) ?></strong>).
            After that you can file leave here.</p>
    </div>
<?php else: ?>
<?= render_errors($errors) ?>
<div class="grid cols-3-1">
    <div class="card">
        <div class="card-header"><h3>My leave requests</h3><span class="chip">Approved this year <b><?= $used + 0 ?> day(s)</b></span></div>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Leave</th><th>Dates</th><th class="num">Days</th><th>Reason</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $l): ?>
                <tr>
                    <td><?= e($l['leave_type']) ?><div class="small muted">filed <?= fmt_date($l['created_at']) ?></div></td>
                    <td class="nowrap small"><?= fmt_date($l['date_from']) ?> – <?= fmt_date($l['date_to']) ?></td>
                    <td class="num"><?= $l['days'] + 0 ?></td>
                    <td class="small"><?= e($l['reason']) ?></td>
                    <td><?= badge($l['status']) ?><?= $l['remarks'] ? '<div class="small">' . e($l['remarks']) . '</div>' : '' ?></td>
                    <td class="actions"><?php if ($l['status'] === 'pending'): ?><?= post_button('my_leave.php', 'Cancel', ['action' => 'cancel', 'leave_id' => $l['leave_id']], 'btn btn-sm btn-danger', 'Cancel this leave request?') ?><?php endif; ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$rows): ?><tr><td colspan="6" class="empty">You have not filed any leave.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>
    <div class="card">
        <h3>File a leave</h3>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="file">
            <div class="form-grid one">
                <?= select_field('Leave type', 'leave_type', LEAVE_TYPES, $f['leave_type'], 'required', false) ?>
                <?= field('From', 'date_from', $f['date_from'], 'date', 'required') ?>
                <?= field('To', 'date_to', $f['date_to'], 'date', 'required') ?>
                <?= field('Reason', 'reason', $f['reason'], 'text', 'required maxlength="255"') ?>
            </div>
            <p class="hint">Weekdays only are counted. The HR office will notify you once it is reviewed.</p>
            <div class="form-actions"><button class="btn btn-primary">Send request</button></div>
        </form>
    </div>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
