<?php
/* Personnel directory (201 files) */
require __DIR__ . '/../../includes/init.php';
require_perm('hr');

$search = get('q');
$position = get('position');
$emp = get('employment');
$status = get('status', 'current');
$expiring = get('expiring') === '1';

$where = ['1=1'];
$params = [];
if ($search !== '') {
    $where[] = "(p.first_name LIKE ? OR p.last_name LIKE ? OR CONCAT(p.first_name, ' ', p.last_name) LIKE ? OR p.employee_no LIKE ? OR p.license_no LIKE ?)";
    $like = "%$search%";
    array_push($params, $like, $like, $like, $like, $like);
}
if ($position !== '') { $where[] = 'p.position = ?'; $params[] = $position; }
if ($emp !== '')      { $where[] = 'p.employment_status = ?'; $params[] = $emp; }
if ($status === 'current') {
    $where[] = "p.status IN ('active', 'on leave')";
} elseif ($status !== '') {
    $where[] = 'p.status = ?';
    $params[] = $status;
}
if ($expiring) {
    $where[] = 'p.license_expiry IS NOT NULL AND p.license_expiry <= ?';
    $params[] = date('Y-m-d', strtotime('+90 days'));
}
$w = implode(' AND ', $where);
$from = 'FROM personnel p LEFT JOIN users u ON u.user_id = p.user_id';

if (get('export') === 'csv') {
    $rows = q("SELECT p.*, u.username $from WHERE $w ORDER BY p.last_name, p.first_name", $params)->fetchAll();
    log_activity('EXPORT', 'personnel', null, 'Exported personnel list');
    send_csv('personnel_' . date('Ymd') . '.csv',
        ['Employee no.', 'Name', 'Sex', 'Position', 'Employment', 'Date hired', 'Assigned area', 'Contact', 'Email', 'License no.', 'License expiry', 'Status', 'Login'],
        array_map(function ($r) {
            return [$r['employee_no'], full_name($r), $r['sex'], $r['position'], $r['employment_status'], $r['date_hired'], $r['assigned_area'],
                    $r['contact_no'], $r['email'], $r['license_no'], $r['license_expiry'], $r['status'], $r['username']];
        }, $rows));
}

$pg = paginate((int)q("SELECT COUNT(*) $from WHERE $w", $params)->fetchColumn());
$rows = q("SELECT p.*, u.username, u.role $from WHERE $w ORDER BY p.last_name, p.first_name LIMIT {$pg['per']} OFFSET {$pg['offset']}", $params)->fetchAll();
$positions = q('SELECT DISTINCT position FROM personnel ORDER BY position')->fetchAll(PDO::FETCH_COLUMN);

$page_title = 'Personnel (201 Files)';
$page_kicker = 'Human Resource';
require __DIR__ . '/../../includes/header.php';
?>
<div class="card">
    <div class="card-header">
        <h3>Personnel directory</h3>
        <div class="btn-group">
            <a class="btn btn-sm" href="?<?= e(http_build_query(array_merge($_GET, ['export' => 'csv']))) ?>">Export CSV</a>
            <?php if (can('hr', 'edit')): ?><a class="btn btn-primary" href="personnel_form.php">+ Add personnel</a><?php endif; ?>
        </div>
    </div>
    <form class="toolbar" method="get">
        <div class="grow"><label>Search</label><input type="search" name="q" value="<?= e($search) ?>" placeholder="Name, employee no. or license no."></div>
        <div><label>Position</label><select name="position"><?= options($positions, $position, 'All') ?></select></div>
        <div><label>Employment</label><select name="employment"><?= options(EMPLOYMENT_STATUS, $emp, 'All') ?></select></div>
        <div><label>Status</label><select name="status"><?= options(['current' => 'Active + on leave'] + array_combine(PERSONNEL_STATUS, array_map('ucfirst', PERSONNEL_STATUS)), $status, 'All') ?></select></div>
        <button class="btn">Filter</button>
        <a class="btn" href="personnel.php">Reset</a>
    </form>
    <?php if ($expiring): ?><div class="alert alert-warning">Showing licenses that expire within 90 days. <a href="personnel.php">Show everyone</a></div><?php endif; ?>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Employee</th><th>Position</th><th>Employment</th><th>Area</th><th>Contact</th><th>License</th><th>Login</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $p): ?>
            <tr>
                <td><a href="personnel_view.php?id=<?= (int)$p['personnel_id'] ?>"><strong><?= e(full_name($p)) ?></strong></a><div class="small muted"><?= e($p['employee_no']) ?></div></td>
                <td><?= e($p['position']) ?></td>
                <td><?= e($p['employment_status']) ?><div class="small muted"><?= $p['date_hired'] ? 'Since ' . fmt_date($p['date_hired'], 'M Y') : '' ?></div></td>
                <td><?= e($p['assigned_area'] ?: '—') ?></td>
                <td class="small"><?= e($p['contact_no'] ?: '—') ?></td>
                <td class="small"><?= e($p['license_no'] ?: '—') ?>
                    <?php if ($p['license_expiry']): ?><div class="<?= $p['license_expiry'] < today() ? 'text-danger' : 'muted' ?>">exp. <?= fmt_date($p['license_expiry']) ?></div><?php endif; ?></td>
                <td class="small"><?= $p['username'] ? '@' . e($p['username']) : '<span class="muted">None</span>' ?></td>
                <td><?= badge($p['status']) ?></td>
                <td class="actions">
                    <a class="btn btn-sm" href="personnel_view.php?id=<?= (int)$p['personnel_id'] ?>">201 File</a>
                    <?php if (can('hr', 'edit')): ?><a class="btn btn-sm" href="personnel_form.php?id=<?= (int)$p['personnel_id'] ?>">Edit</a><?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="9" class="empty">No personnel found.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
    <?= pagination_links($pg) ?>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
