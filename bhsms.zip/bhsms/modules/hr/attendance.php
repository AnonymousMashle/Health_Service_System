<?php
/* Daily attendance sheet + monthly summary */
require __DIR__ . '/../../includes/init.php';
require_perm('hr');

$date = valid_date(get('date')) ? get('date') : today();
$view = get('view') === 'month' ? 'month' : 'day';
$month = preg_match('/^\d{4}-\d{2}$/', get('month')) ? get('month') : substr($date, 0, 7);

if (is_post()) {
    require_perm('hr', 'edit');
    $date = input('date');
    if (!valid_date($date) || $date > today()) {
        flash('danger', 'Choose a valid date (not in the future).');
        redirect('modules/hr/attendance.php');
    }
    $saved = 0;
    foreach ((array)($_POST['status'] ?? []) as $pid => $status) {
        $pid = (int)$pid;
        $status = (string)$status;
        $in = trim((string)($_POST['time_in'][$pid] ?? ''));
        $out = trim((string)($_POST['time_out'][$pid] ?? ''));
        $remarks = mb_substr(trim((string)($_POST['remarks'][$pid] ?? '')), 0, 255);
        $exists = q('SELECT attendance_id FROM personnel_attendance WHERE personnel_id = ? AND work_date = ?', [$pid, $date])->fetchColumn();
        if ($status === '') {                          // blank = not recorded; remove an existing entry
            if ($exists) {
                q('DELETE FROM personnel_attendance WHERE attendance_id = ?', [$exists]);
            }
            continue;
        }
        if (!in_array($status, ATTENDANCE_STATUS, true)) {
            continue;
        }
        foreach (['in', 'out'] as $t) {
            if ($$t !== '' && !preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $$t)) {
                $$t = '';
            }
        }
        $data = ['time_in' => nullable($in), 'time_out' => nullable($out), 'status' => $status, 'remarks' => nullable($remarks), 'recorded_by' => user_id()];
        if ($exists) {
            db_update('personnel_attendance', $data, 'attendance_id', $exists);
        } else {
            db_insert('personnel_attendance', $data + ['personnel_id' => $pid, 'work_date' => $date]);
        }
        $saved++;
    }
    log_activity('UPDATE', 'personnel_attendance', null, 'Saved attendance for ' . $date . " ($saved entries)");
    flash('success', "Attendance for " . fmt_date($date) . " saved ($saved entries).");
    redirect('modules/hr/attendance.php?date=' . $date);
}

$staff = q("SELECT p.*, a.time_in, a.time_out, a.status AS att_status, a.remarks AS att_remarks,
                   (SELECT l.leave_type FROM leave_requests l WHERE l.personnel_id = p.personnel_id AND l.status = 'approved'
                     AND ? BETWEEN l.date_from AND l.date_to LIMIT 1) AS on_leave
            FROM personnel p LEFT JOIN personnel_attendance a ON a.personnel_id = p.personnel_id AND a.work_date = ?
            WHERE p.status IN ('active', 'on leave') ORDER BY p.last_name, p.first_name", [$date, $date])->fetchAll();

$monthRows = [];
if ($view === 'month') {
    $monthRows = q("SELECT p.personnel_id, p.first_name, p.middle_name, p.last_name, p.suffix, p.position,
                           SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS present,
                           SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) AS late,
                           SUM(CASE WHEN a.status = 'Half day' THEN 1 ELSE 0 END) AS half,
                           SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent,
                           SUM(CASE WHEN a.status = 'On leave' THEN 1 ELSE 0 END) AS leave_days,
                           SUM(CASE WHEN a.status = 'Official business' THEN 1 ELSE 0 END) AS ob
                    FROM personnel p LEFT JOIN personnel_attendance a ON a.personnel_id = p.personnel_id AND a.work_date BETWEEN ? AND ?
                    WHERE p.status IN ('active', 'on leave')
                    GROUP BY p.personnel_id, p.first_name, p.middle_name, p.last_name, p.suffix, p.position
                    ORDER BY p.last_name, p.first_name", [$month . '-01', date('Y-m-t', strtotime($month . '-01'))])->fetchAll();
}
$canEdit = can('hr', 'edit');

$page_title = 'Attendance';
$page_kicker = 'Human Resource';
require __DIR__ . '/../../includes/header.php';
?>
<div class="tabs">
    <a class="<?= $view === 'day' ? 'active' : '' ?>" href="?date=<?= e($date) ?>">Daily sheet</a>
    <a class="<?= $view === 'month' ? 'active' : '' ?>" href="?view=month&amp;month=<?= e($month) ?>">Monthly summary</a>
</div>

<?php if ($view === 'day'): ?>
<div class="card">
    <div class="card-header">
        <h3>Attendance for <?= fmt_date($date, 'l, F j, Y') ?></h3>
        <form class="toolbar" method="get" style="margin:0">
            <a class="btn btn-sm" href="?date=<?= date('Y-m-d', strtotime($date . ' -1 day')) ?>">&lsaquo; Prev</a>
            <input type="date" name="date" value="<?= e($date) ?>" max="<?= today() ?>" onchange="this.form.submit()">
            <?php if ($date < today()): ?><a class="btn btn-sm" href="?date=<?= date('Y-m-d', strtotime($date . ' +1 day')) ?>">Next &rsaquo;</a><?php endif; ?>
        </form>
    </div>
    <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="date" value="<?= e($date) ?>">
        <?php if ($canEdit): ?>
            <div class="btn-group mb">
                <button type="button" class="btn btn-sm" data-fill-attendance="Present">Mark everyone without a record as Present</button>
            </div>
        <?php endif; ?>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Employee</th><th>Status</th><th>Time in</th><th>Time out</th><th>Remarks</th></tr></thead>
            <tbody>
            <?php foreach ($staff as $s): $pid = (int)$s['personnel_id']; $st = $s['att_status'] ?? ($s['on_leave'] ? 'On leave' : ''); ?>
                <tr>
                    <td><a href="personnel_view.php?id=<?= $pid ?>"><strong><?= e(full_name($s)) ?></strong></a>
                        <div class="small muted"><?= e($s['position']) ?><?= $s['on_leave'] ? ' &middot; <span class="badge badge-purple">' . e($s['on_leave']) . ' leave</span>' : '' ?></div></td>
                    <td><select name="status[<?= $pid ?>]" <?= $canEdit ? '' : 'disabled' ?>><?= options(ATTENDANCE_STATUS, $st, '— not recorded —') ?></select></td>
                    <td><input type="time" name="time_in[<?= $pid ?>]" value="<?= e($s['time_in'] ? substr($s['time_in'], 0, 5) : '') ?>" <?= $canEdit ? '' : 'disabled' ?>></td>
                    <td><input type="time" name="time_out[<?= $pid ?>]" value="<?= e($s['time_out'] ? substr($s['time_out'], 0, 5) : '') ?>" <?= $canEdit ? '' : 'disabled' ?>></td>
                    <td><input type="text" name="remarks[<?= $pid ?>]" value="<?= e($s['att_remarks']) ?>" maxlength="255" <?= $canEdit ? '' : 'disabled' ?>></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$staff): ?><tr><td colspan="5" class="empty">No active personnel. <a href="personnel_form.php">Add a 201 file first.</a></td></tr><?php endif; ?>
            </tbody>
        </table></div>
        <?php if ($canEdit && $staff): ?><div class="form-actions"><button class="btn btn-primary">Save attendance</button></div><?php endif; ?>
    </form>
</div>
<?php else: ?>
<div class="card">
    <div class="card-header">
        <h3>Summary for <?= e(date('F Y', strtotime($month . '-01'))) ?></h3>
        <form class="toolbar" method="get" style="margin:0">
            <input type="hidden" name="view" value="month">
            <input type="month" name="month" value="<?= e($month) ?>" onchange="this.form.submit()">
        </form>
    </div>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Employee</th><th class="num">Present</th><th class="num">Late</th><th class="num">Half day</th><th class="num">Absent</th><th class="num">On leave</th><th class="num">Official business</th></tr></thead>
        <tbody>
        <?php foreach ($monthRows as $m): ?>
            <tr class="<?= $m['absent'] >= 3 ? 'row-warning' : '' ?>">
                <td><a href="personnel_view.php?id=<?= (int)$m['personnel_id'] ?>&amp;month=<?= e($month) ?>"><?= e(full_name($m)) ?></a><div class="small muted"><?= e($m['position']) ?></div></td>
                <td class="num"><?= (int)$m['present'] ?></td>
                <td class="num"><?= (int)$m['late'] ?></td>
                <td class="num"><?= (int)$m['half'] ?></td>
                <td class="num"><?= (int)$m['absent'] ?></td>
                <td class="num"><?= (int)$m['leave_days'] ?></td>
                <td class="num"><?= (int)$m['ob'] ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$monthRows): ?><tr><td colspan="7" class="empty">No personnel.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
