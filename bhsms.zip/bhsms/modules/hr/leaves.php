<?php
/* Leave requests: HR reviews, approves or rejects; HR can also file leave for an employee */
require __DIR__ . '/../../includes/init.php';
require_perm('hr');

$errors = [];
$f = ['personnel_id' => get('file'), 'leave_type' => 'Vacation', 'date_from' => '', 'date_to' => '', 'reason' => ''];

if (is_post()) {
    $action = input('action');

    if ($action === 'file') {
        require_perm('hr', 'edit');
        foreach (array_keys($f) as $k) { $f[$k] = input($k); }
        $errors = validate_leave($f);
        if (!$errors) {
            $lid = db_insert('leave_requests', [
                'personnel_id' => (int)$f['personnel_id'], 'leave_type' => $f['leave_type'], 'date_from' => $f['date_from'], 'date_to' => $f['date_to'],
                'days' => working_days($f['date_from'], $f['date_to']), 'reason' => $f['reason'], 'status' => 'pending', 'filed_by' => user_id(),
            ]);
            log_activity('CREATE', 'leave_requests', $lid, 'Filed ' . $f['leave_type'] . ' leave');
            flash('success', 'Leave request filed. Approve it below when ready.');
            redirect('modules/hr/leaves.php?status=pending');
        }
    }

    if (in_array($action, ['approve', 'reject'], true)) {
        require_perm('hr', 'approve');
        $lid = (int)input('leave_id');
        $l = q("SELECT l.*, p.user_id, p.first_name, p.last_name FROM leave_requests l JOIN personnel p ON p.personnel_id = l.personnel_id
                WHERE l.leave_id = ? AND l.status = 'pending'", [$lid])->fetch();
        if (!$l) {
            flash('danger', 'That leave request was already processed.');
            redirect('modules/hr/leaves.php');
        }
        $remarks = input('remarks');
        if ($action === 'reject' && $remarks === '') {
            flash('danger', 'Give a reason for rejecting the leave (the employee will see it).');
            redirect(back_url('modules/hr/leaves.php'));
        }
        $name = $l['first_name'] . ' ' . $l['last_name'];
        db()->beginTransaction();
        q('UPDATE leave_requests SET status = ?, remarks = ?, reviewed_by = ?, reviewed_at = NOW() WHERE leave_id = ?',
          [$action === 'approve' ? 'approved' : 'rejected', nullable($remarks), user_id(), $lid]);
        if ($action === 'approve') {
            // Mark the leave days in the attendance log (weekdays only, without overwriting existing entries)
            for ($d = new DateTime($l['date_from']), $end = new DateTime($l['date_to']); $d <= $end; $d->modify('+1 day')) {
                if ((int)$d->format('N') > 5) continue;
                $day = $d->format('Y-m-d');
                if (!q('SELECT 1 FROM personnel_attendance WHERE personnel_id = ? AND work_date = ?', [$l['personnel_id'], $day])->fetchColumn()) {
                    db_insert('personnel_attendance', ['personnel_id' => $l['personnel_id'], 'work_date' => $day, 'status' => 'On leave',
                                                       'remarks' => $l['leave_type'] . ' leave', 'recorded_by' => user_id()]);
                }
            }
        }
        db()->commit();
        if ($l['user_id']) {
            notify((int)$l['user_id'], 'Leave ' . ($action === 'approve' ? 'approved' : 'not approved'),
                'Your ' . $l['leave_type'] . ' leave (' . fmt_date($l['date_from']) . ' – ' . fmt_date($l['date_to']) . ') was '
                . ($action === 'approve' ? 'approved.' : 'not approved: ' . $remarks), 'modules/hr/my_leave.php');
        }
        log_activity($action === 'approve' ? 'APPROVE' : 'REJECT', 'leave_requests', $lid, ucfirst($action) . 'd leave of ' . $name);
        flash('success', $name . "'s leave was " . ($action === 'approve' ? 'approved.' : 'rejected.'));
        redirect(back_url('modules/hr/leaves.php'));
    }
}

$status = get('status', 'pending');
$where = ['1=1'];
$params = [];
if ($status !== '') { $where[] = 'l.status = ?'; $params[] = $status; }
$w = implode(' AND ', $where);
$pg = paginate((int)q("SELECT COUNT(*) FROM leave_requests l WHERE $w", $params)->fetchColumn());
$rows = q("SELECT l.*, p.first_name, p.middle_name, p.last_name, p.suffix, p.position, r.full_name AS reviewer
           FROM leave_requests l JOIN personnel p ON p.personnel_id = l.personnel_id LEFT JOIN users r ON r.user_id = l.reviewed_by
           WHERE $w ORDER BY l.status = 'pending' DESC, l.date_from DESC LIMIT {$pg['per']} OFFSET {$pg['offset']}", $params)->fetchAll();
$counts = [];
foreach (q('SELECT status, COUNT(*) AS n FROM leave_requests GROUP BY status')->fetchAll() as $c) {
    $counts[$c['status']] = (int)$c['n'];
}

$page_title = 'Leave Requests';
$page_kicker = 'Human Resource';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<div class="tabs">
    <?php foreach (['pending' => 'Pending', 'approved' => 'Approved', 'rejected' => 'Rejected', 'cancelled' => 'Cancelled', '' => 'All'] as $k => $label): ?>
        <a class="<?= $status === $k ? 'active' : '' ?>" href="?status=<?= e($k) ?>"><?= e($label) ?><?= $k !== '' && !empty($counts[$k]) ? ' (' . $counts[$k] . ')' : '' ?></a>
    <?php endforeach; ?>
</div>

<div class="grid cols-3-1">
    <div class="card">
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Employee</th><th>Leave</th><th>Dates</th><th class="num">Days</th><th>Reason</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $l): ?>
                <tr>
                    <td><a href="personnel_view.php?id=<?= (int)$l['personnel_id'] ?>#leave"><strong><?= e(full_name($l)) ?></strong></a><div class="small muted"><?= e($l['position']) ?></div></td>
                    <td><?= e($l['leave_type']) ?><div class="small muted">filed <?= fmt_date($l['created_at']) ?></div></td>
                    <td class="nowrap small"><?= fmt_date($l['date_from']) ?> –<br><?= fmt_date($l['date_to']) ?></td>
                    <td class="num"><?= $l['days'] + 0 ?></td>
                    <td class="small"><?= e($l['reason']) ?></td>
                    <td><?= badge($l['status']) ?>
                        <?php if ($l['reviewer']): ?><div class="small muted">by <?= e($l['reviewer']) ?></div><?php endif; ?>
                        <?php if ($l['remarks']): ?><div class="small"><?= e($l['remarks']) ?></div><?php endif; ?></td>
                    <td class="actions">
                        <?php if ($l['status'] === 'pending' && can('hr', 'approve')): ?>
                            <?= post_button('leaves.php', 'Approve', ['action' => 'approve', 'leave_id' => $l['leave_id']], 'btn btn-sm btn-success') ?>
                            <details class="pop">
                                <summary class="btn btn-sm btn-danger">Reject</summary>
                                <div class="pop-body">
                                    <form method="post" action="leaves.php">
                                        <?= csrf_field() ?><?= back_field() ?>
                                        <input type="hidden" name="action" value="reject">
                                        <input type="hidden" name="leave_id" value="<?= (int)$l['leave_id'] ?>">
                                        <?= field('Reason (shown to the employee)', 'remarks', '', 'text', 'required maxlength="255"') ?>
                                        <button class="btn btn-danger btn-sm">Reject leave</button>
                                    </form>
                                </div>
                            </details>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$rows): ?><tr><td colspan="7" class="empty">No leave requests here.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
        <?= pagination_links($pg) ?>
    </div>

    <?php if (can('hr', 'edit')): ?>
    <div class="card" id="file">
        <h3>File leave for an employee</h3>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="file">
            <div class="form-grid one">
                <?= select_field('Employee', 'personnel_id', personnel_options(), $f['personnel_id'], 'required class="searchable"') ?>
                <?= select_field('Leave type', 'leave_type', LEAVE_TYPES, $f['leave_type'], 'required', false) ?>
                <?= field('From', 'date_from', $f['date_from'], 'date', 'required') ?>
                <?= field('To', 'date_to', $f['date_to'], 'date', 'required') ?>
                <?= field('Reason', 'reason', $f['reason'], 'text', 'required maxlength="255"') ?>
            </div>
            <p class="hint">Only weekdays are counted as leave days.</p>
            <div class="form-actions"><button class="btn btn-primary">File leave</button></div>
        </form>
    </div>
    <?php endif; ?>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
