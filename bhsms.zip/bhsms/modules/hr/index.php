<?php
/* Human Resource dashboard */
require __DIR__ . '/../../includes/init.php';
require_perm('hr');

$today = today();
$counts = [
    'active'    => (int)q("SELECT COUNT(*) FROM personnel WHERE status IN ('active', 'on leave')")->fetchColumn(),
    'volunteer' => (int)q("SELECT COUNT(*) FROM personnel WHERE status IN ('active', 'on leave') AND employment_status = 'Volunteer'")->fetchColumn(),
    'pending'   => (int)q("SELECT COUNT(*) FROM leave_requests WHERE status = 'pending'")->fetchColumn(),
    'on_leave'  => (int)q("SELECT COUNT(DISTINCT personnel_id) FROM leave_requests WHERE status = 'approved' AND ? BETWEEN date_from AND date_to", [$today])->fetchColumn(),
    'present'   => (int)q("SELECT COUNT(*) FROM personnel_attendance WHERE work_date = ? AND status IN ('Present', 'Late', 'Half day', 'Official business')", [$today])->fetchColumn(),
    'expiring'  => (int)q("SELECT COUNT(*) FROM personnel WHERE status = 'active' AND license_expiry IS NOT NULL AND license_expiry <= ?", [date('Y-m-d', strtotime('+90 days'))])->fetchColumn(),
];
$pendingLeaves = q("SELECT l.*, p.first_name, p.middle_name, p.last_name, p.suffix, p.position FROM leave_requests l
                    JOIN personnel p ON p.personnel_id = l.personnel_id WHERE l.status = 'pending' ORDER BY l.date_from LIMIT 8")->fetchAll();
$onLeave = q("SELECT l.*, p.first_name, p.middle_name, p.last_name, p.suffix, p.position FROM leave_requests l
              JOIN personnel p ON p.personnel_id = l.personnel_id
              WHERE l.status = 'approved' AND l.date_to >= ? ORDER BY l.date_from LIMIT 8", [$today])->fetchAll();
$expiring = q("SELECT * FROM personnel WHERE status = 'active' AND license_expiry IS NOT NULL AND license_expiry <= ?
               ORDER BY license_expiry LIMIT 8", [date('Y-m-d', strtotime('+90 days'))])->fetchAll();
$byPosition = q("SELECT position, COUNT(*) AS n FROM personnel WHERE status IN ('active', 'on leave') GROUP BY position ORDER BY n DESC")->fetchAll();
$maxPos = max(array_merge([1], array_column($byPosition, 'n')));

$page_title = 'HR Dashboard';
$page_kicker = 'Human Resource';
require __DIR__ . '/../../includes/header.php';
?>
<div class="page-head">
    <div>
        <h2>Health center workforce</h2>
        <div class="muted"><?= date('l, F j, Y') ?></div>
    </div>
    <div class="btn-group">
        <?php if (can('hr', 'edit')): ?>
            <a class="btn" href="attendance.php">Today's attendance</a>
            <a class="btn btn-primary" href="personnel_form.php">+ Add personnel</a>
        <?php endif; ?>
    </div>
</div>

<div class="stats">
    <a class="stat" href="personnel.php"><div class="label">Active personnel</div><div class="value"><?= $counts['active'] ?></div><div class="sub"><?= $counts['volunteer'] ?> volunteers</div></a>
    <a class="stat blue" href="attendance.php"><div class="label">Reported for duty today</div><div class="value"><?= $counts['present'] ?></div></a>
    <a class="stat amber" href="leaves.php?status=pending"><div class="label">Leave requests to review</div><div class="value"><?= $counts['pending'] ?></div></a>
    <a class="stat purple" href="leaves.php?status=approved"><div class="label">On leave today</div><div class="value"><?= $counts['on_leave'] ?></div></a>
    <a class="stat <?= $counts['expiring'] ? 'red' : '' ?>" href="personnel.php?expiring=1"><div class="label">Licenses expiring (90 days)</div><div class="value"><?= $counts['expiring'] ?></div></a>
</div>

<div class="grid cols-2">
    <div class="card">
        <div class="card-header"><h3>Leave requests waiting for approval</h3><a class="btn btn-sm" href="leaves.php?status=pending">Open</a></div>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Employee</th><th>Type</th><th>Dates</th><th class="num">Days</th></tr></thead>
            <tbody>
            <?php foreach ($pendingLeaves as $l): ?>
                <tr>
                    <td><strong><?= e(full_name($l)) ?></strong><div class="small muted"><?= e($l['position']) ?></div></td>
                    <td><?= e($l['leave_type']) ?></td>
                    <td class="nowrap small"><?= fmt_date($l['date_from']) ?> – <?= fmt_date($l['date_to']) ?></td>
                    <td class="num"><?= e($l['days'] + 0) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$pendingLeaves): ?><tr><td colspan="4" class="empty">No pending leave requests.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>

    <div class="card">
        <div class="card-header"><h3>Current &amp; upcoming approved leave</h3></div>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Employee</th><th>Type</th><th>Dates</th></tr></thead>
            <tbody>
            <?php foreach ($onLeave as $l): ?>
                <tr>
                    <td><?= e(full_name($l)) ?><div class="small muted"><?= e($l['position']) ?></div></td>
                    <td><?= e($l['leave_type']) ?></td>
                    <td class="nowrap small"><?= fmt_date($l['date_from']) ?> – <?= fmt_date($l['date_to']) ?>
                        <?= $l['date_from'] <= today() ? ' <span class="badge badge-purple">On leave</span>' : '' ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$onLeave): ?><tr><td colspan="3" class="empty">Nobody is on leave.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>

    <div class="card">
        <div class="card-header"><h3>Licenses &amp; accreditations expiring</h3></div>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Employee</th><th>License no.</th><th>Expiry</th></tr></thead>
            <tbody>
            <?php foreach ($expiring as $p): ?>
                <tr>
                    <td><a href="personnel_view.php?id=<?= (int)$p['personnel_id'] ?>"><?= e(full_name($p)) ?></a><div class="small muted"><?= e($p['position']) ?></div></td>
                    <td><?= e($p['license_no']) ?></td>
                    <td><?= fmt_date($p['license_expiry']) ?> <?= badge($p['license_expiry'] < today() ? 'expired' : 'due soon') ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$expiring): ?><tr><td colspan="3" class="empty">No licenses expiring in the next 90 days.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>

    <div class="card">
        <h3>Personnel by position</h3>
        <?php foreach ($byPosition as $bp): ?>
            <div class="bar-row">
                <span><?= e($bp['position']) ?></span>
                <div class="bar"><i style="width:<?= round($bp['n'] / $maxPos * 100) ?>%"></i></div>
                <b><?= (int)$bp['n'] ?></b>
            </div>
        <?php endforeach; ?>
        <?php if (!$byPosition): ?><p class="empty">No personnel yet.</p><?php endif; ?>
    </div>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
