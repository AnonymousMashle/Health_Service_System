<?php
/*
 * Sends a resident photo (?photo=<resident_id>) or document (?doc=<document_id>[&download=1]).
 * Files live in uploads/, which the browser cannot open directly (.htaccess "Require all denied"),
 * so every file goes through this page and its access check:
 *   - staff who can view residents: any resident
 *   - a resident: their own files and those of household members under 18
 */
require __DIR__ . '/../../includes/init.php';
require_login();

$residentId = 0;
$path = null;
$mime = 'application/octet-stream';
$downloadName = null;

if (get('photo') !== '') {
    $r = q('SELECT resident_id, photo_path FROM residents WHERE resident_id = ?', [(int)get('photo')])->fetch();
    if ($r && $r['photo_path']) {
        $residentId = (int)$r['resident_id'];
        $path = $r['photo_path'];
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        $mime = ['jpg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp'][$ext] ?? $mime;
    }
} elseif (get('doc') !== '') {
    $d = q('SELECT * FROM resident_documents WHERE document_id = ?', [(int)get('doc')])->fetch();
    if ($d) {
        $residentId = (int)$d['resident_id'];
        $path = $d['file_path'];
        $mime = $d['mime_type'];
        $downloadName = $d['original_name'];
    }
}

// Access check
$allowed = false;
if ($residentId) {
    if (user_role() === 'resident') {
        $self = q('SELECT resident_id, household_id FROM residents WHERE resident_id = ?', [(int)(current_user()['resident_id'] ?? 0)])->fetch();
        if ($self) {
            $allowed = $residentId === (int)$self['resident_id']
                || ($self['household_id'] && q("SELECT 1 FROM residents WHERE resident_id = ? AND household_id = ? AND TIMESTAMPDIFF(YEAR, birthdate, CURDATE()) < 18",
                                               [$residentId, $self['household_id']])->fetchColumn());
        }
    } else {
        $allowed = can('residents');
    }
}

$full = $path ? realpath(UPLOAD_DIR . '/' . $path) : false;
$root = realpath(UPLOAD_DIR);
if (!$allowed || !$full || !$root || strpos($full, $root . DIRECTORY_SEPARATOR) !== 0 || !is_file($full)) {
    http_response_code(404);
    exit('File not found or you do not have access to it.');
}

if ($downloadName !== null && get('download') === '1') {
    log_activity('DOWNLOAD', 'resident_documents', (int)get('doc'), 'Downloaded ' . $downloadName);
}
header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($full));
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, max-age=300');
$disposition = ($downloadName !== null && get('download') === '1') ? 'attachment' : 'inline';
header('Content-Disposition: ' . $disposition . '; filename="' . str_replace(['"', "\r", "\n"], '', $downloadName ?? basename($path)) . '"');
readfile($full);
