<?php
/* Upload or delete a resident's document attachment (valid ID, birth certificate, lab result...). POST only. */
require __DIR__ . '/../../includes/init.php';
require_perm('residents', 'edit');

if (!is_post()) {
    redirect('modules/residents/index.php');
}
$rid = (int)input('resident_id');
$r = q('SELECT resident_id, first_name, last_name FROM residents WHERE resident_id = ?', [$rid])->fetch();
if (!$r) {
    flash('danger', 'Resident not found.');
    redirect('modules/residents/index.php');
}
$back = 'modules/residents/view.php?id=' . $rid . '#documents';

if (input('action') === 'upload') {
    $title = input('title');
    $type = input('doc_type');
    $errors = [];
    if ($title === '') $errors[] = 'Give the document a title.';
    if (!in_array($type, DOC_TYPES, true)) $errors[] = 'Choose the document type.';
    if (!$errors) {
        try {
            $file = store_upload('document', 'documents', ['image', 'pdf'], 5 * 1024 * 1024);
            if ($file === null) {
                $errors[] = 'Choose a file to upload.';
            } else {
                $did = db_insert('resident_documents', [
                    'resident_id' => $rid, 'title' => mb_substr($title, 0, 150), 'doc_type' => $type, 'file_path' => $file['path'],
                    'original_name' => $file['name'], 'mime_type' => $file['mime'], 'file_size' => $file['size'], 'uploaded_by' => user_id(),
                ]);
                log_activity('UPLOAD', 'resident_documents', $did, $type . ' for ' . $r['first_name'] . ' ' . $r['last_name']);
                flash('success', 'Document uploaded: ' . $title . '.');
            }
        } catch (RuntimeException $ex) {
            $errors[] = $ex->getMessage();
        }
    }
    foreach ($errors as $err) {
        flash('danger', $err);
    }
}

if (input('action') === 'delete') {
    $d = q('SELECT * FROM resident_documents WHERE document_id = ? AND resident_id = ?', [(int)input('document_id'), $rid])->fetch();
    if ($d) {
        q('DELETE FROM resident_documents WHERE document_id = ?', [$d['document_id']]);
        delete_upload($d['file_path']);
        log_activity('DELETE', 'resident_documents', $d['document_id'], 'Deleted document ' . $d['title']);
        flash('success', 'Document deleted.');
    }
}
redirect($back);
