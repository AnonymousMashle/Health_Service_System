<?php
/* BHW / Nurse verify resident accounts created through online registration. */
require __DIR__ . '/../../includes/init.php';
require_perm('residents', 'edit');

const RELATIONSHIPS = ['Head', 'Spouse', 'Partner', 'Son', 'Daughter', 'Father', 'Mother', 'Sibling', 'Grandchild', 'Relative', 'Other'];

if (is_post()) {
    $uid = (int)input('user_id');
    $action = input('action');
    $u = q("SELECT u.*, r.status AS resident_status, r.household_id, r.first_name, r.last_name
            FROM users u LEFT JOIN residents r ON r.resident_id = u.resident_id
            WHERE u.user_id = ? AND u.role = 'resident' AND u.status = 'pending'", [$uid])->fetch();
    if (!$u) {
        flash('danger', 'That registration was already processed or does not exist.');
        redirect('modules/residents/registrations.php');
    }
    $name = $u['full_name'];

    if ($action === 'approve') {
        $householdId = input('household_id');
        $relationship = input('relationship_to_head');
        if ($householdId === 'new') {
            // Create a household from the address the resident typed ("street, purok"), with the resident as head
            $addr = (string)$u['registered_address'];
            $cut = strrpos($addr, ',');
            $street = trim($cut === false ? $addr : substr($addr, 0, $cut));
            $purok = trim($cut === false ? 'Unassigned' : substr($addr, $cut + 1));
            $householdId = (string)create_household($street !== '' ? $street : 'Not given', $purok !== '' ? $purok : 'Unassigned');
            $relationship = 'Head';
        }
        if ($householdId !== '' && !q('SELECT 1 FROM households WHERE household_id = ?', [$householdId])->fetchColumn()) {
            flash('danger', 'Selected household does not exist.');
            redirect('modules/residents/registrations.php');
        }
        db()->beginTransaction();
        q("UPDATE users SET status = 'active', remarks = NULL, verified_by = ?, verified_at = NOW() WHERE user_id = ?", [user_id(), $uid]);
        if ($u['resident_id']) {
            q("UPDATE residents SET status = 'active', created_by = COALESCE(created_by, ?) WHERE resident_id = ? AND status = 'pending'", [user_id(), $u['resident_id']]);
            if ($householdId !== '' && !$u['household_id']) {
                q('UPDATE residents SET household_id = ?, relationship_to_head = ? WHERE resident_id = ?',
                  [$householdId, nullable($relationship), $u['resident_id']]);
                if ($relationship === 'Head') {
                    q('UPDATE households SET head_resident_id = COALESCE(head_resident_id, ?) WHERE household_id = ?', [$u['resident_id'], $householdId]);
                }
            }
        }
        db()->commit();
        notify($uid, 'Account verified', 'Welcome! Your resident account has been approved. You can now view your health records and request appointments.', 'portal/index.php');
        log_activity('VERIFY', 'users', $uid, 'Approved resident registration of ' . $name);
        flash('success', $name . "'s account is approved and can now log in.");
    }

    if ($action === 'reject') {
        $reason = input('remarks');
        if ($reason === '') {
            flash('danger', 'Give a reason for rejecting the registration (the resident will see it).');
            redirect('modules/residents/registrations.php');
        }
        db()->beginTransaction();
        q("UPDATE users SET status = 'rejected', remarks = ?, verified_by = ?, verified_at = NOW(), resident_id = NULL WHERE user_id = ?", [$reason, user_id(), $uid]);
        // Remove the resident record only if it was created by this registration and has no health records
        if ($u['resident_id'] && $u['resident_status'] === 'pending') {
            q("DELETE FROM residents WHERE resident_id = ? AND status = 'pending'
               AND NOT EXISTS (SELECT 1 FROM consultations WHERE resident_id = ?)
               AND NOT EXISTS (SELECT 1 FROM vaccinations WHERE resident_id = ?)", [$u['resident_id'], $u['resident_id'], $u['resident_id']]);
        }
        db()->commit();
        log_activity('VERIFY', 'users', $uid, 'Rejected resident registration of ' . $name . ': ' . $reason);
        flash('success', $name . "'s registration was rejected.");
    }
    redirect('modules/residents/registrations.php');
}

$pending = q("SELECT u.user_id, u.username, u.email, u.registered_address, u.created_at,
                     r.resident_id, r.first_name, r.middle_name, r.last_name, r.suffix, r.sex, r.birthdate, r.civil_status,
                     r.contact_no, r.status AS resident_status, r.household_id, h.household_no, h.purok,
                     (SELECT COUNT(*) FROM residents d WHERE d.status = 'active' AND d.last_name = r.last_name
                         AND d.birthdate = r.birthdate AND d.resident_id <> r.resident_id) AS possible_duplicates
              FROM users u LEFT JOIN residents r ON r.resident_id = u.resident_id
              LEFT JOIN households h ON h.household_id = r.household_id
              WHERE u.role = 'resident' AND u.status = 'pending' ORDER BY u.created_at")->fetchAll();
$processed = q("SELECT u.user_id, u.username, u.full_name, u.status, u.remarks, u.verified_at, v.full_name AS verifier
                FROM users u LEFT JOIN users v ON v.user_id = u.verified_by
                WHERE u.role = 'resident' AND u.verified_at IS NOT NULL ORDER BY u.verified_at DESC LIMIT 15")->fetchAll();
$households = household_options();

$page_title = 'Account Verification';
$page_kicker = 'Residents';
require __DIR__ . '/../../includes/header.php';
?>
<div class="alert alert-info">
    Residents register on the public homepage. Check each person against your records (and a valid ID if they visit) before approving.
    <strong>Existing record</strong> means the name and birthdate matched someone already in the registry.
</div>

<div class="card">
    <div class="card-header"><h3>Waiting for verification (<?= count($pending) ?>)</h3></div>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Registered</th><th>Name</th><th>Sex / Age</th><th>Contact</th><th>Address given</th><th>Match</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($pending as $p): $isExisting = $p['resident_status'] === 'active'; ?>
            <tr>
                <td class="nowrap small"><?= fmt_datetime($p['created_at']) ?><div class="muted">@<?= e($p['username']) ?></div></td>
                <td><strong><?= $p['last_name'] ? e(full_name($p)) : '—' ?></strong><div class="small muted">Born <?= fmt_date($p['birthdate']) ?> &middot; <?= e($p['civil_status']) ?></div></td>
                <td class="nowrap"><?= e($p['sex']) ?>, <?= e(age_label($p['birthdate'])) ?></td>
                <td class="small"><?= e($p['contact_no']) ?><div class="muted"><?= e($p['email']) ?></div></td>
                <td class="small"><?= e($p['registered_address']) ?></td>
                <td class="small">
                    <?php if ($isExisting): ?>
                        <span class="badge badge-green">Existing record</span>
                        <div><a href="<?= e(url('modules/residents/view.php?id=' . $p['resident_id'])) ?>" target="_blank">View #<?= (int)$p['resident_id'] ?></a>
                            <?= $p['household_no'] ? '&middot; ' . e($p['household_no']) . ', ' . e($p['purok']) : '' ?></div>
                    <?php else: ?>
                        <span class="badge badge-blue">New resident</span>
                        <?php if ($p['possible_duplicates']): ?><div class="text-danger">&#9888; <?= (int)$p['possible_duplicates'] ?> resident(s) with same last name &amp; birthdate</div><?php endif; ?>
                    <?php endif; ?>
                </td>
                <td class="actions">
                    <details class="pop">
                        <summary class="btn btn-sm btn-success">Approve</summary>
                        <div class="pop-body">
                            <form method="post">
                                <?= csrf_field() ?>
                                <input type="hidden" name="user_id" value="<?= (int)$p['user_id'] ?>">
                                <input type="hidden" name="action" value="approve">
                                <?php if (!$p['household_id']): ?>
                                    <div class="field">
                                        <label>Assign to household</label>
                                        <select name="household_id" class="searchable" data-placeholder="Search head's name or HH no.">
                                            <option value="">-- Assign later --</option>
                                            <option value="new">+ New household from the address given (resident becomes head)</option>
                                            <?= options($households, '', false) ?>
                                        </select>
                                    </div>
                                    <?= select_field('Relationship to head', 'relationship_to_head', RELATIONSHIPS, '', '', '-- Select --') ?>
                                <?php else: ?>
                                    <p class="small">Household: <?= e($p['household_no']) ?></p>
                                <?php endif; ?>
                                <button class="btn btn-success btn-sm">Approve account</button>
                            </form>
                        </div>
                    </details>
                    <details class="pop">
                        <summary class="btn btn-sm btn-danger">Reject</summary>
                        <div class="pop-body">
                            <form method="post">
                                <?= csrf_field() ?>
                                <input type="hidden" name="user_id" value="<?= (int)$p['user_id'] ?>">
                                <input type="hidden" name="action" value="reject">
                                <?= field('Reason (shown to the resident)', 'remarks', '', 'text', 'required maxlength="255" placeholder="e.g. Not a resident of this barangay"') ?>
                                <button class="btn btn-danger btn-sm">Reject registration</button>
                            </form>
                        </div>
                    </details>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$pending): ?><tr><td colspan="7" class="empty">No registrations waiting for verification.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div>

<div class="card">
    <h3>Recently processed</h3>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Date</th><th>Resident</th><th>Result</th><th>Remarks</th><th>By</th></tr></thead>
        <tbody>
        <?php foreach ($processed as $p): ?>
            <tr>
                <td class="nowrap small"><?= fmt_datetime($p['verified_at']) ?></td>
                <td><?= e($p['full_name']) ?> <span class="small muted">@<?= e($p['username']) ?></span></td>
                <td><?= badge($p['status'] === 'rejected' ? 'rejected' : 'approved') ?></td>
                <td class="small"><?= e($p['remarks']) ?></td>
                <td class="small"><?= e($p['verifier']) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$processed): ?><tr><td colspan="5" class="empty">Nothing processed yet.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
