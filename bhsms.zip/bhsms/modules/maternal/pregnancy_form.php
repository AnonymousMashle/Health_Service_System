<?php
/* Register or update a pregnancy. EDD = LMP + 280 days (computed automatically). High-risk pregnancies alert the nurses. */
require __DIR__ . '/../../includes/init.php';
require_perm('maternal', 'edit');

$id = (int)get('id');
$p = ['resident_id' => get('resident_id'), 'lmp' => '', 'edd' => '', 'gravida' => 1, 'para' => 0, 'risk_level' => 'Low', 'risk_notes' => '',
      'status' => 'ongoing', 'delivery_date' => '', 'delivery_place' => ''];
if ($id) {
    $row = q('SELECT * FROM pregnancies WHERE pregnancy_id = ?', [$id])->fetch();
    if (!$row) {
        flash('danger', 'Pregnancy record not found.');
        redirect('modules/maternal/index.php');
    }
    $p = array_map(function ($x) { return $x ?? ''; }, $row);
}

$errors = [];
if (is_post()) {
    $oldRisk = $p['risk_level'];
    foreach (['resident_id', 'lmp', 'edd', 'gravida', 'para', 'risk_level', 'risk_notes'] as $k) { $p[$k] = input($k); }
    if ($id) {
        foreach (['status', 'delivery_date', 'delivery_place'] as $k) { $p[$k] = input($k); }
    }
    $mother = q("SELECT * FROM residents WHERE resident_id = ? AND status = 'active' AND sex = 'Female'", [(int)$p['resident_id']])->fetch();
    if (!$mother) $errors[] = 'Choose the mother (a female resident).';
    if (!valid_date($p['lmp'])) {
        $errors[] = 'Enter the last menstrual period (LMP).';
    } elseif ($p['lmp'] > today()) {
        $errors[] = 'The LMP cannot be in the future.';
    } elseif (!$id && $p['lmp'] < date('Y-m-d', strtotime('-300 days'))) {
        $errors[] = 'The LMP is more than 300 days ago. Check the date.';
    }
    if ($p['edd'] === '' && valid_date($p['lmp'])) {
        $p['edd'] = date('Y-m-d', strtotime($p['lmp'] . ' +280 days'));     // Naegele's rule
    }
    if (!valid_date($p['edd']) || ($p['lmp'] !== '' && $p['edd'] <= $p['lmp'])) $errors[] = 'Enter a valid expected delivery date (after the LMP).';
    if (!ctype_digit((string)$p['gravida']) || $p['gravida'] < 1 || $p['gravida'] > 20) $errors[] = 'Gravida must be 1 to 20.';
    if (!ctype_digit((string)$p['para']) || $p['para'] < 0 || $p['para'] >= max(1, (int)$p['gravida'])) $errors[] = 'Para must be lower than gravida.';
    if (!in_array($p['risk_level'], ['Low', 'Moderate', 'High'], true)) $errors[] = 'Choose the risk level.';
    if ($p['risk_level'] === 'High' && $p['risk_notes'] === '') $errors[] = 'Write the reason for the high-risk classification.';
    if (!in_array($p['status'], ['ongoing', 'delivered', 'miscarriage', 'transferred'], true)) $errors[] = 'Choose a status.';
    if ($p['status'] === 'delivered') {
        if (!valid_date($p['delivery_date']) || $p['delivery_date'] > today() || $p['delivery_date'] < $p['lmp']) $errors[] = 'Enter a valid delivery date.';
        if ($p['delivery_place'] === '') $errors[] = 'Enter the place of delivery.';
    }
    if ($mother && $p['status'] === 'ongoing'
        && q("SELECT 1 FROM pregnancies WHERE resident_id = ? AND status = 'ongoing' AND pregnancy_id <> ?", [$mother['resident_id'], $id])->fetchColumn()) {
        $errors[] = 'This resident already has an ongoing pregnancy record.';
    }

    if (!$errors) {
        $data = [
            'resident_id' => (int)$p['resident_id'], 'lmp' => $p['lmp'], 'edd' => $p['edd'], 'gravida' => (int)$p['gravida'], 'para' => (int)$p['para'],
            'risk_level' => $p['risk_level'], 'risk_notes' => nullable($p['risk_notes']), 'status' => $p['status'],
            'delivery_date' => $p['status'] === 'delivered' ? $p['delivery_date'] : null,
            'delivery_place' => $p['status'] === 'delivered' ? $p['delivery_place'] : null,
        ];
        if ($id) {
            db_update('pregnancies', $data, 'pregnancy_id', $id);
            log_activity('UPDATE', 'pregnancies', $id, 'Updated pregnancy of ' . $mother['first_name'] . ' ' . $mother['last_name'] . ' (' . $p['status'] . ')');
        } else {
            $data['registered_by'] = user_id();
            $id = db_insert('pregnancies', $data);
            log_activity('CREATE', 'pregnancies', $id, 'Registered pregnancy of ' . $mother['first_name'] . ' ' . $mother['last_name']);
        }
        if ($p['risk_level'] === 'High' && $oldRisk !== 'High' && $p['status'] === 'ongoing') {
            notify_roles(['nurse'], 'High-risk pregnancy', $mother['first_name'] . ' ' . $mother['last_name'] . ': ' . $p['risk_notes'], 'modules/maternal/pregnancy_view.php?id=' . $id);
        }
        flash('success', 'Pregnancy record saved. EDD: ' . fmt_date($p['edd']) . '.' . ($p['status'] === 'delivered' ? ' Remember to register the newborn as a resident.' : ''));
        redirect('modules/maternal/pregnancy_view.php?id=' . $id);
    }
}

$page_title = $id ? 'Edit Pregnancy' : 'Register Pregnancy';
$nav_active = 'modules/maternal/index.php';
$page_kicker = 'Maternal Health';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<form method="post" class="card">
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="field required span-2">
            <label for="f_resident_id">Mother</label>
            <select id="f_resident_id" name="resident_id" class="searchable" required data-placeholder="Type the mother's name">
                <?= options(resident_options("sex = 'Female' AND TIMESTAMPDIFF(YEAR, birthdate, CURDATE()) BETWEEN 10 AND 60"), $p['resident_id']) ?>
            </select>
        </div>
        <?= field('Last menstrual period (LMP)', 'lmp', $p['lmp'], 'date', 'required max="' . today() . '"') ?>
        <?= field('Expected delivery date (EDD)', 'edd', $p['edd'], 'date', 'placeholder="LMP + 280 days"') ?>
        <?= field('Gravida (no. of pregnancies incl. this)', 'gravida', $p['gravida'], 'number', 'required min="1" max="20"') ?>
        <?= field('Para (no. of births)', 'para', $p['para'], 'number', 'required min="0" max="19"') ?>
        <?= select_field('Risk level', 'risk_level', ['Low', 'Moderate', 'High'], $p['risk_level'], 'required', false) ?>
        <?= field('Risk notes', 'risk_notes', $p['risk_notes'], 'text', 'maxlength="255" placeholder="e.g. Age 35+, hypertension, anemia"') ?>
        <?php if ($id): ?>
            <?= select_field('Status', 'status', ['ongoing' => 'Ongoing', 'delivered' => 'Delivered', 'miscarriage' => 'Miscarriage', 'transferred' => 'Transferred'], $p['status'], 'required', false) ?>
            <div data-show-when="status=delivered"><?= field('Delivery date', 'delivery_date', $p['delivery_date'], 'date', 'max="' . today() . '"') ?></div>
            <div data-show-when="status=delivered"><?= field('Place of delivery', 'delivery_place', $p['delivery_place'], 'text', 'maxlength="150" placeholder="e.g. Baguio General Hospital"') ?></div>
        <?php endif; ?>
    </div>
    <p class="hint">The EDD fills in automatically when you choose the LMP (Naegele's rule: LMP + 280 days).</p>
    <div class="form-actions">
        <a class="btn" href="<?= e(url($id ? 'modules/maternal/pregnancy_view.php?id=' . $id : 'modules/maternal/index.php')) ?>">Cancel</a>
        <button class="btn btn-primary">Save</button>
    </div>
</form>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
