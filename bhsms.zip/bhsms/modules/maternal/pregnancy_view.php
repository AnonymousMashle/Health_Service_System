<?php
/* One pregnancy: details, prenatal visit history and the form to record a prenatal visit. */
require __DIR__ . '/../../includes/init.php';
require_perm('maternal');

$id = (int)get('id');
$p = q('SELECT p.*, r.first_name, r.middle_name, r.last_name, r.suffix, r.birthdate, r.contact_no, u.full_name AS registrar
        FROM pregnancies p JOIN residents r ON r.resident_id = p.resident_id LEFT JOIN users u ON u.user_id = p.registered_by
        WHERE p.pregnancy_id = ?', [$id])->fetch();
if (!$p) {
    flash('danger', 'Pregnancy record not found.');
    redirect('modules/maternal/index.php');
}

$errors = [];
$v = ['visit_date' => today(), 'blood_pressure' => '', 'weight_kg' => '', 'fundal_height_cm' => '', 'fetal_heart_rate' => '',
      'findings' => '', 'supplements_given' => 'Ferrous sulfate + Folic acid', 'next_visit' => date('Y-m-d', strtotime('+28 days'))];
if (is_post() && input('action') === 'add_visit') {
    require_perm('maternal', 'edit');
    foreach (array_keys($v) as $k) { $v[$k] = input($k); }
    if ($p['status'] !== 'ongoing') $errors[] = 'Prenatal visits can only be added to an ongoing pregnancy.';
    if (!valid_date($v['visit_date']) || $v['visit_date'] > today() || $v['visit_date'] < $p['lmp']) $errors[] = 'Enter a valid visit date (between the LMP and today).';
    if ($v['blood_pressure'] !== '' && !preg_match('#^\d{2,3}/\d{2,3}$#', $v['blood_pressure'])) $errors[] = 'Blood pressure must look like 110/70.';
    foreach (['weight_kg' => ['Weight', 30, 200], 'fundal_height_cm' => ['Fundal height', 5, 50], 'fetal_heart_rate' => ['Fetal heart rate', 90, 200]] as $f => [$label, $min, $max]) {
        if ($v[$f] !== '' && (!is_numeric($v[$f]) || $v[$f] < $min || $v[$f] > $max)) $errors[] = "$label must be between $min and $max.";
    }
    if ($v['next_visit'] !== '' && (!valid_date($v['next_visit']) || $v['next_visit'] <= $v['visit_date'])) $errors[] = 'The next visit must be after the visit date.';
    if (!$errors) {
        $aog = aog_weeks($p['lmp'], $v['visit_date']);
        $vid = db_insert('prenatal_visits', [
            'pregnancy_id' => $id, 'visit_date' => $v['visit_date'], 'aog_weeks' => $aog, 'blood_pressure' => nullable($v['blood_pressure']),
            'weight_kg' => nullable($v['weight_kg']), 'fundal_height_cm' => nullable($v['fundal_height_cm']), 'fetal_heart_rate' => nullable($v['fetal_heart_rate']),
            'findings' => nullable($v['findings']), 'supplements_given' => nullable($v['supplements_given']), 'next_visit' => nullable($v['next_visit']),
            'recorded_by' => user_id(),
        ]);
        // The scheduled prenatal visit for this day is now done
        q("UPDATE health_visit_schedules SET status = 'done' WHERE resident_id = ? AND visit_type = 'Prenatal' AND status = 'scheduled' AND scheduled_date <= ?",
          [$p['resident_id'], $v['visit_date']]);
        log_activity('CREATE', 'prenatal_visits', $vid, 'Prenatal visit (AOG ' . $aog . ' wks) for ' . $p['first_name'] . ' ' . $p['last_name']);
        if ($v['next_visit'] !== '') {
            notify_resident((int)$p['resident_id'], 'Next prenatal check-up', 'Your next prenatal check-up is on ' . fmt_date($v['next_visit']) . '.');
        }
        // High blood pressure in pregnancy is a danger sign: alert the nurses
        if ($v['blood_pressure'] !== '' && ((int)explode('/', $v['blood_pressure'])[0] >= 140 || (int)explode('/', $v['blood_pressure'])[1] >= 90)) {
            notify_roles(['nurse'], 'High BP in pregnancy', $p['first_name'] . ' ' . $p['last_name'] . ' had BP ' . $v['blood_pressure'] . ' at ' . $aog . ' weeks.', 'modules/maternal/pregnancy_view.php?id=' . $id);
            flash('warning', 'Blood pressure ' . $v['blood_pressure'] . ' is high for a pregnant woman. The nurses were alerted.');
        }
        flash('success', 'Prenatal visit saved (AOG ' . $aog . ' weeks).');
        redirect('modules/maternal/pregnancy_view.php?id=' . $id);
    }
}

$visits = q('SELECT pv.*, u.full_name AS recorder FROM prenatal_visits pv LEFT JOIN users u ON u.user_id = pv.recorded_by
             WHERE pv.pregnancy_id = ? ORDER BY pv.visit_date DESC, pv.visit_id DESC', [$id])->fetchAll();
$nextVisit = $visits[0]['next_visit'] ?? null;
$aogNow = $p['status'] === 'ongoing' ? aog_weeks($p['lmp']) : null;
$trimester = $aogNow === null ? '' : ($aogNow < 14 ? '1st trimester' : ($aogNow < 28 ? '2nd trimester' : '3rd trimester'));

$page_title = 'Pregnancy Record';
$nav_active = 'modules/maternal/index.php';
$page_kicker = 'Maternal Health';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<div class="page-head">
    <div>
        <h2><a href="<?= e(url('modules/residents/view.php?id=' . $p['resident_id'])) ?>"><?= e(full_name($p)) ?></a> <?= badge($p['status']) ?> <?= badge($p['risk_level']) ?></h2>
        <div class="muted"><?= e(age_label($p['birthdate'])) ?> old &middot; G<?= (int)$p['gravida'] ?> P<?= (int)$p['para'] ?>
            <?= $aogNow !== null ? ' &middot; AOG <strong>' . $aogNow . ' weeks</strong> (' . $trimester . ')' : '' ?></div>
    </div>
    <div class="btn-group no-print">
        <?php if (can('maternal', 'edit')): ?><a class="btn" href="pregnancy_form.php?id=<?= $id ?>"><?= $p['status'] === 'ongoing' ? 'Edit / record delivery' : 'Edit' ?></a><?php endif; ?>
        <button class="btn" data-print>Print</button>
    </div>
</div>

<div class="grid cols-2 mb">
    <div class="card">
        <h3>Pregnancy details</h3>
        <dl class="info">
            <dt>LMP</dt><dd><?= fmt_date($p['lmp']) ?></dd>
            <dt>EDD</dt><dd><strong><?= fmt_date($p['edd']) ?></strong></dd>
            <dt>Risk notes</dt><dd class="<?= $p['risk_level'] === 'High' ? 'text-danger' : '' ?>"><?= e($p['risk_notes'] ?: '—') ?></dd>
            <dt>Next prenatal visit</dt><dd><?= $p['status'] === 'ongoing' ? fmt_date($nextVisit) . ($nextVisit && $nextVisit < today() ? ' ' . badge('overdue') : '') : '—' ?></dd>
            <?php if ($p['status'] === 'delivered'): ?><dt>Delivered</dt><dd><?= fmt_date($p['delivery_date']) ?> at <?= e($p['delivery_place']) ?></dd><?php endif; ?>
            <dt>Contact no.</dt><dd><?= e($p['contact_no'] ?: '—') ?></dd>
            <dt>Registered by</dt><dd class="small"><?= e($p['registrar'] ?: '—') ?>, <?= fmt_datetime($p['created_at']) ?></dd>
        </dl>
    </div>
    <?php if ($p['status'] === 'ongoing' && can('maternal', 'edit')): ?>
    <form method="post" class="card">
        <h3>Record prenatal visit</h3>
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="add_visit">
        <div class="form-grid">
            <?= field('Visit date', 'visit_date', $v['visit_date'], 'date', 'required max="' . today() . '"') ?>
            <?= field('Blood pressure', 'blood_pressure', $v['blood_pressure'], 'text', 'maxlength="7" placeholder="110/70"') ?>
            <?= field('Weight (kg)', 'weight_kg', $v['weight_kg'], 'number', 'step="0.1" min="30" max="200"') ?>
            <?= field('Fundal height (cm)', 'fundal_height_cm', $v['fundal_height_cm'], 'number', 'step="0.1" min="5" max="50"') ?>
            <?= field('Fetal heart rate (bpm)', 'fetal_heart_rate', $v['fetal_heart_rate'], 'number', 'min="90" max="200"') ?>
            <?= field('Next visit', 'next_visit', $v['next_visit'], 'date') ?>
            <?= field('Supplements given', 'supplements_given', $v['supplements_given'], 'text', 'maxlength="255"', 'span-2') ?>
            <?= field('Findings', 'findings', $v['findings'], 'textarea', '', 'span-2') ?>
        </div>
        <p class="hint">Age of gestation (AOG) is computed from the LMP and the visit date.</p>
        <button class="btn btn-primary">Save visit</button>
    </form>
    <?php endif; ?>
</div>

<div class="card">
    <h3>Prenatal visits (<?= count($visits) ?>)</h3>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Date</th><th>AOG</th><th>BP</th><th class="num">Weight</th><th class="num">Fundal ht.</th><th class="num">FHR</th><th>Findings</th><th>Supplements</th><th>Next visit</th><th>By</th></tr></thead>
        <tbody>
        <?php foreach ($visits as $pv): ?>
            <tr>
                <td class="nowrap"><?= fmt_date($pv['visit_date']) ?></td>
                <td><?= e($pv['aog_weeks']) ?> wks</td>
                <td><?= e($pv['blood_pressure'] ?: '—') ?></td>
                <td class="num"><?= e($pv['weight_kg'] ?: '—') ?></td>
                <td class="num"><?= e($pv['fundal_height_cm'] ?: '—') ?></td>
                <td class="num"><?= e($pv['fetal_heart_rate'] ?: '—') ?></td>
                <td class="small"><?= e($pv['findings']) ?></td>
                <td class="small"><?= e($pv['supplements_given']) ?></td>
                <td class="nowrap"><?= fmt_date($pv['next_visit']) ?></td>
                <td class="small"><?= e($pv['recorder']) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$visits): ?><tr><td colspan="10" class="empty">No prenatal visits yet.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
