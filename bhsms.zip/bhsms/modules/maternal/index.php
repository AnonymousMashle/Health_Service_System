<?php
require __DIR__ . '/../../includes/init.php';
require_perm('maternal');

$status = get('status', 'ongoing');
$risk = get('risk');
$search = get('q');

$where = ['1=1'];
$params = [];
if (in_array($status, ['ongoing', 'delivered', 'miscarriage', 'transferred'], true)) { $where[] = 'p.status = ?'; $params[] = $status; }
if (in_array($risk, ['Low', 'Moderate', 'High'], true)) { $where[] = 'p.risk_level = ?'; $params[] = $risk; }
if ($search !== '') { $where[] = "CONCAT(r.first_name, ' ', r.last_name) LIKE ?"; $params[] = '%' . $search . '%'; }
$w = implode(' AND ', $where);

$rows = q("SELECT p.*, r.first_name, r.middle_name, r.last_name, r.suffix, r.birthdate, r.contact_no,
                  (SELECT COUNT(*) FROM prenatal_visits pv WHERE pv.pregnancy_id = p.pregnancy_id) AS visits,
                  (SELECT pv.next_visit FROM prenatal_visits pv WHERE pv.pregnancy_id = p.pregnancy_id ORDER BY pv.visit_date DESC, pv.visit_id DESC LIMIT 1) AS next_visit
           FROM pregnancies p JOIN residents r ON r.resident_id = p.resident_id
           WHERE $w ORDER BY p.status = 'ongoing' DESC, p.edd", $params)->fetchAll();

$stats = q('SELECT * FROM v_maternal_child_stats')->fetch();
$dueSoon = (int)q("SELECT COUNT(*) FROM pregnancies WHERE status = 'ongoing' AND edd <= CURDATE() + INTERVAL 30 DAY")->fetchColumn();
$missed = (int)q("SELECT COUNT(*) FROM pregnancies p WHERE p.status = 'ongoing' AND (SELECT pv.next_visit FROM prenatal_visits pv
                   WHERE pv.pregnancy_id = p.pregnancy_id ORDER BY pv.visit_date DESC, pv.visit_id DESC LIMIT 1) < CURDATE()")->fetchColumn();

$page_title = 'Maternal Health';
require __DIR__ . '/../../includes/header.php';
?>
<div class="stats">
    <a class="stat purple" href="?status=ongoing"><div class="label">Ongoing pregnancies</div><div class="value"><?= (int)$stats['ongoing_pregnancies'] ?></div></a>
    <a class="stat <?= $stats['high_risk_pregnancies'] ? 'red' : '' ?>" href="?status=ongoing&amp;risk=High"><div class="label">High-risk</div><div class="value"><?= (int)$stats['high_risk_pregnancies'] ?></div></a>
    <div class="stat amber"><div class="label">Due to deliver (30 days)</div><div class="value"><?= $dueSoon ?></div></div>
    <div class="stat <?= $missed ? 'red' : '' ?>"><div class="label">Missed prenatal visit</div><div class="value"><?= $missed ?></div></div>
    <div class="stat blue"><div class="label">Deliveries this year</div><div class="value"><?= (int)$stats['deliveries_this_year'] ?></div></div>
</div>

<div class="card">
    <div class="card-header"><h3>Pregnancy registry</h3>
        <?php if (can('maternal', 'edit')): ?><a class="btn btn-primary" href="pregnancy_form.php">+ Register pregnancy</a><?php endif; ?></div>
    <form class="toolbar" method="get">
        <div class="grow"><label>Search</label><input type="search" name="q" value="<?= e($search) ?>" placeholder="Mother's name"></div>
        <div><label>Status</label><select name="status"><?= options(['ongoing' => 'Ongoing', 'delivered' => 'Delivered', 'miscarriage' => 'Miscarriage', 'transferred' => 'Transferred'], $status, 'All') ?></select></div>
        <div><label>Risk</label><select name="risk"><?= options(['Low', 'Moderate', 'High'], $risk, 'All') ?></select></div>
        <button class="btn">Filter</button><a class="btn" href="index.php">Reset</a>
    </form>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Mother</th><th>LMP</th><th>EDD</th><th>AOG</th><th>G / P</th><th>Risk</th><th class="num">Visits</th><th>Next visit</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $p): $late = $p['status'] === 'ongoing' && $p['next_visit'] && $p['next_visit'] < today(); ?>
            <tr class="<?= $late ? 'row-danger' : ($p['risk_level'] === 'High' && $p['status'] === 'ongoing' ? 'row-warning' : '') ?>">
                <td><a href="pregnancy_view.php?id=<?= (int)$p['pregnancy_id'] ?>"><strong><?= e(full_name($p)) ?></strong></a>
                    <div class="small muted"><?= e(age_label($p['birthdate'])) ?> &middot; <?= e($p['contact_no'] ?: 'no contact no.') ?></div></td>
                <td class="nowrap"><?= fmt_date($p['lmp']) ?></td>
                <td class="nowrap"><?= fmt_date($p['edd']) ?></td>
                <td class="nowrap"><?= $p['status'] === 'ongoing' ? aog_weeks($p['lmp']) . ' wks' : '—' ?></td>
                <td>G<?= (int)$p['gravida'] ?> P<?= (int)$p['para'] ?></td>
                <td><?= badge($p['risk_level']) ?></td>
                <td class="num"><?= (int)$p['visits'] ?></td>
                <td class="nowrap"><?= $p['status'] === 'ongoing' ? fmt_date($p['next_visit']) . ($late ? ' ' . badge('overdue') : '') : '—' ?></td>
                <td><?= badge($p['status']) ?></td>
                <td class="actions"><a class="btn btn-sm" href="pregnancy_view.php?id=<?= (int)$p['pregnancy_id'] ?>">Open</a></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="10" class="empty">No pregnancies found.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
    <p class="hint">Rows in red missed their prenatal visit (next visit date has passed) — schedule a home visit under <a href="schedules.php">Scheduled Visits</a>.</p>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
