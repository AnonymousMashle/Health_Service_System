<?php
/* Children under 6 years: latest growth measurement, nutrition status and next check-up. */
require __DIR__ . '/../../includes/init.php';
require_perm('maternal');

$search = get('q');
$filter = get('filter');
$where = ["r.status = 'active'", 'r.birthdate > ?'];
$params = [date('Y-m-d', strtotime('-72 months'))];
if ($search !== '') { $where[] = "CONCAT(r.first_name, ' ', r.last_name) LIKE ?"; $params[] = '%' . $search . '%'; }
if ($filter === 'due') { $where[] = '(lm.next_visit IS NULL OR lm.next_visit <= CURDATE() + INTERVAL 7 DAY)'; }
if ($filter === 'concern') { $where[] = "lm.nutrition_status IS NOT NULL AND lm.nutrition_status <> 'Normal'"; }
$w = implode(' AND ', $where);

$rows = q("SELECT r.resident_id, r.first_name, r.middle_name, r.last_name, r.suffix, r.sex, r.birthdate, h.household_no,
                  lm.visit_date, lm.weight_kg, lm.height_cm, lm.muac_cm, lm.nutrition_status, lm.next_visit
           FROM residents r LEFT JOIN households h ON h.household_id = r.household_id " . latest_measure_join('lm') . "
           WHERE $w ORDER BY r.birthdate DESC", $params)->fetchAll();

$page_title = 'Child Health';
require __DIR__ . '/../../includes/header.php';
?>
<div class="card">
    <div class="card-header"><h3>Children 0–71 months (<?= count($rows) ?>)</h3></div>
    <form class="toolbar" method="get">
        <div class="grow"><label>Search</label><input type="search" name="q" value="<?= e($search) ?>" placeholder="Child's name"></div>
        <div><label>Show</label><select name="filter"><?= options(['due' => 'Check-up due / overdue / never weighed', 'concern' => 'With nutrition concern'], $filter, 'All children') ?></select></div>
        <button class="btn">Filter</button><a class="btn" href="children.php">Reset</a>
    </form>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Child</th><th>Age</th><th>Household</th><th>Last check-up</th><th class="num">Weight</th><th class="num">Height</th><th>Nutrition status</th><th>Next check-up</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $c): $late = $c['next_visit'] && $c['next_visit'] < today(); ?>
            <tr class="<?= $late ? 'row-danger' : '' ?>">
                <td><a href="child_view.php?id=<?= (int)$c['resident_id'] ?>"><strong><?= e(full_name($c)) ?></strong></a> <span class="small muted"><?= e($c['sex']) ?></span></td>
                <td class="nowrap"><?= e(age_label($c['birthdate'])) ?></td>
                <td><?= e($c['household_no'] ?? '—') ?></td>
                <td class="nowrap"><?= $c['visit_date'] ? fmt_date($c['visit_date']) : '<span class="muted">Never</span>' ?></td>
                <td class="num"><?= $c['weight_kg'] ? e($c['weight_kg']) . ' kg' : '—' ?></td>
                <td class="num"><?= $c['height_cm'] ? e($c['height_cm']) . ' cm' : '—' ?></td>
                <td><?= $c['nutrition_status'] ? badge($c['nutrition_status']) : '—' ?></td>
                <td class="nowrap"><?= fmt_date($c['next_visit']) ?> <?= $late ? badge('overdue') : '' ?></td>
                <td class="actions"><a class="btn btn-sm" href="child_view.php?id=<?= (int)$c['resident_id'] ?>">Open</a></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="9" class="empty">No children found.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
