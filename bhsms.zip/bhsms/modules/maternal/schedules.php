<?php
/*
 * Scheduled health visits (prenatal, postnatal, child check-ups, home visits, follow-ups).
 * Each visit is assigned to a BHW or nurse. Past visits still marked "scheduled" are shown as missed so the
 * health worker can do a home visit (interview answer: "we do home visits when patients don't follow their schedule").
 */
require __DIR__ . '/../../includes/init.php';
require_perm('maternal');

const VISIT_TYPES = ['Prenatal', 'Postnatal', 'Child Check-up', 'Home Visit', 'Follow-up'];

$errors = [];
$f = ['resident_id' => get('resident_id'), 'visit_type' => get('visit_type', 'Home Visit'), 'scheduled_date' => date('Y-m-d', strtotime('+1 day')),
      'assigned_to' => (string)(has_role('bhw', 'nurse') ? user_id() : ''), 'notes' => get('notes')];

if (is_post()) {
    require_perm('maternal', 'edit');
    $action = input('action');

    if ($action === 'add') {
        foreach (array_keys($f) as $k) { $f[$k] = input($k); }
        $res = q("SELECT first_name, last_name FROM residents WHERE resident_id = ? AND status = 'active'", [(int)$f['resident_id']])->fetch();
        if (!$res) $errors[] = 'Choose the resident.';
        if (!in_array($f['visit_type'], VISIT_TYPES, true)) $errors[] = 'Choose the visit type.';
        if (!valid_date($f['scheduled_date']) || $f['scheduled_date'] < today()) $errors[] = 'The schedule date must be today or later.';
        if ($f['assigned_to'] !== '' && !array_key_exists((int)$f['assigned_to'], staff_options())) $errors[] = 'Assign the visit to a BHW or nurse.';
        if (!$errors) {
            $sid = db_insert('health_visit_schedules', [
                'resident_id' => (int)$f['resident_id'], 'visit_type' => $f['visit_type'], 'scheduled_date' => $f['scheduled_date'],
                'assigned_to' => nullable($f['assigned_to']), 'status' => 'scheduled', 'notes' => nullable(mb_substr($f['notes'], 0, 255)),
            ]);
            log_activity('CREATE', 'health_visit_schedules', $sid, $f['visit_type'] . ' for ' . $res['first_name'] . ' ' . $res['last_name']);
            if ($f['assigned_to'] !== '' && (int)$f['assigned_to'] !== user_id()) {
                notify((int)$f['assigned_to'], 'Visit assigned to you', $f['visit_type'] . ' for ' . $res['first_name'] . ' ' . $res['last_name'] . ' on ' . fmt_date($f['scheduled_date']) . '.', 'modules/maternal/schedules.php?mine=1');
            }
            notify_resident((int)$f['resident_id'], 'Health visit scheduled', $f['visit_type'] . ' on ' . fmt_date($f['scheduled_date']) . '.');
            flash('success', $f['visit_type'] . ' scheduled for ' . fmt_date($f['scheduled_date']) . '.');
            redirect('modules/maternal/schedules.php');
        }
    }

    if (in_array($action, ['done', 'missed', 'cancelled'], true)) {
        $s = q("SELECT * FROM health_visit_schedules WHERE schedule_id = ? AND status = 'scheduled'", [(int)input('schedule_id')])->fetch();
        if ($s) {
            $note = input('remarks');
            $notes = trim(($s['notes'] ?? '') . ($note !== '' ? ' | ' . date('M j') . ': ' . $note : ''), ' |');
            q('UPDATE health_visit_schedules SET status = ?, notes = ? WHERE schedule_id = ?', [$action, nullable(mb_substr($notes, 0, 255)), $s['schedule_id']]);
            log_activity('UPDATE', 'health_visit_schedules', $s['schedule_id'], 'Marked ' . $s['visit_type'] . ' as ' . $action);
            flash('success', 'Visit marked as ' . $action . '.' . ($action === 'missed' ? ' Schedule a home visit below.' : ''));
            if ($action === 'missed') {
                redirect('modules/maternal/schedules.php?resident_id=' . $s['resident_id'] . '&visit_type=Home+Visit&notes=' . rawurlencode('Missed ' . $s['visit_type'] . ' on ' . fmt_date($s['scheduled_date'])) . '#add');
            }
        }
        redirect(back_url('modules/maternal/schedules.php'));
    }
}

// ----- List -----
$status = get('status', 'open');
$type = get('type');
$mine = get('mine') === '1';
$where = ['1=1'];
$params = [];
if ($status === 'open') {
    $where[] = "s.status = 'scheduled'";
} elseif ($status === 'missed') {
    $where[] = "(s.status = 'missed' OR (s.status = 'scheduled' AND s.scheduled_date < CURDATE()))";
} elseif (in_array($status, ['done', 'cancelled'], true)) {
    $where[] = 's.status = ?';
    $params[] = $status;
}
if (in_array($type, VISIT_TYPES, true)) { $where[] = 's.visit_type = ?'; $params[] = $type; }
if ($mine) { $where[] = 's.assigned_to = ?'; $params[] = user_id(); }
$w = implode(' AND ', $where);
$rows = q("SELECT s.*, r.first_name, r.middle_name, r.last_name, r.suffix, r.birthdate, r.contact_no, h.street_address, h.purok, u.full_name AS assignee
           FROM health_visit_schedules s JOIN residents r ON r.resident_id = s.resident_id
           LEFT JOIN households h ON h.household_id = r.household_id LEFT JOIN users u ON u.user_id = s.assigned_to
           WHERE $w ORDER BY s.scheduled_date, s.schedule_id LIMIT 300", $params)->fetchAll();
$overdue = (int)q("SELECT COUNT(*) FROM health_visit_schedules WHERE status = 'scheduled' AND scheduled_date < CURDATE()")->fetchColumn();
$todayCount = (int)q("SELECT COUNT(*) FROM health_visit_schedules WHERE status = 'scheduled' AND scheduled_date = CURDATE()")->fetchColumn();
$week = (int)q("SELECT COUNT(*) FROM health_visit_schedules WHERE status = 'scheduled' AND scheduled_date BETWEEN CURDATE() AND CURDATE() + INTERVAL 7 DAY")->fetchColumn();

$page_title = 'Scheduled Visits';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<div class="stats">
    <a class="stat <?= $overdue ? 'red' : '' ?>" href="?status=missed"><div class="label">Missed / not yet visited</div><div class="value"><?= $overdue ?></div></a>
    <div class="stat amber"><div class="label">Visits today</div><div class="value"><?= $todayCount ?></div></div>
    <div class="stat blue"><div class="label">Next 7 days</div><div class="value"><?= $week ?></div></div>
    <?php if (has_role('bhw', 'nurse')): ?><a class="stat purple" href="?mine=1"><div class="label">Assigned to me</div><div class="value"><?= (int)q("SELECT COUNT(*) FROM health_visit_schedules WHERE status = 'scheduled' AND assigned_to = ?", [user_id()])->fetchColumn() ?></div></a><?php endif; ?>
</div>

<div class="grid <?= can('maternal', 'edit') ? 'cols-3-1' : '' ?>">
    <div class="card">
        <div class="card-header"><h3>Visits</h3><button class="btn btn-sm" data-print>Print list</button></div>
        <form class="toolbar" method="get">
            <div><label>Status</label><select name="status"><?= options(['open' => 'Scheduled', 'missed' => 'Missed / overdue', 'done' => 'Done', 'cancelled' => 'Cancelled'], $status, 'All') ?></select></div>
            <div><label>Type</label><select name="type"><?= options(VISIT_TYPES, $type, 'All') ?></select></div>
            <label class="check"><input type="checkbox" name="mine" value="1" <?= $mine ? 'checked' : '' ?>> Assigned to me</label>
            <button class="btn">Filter</button><a class="btn" href="schedules.php">Reset</a>
        </form>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Date</th><th>Resident</th><th>Type</th><th>Address / contact</th><th>Assigned to</th><th>Notes</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $s): $late = $s['status'] === 'scheduled' && $s['scheduled_date'] < today(); ?>
                <tr class="<?= $late ? 'row-danger' : ($s['status'] !== 'scheduled' ? 'row-muted' : '') ?>">
                    <td class="nowrap"><?= fmt_date($s['scheduled_date']) ?></td>
                    <td><a href="<?= e(url('modules/residents/view.php?id=' . $s['resident_id'])) ?>"><?= e(full_name($s)) ?></a> <span class="small muted"><?= e(age_label($s['birthdate'])) ?></span></td>
                    <td><?= e($s['visit_type']) ?></td>
                    <td class="small"><?= e(trim(($s['street_address'] ?? '') . ', ' . ($s['purok'] ?? ''), ', ')) ?><div class="muted"><?= e($s['contact_no']) ?></div></td>
                    <td class="small"><?= e($s['assignee'] ?: 'Unassigned') ?></td>
                    <td class="small"><?= e($s['notes']) ?></td>
                    <td><?= $late ? badge('overdue') : badge($s['status']) ?></td>
                    <td class="actions">
                        <?php if ($s['status'] === 'scheduled' && can('maternal', 'edit')): ?>
                            <details class="pop">
                                <summary class="btn btn-sm">Update</summary>
                                <div class="pop-body">
                                    <form method="post">
                                        <?= csrf_field() ?><?= back_field() ?>
                                        <input type="hidden" name="schedule_id" value="<?= (int)$s['schedule_id'] ?>">
                                        <?= field('Remarks', 'remarks', '', 'text', 'maxlength="100" placeholder="e.g. Not at home, will return Friday"') ?>
                                        <div class="btn-group">
                                            <button class="btn btn-sm btn-success" name="action" value="done">Done</button>
                                            <button class="btn btn-sm btn-danger" name="action" value="missed">Missed</button>
                                            <button class="btn btn-sm" name="action" value="cancelled">Cancel visit</button>
                                        </div>
                                    </form>
                                </div>
                            </details>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$rows): ?><tr><td colspan="8" class="empty">No visits found.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>

    <?php if (can('maternal', 'edit')): ?>
    <form method="post" class="card" id="add">
        <h3>Schedule a visit</h3>
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="add">
        <div class="form-grid one">
            <div class="field required">
                <label for="f_resident_id">Resident</label>
                <select id="f_resident_id" name="resident_id" class="searchable" required data-placeholder="Type the resident's name"><?= options(resident_options(), $f['resident_id']) ?></select>
            </div>
            <?= select_field('Visit type', 'visit_type', VISIT_TYPES, $f['visit_type'], 'required', false) ?>
            <?= field('Date', 'scheduled_date', $f['scheduled_date'], 'date', 'required min="' . today() . '"') ?>
            <?= select_field('Assign to', 'assigned_to', staff_options(), $f['assigned_to'], '', '-- Unassigned --') ?>
            <?= field('Notes', 'notes', $f['notes'], 'text', 'maxlength="255"') ?>
        </div>
        <button class="btn btn-primary">Save schedule</button>
    </form>
    <?php endif; ?>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
