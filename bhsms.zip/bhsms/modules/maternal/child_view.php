<?php
/* One child's growth monitoring: check-up history and the form to record a check-up. */
require __DIR__ . '/../../includes/init.php';
require_perm('maternal');

$id = (int)get('id');
$c = q('SELECT r.*, h.household_no FROM residents r LEFT JOIN households h ON h.household_id = r.household_id WHERE r.resident_id = ?', [$id])->fetch();
if (!$c) {
    flash('danger', 'Child not found.');
    redirect('modules/maternal/children.php');
}
$ageMonths = age_months($c['birthdate']);

$errors = [];
$f = ['visit_date' => today(), 'weight_kg' => '', 'height_cm' => '', 'muac_cm' => '', 'nutrition_status' => '', 'milestones' => '', 'remarks' => '',
      'next_visit' => date('Y-m-d', strtotime($ageMonths < 12 ? '+1 month' : '+3 months'))];
if (is_post()) {
    require_perm('maternal', 'edit');
    foreach (array_keys($f) as $k) { $f[$k] = input($k); }
    if (!valid_date($f['visit_date']) || $f['visit_date'] > today() || $f['visit_date'] < $c['birthdate']) $errors[] = 'Enter a valid check-up date.';
    if ($f['weight_kg'] === '' || !is_numeric($f['weight_kg']) || $f['weight_kg'] < 0.5 || $f['weight_kg'] > 60) $errors[] = 'Weight must be between 0.5 and 60 kg.';
    if ($f['height_cm'] !== '' && (!is_numeric($f['height_cm']) || $f['height_cm'] < 30 || $f['height_cm'] > 150)) $errors[] = 'Height must be between 30 and 150 cm.';
    if ($f['muac_cm'] !== '' && (!is_numeric($f['muac_cm']) || $f['muac_cm'] < 5 || $f['muac_cm'] > 30)) $errors[] = 'MUAC must be between 5 and 30 cm.';
    if ($f['nutrition_status'] === '') {
        $f['nutrition_status'] = muac_assessment($f['muac_cm'], $ageMonths) ?? '';     // WHO MUAC cut-offs when no status chosen
    }
    if ($f['nutrition_status'] !== '' && !in_array($f['nutrition_status'], NUTRITION_STATUS, true)) $errors[] = 'Choose a valid nutrition status.';
    if ($f['next_visit'] !== '' && (!valid_date($f['next_visit']) || $f['next_visit'] <= $f['visit_date'])) $errors[] = 'The next check-up must be after the check-up date.';
    if (!$errors) {
        $rid = db_insert('child_monitoring', [
            'resident_id' => $id, 'visit_date' => $f['visit_date'], 'weight_kg' => $f['weight_kg'], 'height_cm' => nullable($f['height_cm']),
            'muac_cm' => nullable($f['muac_cm']), 'nutrition_status' => nullable($f['nutrition_status']), 'milestones' => nullable($f['milestones']),
            'remarks' => nullable($f['remarks']), 'next_visit' => nullable($f['next_visit']), 'recorded_by' => user_id(),
        ]);
        q("UPDATE health_visit_schedules SET status = 'done' WHERE resident_id = ? AND visit_type = 'Child Check-up' AND status = 'scheduled' AND scheduled_date <= ?", [$id, $f['visit_date']]);
        log_activity('CREATE', 'child_monitoring', $rid, 'Child check-up for ' . $c['first_name'] . ' ' . $c['last_name']);
        if (in_array($f['nutrition_status'], SEVERE_STATUS, true)) {
            notify_roles(['nao', 'nurse'], 'Severe malnutrition', $c['first_name'] . ' ' . $c['last_name'] . ' (' . age_label($c['birthdate']) . ') was assessed as ' . $f['nutrition_status'] . '.', 'modules/maternal/child_view.php?id=' . $id);
        }
        if ($f['next_visit'] !== '') {
            notify_resident($id, 'Next child check-up', $c['first_name'] . "'s next check-up is on " . fmt_date($f['next_visit']) . '.');
            // parents see their children's notifications through their own account
            $parent = q("SELECT u.user_id FROM users u JOIN residents p ON p.resident_id = u.resident_id
                         WHERE u.role = 'resident' AND u.status = 'active' AND p.household_id = ? AND p.resident_id <> ? LIMIT 1", [$c['household_id'] ?? 0, $id])->fetchColumn();
            if ($parent) {
                notify((int)$parent, 'Next child check-up', $c['first_name'] . "'s next check-up is on " . fmt_date($f['next_visit']) . '.', 'portal/index.php?member=' . $id);
            }
        }
        flash('success', 'Check-up saved' . ($f['nutrition_status'] ? ' — nutrition status: ' . $f['nutrition_status'] : '') . '.');
        redirect('modules/maternal/child_view.php?id=' . $id);
    }
}

$records = q('SELECT cm.*, u.full_name AS recorder FROM child_monitoring cm LEFT JOIN users u ON u.user_id = cm.recorded_by
              WHERE cm.resident_id = ? ORDER BY cm.visit_date DESC, cm.record_id DESC', [$id])->fetchAll();
$vacc = can('vaccinations') ? q('SELECT * FROM v_vaccination_status WHERE resident_id = ? ORDER BY vaccine_name', [$id])->fetchAll() : [];

$page_title = 'Child Health Record';
$nav_active = 'modules/maternal/children.php';
$page_kicker = 'Child Health';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<div class="page-head">
    <div>
        <h2><a href="<?= e(url('modules/residents/view.php?id=' . $id)) ?>"><?= e(full_name($c)) ?></a></h2>
        <div class="muted"><?= e($c['sex']) ?> &middot; <?= e(age_label($c['birthdate'])) ?> old (<?= $ageMonths ?> months) &middot; born <?= fmt_date($c['birthdate']) ?>
            <?= $c['household_no'] ? ' &middot; ' . e($c['household_no']) : '' ?></div>
    </div>
    <div class="btn-group no-print">
        <?php if (can('vaccinations', 'edit')): ?><a class="btn" href="<?= e(url('modules/vaccinations/form.php?resident_id=' . $id)) ?>">+ Vaccination</a><?php endif; ?>
        <button class="btn" data-print>Print</button>
    </div>
</div>

<div class="grid cols-2 mb">
    <?php if (can('maternal', 'edit')): ?>
    <form method="post" class="card">
        <h3>Record check-up / growth monitoring</h3>
        <?= csrf_field() ?>
        <div class="form-grid">
            <?= field('Check-up date', 'visit_date', $f['visit_date'], 'date', 'required max="' . today() . '"') ?>
            <?= field('Weight (kg)', 'weight_kg', $f['weight_kg'], 'number', 'required step="0.01" min="0.5" max="60"') ?>
            <?= field('Height / length (cm)', 'height_cm', $f['height_cm'], 'number', 'step="0.1" min="30" max="150"') ?>
            <?= field('MUAC (cm)', 'muac_cm', $f['muac_cm'], 'number', 'step="0.1" min="5" max="30"') ?>
            <?= select_field('Nutrition status', 'nutrition_status', NUTRITION_STATUS, $f['nutrition_status'], '', '-- From MUAC / not assessed --') ?>
            <?= field('Next check-up', 'next_visit', $f['next_visit'], 'date') ?>
            <?= field('Milestones', 'milestones', $f['milestones'], 'text', 'maxlength="255" placeholder="e.g. Walks alone, says few words"', 'span-2') ?>
            <?= field('Remarks', 'remarks', $f['remarks'], 'textarea', '', 'span-2') ?>
        </div>
        <p class="hint">For 6–59 months, leaving the status blank uses the WHO MUAC cut-offs (below 11.5 cm = severe, below 12.5 cm = moderate wasting).</p>
        <button class="btn btn-primary">Save check-up</button>
    </form>
    <?php endif; ?>
    <?php if (can('vaccinations')): ?>
    <div class="card">
        <h3>Vaccination card</h3>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Vaccine</th><th class="num">Doses</th><th>Next</th><th>Status</th></tr></thead>
            <tbody>
            <?php foreach ($vacc as $v): ?>
                <tr><td><?= e($v['vaccine_name']) ?></td><td class="num"><?= (int)$v['doses_received'] ?>/<?= (int)$v['doses_required'] ?></td>
                    <td><?= $v['completion_status'] === 'Complete' ? '—' : fmt_date($v['next_schedule']) ?></td><td><?= badge($v['completion_status']) ?></td></tr>
            <?php endforeach; ?>
            <?php if (!$vacc): ?><tr><td colspan="4" class="empty">No vaccinations recorded.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>
    <?php endif; ?>
</div>

<div class="card">
    <h3>Growth monitoring history (<?= count($records) ?>)</h3>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Date</th><th>Age then</th><th class="num">Weight (kg)</th><th class="num">Height (cm)</th><th class="num">MUAC (cm)</th><th>Status</th><th>Milestones / remarks</th><th>Next</th><th>By</th></tr></thead>
        <tbody>
        <?php foreach ($records as $r): $d = (new DateTime($c['birthdate']))->diff(new DateTime($r['visit_date'])); ?>
            <tr>
                <td class="nowrap"><?= fmt_date($r['visit_date']) ?></td>
                <td class="nowrap"><?= $d->y * 12 + $d->m ?> mos</td>
                <td class="num"><?= e($r['weight_kg'] ?? '—') ?></td>
                <td class="num"><?= e($r['height_cm'] ?? '—') ?></td>
                <td class="num"><?= e($r['muac_cm'] ?? '—') ?></td>
                <td><?= $r['nutrition_status'] ? badge($r['nutrition_status']) : '—' ?></td>
                <td class="small"><?= e(trim($r['milestones'] . ' ' . $r['remarks'])) ?></td>
                <td class="nowrap"><?= fmt_date($r['next_visit']) ?></td>
                <td class="small"><?= e($r['recorder']) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$records): ?><tr><td colspan="9" class="empty">No check-ups recorded yet.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
