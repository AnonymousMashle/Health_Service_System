<?php
/* Add or edit a medicine in the master list (the reorder level is the low-stock threshold). */
require __DIR__ . '/../../includes/init.php';
require_perm('inventory', 'edit');

$id = (int)get('id');
$m = ['generic_name' => '', 'brand_name' => '', 'dosage_form' => 'Tablet', 'strength' => '', 'unit' => 'pcs', 'reorder_level' => 50, 'is_active' => 1];
if ($id) {
    $row = q('SELECT * FROM medicines WHERE medicine_id = ?', [$id])->fetch();
    if (!$row) {
        flash('danger', 'Medicine not found.');
        redirect('modules/inventory/index.php');
    }
    $m = array_map(function ($x) { return $x ?? ''; }, $row);
}
$errors = [];
if (is_post()) {
    foreach (['generic_name', 'brand_name', 'dosage_form', 'strength', 'unit', 'reorder_level'] as $k) { $m[$k] = input($k); }
    $m['is_active'] = isset($_POST['is_active']) ? 1 : 0;
    if ($m['generic_name'] === '') $errors[] = 'Enter the generic name.';
    if (!in_array($m['dosage_form'], DOSAGE_FORMS, true)) $errors[] = 'Choose the dosage form.';
    if ($m['unit'] === '') $errors[] = 'Enter the unit (pcs, bottle, sachet...).';
    if (!ctype_digit((string)$m['reorder_level']) || (int)$m['reorder_level'] > 100000) $errors[] = 'Enter the reorder level (0 or more).';
    if (!$errors) {
        $data = ['generic_name' => $m['generic_name'], 'brand_name' => nullable($m['brand_name']), 'dosage_form' => $m['dosage_form'],
                 'strength' => nullable($m['strength']), 'unit' => $m['unit'], 'reorder_level' => (int)$m['reorder_level'], 'is_active' => $m['is_active']];
        try {
            if ($id) {
                db_update('medicines', $data, 'medicine_id', $id);
                log_activity('UPDATE', 'medicines', $id, 'Updated medicine ' . $m['generic_name']);
                check_stock_alert($id);      // a higher reorder level may make it "low stock" now
            } else {
                $id = db_insert('medicines', $data);
                log_activity('CREATE', 'medicines', $id, 'Added medicine ' . $m['generic_name'] . ' (record a stock-in next)');
            }
            flash('success', 'Medicine saved: ' . $m['generic_name'] . '.');
            redirect('modules/inventory/index.php');
        } catch (PDOException $e) {
            if (!is_duplicate_error($e)) throw $e;
            $errors[] = 'This medicine (same name, form and strength) already exists.';
        }
    }
}

$page_title = $id ? 'Edit Medicine' : 'New Medicine';
$nav_active = 'modules/inventory/index.php';
$page_kicker = 'Medicine Inventory';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<form method="post" class="card">
    <?= csrf_field() ?>
    <div class="form-grid">
        <?= field('Generic name', 'generic_name', $m['generic_name'], 'text', 'required maxlength="150"') ?>
        <?= field('Brand name', 'brand_name', $m['brand_name'], 'text', 'maxlength="150"') ?>
        <?= select_field('Dosage form', 'dosage_form', DOSAGE_FORMS, $m['dosage_form'], 'required', false) ?>
        <?= field('Strength', 'strength', $m['strength'], 'text', 'maxlength="50" placeholder="e.g. 500 mg"') ?>
        <?= field('Unit', 'unit', $m['unit'], 'text', 'required maxlength="20" placeholder="pcs, bottle, sachet"') ?>
        <?= field('Reorder level (low-stock alert at or below)', 'reorder_level', $m['reorder_level'], 'number', 'required min="0"') ?>
        <?= checkbox('Active', 'is_active', $m['is_active']) ?>
    </div>
    <div class="form-actions">
        <a class="btn" href="<?= e(url('modules/inventory/index.php')) ?>">Cancel</a>
        <button class="btn btn-primary">Save medicine</button>
    </div>
</form>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
