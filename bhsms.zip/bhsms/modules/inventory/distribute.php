<?php
/*
 * Give medicine to a resident (stock-out).
 * Stock is deducted automatically from the batch that expires first (FEFO); expired batches are never used.
 * If the medicine falls to its reorder level, the nurses and the admin get a low-stock / out-of-stock alert.
 */
require __DIR__ . '/../../includes/init.php';
require_perm('inventory', 'distribute');

$f = ['resident_id' => get('resident_id'), 'consultation_id' => get('consultation_id'), 'medicine_id' => get('medicine_id'),
      'quantity' => '', 'distribution_date' => today(), 'instructions' => ''];
$errors = [];

if (is_post()) {
    foreach (array_keys($f) as $k) { $f[$k] = input($k); }
    $res = q("SELECT resident_id, first_name, last_name FROM residents WHERE resident_id = ? AND status = 'active'", [(int)$f['resident_id']])->fetch();
    $med = q('SELECT * FROM medicines WHERE medicine_id = ? AND is_active = 1', [(int)$f['medicine_id']])->fetch();
    if (!$res) $errors[] = 'Choose the resident.';
    if (!$med) $errors[] = 'Choose the medicine.';
    if (!ctype_digit((string)$f['quantity']) || (int)$f['quantity'] < 1 || (int)$f['quantity'] > 10000) $errors[] = 'Enter the quantity (1 or more).';
    if (!valid_date($f['distribution_date']) || $f['distribution_date'] > today() || $f['distribution_date'] < date('Y-m-d', strtotime('-30 days'))) {
        $errors[] = 'The date must be within the last 30 days.';
    }
    if ($f['consultation_id'] !== '' && !q('SELECT 1 FROM consultations WHERE consultation_id = ? AND resident_id = ?', [(int)$f['consultation_id'], (int)$f['resident_id']])->fetchColumn()) {
        $f['consultation_id'] = '';    // the consultation belongs to someone else: do not link it
    }
    if (!$errors) {
        db()->beginTransaction();
        try {
            $given = dispense_medicine((int)$med['medicine_id'], (int)$res['resident_id'], (int)$f['quantity'], $f['distribution_date'],
                                       nullable(mb_substr($f['instructions'], 0, 255)), $f['consultation_id'] !== '' ? (int)$f['consultation_id'] : null);
            db()->commit();
        } catch (RuntimeException $ex) {
            db()->rollBack();
            $errors[] = $ex->getMessage();
        }
        if (!$errors) {
            $name = trim($med['generic_name'] . ' ' . $med['strength']);
            log_activity('DISPENSE', 'medicine_distribution', (int)$med['medicine_id'], "Gave $given {$med['unit']} of $name to {$res['first_name']} {$res['last_name']}");
            $left = (int)q('SELECT usable_stock FROM v_medicine_stock_levels WHERE medicine_id = ?', [$med['medicine_id']])->fetchColumn();
            flash('success', "Gave $given {$med['unit']} of $name to {$res['first_name']} {$res['last_name']}. Stock left: $left {$med['unit']}.");
            $alert = check_stock_alert((int)$med['medicine_id']);
            if ($alert) flash('warning', $alert . ' The nurses and the admin were notified.');
            redirect($f['consultation_id'] !== '' ? 'modules/consultations/view.php?id=' . (int)$f['consultation_id']
                                                  : 'modules/residents/view.php?id=' . (int)$res['resident_id'] . '#medicines');
        }
    }
}

$consults = $f['resident_id'] !== ''
    ? q("SELECT consultation_id, consultation_date, chief_complaint FROM consultations WHERE resident_id = ? ORDER BY consultation_date DESC LIMIT 10", [(int)$f['resident_id']])->fetchAll()
    : [];
$consultOptions = [];
foreach ($consults as $c) {
    $consultOptions[$c['consultation_id']] = fmt_date($c['consultation_date']) . ' — ' . $c['chief_complaint'];
}
$allergy = $f['resident_id'] !== '' ? q('SELECT allergies FROM health_profiles WHERE resident_id = ?', [(int)$f['resident_id']])->fetchColumn() : null;

$page_title = 'Give Medicine';
$nav_active = 'modules/inventory/index.php';
$page_kicker = 'Medicine Inventory';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<?php if ($allergy): ?><div class="alert alert-warning"><strong>Allergies:</strong> <?= e($allergy) ?></div><?php endif; ?>
<form method="post" class="card">
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="field required span-2">
            <label for="f_resident_id">Resident</label>
            <select id="f_resident_id" name="resident_id" class="searchable" required data-placeholder="Type the resident's name"><?= options(resident_options(), $f['resident_id']) ?></select>
        </div>
        <?= select_field('Medicine (only medicines with usable stock)', 'medicine_id', medicine_options(true), $f['medicine_id'], 'required class="searchable"', '-- Select --', 'span-2') ?>
        <?= field('Quantity', 'quantity', $f['quantity'], 'number', 'required min="1" max="10000"') ?>
        <?= field('Date given', 'distribution_date', $f['distribution_date'], 'date', 'required max="' . today() . '"') ?>
        <?php if ($consultOptions): ?>
            <?= select_field('For consultation', 'consultation_id', $consultOptions, $f['consultation_id'], '', '-- Not linked --', 'span-2') ?>
        <?php else: ?>
            <input type="hidden" name="consultation_id" value="<?= e($f['consultation_id']) ?>">
        <?php endif; ?>
        <?= field('Instructions', 'instructions', $f['instructions'], 'text', 'maxlength="255" placeholder="e.g. 1 tab every 6 hours for 3 days"', 'span-2') ?>
    </div>
    <p class="hint">Stock is taken from the batch that expires first. Expired batches are never given out.</p>
    <div class="form-actions">
        <a class="btn" href="<?= e(url('modules/inventory/index.php')) ?>">Cancel</a>
        <button class="btn btn-primary">Give medicine</button>
    </div>
</form>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
