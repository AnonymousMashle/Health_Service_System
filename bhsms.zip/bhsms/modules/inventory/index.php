<?php
/*
 * Medicine inventory: stock levels (low-stock / out-of-stock flags), batches with expiry tracking,
 * stock adjustments (expired, damaged, lost, returned, correction) and the distribution log.
 * Stock goes DOWN automatically when medicine is dispensed (distribute.php) and UP on stock-in (stock_in.php).
 */
require __DIR__ . '/../../includes/init.php';
require_perm('inventory');

if (is_post() && input('action') === 'adjust') {
    require_perm('inventory', 'edit');
    $sid = (int)input('stock_id');
    $type = input('adjustment_type');
    $qty = input('quantity');
    $reason = input('reason');
    db()->beginTransaction();
    $s = q('SELECT s.*, m.generic_name FROM medicine_stock s JOIN medicines m ON m.medicine_id = s.medicine_id WHERE s.stock_id = ? FOR UPDATE', [$sid])->fetch();
    $error = null;
    if (!$s) {
        $error = 'Batch not found.';
    } elseif (!in_array($type, ADJUSTMENT_TYPES, true)) {
        $error = 'Choose the adjustment type.';
    } elseif (!preg_match('/^-?\d+$/', (string)$qty) || (int)$qty === 0) {
        $error = 'Enter a quantity (whole number, not zero).';
    } elseif ($reason === '' && $type !== 'Expired') {
        $error = 'Give a reason for the adjustment.';
    }
    if (!$error) {
        // Expired / Damaged / Lost remove stock, Returned adds it back, Correction can go either way (negative = remove)
        $signed = in_array($type, ['Expired', 'Damaged', 'Lost'], true) ? -abs((int)$qty) : ($type === 'Returned' ? abs((int)$qty) : (int)$qty);
        $newQty = (int)$s['quantity_remaining'] + $signed;
        if ($newQty < 0) {
            $error = 'You can only remove up to ' . (int)$s['quantity_remaining'] . ' from this batch.';
        } elseif ($newQty > (int)$s['quantity_received']) {
            $error = 'The batch cannot hold more than the ' . (int)$s['quantity_received'] . ' received.';
        } else {
            q('UPDATE medicine_stock SET quantity_remaining = ? WHERE stock_id = ?', [$newQty, $sid]);
            $aid = db_insert('stock_adjustments', ['stock_id' => $sid, 'adjustment_type' => $type, 'quantity' => $signed,
                                                   'reason' => nullable(mb_substr($reason, 0, 255)), 'adjusted_by' => user_id()]);
            db()->commit();
            log_activity('ADJUST', 'stock_adjustments', $aid, $type . ' ' . $signed . ' of ' . $s['generic_name'] . ' batch ' . $s['batch_no']);
            $alert = check_stock_alert((int)$s['medicine_id']);
            flash('success', 'Stock adjusted: ' . ($signed > 0 ? '+' : '') . $signed . '. Batch ' . $s['batch_no'] . ' now has ' . $newQty . ' left.');
            if ($alert) flash('warning', $alert);
            redirect(back_url('modules/inventory/index.php?tab=batches'));
        }
    }
    db()->rollBack();
    flash('danger', $error);
    redirect(back_url('modules/inventory/index.php?tab=batches'));
}

$tab = in_array(get('tab'), ['stock', 'batches', 'log', 'adjustments'], true) ? get('tab') : 'stock';
$levels = q("SELECT * FROM v_medicine_stock_levels ORDER BY FIELD(stock_status, 'Out of Stock', 'Low Stock', 'In Stock'), generic_name")->fetchAll();
$counts = ['low' => 0, 'out' => 0];
foreach ($levels as $l) {
    if ($l['stock_status'] === 'Low Stock') $counts['low']++;
    if ($l['stock_status'] === 'Out of Stock') $counts['out']++;
}
$expiring = (int)q('SELECT COUNT(*) FROM medicine_stock WHERE quantity_remaining > 0 AND expiry_date BETWEEN CURDATE() AND CURDATE() + INTERVAL 90 DAY')->fetchColumn();
$expired = (int)q('SELECT COUNT(*) FROM medicine_stock WHERE quantity_remaining > 0 AND expiry_date < CURDATE()')->fetchColumn();
$monthOut = (int)q("SELECT COALESCE(SUM(quantity), 0) FROM medicine_distribution WHERE DATE_FORMAT(distribution_date, '%Y-%m') = DATE_FORMAT(CURDATE(), '%Y-%m')")->fetchColumn();

$filter = get('status');
if ($tab === 'stock' && $filter !== '') {
    $levels = array_values(array_filter($levels, function ($l) use ($filter) { return $l['stock_status'] === $filter; }));
}

$batches = $log = $adjustments = [];
if ($tab === 'batches') {
    $show = get('show', 'available');
    $cond = ['available' => 's.quantity_remaining > 0', 'expiring' => 's.quantity_remaining > 0 AND s.expiry_date BETWEEN CURDATE() AND CURDATE() + INTERVAL 90 DAY',
             'expired' => 's.quantity_remaining > 0 AND s.expiry_date < CURDATE()', 'all' => '1=1'][$show] ?? 's.quantity_remaining > 0';
    $batches = q("SELECT s.*, m.generic_name, m.strength, m.dosage_form, m.unit, u.full_name AS receiver
                  FROM medicine_stock s JOIN medicines m ON m.medicine_id = s.medicine_id LEFT JOIN users u ON u.user_id = s.received_by
                  WHERE $cond ORDER BY s.expiry_date, m.generic_name LIMIT 300")->fetchAll();
}
if ($tab === 'log') {
    [$from, $to] = date_range('from', 'to', date('Y-m-01', strtotime('-2 months')));
    $medId = get('medicine_id');
    $params = [$from, $to];
    $extra = '';
    if ($medId !== '') { $extra = ' AND d.medicine_id = ?'; $params[] = (int)$medId; }
    $log = q("SELECT d.*, m.generic_name, m.strength, m.dosage_form, m.unit, s.batch_no, r.first_name, r.middle_name, r.last_name, r.suffix, u.full_name AS giver
              FROM medicine_distribution d JOIN medicines m ON m.medicine_id = d.medicine_id JOIN medicine_stock s ON s.stock_id = d.stock_id
              JOIN residents r ON r.resident_id = d.resident_id LEFT JOIN users u ON u.user_id = d.given_by
              WHERE d.distribution_date BETWEEN ? AND ? $extra ORDER BY d.distribution_date DESC, d.distribution_id DESC", $params)->fetchAll();
    if (get('export') === 'csv') {
        log_activity('EXPORT', 'medicine_distribution', null, "Distribution log $from to $to");
        send_csv("medicine_distribution_{$from}_{$to}.csv", ['Date', 'Resident', 'Medicine', 'Batch', 'Quantity', 'Unit', 'Instructions', 'Given by'],
            array_map(function ($d) { return [$d['distribution_date'], full_name($d), trim($d['generic_name'] . ' ' . $d['strength'] . ' ' . $d['dosage_form']),
                                               $d['batch_no'], $d['quantity'], $d['unit'], $d['instructions'], $d['giver']]; }, $log));
    }
}
if ($tab === 'adjustments') {
    $adjustments = q('SELECT a.*, s.batch_no, m.generic_name, m.strength, m.unit, u.full_name AS adjuster
                      FROM stock_adjustments a JOIN medicine_stock s ON s.stock_id = a.stock_id JOIN medicines m ON m.medicine_id = s.medicine_id
                      LEFT JOIN users u ON u.user_id = a.adjusted_by ORDER BY a.adjusted_at DESC LIMIT 200')->fetchAll();
}

$page_title = 'Medicine Inventory';
require __DIR__ . '/../../includes/header.php';
?>
<div class="stats">
    <a class="stat <?= $counts['out'] ? 'red' : '' ?>" href="?tab=stock&amp;status=Out+of+Stock"><div class="label">Out of stock</div><div class="value"><?= $counts['out'] ?></div></a>
    <a class="stat amber" href="?tab=stock&amp;status=Low+Stock"><div class="label">Low stock (at/below reorder level)</div><div class="value"><?= $counts['low'] ?></div></a>
    <a class="stat <?= $expiring ? 'amber' : '' ?>" href="?tab=batches&amp;show=expiring"><div class="label">Batches expiring in 90 days</div><div class="value"><?= $expiring ?></div></a>
    <a class="stat <?= $expired ? 'red' : '' ?>" href="?tab=batches&amp;show=expired"><div class="label">Expired batches to dispose</div><div class="value"><?= $expired ?></div></a>
    <a class="stat blue" href="?tab=log"><div class="label">Units given this month</div><div class="value"><?= $monthOut ?></div></a>
</div>

<div class="page-head no-print">
    <div class="tabs">
        <a class="<?= $tab === 'stock' ? 'active' : '' ?>" href="?tab=stock">Stock levels</a>
        <a class="<?= $tab === 'batches' ? 'active' : '' ?>" href="?tab=batches">Batches &amp; expiry</a>
        <a class="<?= $tab === 'log' ? 'active' : '' ?>" href="?tab=log">Distribution log</a>
        <a class="<?= $tab === 'adjustments' ? 'active' : '' ?>" href="?tab=adjustments">Adjustments</a>
    </div>
    <div class="btn-group">
        <?php if (can('inventory', 'distribute')): ?><a class="btn btn-primary" href="distribute.php">Give medicine</a><?php endif; ?>
        <?php if (can('inventory', 'edit')): ?><a class="btn" href="stock_in.php">+ Stock-in</a><a class="btn" href="medicine_form.php">+ New medicine</a><?php endif; ?>
    </div>
</div>

<?php if ($tab === 'stock'): ?>
<div class="card">
    <div class="card-header"><h3>Current stock (usable = not expired)</h3>
        <form method="get" class="inline-form"><input type="hidden" name="tab" value="stock">
            <select name="status" onchange="this.form.submit()"><?= options(['Out of Stock', 'Low Stock', 'In Stock'], $filter, 'All statuses') ?></select></form></div>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Medicine</th><th>Form</th><th class="num">Usable stock</th><th class="num">Reorder level</th><th class="num">Expired (to dispose)</th><th>Nearest expiry</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($levels as $m): ?>
            <tr class="<?= $m['stock_status'] === 'Out of Stock' ? 'row-danger' : ($m['stock_status'] === 'Low Stock' ? 'row-warning' : '') ?>">
                <td><strong><?= e($m['generic_name']) ?></strong> <?= e($m['strength']) ?><?= $m['brand_name'] ? '<div class="small muted">' . e($m['brand_name']) . '</div>' : '' ?></td>
                <td><?= e($m['dosage_form']) ?></td>
                <td class="num"><strong><?= (int)$m['usable_stock'] ?></strong> <?= e($m['unit']) ?></td>
                <td class="num"><?= (int)$m['reorder_level'] ?></td>
                <td class="num"><?= (int)$m['expired_stock'] ? '<span class="text-danger">' . (int)$m['expired_stock'] . '</span>' : '0' ?></td>
                <td class="nowrap"><?= fmt_date($m['nearest_expiry']) ?><?= $m['nearest_expiry'] && $m['nearest_expiry'] <= date('Y-m-d', strtotime('+90 days')) ? ' ' . badge('expiring') : '' ?></td>
                <td><?= badge($m['stock_status']) ?></td>
                <td class="actions">
                    <?php if (can('inventory', 'distribute') && (int)$m['usable_stock'] > 0): ?><a class="btn btn-sm" href="distribute.php?medicine_id=<?= (int)$m['medicine_id'] ?>">Give</a><?php endif; ?>
                    <?php if (can('inventory', 'edit')): ?><a class="btn btn-sm" href="stock_in.php?medicine_id=<?= (int)$m['medicine_id'] ?>">Stock-in</a>
                        <a class="btn btn-sm" href="medicine_form.php?id=<?= (int)$m['medicine_id'] ?>">Edit</a><?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$levels): ?><tr><td colspan="8" class="empty">No medicines found.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div>

<?php elseif ($tab === 'batches'): ?>
<div class="card">
    <div class="card-header"><h3>Batches</h3>
        <div class="btn-group">
            <?php foreach (['available' => 'With stock', 'expiring' => 'Expiring ≤ 90 days', 'expired' => 'Expired', 'all' => 'All'] as $k => $label): ?>
                <a class="btn btn-sm <?= $show === $k ? 'btn-primary' : '' ?>" href="?tab=batches&amp;show=<?= $k ?>"><?= e($label) ?></a>
            <?php endforeach; ?>
        </div></div>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Medicine</th><th>Batch no.</th><th class="num">Received</th><th class="num">Remaining</th><th>Expiry</th><th>Received on</th><th>Source</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($batches as $b):
            $isExpired = $b['expiry_date'] < today();
            $soon = !$isExpired && $b['expiry_date'] <= date('Y-m-d', strtotime('+90 days')); ?>
            <tr class="<?= $isExpired && $b['quantity_remaining'] > 0 ? 'row-danger' : ($soon ? 'row-warning' : '') ?>">
                <td><?= e($b['generic_name']) ?> <span class="small muted"><?= e($b['strength']) ?> <?= e($b['dosage_form']) ?></span></td>
                <td><?= e($b['batch_no']) ?></td>
                <td class="num"><?= (int)$b['quantity_received'] ?></td>
                <td class="num"><strong><?= (int)$b['quantity_remaining'] ?></strong> <?= e($b['unit']) ?></td>
                <td class="nowrap"><?= fmt_date($b['expiry_date']) ?> <?= $isExpired ? badge('expired') : ($soon ? badge('expiring') : '') ?></td>
                <td class="nowrap"><?= fmt_date($b['date_received']) ?></td>
                <td class="small"><?= e($b['source']) ?><div class="muted"><?= e($b['receiver']) ?></div></td>
                <td class="actions">
                    <?php if (can('inventory', 'edit')): ?>
                        <?php if ($isExpired && $b['quantity_remaining'] > 0): ?>
                            <?= post_button('index.php', 'Dispose expired', ['action' => 'adjust', 'stock_id' => $b['stock_id'], 'adjustment_type' => 'Expired',
                                'quantity' => $b['quantity_remaining'], 'reason' => 'Batch expired ' . $b['expiry_date'] . ', for disposal'], 'btn btn-sm btn-danger',
                                'Remove all ' . $b['quantity_remaining'] . ' expired units of batch ' . $b['batch_no'] . '?') ?>
                        <?php endif; ?>
                        <details class="pop">
                            <summary class="btn btn-sm">Adjust</summary>
                            <div class="pop-body">
                                <form method="post" action="index.php">
                                    <?= csrf_field() ?><?= back_field() ?>
                                    <input type="hidden" name="action" value="adjust">
                                    <input type="hidden" name="stock_id" value="<?= (int)$b['stock_id'] ?>">
                                    <?= select_field('Type', 'adjustment_type', ADJUSTMENT_TYPES, 'Damaged', 'required', false) ?>
                                    <?= field('Quantity', 'quantity', '', 'number', 'required placeholder="Correction: negative to remove"') ?>
                                    <?= field('Reason', 'reason', '', 'text', 'maxlength="255"') ?>
                                    <button class="btn btn-sm btn-primary">Save adjustment</button>
                                </form>
                            </div>
                        </details>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$batches): ?><tr><td colspan="8" class="empty">No batches found.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div>

<?php elseif ($tab === 'log'): ?>
<div class="card">
    <div class="card-header"><h3>Medicines given (stock-out)</h3></div>
    <form class="toolbar" method="get" action="index.php#export">
        <input type="hidden" name="tab" value="log">
        <div><label>From</label><input type="date" name="from" value="<?= e($from) ?>"></div>
        <div><label>To</label><input type="date" name="to" value="<?= e($to) ?>"></div>
        <div class="grow"><label>Medicine</label><select name="medicine_id"><?= options(medicine_options(), $medId, 'All') ?></select></div>
        <button class="btn">Filter</button>
        <button class="btn" name="export" value="csv">Export CSV</button>
    </form>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Date</th><th>Resident</th><th>Medicine</th><th>Batch</th><th class="num">Qty</th><th>Instructions</th><th>Given by</th></tr></thead>
        <tbody>
        <?php foreach ($log as $d): ?>
            <tr>
                <td class="nowrap"><?= fmt_date($d['distribution_date']) ?></td>
                <td><a href="<?= e(url('modules/residents/view.php?id=' . $d['resident_id'])) ?>"><?= e(full_name($d)) ?></a></td>
                <td><?= e($d['generic_name']) ?> <span class="small muted"><?= e($d['strength']) ?></span></td>
                <td class="small"><?= e($d['batch_no']) ?></td>
                <td class="num"><?= (int)$d['quantity'] ?> <?= e($d['unit']) ?></td>
                <td class="small"><?= e($d['instructions']) ?></td>
                <td class="small"><?= e($d['giver']) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$log): ?><tr><td colspan="7" class="empty">No medicines given in this period.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
    <p class="hint"><?= count($log) ?> record(s), <?= array_sum(array_column($log, 'quantity')) ?> unit(s) total, <?= fmt_date($from) ?> to <?= fmt_date($to) ?>.</p>
</div>

<?php else: ?>
<div class="card">
    <h3>Stock adjustments</h3>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Date</th><th>Medicine</th><th>Batch</th><th>Type</th><th class="num">Quantity</th><th>Reason</th><th>By</th></tr></thead>
        <tbody>
        <?php foreach ($adjustments as $a): ?>
            <tr>
                <td class="nowrap"><?= fmt_datetime($a['adjusted_at']) ?></td>
                <td><?= e($a['generic_name']) ?> <span class="small muted"><?= e($a['strength']) ?></span></td>
                <td class="small"><?= e($a['batch_no']) ?></td>
                <td><?= e($a['adjustment_type']) ?></td>
                <td class="num <?= $a['quantity'] < 0 ? 'text-danger' : 'text-success' ?>"><?= $a['quantity'] > 0 ? '+' : '' ?><?= (int)$a['quantity'] ?></td>
                <td class="small"><?= e($a['reason']) ?></td>
                <td class="small"><?= e($a['adjuster']) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$adjustments): ?><tr><td colspan="7" class="empty">No adjustments yet.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
