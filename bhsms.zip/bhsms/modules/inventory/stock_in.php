<?php
/* Stock-in: record a delivery / batch of medicine. Stock goes UP immediately. */
require __DIR__ . '/../../includes/init.php';
require_perm('inventory', 'edit');

$f = ['medicine_id' => get('medicine_id'), 'batch_no' => '', 'quantity_received' => '', 'expiry_date' => '', 'date_received' => today(), 'source' => ''];
$errors = [];
if (is_post()) {
    foreach (array_keys($f) as $k) { $f[$k] = input($k); }
    $med = q('SELECT * FROM medicines WHERE medicine_id = ?', [(int)$f['medicine_id']])->fetch();
    if (!$med) $errors[] = 'Choose the medicine.';
    if ($f['batch_no'] === '') $errors[] = 'Enter the batch / lot number.';
    if (!ctype_digit((string)$f['quantity_received']) || (int)$f['quantity_received'] < 1 || (int)$f['quantity_received'] > 1000000) $errors[] = 'Enter the quantity received.';
    if (!valid_date($f['date_received']) || $f['date_received'] > today()) $errors[] = 'Enter a valid date received (not in the future).';
    if (!valid_date($f['expiry_date'])) {
        $errors[] = 'Enter the expiry date.';
    } elseif ($f['expiry_date'] <= today()) {
        $errors[] = 'This batch is already expired. Do not add it to the stock.';
    }
    if ($med && $f['batch_no'] !== '' && q('SELECT 1 FROM medicine_stock WHERE medicine_id = ? AND batch_no = ?', [$med['medicine_id'], $f['batch_no']])->fetchColumn()) {
        $errors[] = 'This batch number is already recorded for this medicine.';
    }
    if (!$errors) {
        $sid = db_insert('medicine_stock', [
            'medicine_id' => (int)$med['medicine_id'], 'batch_no' => mb_substr($f['batch_no'], 0, 50), 'quantity_received' => (int)$f['quantity_received'],
            'quantity_remaining' => (int)$f['quantity_received'], 'expiry_date' => $f['expiry_date'], 'date_received' => $f['date_received'],
            'source' => nullable(mb_substr($f['source'], 0, 150)), 'received_by' => user_id(),
        ]);
        log_activity('STOCK-IN', 'medicine_stock', $sid, 'Received ' . (int)$f['quantity_received'] . ' ' . $med['unit'] . ' of ' . $med['generic_name'] . ' (batch ' . $f['batch_no'] . ')');
        $left = (int)q('SELECT usable_stock FROM v_medicine_stock_levels WHERE medicine_id = ?', [$med['medicine_id']])->fetchColumn();
        flash('success', 'Stock-in saved. ' . $med['generic_name'] . ' now has ' . $left . ' ' . $med['unit'] . ' usable.');
        redirect('modules/inventory/index.php');
    }
}

$page_title = 'Stock-in';
$nav_active = 'modules/inventory/index.php';
$page_kicker = 'Medicine Inventory';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<form method="post" class="card">
    <?= csrf_field() ?>
    <div class="form-grid">
        <?= select_field('Medicine', 'medicine_id', medicine_options(), $f['medicine_id'], 'required class="searchable"', '-- Select --', 'span-2') ?>
        <?= field('Batch / lot no.', 'batch_no', $f['batch_no'], 'text', 'required maxlength="50"') ?>
        <?= field('Quantity received', 'quantity_received', $f['quantity_received'], 'number', 'required min="1"') ?>
        <?= field('Expiry date', 'expiry_date', $f['expiry_date'], 'date', 'required min="' . date('Y-m-d', strtotime('+1 day')) . '"') ?>
        <?= field('Date received', 'date_received', $f['date_received'], 'date', 'required max="' . today() . '"') ?>
        <?= field('Source', 'source', $f['source'], 'text', 'maxlength="150" placeholder="e.g. DOH-CAR, City Health Office, Donation"', 'span-2') ?>
    </div>
    <p class="hint">Not in the list? <a href="medicine_form.php">Add the medicine first</a>.</p>
    <div class="form-actions">
        <a class="btn" href="<?= e(url('modules/inventory/index.php')) ?>">Cancel</a>
        <button class="btn btn-primary">Save stock-in</button>
    </div>
</form>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
