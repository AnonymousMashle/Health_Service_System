<?php
/* Appointment requests: Pending -> Under review (assigned) -> Approved / Rejected -> Completed (or No-show / Cancelled). */
require __DIR__ . '/../../includes/init.php';
require_perm('appointments');

$status = get('status', 'open');
$search = get('q');
$service = get('service');
$from = get('from');
$to = get('to');
$mine = get('mine') === '1';

$where = ['1=1'];
$params = [];
if ($status === 'open') {
    $where[] = "a.status IN ('pending', 'under review')";
} elseif ($status === 'today') {
    $where[] = "a.status = 'approved' AND a.scheduled_date = CURDATE()";
} elseif (in_array($status, APPOINTMENT_STATUS, true)) {
    $where[] = 'a.status = ?';
    $params[] = $status;
}
if ($search !== '') {
    $where[] = "(a.reference_no LIKE ? OR CONCAT(r.first_name, ' ', r.last_name) LIKE ?)";
    array_push($params, '%' . $search . '%', '%' . $search . '%');
}
if (in_array($service, SERVICE_TYPES, true)) { $where[] = 'a.service_type = ?'; $params[] = $service; }
if (valid_date($from)) { $where[] = 'COALESCE(a.scheduled_date, a.preferred_date) >= ?'; $params[] = $from; }
if (valid_date($to)) { $where[] = 'COALESCE(a.scheduled_date, a.preferred_date) <= ?'; $params[] = $to; }
if ($mine) { $where[] = 'a.assigned_to = ?'; $params[] = user_id(); }
$w = implode(' AND ', $where);

$base = 'FROM appointments a JOIN residents r ON r.resident_id = a.resident_id LEFT JOIN users s ON s.user_id = a.assigned_to';
$pg = paginate((int)q("SELECT COUNT(*) $base WHERE $w", $params)->fetchColumn());
$rows = q("SELECT a.*, r.first_name, r.middle_name, r.last_name, r.suffix, r.contact_no, s.full_name AS assignee
           $base WHERE $w ORDER BY FIELD(a.status, 'pending', 'under review', 'approved') = 0, COALESCE(a.scheduled_date, a.preferred_date), a.appointment_id
           LIMIT {$pg['per']} OFFSET {$pg['offset']}", $params)->fetchAll();

$counts = array_fill_keys(APPOINTMENT_STATUS, 0);
foreach (q('SELECT status, COUNT(*) AS n FROM appointments GROUP BY status')->fetchAll() as $c) {
    $counts[$c['status']] = (int)$c['n'];
}
$todayCount = (int)q("SELECT COUNT(*) FROM appointments WHERE status = 'approved' AND scheduled_date = CURDATE()")->fetchColumn();

$page_title = 'Appointments';
require __DIR__ . '/../../includes/header.php';
?>
<div class="stats">
    <a class="stat amber" href="?status=pending"><div class="label">Pending (new requests)</div><div class="value"><?= $counts['pending'] ?></div></a>
    <a class="stat purple" href="?status=under+review"><div class="label">Under review</div><div class="value"><?= $counts['under review'] ?></div></a>
    <a class="stat blue" href="?status=today"><div class="label">Approved for today</div><div class="value"><?= $todayCount ?></div></a>
    <a class="stat" href="?status=completed"><div class="label">Completed</div><div class="value"><?= $counts['completed'] ?></div></a>
</div>

<div class="card">
    <div class="card-header"><h3>Appointment requests</h3>
        <?php if (can('appointments', 'edit')): ?><a class="btn btn-primary" href="form.php">+ Book for a resident</a><?php endif; ?></div>
    <div class="tabs">
        <?php foreach (['open' => 'Needs action', 'today' => 'Today', 'pending' => 'Pending', 'under review' => 'Under review', 'approved' => 'Approved',
                        'completed' => 'Completed', 'rejected' => 'Rejected', 'no-show' => 'No-show', 'cancelled' => 'Cancelled', '' => 'All'] as $k => $label): ?>
            <a class="<?= $status === $k ? 'active' : '' ?>" href="?status=<?= urlencode($k) ?>"><?= e($label) ?><?= isset($counts[$k]) && $counts[$k] ? ' (' . $counts[$k] . ')' : '' ?></a>
        <?php endforeach; ?>
    </div>
    <form class="toolbar" method="get">
        <input type="hidden" name="status" value="<?= e($status) ?>">
        <div class="grow"><label>Search</label><input type="search" name="q" value="<?= e($search) ?>" placeholder="Reference no. (APT-2026-0001) or resident name"></div>
        <div><label>Service</label><select name="service"><?= options(SERVICE_TYPES, $service, 'All') ?></select></div>
        <div><label>From</label><input type="date" name="from" value="<?= e($from) ?>"></div>
        <div><label>To</label><input type="date" name="to" value="<?= e($to) ?>"></div>
        <label class="check"><input type="checkbox" name="mine" value="1" <?= $mine ? 'checked' : '' ?>> Assigned to me</label>
        <button class="btn">Filter</button><a class="btn" href="index.php">Reset</a>
    </form>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Reference no.</th><th>Resident</th><th>Service</th><th>Requested</th><th>Schedule</th><th>Assigned to</th><th>Status</th><th>Submitted</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $a): ?>
            <tr>
                <td><a class="ref-no" href="view.php?id=<?= (int)$a['appointment_id'] ?>"><?= e($a['reference_no']) ?></a></td>
                <td><a href="<?= e(url('modules/residents/view.php?id=' . $a['resident_id'])) ?>"><?= e(full_name($a)) ?></a><div class="small muted"><?= e($a['contact_no']) ?></div></td>
                <td><?= e($a['service_type']) ?><div class="small muted"><?= e($a['reason']) ?></div></td>
                <td class="nowrap"><?= fmt_date($a['preferred_date']) ?> <span class="small muted"><?= fmt_time($a['preferred_time']) ?></span></td>
                <td class="nowrap"><?= $a['scheduled_date'] ? fmt_date($a['scheduled_date']) . ' <span class="small muted">' . fmt_time($a['scheduled_time']) . '</span>' : '—' ?></td>
                <td class="small"><?= e($a['assignee'] ?: '—') ?></td>
                <td><?= badge($a['status']) ?></td>
                <td class="small nowrap"><?= fmt_datetime($a['created_at']) ?></td>
                <td class="actions"><a class="btn btn-sm <?= in_array($a['status'], ['pending', 'under review'], true) ? 'btn-primary' : '' ?>" href="view.php?id=<?= (int)$a['appointment_id'] ?>">Open</a></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="9" class="empty">No appointments found.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
    <?= pagination_links($pg) ?>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
