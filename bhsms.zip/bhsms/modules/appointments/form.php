<?php
/* Staff books an appointment for a resident (walk-in or phone request). It gets a reference number and starts as Pending. */
require __DIR__ . '/../../includes/init.php';
require_perm('appointments', 'edit');

$f = ['resident_id' => get('resident_id'), 'service_type' => 'General Consultation', 'preferred_date' => today(), 'preferred_time' => '', 'reason' => ''];
$errors = [];
if (is_post()) {
    foreach (array_keys($f) as $k) { $f[$k] = input($k); }
    $res = q("SELECT resident_id, first_name, last_name FROM residents WHERE resident_id = ? AND status = 'active'", [(int)$f['resident_id']])->fetch();
    if (!$res) $errors[] = 'Choose the resident.';
    if (!in_array($f['service_type'], SERVICE_TYPES, true)) $errors[] = 'Choose the service.';
    if ($err = appointment_date_error($f['preferred_date'])) $errors[] = $err;
    if ($f['preferred_time'] !== '' && !preg_match('/^(0[7-9]|1[0-6]):[0-5]\d$/', $f['preferred_time'])) $errors[] = 'Choose a time between 7:00 AM and 4:59 PM.';
    if (!$errors) {
        [$aid, $ref] = create_appointment([
            'resident_id' => (int)$res['resident_id'], 'service_type' => $f['service_type'], 'preferred_date' => $f['preferred_date'],
            'preferred_time' => nullable($f['preferred_time']), 'reason' => nullable(mb_substr($f['reason'], 0, 255)),
        ]);
        log_activity('CREATE', 'appointments', $aid, "Booked $ref for {$res['first_name']} {$res['last_name']}");
        flash('success', "Appointment $ref created. Review and approve it below.");
        redirect('modules/appointments/view.php?id=' . $aid);
    }
}
$times = [];
for ($t = strtotime('08:00'); $t <= strtotime('16:30'); $t += 1800) {
    $times[date('H:i', $t)] = date('g:i A', $t);
}

$page_title = 'Book Appointment';
$nav_active = 'modules/appointments/index.php';
$page_kicker = 'Appointments';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<form method="post" class="card">
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="field required span-2">
            <label for="f_resident_id">Resident</label>
            <select id="f_resident_id" name="resident_id" class="searchable" required data-placeholder="Type the resident's name"><?= options(resident_options(), $f['resident_id']) ?></select>
        </div>
        <?= select_field('Service', 'service_type', SERVICE_TYPES, $f['service_type'], 'required', false) ?>
        <?= field('Preferred date', 'preferred_date', $f['preferred_date'], 'date', 'required min="' . today() . '"') ?>
        <?= select_field('Preferred time', 'preferred_time', $times, $f['preferred_time'], '', '-- Any time --') ?>
        <?= field('Reason', 'reason', $f['reason'], 'text', 'maxlength="255"', 'span-2') ?>
    </div>
    <div class="form-actions">
        <a class="btn" href="<?= e(url('modules/appointments/index.php')) ?>">Cancel</a>
        <button class="btn btn-primary">Create appointment</button>
    </div>
</form>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
