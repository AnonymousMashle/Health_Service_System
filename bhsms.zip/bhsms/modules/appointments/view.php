<?php
/*
 * One appointment and its whole lifecycle:
 *   Pending --(review & assign)--> Under review --(approve with schedule | reject with reason)--> Approved / Rejected
 *   Approved --(consultation recorded / mark completed)--> Completed      Approved --(did not come)--> No-show
 * Every step is written to appointment_logs (timestamp, staff, remarks) and the resident is notified.
 */
require __DIR__ . '/../../includes/init.php';
require_perm('appointments');

$id = (int)get('id');
function load_appointment(int $id)
{
    return q('SELECT a.*, r.first_name, r.middle_name, r.last_name, r.suffix, r.birthdate, r.sex, r.contact_no,
                     s.full_name AS assignee, ap.full_name AS approver, rq.full_name AS requester, rq.role AS requester_role
              FROM appointments a JOIN residents r ON r.resident_id = a.resident_id
              LEFT JOIN users s ON s.user_id = a.assigned_to LEFT JOIN users ap ON ap.user_id = a.approved_by
              LEFT JOIN users rq ON rq.user_id = a.requested_by
              WHERE a.appointment_id = ?', [$id])->fetch();
}
$a = load_appointment($id);
if (!$a) {
    flash('danger', 'Appointment not found.');
    redirect('modules/appointments/index.php');
}

if (is_post()) {
    require_perm('appointments', 'edit');
    $action = input('action');
    $remarks = input('remarks');
    $ref = $a['reference_no'];
    $name = $a['first_name'] . ' ' . $a['last_name'];
    $error = null;
    $allowed = [
        'review' => ['pending'], 'approve' => ['pending', 'under review'], 'reject' => ['pending', 'under review'],
        'complete' => ['approved'], 'no-show' => ['approved'], 'cancel' => ['pending', 'under review', 'approved'], 'assign' => ['under review', 'approved'],
    ];
    if (!isset($allowed[$action]) || !in_array($a['status'], $allowed[$action], true)) {
        $error = 'This action is not possible while the appointment is "' . $a['status'] . '". The page was refreshed.';
    }
    $assignee = input('assigned_to');
    if (!$error && in_array($action, ['review', 'assign'], true) && !array_key_exists((int)$assignee, staff_options())) {
        $error = 'Choose the BHW or nurse who will handle this appointment.';
    }
    if (!$error && in_array($action, ['reject', 'cancel'], true) && $remarks === '') {
        $error = 'Give a reason (the resident will see it).';
    }
    $schedDate = input('scheduled_date');
    $schedTime = input('scheduled_time');
    if (!$error && $action === 'approve') {
        $error = appointment_date_error($schedDate);
        if (!$error && $schedTime !== '' && !preg_match('/^(0[7-9]|1[0-6]):[0-5]\d$/', $schedTime)) {
            $error = 'Choose a time between 7:00 AM and 4:59 PM.';
        }
    }
    if (!$error && $action === 'no-show' && $a['scheduled_date'] > today()) {
        $error = 'You can only mark a no-show on or after the scheduled date.';
    }

    if (!$error) {
        db()->beginTransaction();
        switch ($action) {
            case 'review':
                q("UPDATE appointments SET status = 'under review', assigned_to = ?, reviewed_at = NOW(), remarks = COALESCE(?, remarks) WHERE appointment_id = ?",
                  [(int)$assignee, nullable($remarks), $id]);
                $who = staff_options()[(int)$assignee];
                log_appointment($id, 'under review', 'Assigned to ' . $who . ($remarks !== '' ? ' — ' . $remarks : ''));
                if ((int)$assignee !== user_id()) {
                    notify((int)$assignee, 'Appointment assigned to you', "$ref: {$a['service_type']} for $name.", 'modules/appointments/view.php?id=' . $id);
                }
                notify_resident((int)$a['resident_id'], 'Appointment under review', "Your request $ref is now being reviewed by the health center.", 'portal/appointments.php');
                $msg = "$ref is now under review and assigned to $who.";
                break;
            case 'assign':
                q('UPDATE appointments SET assigned_to = ? WHERE appointment_id = ?', [(int)$assignee, $id]);
                log_appointment($id, $a['status'], 'Reassigned to ' . staff_options()[(int)$assignee] . ($remarks !== '' ? ' — ' . $remarks : ''));
                notify((int)$assignee, 'Appointment assigned to you', "$ref: {$a['service_type']} for $name.", 'modules/appointments/view.php?id=' . $id);
                $msg = "$ref reassigned.";
                break;
            case 'approve':
                q("UPDATE appointments SET status = 'approved', scheduled_date = ?, scheduled_time = ?, remarks = ?, approved_by = ?, approved_at = NOW(),
                   assigned_to = COALESCE(assigned_to, ?), reviewed_at = COALESCE(reviewed_at, NOW()) WHERE appointment_id = ?",
                  [$schedDate, nullable($schedTime), nullable($remarks), user_id(), user_id(), $id]);
                $when = fmt_date($schedDate) . ($schedTime !== '' ? ' at ' . fmt_time($schedTime) : '');
                log_appointment($id, 'approved', 'Scheduled on ' . $when . ($remarks !== '' ? ' — ' . $remarks : ''));
                notify_resident((int)$a['resident_id'], 'Appointment approved', "Your {$a['service_type']} ($ref) is approved for $when.", 'portal/appointments.php');
                $msg = "$ref approved for $when. The resident was notified.";
                break;
            case 'reject':
                q("UPDATE appointments SET status = 'rejected', remarks = ?, approved_by = ?, approved_at = NOW() WHERE appointment_id = ?", [$remarks, user_id(), $id]);
                log_appointment($id, 'rejected', $remarks);
                notify_resident((int)$a['resident_id'], 'Appointment not approved', "Your request $ref was not approved: $remarks", 'portal/appointments.php');
                $msg = "$ref rejected. The resident was notified.";
                break;
            case 'complete':
                q("UPDATE appointments SET status = 'completed', completed_at = NOW(), remarks = COALESCE(?, remarks) WHERE appointment_id = ?", [nullable($remarks), $id]);
                log_appointment($id, 'completed', $remarks !== '' ? $remarks : 'Service given');
                notify_resident((int)$a['resident_id'], 'Appointment completed', "Your appointment $ref is completed. Thank you!", 'portal/appointments.php');
                $msg = "$ref marked as completed.";
                break;
            case 'no-show':
                q("UPDATE appointments SET status = 'no-show', remarks = COALESCE(?, remarks) WHERE appointment_id = ?", [nullable($remarks), $id]);
                log_appointment($id, 'no-show', $remarks !== '' ? $remarks : 'Resident did not come');
                notify_resident((int)$a['resident_id'], 'Missed appointment', "You missed your appointment $ref. Please request a new one.", 'portal/appointments.php');
                $msg = "$ref marked as no-show.";
                break;
            default: // cancel
                q("UPDATE appointments SET status = 'cancelled', remarks = ? WHERE appointment_id = ?", [$remarks, $id]);
                log_appointment($id, 'cancelled', 'Cancelled by the health center: ' . $remarks);
                notify_resident((int)$a['resident_id'], 'Appointment cancelled', "Your appointment $ref was cancelled: $remarks", 'portal/appointments.php');
                $msg = "$ref cancelled.";
        }
        db()->commit();
        log_activity(strtoupper($action), 'appointments', $id, $msg);
        flash('success', $msg);
        if ($action === 'no-show' && can('maternal', 'edit') && page_exists('modules/maternal/schedules.php')) {
            flash('info', 'Tip: schedule a home visit for ' . $name . ' under Scheduled Visits.');
        }
    } else {
        flash('danger', $error);
    }
    redirect('modules/appointments/view.php?id=' . $id);
}

$logs = q('SELECT l.*, u.full_name, u.role FROM appointment_logs l LEFT JOIN users u ON u.user_id = l.changed_by
           WHERE l.appointment_id = ? ORDER BY l.changed_at, l.log_id', [$id])->fetchAll();
$consult = q('SELECT consultation_id, consultation_date, status FROM consultations WHERE appointment_id = ? ORDER BY consultation_id DESC LIMIT 1', [$id])->fetch();
$staff = staff_options();
$canEdit = can('appointments', 'edit');
$times = [];
for ($t = strtotime('08:00'); $t <= strtotime('16:30'); $t += 1800) {
    $times[date('H:i', $t)] = date('g:i A', $t);
}

$page_title = 'Appointment ' . $a['reference_no'];
$nav_active = 'modules/appointments/index.php';
$page_kicker = 'Appointments';
require __DIR__ . '/../../includes/header.php';
?>
<div class="page-head">
    <div>
        <h2><span class="ref-no"><?= e($a['reference_no']) ?></span> <?= badge($a['status']) ?></h2>
        <div class="muted"><?= e($a['service_type']) ?> for <a href="<?= e(url('modules/residents/view.php?id=' . $a['resident_id'])) ?>"><?= e(full_name($a)) ?></a>
            (<?= e($a['sex']) ?>, <?= e(age_label($a['birthdate'])) ?>) &middot; submitted <?= fmt_datetime($a['created_at']) ?></div>
    </div>
    <div class="btn-group no-print"><button class="btn" data-print>Print</button></div>
</div>

<div class="grid cols-2 mb">
    <div class="card">
        <h3>Request details</h3>
        <dl class="info">
            <dt>Service</dt><dd><?= e($a['service_type']) ?></dd>
            <dt>Reason</dt><dd><?= e($a['reason'] ?: '—') ?></dd>
            <dt>Preferred</dt><dd><?= fmt_date($a['preferred_date']) ?> <?= $a['preferred_time'] ? fmt_time($a['preferred_time']) : '' ?></dd>
            <dt>Scheduled</dt><dd><strong><?= $a['scheduled_date'] ? fmt_date($a['scheduled_date']) . ' ' . ($a['scheduled_time'] ? fmt_time($a['scheduled_time']) : '') : '—' ?></strong></dd>
            <dt>Assigned to</dt><dd><?= e($a['assignee'] ?: 'Not yet assigned') ?></dd>
            <dt>Requested by</dt><dd><?= e($a['requester'] ?: '—') ?> <span class="small muted"><?= e(ROLE_LABELS[$a['requester_role']] ?? '') ?></span></dd>
            <dt>Contact no.</dt><dd><?= e($a['contact_no'] ?: '—') ?></dd>
            <dt>Remarks</dt><dd><?= e($a['remarks'] ?: '—') ?></dd>
            <?php if ($a['approved_at']): ?><dt><?= $a['status'] === 'rejected' ? 'Rejected' : 'Approved' ?></dt><dd class="small"><?= fmt_datetime($a['approved_at']) ?> by <?= e($a['approver']) ?></dd><?php endif; ?>
            <?php if ($a['completed_at']): ?><dt>Completed</dt><dd class="small"><?= fmt_datetime($a['completed_at']) ?></dd><?php endif; ?>
            <?php if ($consult): ?><dt>Consultation</dt><dd><a href="<?= e(url('modules/consultations/view.php?id=' . $consult['consultation_id'])) ?>"><?= fmt_datetime($consult['consultation_date']) ?></a> <?= badge($consult['status']) ?></dd><?php endif; ?>
        </dl>
    </div>

    <div class="card">
        <h3>Status history</h3>
        <ol class="timeline">
            <?php foreach ($logs as $l): ?>
                <li><?= badge($l['status']) ?> <?= e($l['remarks']) ?>
                    <div class="when"><?= fmt_datetime($l['changed_at']) ?> &middot; <?= e($l['full_name'] ?: 'System') ?><?= $l['role'] ? ' (' . e(ROLE_LABELS[$l['role']] ?? $l['role']) . ')' : '' ?></div></li>
            <?php endforeach; ?>
            <?php if (!$logs): ?><li class="muted">No history yet.</li><?php endif; ?>
        </ol>
    </div>
</div>

<?php if ($canEdit && in_array($a['status'], APPOINTMENT_OPEN, true)): ?>
<div class="card no-print">
    <h3>Next step</h3>
    <div class="grid cols-2">
        <?php if ($a['status'] === 'pending'): ?>
        <form method="post">
            <?= csrf_field() ?><input type="hidden" name="action" value="review">
            <h4>1. Review &amp; assign</h4>
            <?= select_field('Assign to', 'assigned_to', $staff, (string)user_id(), 'required', '-- Select staff --') ?>
            <?= field('Note (optional)', 'remarks', '', 'text', 'maxlength="200"') ?>
            <button class="btn btn-primary">Mark as under review</button>
        </form>
        <?php endif; ?>

        <?php if (in_array($a['status'], ['pending', 'under review'], true)): ?>
        <form method="post">
            <?= csrf_field() ?><input type="hidden" name="action" value="approve">
            <h4>2. Approve with schedule</h4>
            <div class="form-grid">
                <?= field('Date', 'scheduled_date', max($a['preferred_date'], today()), 'date', 'required min="' . today() . '"') ?>
                <?= select_field('Time', 'scheduled_time', $times, $a['preferred_time'] ? substr($a['preferred_time'], 0, 5) : '08:00', '', '-- Any time --') ?>
            </div>
            <?= field('Note to resident', 'remarks', '', 'text', 'maxlength="200" placeholder="e.g. Bring your vaccination card"') ?>
            <button class="btn btn-success">Approve</button>
        </form>
        <form method="post">
            <?= csrf_field() ?><input type="hidden" name="action" value="reject">
            <h4>or Reject</h4>
            <?= field('Reason (shown to the resident)', 'remarks', '', 'text', 'required maxlength="200" placeholder="e.g. Service not available on that date"') ?>
            <button class="btn btn-danger">Reject</button>
        </form>
        <?php endif; ?>

        <?php if ($a['status'] === 'approved'): ?>
        <div>
            <h4>3. Serve the resident</h4>
            <?php if (can('consultations', 'edit') && in_array($a['service_type'], ['General Consultation', 'Prenatal Check-up', 'Child Check-up', 'Medicine Request', 'Family Planning', 'Other'], true)): ?>
                <p><a class="btn btn-primary" href="<?= e(url('modules/consultations/form.php?appointment_id=' . $id)) ?>">Start consultation</a></p>
                <p class="hint">Saving a completed consultation automatically completes this appointment.</p>
            <?php endif; ?>
            <?php if ($a['service_type'] === 'Vaccination' && can('vaccinations', 'edit')): ?>
                <p><a class="btn btn-primary" href="<?= e(url('modules/vaccinations/form.php?resident_id=' . $a['resident_id'])) ?>">Record vaccination</a></p>
            <?php endif; ?>
            <form method="post">
                <?= csrf_field() ?><input type="hidden" name="action" value="complete">
                <?= field('Completion note', 'remarks', '', 'text', 'maxlength="200" placeholder="e.g. Vaccine given, refill released"') ?>
                <button class="btn btn-success">Mark completed</button>
            </form>
        </div>
        <form method="post">
            <?= csrf_field() ?><input type="hidden" name="action" value="no-show">
            <h4>Did not come?</h4>
            <?= field('Remarks', 'remarks', '', 'text', 'maxlength="200"') ?>
            <button class="btn btn-danger" <?= $a['scheduled_date'] > today() ? 'disabled title="Available on the scheduled date"' : '' ?>>Mark no-show</button>
        </form>
        <?php endif; ?>

        <?php if (in_array($a['status'], ['under review', 'approved'], true)): ?>
        <form method="post">
            <?= csrf_field() ?><input type="hidden" name="action" value="assign">
            <h4>Reassign</h4>
            <?= select_field('Assign to', 'assigned_to', $staff, (string)$a['assigned_to'], 'required', '-- Select staff --') ?>
            <button class="btn">Reassign</button>
        </form>
        <?php endif; ?>

        <form method="post" data-confirm="Cancel this appointment?">
            <?= csrf_field() ?><input type="hidden" name="action" value="cancel">
            <h4>Cancel</h4>
            <?= field('Reason (shown to the resident)', 'remarks', '', 'text', 'required maxlength="200"') ?>
            <button class="btn">Cancel appointment</button>
        </form>
    </div>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
