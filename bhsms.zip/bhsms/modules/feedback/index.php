<?php
/*
 * Resident feedback & ratings: Pending -> Under review -> Resolved (with a response the resident sees).
 * Summary: average rating overall and per category for the chosen period.
 */
require __DIR__ . '/../../includes/init.php';
require_perm('feedback');

if (is_post()) {
    require_perm('feedback', 'edit');
    $fb = q('SELECT * FROM feedback WHERE feedback_id = ?', [(int)input('feedback_id')])->fetch();
    $action = input('action');
    if (!$fb) {
        flash('danger', 'Feedback not found.');
    } elseif ($action === 'review' && $fb['status'] === 'pending') {
        q("UPDATE feedback SET status = 'under review' WHERE feedback_id = ?", [$fb['feedback_id']]);
        log_activity('UPDATE', 'feedback', $fb['feedback_id'], $fb['reference_no'] . ' under review');
        if ($fb['user_id']) notify((int)$fb['user_id'], 'Feedback under review', 'Your feedback ' . $fb['reference_no'] . ' is being reviewed.', 'portal/feedback.php');
        flash('success', $fb['reference_no'] . ' is now under review.');
    } elseif ($action === 'resolve' && $fb['status'] !== 'resolved') {
        $response = input('response');
        if ($response === '') {
            flash('danger', 'Write a response for the resident before resolving.');
        } else {
            q("UPDATE feedback SET status = 'resolved', response = ?, responded_by = ?, responded_at = NOW() WHERE feedback_id = ?",
              [mb_substr($response, 0, 2000), user_id(), $fb['feedback_id']]);
            log_activity('UPDATE', 'feedback', $fb['feedback_id'], $fb['reference_no'] . ' resolved');
            if ($fb['user_id']) notify((int)$fb['user_id'], 'We replied to your feedback', $fb['reference_no'] . ': ' . mb_substr($response, 0, 150), 'portal/feedback.php');
            flash('success', $fb['reference_no'] . ' resolved. The resident can see your response.');
        }
    }
    redirect(back_url('modules/feedback/index.php'));
}

$status = get('status');
$category = get('category');
[$from, $to] = date_range('from', 'to', date('Y-m-01', strtotime('-11 months')));
$where = ['DATE(f.created_at) BETWEEN ? AND ?'];
$params = [$from, $to];
if (in_array($status, FEEDBACK_STATUS, true)) { $where[] = 'f.status = ?'; $params[] = $status; }
if (in_array($category, FEEDBACK_CATEGORIES, true)) { $where[] = 'f.category = ?'; $params[] = $category; }
$w = implode(' AND ', $where);
$rows = q("SELECT f.*, r.first_name, r.middle_name, r.last_name, r.suffix, u.full_name AS responder
           FROM feedback f LEFT JOIN residents r ON r.resident_id = f.resident_id LEFT JOIN users u ON u.user_id = f.responded_by
           WHERE $w ORDER BY f.status = 'resolved', f.created_at DESC LIMIT 300", $params)->fetchAll();
$summary = q("SELECT COUNT(*) AS n, AVG(rating) AS avg_rating, SUM(status = 'pending') AS pending, SUM(status = 'under review') AS reviewing, SUM(status = 'resolved') AS resolved
              FROM feedback f WHERE DATE(f.created_at) BETWEEN ? AND ?", [$from, $to])->fetch();
$byCat = q('SELECT category, COUNT(*) AS n, AVG(rating) AS avg_rating FROM feedback f WHERE DATE(f.created_at) BETWEEN ? AND ? GROUP BY category ORDER BY n DESC', [$from, $to])->fetchAll();

$page_title = 'Resident Feedback';
require __DIR__ . '/../../includes/header.php';
?>
<div class="stats">
    <div class="stat"><div class="label">Average rating</div><div class="value"><?= $summary['n'] ? number_format((float)$summary['avg_rating'], 1) : '—' ?> <small>/ 5</small></div><div class="sub"><?= stars($summary['avg_rating'] ?? 0) ?></div></div>
    <a class="stat amber" href="?status=pending"><div class="label">Pending</div><div class="value"><?= (int)$summary['pending'] ?></div></a>
    <a class="stat purple" href="?status=under+review"><div class="label">Under review</div><div class="value"><?= (int)$summary['reviewing'] ?></div></a>
    <a class="stat blue" href="?status=resolved"><div class="label">Resolved</div><div class="value"><?= (int)$summary['resolved'] ?></div></a>
</div>

<div class="grid cols-3-1">
    <div class="card">
        <div class="card-header"><h3>Feedback (<?= count($rows) ?>)</h3></div>
        <form class="toolbar" method="get">
            <div><label>Status</label><select name="status"><?= options(FEEDBACK_STATUS, $status, 'All') ?></select></div>
            <div><label>Category</label><select name="category"><?= options(FEEDBACK_CATEGORIES, $category, 'All') ?></select></div>
            <div><label>From</label><input type="date" name="from" value="<?= e($from) ?>"></div>
            <div><label>To</label><input type="date" name="to" value="<?= e($to) ?>"></div>
            <button class="btn">Filter</button><a class="btn" href="index.php">Reset</a>
        </form>
        <div class="ann-list">
        <?php foreach ($rows as $f): ?>
            <div class="ann">
                <div class="meta"><span class="ref-no"><?= e($f['reference_no']) ?></span> <?= stars($f['rating']) ?> <span><?= e($f['category']) ?></span>
                    <span><?= $f['last_name'] ? e(full_name($f)) : 'Resident' ?></span><span><?= fmt_datetime($f['created_at']) ?></span> <?= badge($f['status']) ?></div>
                <p><?= e($f['comments']) ?></p>
                <?php if ($f['response']): ?><div class="alert alert-info small" style="margin:10px 0 0"><strong>Response</strong> (<?= e($f['responder']) ?>, <?= fmt_datetime($f['responded_at']) ?>): <?= e($f['response']) ?></div><?php endif; ?>
                <?php if (can('feedback', 'edit') && $f['status'] !== 'resolved'): ?>
                    <div class="btn-group" style="margin-top:10px">
                        <?php if ($f['status'] === 'pending'): ?><?= post_button('index.php', 'Mark under review', ['action' => 'review', 'feedback_id' => $f['feedback_id']]) ?><?php endif; ?>
                        <details class="pop">
                            <summary class="btn btn-sm btn-primary">Respond &amp; resolve</summary>
                            <div class="pop-body">
                                <form method="post" action="index.php">
                                    <?= csrf_field() ?><?= back_field() ?>
                                    <input type="hidden" name="action" value="resolve"><input type="hidden" name="feedback_id" value="<?= (int)$f['feedback_id'] ?>">
                                    <?= field('Response to the resident', 'response', '', 'textarea', 'required maxlength="2000"') ?>
                                    <button class="btn btn-sm btn-success">Send &amp; resolve</button>
                                </form>
                            </div>
                        </details>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
        <?php if (!$rows): ?><p class="muted">No feedback in this period.</p><?php endif; ?>
        </div>
    </div>
    <div class="card">
        <h3>Rating by category</h3>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Category</th><th class="num">Count</th><th>Average</th></tr></thead>
            <tbody>
            <?php foreach ($byCat as $c): ?>
                <tr><td><?= e($c['category']) ?></td><td class="num"><?= (int)$c['n'] ?></td><td class="nowrap"><?= number_format((float)$c['avg_rating'], 1) ?> <?= stars($c['avg_rating']) ?></td></tr>
            <?php endforeach; ?>
            <?php if (!$byCat): ?><tr><td colspan="3" class="empty">No ratings yet.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
        <p class="hint"><?= fmt_date($from) ?> – <?= fmt_date($to) ?></p>
    </div>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
