<?php
require __DIR__ . '/../../includes/init.php';
require_perm('consultations');

$search = get('q');
$status = get('status');
$from = get('from');
$to = get('to');

$where = ['1=1'];
$params = [];
if ($search !== '') {
    $where[] = "(CONCAT(r.first_name, ' ', r.last_name) LIKE ? OR r.last_name LIKE ? OR c.chief_complaint LIKE ? OR c.assessment LIKE ?)";
    $like = '%' . $search . '%';
    array_push($params, $like, $like, $like, $like);
}
if (in_array($status, ['waiting', 'ongoing', 'completed', 'referred'], true)) {
    $where[] = 'c.status = ?';
    $params[] = $status;
}
if (valid_date($from)) { $where[] = 'c.consultation_date >= ?'; $params[] = $from . ' 00:00:00'; }
if (valid_date($to))   { $where[] = 'c.consultation_date <= ?'; $params[] = $to . ' 23:59:59'; }
$w = implode(' AND ', $where);

$from_sql = 'FROM consultations c JOIN residents r ON r.resident_id = c.resident_id LEFT JOIN users u ON u.user_id = c.recorded_by';
$pg = paginate((int)q("SELECT COUNT(*) $from_sql WHERE $w", $params)->fetchColumn());
$rows = q("SELECT c.*, r.first_name, r.middle_name, r.last_name, r.suffix, r.birthdate, r.sex, u.full_name AS recorder
           $from_sql WHERE $w ORDER BY c.consultation_date DESC, c.consultation_id DESC LIMIT {$pg['per']} OFFSET {$pg['offset']}", $params)->fetchAll();

$queue = (int)q("SELECT COUNT(*) FROM consultations WHERE status IN ('waiting', 'ongoing')")->fetchColumn();
$today = (int)q('SELECT COUNT(*) FROM consultations WHERE DATE(consultation_date) = CURDATE()')->fetchColumn();
$month = (int)q("SELECT COUNT(*) FROM consultations WHERE DATE_FORMAT(consultation_date, '%Y-%m') = DATE_FORMAT(CURDATE(), '%Y-%m')")->fetchColumn();
$referred = (int)q("SELECT COUNT(*) FROM consultations WHERE status = 'referred' AND DATE_FORMAT(consultation_date, '%Y-%m') = DATE_FORMAT(CURDATE(), '%Y-%m')")->fetchColumn();

$page_title = 'Consultations';
require __DIR__ . '/../../includes/header.php';
?>
<div class="stats">
    <a class="stat <?= $queue ? 'amber' : '' ?>" href="?status=waiting"><div class="label">Waiting / ongoing</div><div class="value"><?= $queue ?></div></a>
    <div class="stat blue"><div class="label">Consultations today</div><div class="value"><?= $today ?></div></div>
    <div class="stat"><div class="label">This month</div><div class="value"><?= $month ?></div></div>
    <a class="stat purple" href="?status=referred"><div class="label">Referred this month</div><div class="value"><?= $referred ?></div></a>
</div>

<div class="card">
    <div class="card-header">
        <h3>Consultation records</h3>
        <?php if (can('consultations', 'edit')): ?><a class="btn btn-primary" href="form.php">+ New consultation</a><?php endif; ?>
    </div>
    <form class="toolbar" method="get">
        <div class="grow"><label>Search</label><input type="search" name="q" value="<?= e($search) ?>" placeholder="Patient name, complaint or assessment"></div>
        <div><label>Status</label><select name="status"><?= options(['waiting' => 'Waiting (intake done)', 'ongoing' => 'Ongoing', 'completed' => 'Completed', 'referred' => 'Referred'], $status, 'All') ?></select></div>
        <div><label>From</label><input type="date" name="from" value="<?= e($from) ?>"></div>
        <div><label>To</label><input type="date" name="to" value="<?= e($to) ?>"></div>
        <button class="btn">Filter</button>
        <a class="btn" href="index.php">Reset</a>
    </form>

    <div class="table-wrap"><table class="table">
        <thead><tr><th>Date &amp; time</th><th>Patient</th><th>Chief complaint</th><th>Vitals</th><th>Assessment</th><th>Status</th><th>Recorded by</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $c): ?>
            <tr>
                <td class="nowrap"><?= fmt_datetime($c['consultation_date']) ?></td>
                <td><a href="<?= e(url('modules/residents/view.php?id=' . $c['resident_id'])) ?>"><strong><?= e(full_name($c)) ?></strong></a>
                    <div class="small muted"><?= e($c['sex']) ?>, <?= e(age_label($c['birthdate'])) ?></div></td>
                <td><?= e($c['chief_complaint']) ?></td>
                <td class="small nowrap"><?= $c['blood_pressure'] ? 'BP ' . e($c['blood_pressure']) . '<br>' : '' ?><?= $c['temperature_c'] ? e($c['temperature_c']) . '&deg;C' : '' ?></td>
                <td class="small"><?= e($c['assessment'] ?: '—') ?></td>
                <td><?= badge($c['status']) ?></td>
                <td class="small"><?= e($c['recorder'] ?: '—') ?></td>
                <td class="actions"><a class="btn btn-sm" href="view.php?id=<?= (int)$c['consultation_id'] ?>">Open</a></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="8" class="empty">No consultations found.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
    <?= pagination_links($pg) ?>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
