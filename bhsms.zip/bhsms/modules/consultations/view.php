<?php
require __DIR__ . '/../../includes/init.php';
require_perm('consultations');

$id = (int)get('id');
$c = q('SELECT c.*, r.first_name, r.middle_name, r.last_name, r.suffix, r.birthdate, r.sex, r.contact_no,
               u.full_name AS recorder, a.reference_no, a.service_type
        FROM consultations c JOIN residents r ON r.resident_id = c.resident_id
        LEFT JOIN users u ON u.user_id = c.recorded_by LEFT JOIN appointments a ON a.appointment_id = c.appointment_id
        WHERE c.consultation_id = ?', [$id])->fetch();
if (!$c) {
    flash('danger', 'Consultation not found.');
    redirect('modules/consultations/index.php');
}

if (is_post() && input('action') === 'delete') {
    require_perm('consultations', 'delete');
    q('DELETE FROM consultations WHERE consultation_id = ?', [$id]);
    log_activity('DELETE', 'consultations', $id, 'Deleted consultation of ' . $c['first_name'] . ' ' . $c['last_name']);
    flash('success', 'Consultation deleted.');
    redirect('modules/consultations/index.php');
}

$hp = q('SELECT allergies, existing_conditions, maintenance_meds FROM health_profiles WHERE resident_id = ?', [$c['resident_id']])->fetch();
$meds = q('SELECT d.*, m.generic_name, m.strength, m.dosage_form, m.unit, s.batch_no, u.full_name AS giver
           FROM medicine_distribution d JOIN medicines m ON m.medicine_id = d.medicine_id
           JOIN medicine_stock s ON s.stock_id = d.stock_id LEFT JOIN users u ON u.user_id = d.given_by
           WHERE d.consultation_id = ? ORDER BY d.distribution_id', [$id])->fetchAll();

$page_title = 'Consultation';
$nav_active = 'modules/consultations/index.php';
$page_kicker = 'Consultations';
require __DIR__ . '/../../includes/header.php';
?>
<div class="page-head">
    <div>
        <h2><a href="<?= e(url('modules/residents/view.php?id=' . $c['resident_id'])) ?>"><?= e(full_name($c)) ?></a> <?= badge($c['status']) ?></h2>
        <div class="muted"><?= e($c['sex']) ?>, <?= e(age_label($c['birthdate'])) ?> &middot; <?= fmt_datetime($c['consultation_date']) ?>
            <?php if ($c['reference_no']): ?> &middot; Appointment <a class="ref-no" href="<?= e(url('modules/appointments/view.php?id=' . $c['appointment_id'])) ?>"><?= e($c['reference_no']) ?></a><?php endif; ?></div>
    </div>
    <div class="btn-group no-print">
        <?php if (can('consultations', 'assess') || (can('consultations', 'edit') && in_array($c['status'], ['waiting', 'ongoing'], true))): ?>
            <a class="btn btn-primary" href="form.php?id=<?= $id ?>"><?= can('consultations', 'assess') && $c['status'] === 'waiting' ? 'Assess patient' : 'Edit' ?></a>
        <?php endif; ?>
        <?php if (can('inventory', 'distribute')): ?>
            <a class="btn" href="<?= e(url('modules/inventory/distribute.php?resident_id=' . $c['resident_id'] . '&consultation_id=' . $id)) ?>">Give medicine</a>
        <?php endif; ?>
        <button class="btn" data-print>Print</button>
        <?php if (can('consultations', 'delete')): ?>
            <?= post_button('view.php?id=' . $id, 'Delete', ['action' => 'delete'], 'btn btn-danger', 'Delete this consultation? This cannot be undone.') ?>
        <?php endif; ?>
    </div>
</div>

<div class="grid cols-2 mb">
    <div class="card">
        <h3>Complaint &amp; vital signs</h3>
        <dl class="info">
            <dt>Chief complaint</dt><dd><strong><?= e($c['chief_complaint']) ?></strong></dd>
            <dt>Symptoms / history</dt><dd><?= nl2br(e($c['symptoms'] ?: '—')) ?></dd>
            <dt>Blood pressure</dt><dd><?= e($c['blood_pressure'] ?: '—') ?></dd>
            <dt>Temperature</dt><dd><?= $c['temperature_c'] ? e($c['temperature_c']) . ' &deg;C' : '—' ?></dd>
            <dt>Pulse / Resp. rate</dt><dd><?= e($c['pulse_rate'] ?: '—') ?> bpm / <?= e($c['respiratory_rate'] ?: '—') ?> per min</dd>
            <dt>Weight</dt><dd><?= $c['weight_kg'] ? e($c['weight_kg']) . ' kg' : '—' ?></dd>
            <dt>Recorded by</dt><dd><?= e($c['recorder'] ?: '—') ?> &middot; <span class="small muted"><?= fmt_datetime($c['created_at']) ?></span></dd>
        </dl>
    </div>
    <div class="card">
        <h3>Assessment &amp; treatment</h3>
        <dl class="info">
            <dt>Assessment</dt><dd><?= nl2br(e($c['assessment'] ?: 'Waiting for the nurse\'s assessment')) ?></dd>
            <dt>Treatment / advice</dt><dd><?= nl2br(e($c['treatment_plan'] ?: '—')) ?></dd>
            <dt>Referred to</dt><dd><?= e($c['referred_to'] ?: '—') ?></dd>
            <dt>Last updated</dt><dd class="small muted"><?= fmt_datetime($c['updated_at']) ?></dd>
        </dl>
        <?php if ($hp && ($hp['allergies'] || $hp['existing_conditions'])): ?>
            <div class="alert alert-warning small">
                <?= $hp['allergies'] ? '<strong>Allergies:</strong> ' . e($hp['allergies']) . '<br>' : '' ?>
                <?= $hp['existing_conditions'] ? '<strong>Conditions:</strong> ' . e($hp['existing_conditions']) : '' ?>
                <?= $hp['maintenance_meds'] ? '<br><strong>Maintenance:</strong> ' . e($hp['maintenance_meds']) : '' ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="card">
    <div class="card-header"><h3>Medicines given for this consultation</h3></div>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Date</th><th>Medicine</th><th>Batch</th><th class="num">Quantity</th><th>Instructions</th><th>Given by</th></tr></thead>
        <tbody>
        <?php foreach ($meds as $m): ?>
            <tr>
                <td><?= fmt_date($m['distribution_date']) ?></td>
                <td><?= e($m['generic_name']) ?> <span class="small muted"><?= e($m['strength']) ?> <?= e($m['dosage_form']) ?></span></td>
                <td class="small"><?= e($m['batch_no']) ?></td>
                <td class="num"><?= (int)$m['quantity'] ?> <?= e($m['unit']) ?></td>
                <td><?= e($m['instructions']) ?></td>
                <td class="small"><?= e($m['giver']) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$meds): ?><tr><td colspan="6" class="empty">No medicines given yet.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
