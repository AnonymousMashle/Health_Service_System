<?php
/*
 * Consultation intake and assessment.
 *  - BHW: registers the visit (complaint, symptoms, vital signs). Status stays "waiting" for the nurse.
 *  - Nurse: adds the assessment, treatment plan, referral and sets the status (ongoing, completed, referred).
 * Opened from an approved appointment (?appointment_id=), saving a completed consultation also completes the appointment.
 */
require __DIR__ . '/../../includes/init.php';
require_perm('consultations', 'edit');

$canAssess = can('consultations', 'assess');
$id = (int)get('id');
$c = [
    'resident_id' => get('resident_id'), 'appointment_id' => get('appointment_id'), 'consultation_date' => date('Y-m-d\TH:i'),
    'chief_complaint' => '', 'symptoms' => '', 'blood_pressure' => '', 'temperature_c' => '', 'pulse_rate' => '',
    'respiratory_rate' => '', 'weight_kg' => '', 'assessment' => '', 'treatment_plan' => '', 'referred_to' => '',
    'status' => $canAssess ? 'completed' : 'waiting',
];

if ($id) {
    $row = q('SELECT * FROM consultations WHERE consultation_id = ?', [$id])->fetch();
    if (!$row) {
        flash('danger', 'Consultation not found.');
        redirect('modules/consultations/index.php');
    }
    if (!$canAssess && !in_array($row['status'], ['waiting', 'ongoing'], true)) {
        flash('warning', 'Only the nurse can change a consultation that is already completed or referred.');
        redirect('modules/consultations/view.php?id=' . $id);
    }
    $c = array_map(function ($v) { return $v ?? ''; }, $row);
    $c['consultation_date'] = date('Y-m-d\TH:i', strtotime($row['consultation_date']));
}

// Opened from an appointment: take the resident and reason from it
$appt = null;
if ($c['appointment_id'] !== '') {
    $appt = q("SELECT * FROM appointments WHERE appointment_id = ?", [(int)$c['appointment_id']])->fetch();
    if ($appt) {
        $c['resident_id'] = $c['resident_id'] !== '' ? $c['resident_id'] : $appt['resident_id'];
        if (!$id && $c['chief_complaint'] === '') {
            $c['chief_complaint'] = mb_substr((string)($appt['reason'] ?: $appt['service_type']), 0, 255);
        }
    } else {
        $c['appointment_id'] = '';
    }
}

$errors = [];
if (is_post()) {
    $fields = ['resident_id', 'consultation_date', 'chief_complaint', 'symptoms', 'blood_pressure', 'temperature_c', 'pulse_rate', 'respiratory_rate', 'weight_kg'];
    if ($canAssess) {
        array_push($fields, 'assessment', 'treatment_plan', 'referred_to', 'status');
    }
    foreach ($fields as $f) { $c[$f] = input($f); }

    if (!q("SELECT 1 FROM residents WHERE resident_id = ? AND status = 'active'", [(int)$c['resident_id']])->fetchColumn()) $errors[] = 'Choose the patient.';
    $dt = DateTime::createFromFormat('Y-m-d\TH:i', $c['consultation_date']);
    if (!$dt) {
        $errors[] = 'Enter the consultation date and time.';
    } elseif ($dt > new DateTime('+5 minutes')) {
        $errors[] = 'The consultation date cannot be in the future.';
    }
    if ($c['chief_complaint'] === '') $errors[] = 'Enter the chief complaint.';
    if ($c['blood_pressure'] !== '' && !preg_match('#^\d{2,3}/\d{2,3}$#', $c['blood_pressure'])) $errors[] = 'Blood pressure must look like 120/80.';
    foreach (['temperature_c' => ['Temperature', 34, 43], 'pulse_rate' => ['Pulse rate', 30, 220], 'respiratory_rate' => ['Respiratory rate', 8, 80], 'weight_kg' => ['Weight', 0.5, 300]] as $f => [$label, $min, $max]) {
        if ($c[$f] !== '' && (!is_numeric($c[$f]) || $c[$f] < $min || $c[$f] > $max)) {
            $errors[] = "$label must be between $min and $max.";
        }
    }
    if ($canAssess) {
        if (!in_array($c['status'], ['waiting', 'ongoing', 'completed', 'referred'], true)) $errors[] = 'Choose a status.';
        if (in_array($c['status'], ['completed', 'referred'], true) && $c['assessment'] === '') $errors[] = 'Enter your assessment before completing the consultation.';
        if ($c['status'] === 'referred' && $c['referred_to'] === '') $errors[] = 'Enter where the patient is referred to.';
    }
    if ($appt && (int)$appt['resident_id'] !== (int)$c['resident_id']) $errors[] = 'The patient does not match the appointment.';

    if (!$errors) {
        $data = [
            'resident_id' => (int)$c['resident_id'], 'appointment_id' => $appt ? (int)$appt['appointment_id'] : null,
            'consultation_date' => $dt->format('Y-m-d H:i:s'), 'chief_complaint' => $c['chief_complaint'], 'symptoms' => nullable($c['symptoms']),
            'blood_pressure' => nullable($c['blood_pressure']), 'temperature_c' => nullable($c['temperature_c']), 'pulse_rate' => nullable($c['pulse_rate']),
            'respiratory_rate' => nullable($c['respiratory_rate']), 'weight_kg' => nullable($c['weight_kg']),
        ];
        if ($canAssess) {
            $data += ['assessment' => nullable($c['assessment']), 'treatment_plan' => nullable($c['treatment_plan']),
                      'referred_to' => nullable($c['referred_to']), 'status' => $c['status']];
        } elseif (!$id) {
            $data['status'] = 'waiting';
        }

        db()->beginTransaction();
        if ($id) {
            db_update('consultations', $data, 'consultation_id', $id);
            log_activity('UPDATE', 'consultations', $id, 'Updated consultation (' . $c['chief_complaint'] . ')');
        } else {
            $data['recorded_by'] = user_id();
            $id = db_insert('consultations', $data);
            log_activity('CREATE', 'consultations', $id, 'Recorded consultation (' . $c['chief_complaint'] . ')');
        }
        // A finished consultation completes its appointment (end of the appointment workflow)
        $finalStatus = $data['status'] ?? ($row['status'] ?? 'waiting');
        if ($appt && in_array($finalStatus, ['completed', 'referred'], true) && in_array($appt['status'], ['approved', 'under review', 'pending'], true)) {
            q("UPDATE appointments SET status = 'completed', completed_at = NOW() WHERE appointment_id = ?", [$appt['appointment_id']]);
            log_appointment((int)$appt['appointment_id'], 'completed', 'Consultation recorded' . ($finalStatus === 'referred' ? ' (referred)' : ''));
            notify_resident((int)$appt['resident_id'], 'Appointment completed', 'Your appointment ' . $appt['reference_no'] . ' is completed. Thank you for visiting the health center.', 'portal/appointments.php');
        }
        db()->commit();

        if (!$canAssess && ($data['status'] ?? '') === 'waiting') {
            notify_roles(['nurse'], 'Patient waiting', 'A patient is waiting for assessment: ' . $c['chief_complaint'] . '.', 'modules/consultations/view.php?id=' . $id, true);
        }
        flash('success', 'Consultation saved.');
        redirect('modules/consultations/view.php?id=' . $id);
    }
}

$page_title = $id ? 'Edit Consultation' : 'New Consultation';
$nav_active = 'modules/consultations/index.php';
$page_kicker = 'Consultations';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<?php if ($appt): ?>
    <div class="alert alert-info">From appointment <strong class="ref-no"><?= e($appt['reference_no']) ?></strong> — <?= e($appt['service_type']) ?>
        (<?= e($appt['status']) ?>). Completing this consultation marks the appointment as completed.</div>
<?php endif; ?>
<?php if (!$canAssess): ?>
    <div class="alert alert-info">You are recording the <strong>intake</strong> (complaint and vital signs). The nurse will add the assessment and treatment.</div>
<?php endif; ?>
<form method="post" class="card">
    <?= csrf_field() ?>
    <fieldset>
        <legend>Patient &amp; complaint</legend>
        <div class="form-grid">
            <div class="field required span-2">
                <label for="f_resident_id">Patient</label>
                <select id="f_resident_id" name="resident_id" class="searchable" data-placeholder="Type the patient's name" required <?= $appt ? 'disabled' : '' ?>>
                    <?= options(resident_options(), $c['resident_id']) ?>
                </select>
                <?php if ($appt): ?><input type="hidden" name="resident_id" value="<?= (int)$c['resident_id'] ?>"><?php endif; ?>
            </div>
            <?= field('Date & time', 'consultation_date', $c['consultation_date'], 'datetime-local', 'required max="' . date('Y-m-d\TH:i') . '"') ?>
            <?= field('Chief complaint', 'chief_complaint', $c['chief_complaint'], 'text', 'required maxlength="255" placeholder="e.g. Fever for 2 days"') ?>
            <?= field('Symptoms / history', 'symptoms', $c['symptoms'], 'textarea', '', 'span-2') ?>
        </div>
    </fieldset>
    <fieldset>
        <legend>Vital signs</legend>
        <div class="form-grid">
            <?= field('Blood pressure (mmHg)', 'blood_pressure', $c['blood_pressure'], 'text', 'maxlength="7" placeholder="120/80" pattern="\d{2,3}/\d{2,3}"') ?>
            <?= field('Temperature (°C)', 'temperature_c', $c['temperature_c'], 'number', 'step="0.1" min="34" max="43"') ?>
            <?= field('Pulse rate (bpm)', 'pulse_rate', $c['pulse_rate'], 'number', 'min="30" max="220"') ?>
            <?= field('Respiratory rate (/min)', 'respiratory_rate', $c['respiratory_rate'], 'number', 'min="8" max="80"') ?>
            <?= field('Weight (kg)', 'weight_kg', $c['weight_kg'], 'number', 'step="0.1" min="0.5" max="300"') ?>
        </div>
    </fieldset>
    <?php if ($canAssess): ?>
    <fieldset>
        <legend>Assessment &amp; treatment (nurse)</legend>
        <div class="form-grid">
            <?= field('Assessment / impression', 'assessment', $c['assessment'], 'textarea', '', 'span-2') ?>
            <?= field('Treatment plan / advice', 'treatment_plan', $c['treatment_plan'], 'textarea', '', 'span-2') ?>
            <?= select_field('Status', 'status', ['waiting' => 'Waiting', 'ongoing' => 'Ongoing', 'completed' => 'Completed', 'referred' => 'Referred'], $c['status'], 'required', false) ?>
            <div data-show-when="status=referred"><?= field('Referred to', 'referred_to', $c['referred_to'], 'text', 'maxlength="150" placeholder="e.g. Baguio General Hospital"') ?></div>
        </div>
    </fieldset>
    <?php endif; ?>
    <div class="form-actions">
        <a class="btn" href="<?= e(url($id ? 'modules/consultations/view.php?id=' . $id : 'modules/consultations/index.php')) ?>">Cancel</a>
        <button class="btn btn-primary">Save consultation</button>
    </div>
</form>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
