<?php
/*
 * Reports & analytics. Every number is computed live from the database for the chosen date range,
 * so records entered during the demo show up immediately. Each section can be printed or exported to CSV.
 * Answers interview Q10 (monthly reports are counted by hand from logbooks) and Q12 (print records for past years).
 */
require __DIR__ . '/../../includes/init.php';
require_perm('reports');

const REPORT_SECTIONS = [
    'summary' => 'Monthly service summary', 'population' => 'Population', 'consultations' => 'Consultations', 'vaccinations' => 'Immunization',
    'maternal' => 'Maternal & child health', 'medicines' => 'Medicine distribution', 'appointments' => 'Appointments', 'feedback' => 'Feedback & ratings',
];
[$from, $to] = date_range('from', 'to', date('Y-m-01', strtotime('-5 months')));
$section = array_key_exists(get('section'), REPORT_SECTIONS) ? get('section') : '';
$show = function (string $s) use ($section) { return $section === '' || $section === $s; };
$p = [$from, $to];
$pdt = [$from . ' 00:00:00', $to . ' 23:59:59'];

// Months in the range (for the monthly summary and charts)
$months = [];
for ($m = new DateTime(substr($from, 0, 7) . '-01'), $end = new DateTime(substr($to, 0, 7) . '-01'); $m <= $end; $m->modify('+1 month')) {
    $months[$m->format('Y-m')] = $m->format('M Y');
}
function per_month(string $sql, array $params, array $months): array
{
    $out = array_fill_keys(array_keys($months), 0);
    foreach (q($sql, $params)->fetchAll() as $r) {
        if (isset($out[$r['ym']])) $out[$r['ym']] = (float)$r['n'];
    }
    return $out;
}

$R = [];
// ----- Monthly summary -----
$R['summary'] = [
    'Consultations'          => per_month("SELECT DATE_FORMAT(consultation_date, '%Y-%m') ym, COUNT(*) n FROM consultations WHERE consultation_date BETWEEN ? AND ? GROUP BY ym", $pdt, $months),
    'Referrals'              => per_month("SELECT DATE_FORMAT(consultation_date, '%Y-%m') ym, COUNT(*) n FROM consultations WHERE status = 'referred' AND consultation_date BETWEEN ? AND ? GROUP BY ym", $pdt, $months),
    'Vaccine doses given'    => per_month("SELECT DATE_FORMAT(date_given, '%Y-%m') ym, COUNT(*) n FROM vaccinations WHERE date_given BETWEEN ? AND ? GROUP BY ym", $p, $months),
    'Prenatal visits'        => per_month("SELECT DATE_FORMAT(visit_date, '%Y-%m') ym, COUNT(*) n FROM prenatal_visits WHERE visit_date BETWEEN ? AND ? GROUP BY ym", $p, $months),
    'Child check-ups'        => per_month("SELECT DATE_FORMAT(visit_date, '%Y-%m') ym, COUNT(*) n FROM child_monitoring WHERE visit_date BETWEEN ? AND ? GROUP BY ym", $p, $months),
    'Medicine units given'   => per_month("SELECT DATE_FORMAT(distribution_date, '%Y-%m') ym, SUM(quantity) n FROM medicine_distribution WHERE distribution_date BETWEEN ? AND ? GROUP BY ym", $p, $months),
    'Appointments completed' => per_month("SELECT DATE_FORMAT(COALESCE(completed_at, scheduled_date), '%Y-%m') ym, COUNT(*) n FROM appointments WHERE status = 'completed' AND COALESCE(completed_at, scheduled_date) BETWEEN ? AND ? GROUP BY ym", $pdt, $months),
    'New residents'          => per_month("SELECT DATE_FORMAT(created_at, '%Y-%m') ym, COUNT(*) n FROM residents WHERE status = 'active' AND created_at BETWEEN ? AND ? GROUP BY ym", $pdt, $months),
];

// ----- Population (as of today) -----
$R['population'] = q("SELECT CASE
        WHEN TIMESTAMPDIFF(MONTH, birthdate, CURDATE()) < 12 THEN '0-11 months'
        WHEN TIMESTAMPDIFF(YEAR, birthdate, CURDATE()) < 5 THEN '1-4 years'
        WHEN TIMESTAMPDIFF(YEAR, birthdate, CURDATE()) < 10 THEN '5-9 years'
        WHEN TIMESTAMPDIFF(YEAR, birthdate, CURDATE()) < 20 THEN '10-19 years'
        WHEN TIMESTAMPDIFF(YEAR, birthdate, CURDATE()) < 60 THEN '20-59 years'
        ELSE '60+ years' END AS age_group,
        SUM(sex = 'Male') AS male, SUM(sex = 'Female') AS female, COUNT(*) AS total
    FROM residents WHERE status = 'active' GROUP BY age_group
    ORDER BY FIELD(age_group, '0-11 months', '1-4 years', '5-9 years', '10-19 years', '20-59 years', '60+ years')")->fetchAll();
$pop = q("SELECT COUNT(*) total, SUM(is_senior) seniors, SUM(is_pwd) pwd, SUM(is_4ps_member) fourps,
                 SUM(sex = 'Female' AND TIMESTAMPDIFF(YEAR, birthdate, CURDATE()) BETWEEN 15 AND 49) wra,
                 (SELECT COUNT(*) FROM households) households FROM residents WHERE status = 'active'")->fetch();
$byPurok = q("SELECT COALESCE(h.purok, 'No household') purok, COUNT(*) n FROM residents r LEFT JOIN households h ON h.household_id = r.household_id
              WHERE r.status = 'active' GROUP BY purok ORDER BY purok")->fetchAll();

// ----- Consultations -----
$cons = q("SELECT COUNT(*) total, SUM(status = 'completed') completed, SUM(status = 'referred') referred, SUM(status IN ('waiting', 'ongoing')) open_
           FROM consultations WHERE consultation_date BETWEEN ? AND ?", $pdt)->fetch();
$R['complaints'] = q("SELECT LOWER(TRIM(chief_complaint)) complaint, COUNT(*) n FROM consultations WHERE consultation_date BETWEEN ? AND ?
                      GROUP BY complaint ORDER BY n DESC, complaint LIMIT 10", $pdt)->fetchAll();
$R['diagnoses'] = q("SELECT assessment, COUNT(*) n FROM consultations WHERE assessment IS NOT NULL AND consultation_date BETWEEN ? AND ?
                     GROUP BY assessment ORDER BY n DESC LIMIT 10", $pdt)->fetchAll();

// ----- Immunization -----
$R['vaccines'] = q('SELECT vc.vaccine_name, COUNT(v.vaccination_id) doses, COUNT(DISTINCT v.resident_id) residents
                    FROM vaccines vc LEFT JOIN vaccinations v ON v.vaccine_id = vc.vaccine_id AND v.date_given BETWEEN ? AND ?
                    GROUP BY vc.vaccine_id, vc.vaccine_name ORDER BY doses DESC, vc.vaccine_name', $p)->fetchAll();
// Fully immunized child (12-23 months): BCG, 3 doses Pentavalent, 3 doses OPV and at least 1 MMR
$fic = q("SELECT COUNT(*) children,
                 SUM((SELECT COUNT(*) FROM vaccinations v JOIN vaccines vc ON vc.vaccine_id = v.vaccine_id WHERE v.resident_id = r.resident_id AND vc.vaccine_name = 'BCG') >= 1
                 AND (SELECT COUNT(*) FROM vaccinations v JOIN vaccines vc ON vc.vaccine_id = v.vaccine_id WHERE v.resident_id = r.resident_id AND vc.vaccine_name LIKE 'Pentavalent%') >= 3
                 AND (SELECT COUNT(*) FROM vaccinations v JOIN vaccines vc ON vc.vaccine_id = v.vaccine_id WHERE v.resident_id = r.resident_id AND vc.vaccine_name = 'OPV') >= 3
                 AND (SELECT COUNT(*) FROM vaccinations v JOIN vaccines vc ON vc.vaccine_id = v.vaccine_id WHERE v.resident_id = r.resident_id AND vc.vaccine_name = 'MMR') >= 1) fully
          FROM residents r WHERE r.status = 'active' AND TIMESTAMPDIFF(MONTH, r.birthdate, CURDATE()) BETWEEN 12 AND 23")->fetch();
$overdueVacc = (int)q('SELECT COUNT(*) FROM (' . due_vaccinations_sql() . ' AND v.next_schedule < CURDATE()) x')->fetchColumn();

// ----- Maternal & child -----
$mat = q("SELECT
    (SELECT COUNT(*) FROM pregnancies WHERE created_at BETWEEN ? AND ?) registered,
    (SELECT COUNT(*) FROM prenatal_visits WHERE visit_date BETWEEN ? AND ?) visits,
    (SELECT COUNT(*) FROM pregnancies WHERE status = 'delivered' AND delivery_date BETWEEN ? AND ?) deliveries,
    (SELECT COUNT(*) FROM pregnancies WHERE status = 'ongoing') ongoing,
    (SELECT COUNT(*) FROM pregnancies WHERE status = 'ongoing' AND risk_level = 'High') high_risk,
    (SELECT COUNT(*) FROM pregnancies p WHERE p.status = 'ongoing' AND (SELECT COUNT(*) FROM prenatal_visits pv WHERE pv.pregnancy_id = p.pregnancy_id) >= 4) four_anc,
    (SELECT COUNT(*) FROM child_monitoring WHERE visit_date BETWEEN ? AND ?) checkups", array_merge($pdt, $p, $p, $p))->fetch();
$R['nutrition'] = q("SELECT COALESCE(lm.nutrition_status, 'Not yet assessed') status, COUNT(*) n FROM residents r " . latest_measure_join('lm') . "
                     WHERE r.status = 'active' AND r.birthdate > ? GROUP BY status ORDER BY n DESC", [date('Y-m-d', strtotime('-60 months'))])->fetchAll();

// ----- Medicines -----
$R['medicines'] = q('SELECT m.generic_name, m.strength, m.dosage_form, m.unit, SUM(d.quantity) units, COUNT(DISTINCT d.resident_id) residents
                     FROM medicine_distribution d JOIN medicines m ON m.medicine_id = d.medicine_id
                     WHERE d.distribution_date BETWEEN ? AND ? GROUP BY m.medicine_id, m.generic_name, m.strength, m.dosage_form, m.unit
                     ORDER BY units DESC', $p)->fetchAll();
$stock = q("SELECT SUM(stock_status = 'Low Stock') low, SUM(stock_status = 'Out of Stock') out_ FROM v_medicine_stock_levels")->fetch();

// ----- Appointments -----
$R['appointments'] = q('SELECT status, COUNT(*) n FROM appointments WHERE created_at BETWEEN ? AND ? GROUP BY status ORDER BY n DESC', $pdt)->fetchAll();
$apptTime = q("SELECT AVG(TIMESTAMPDIFF(HOUR, created_at, approved_at)) hrs FROM appointments WHERE approved_at IS NOT NULL AND status <> 'rejected' AND created_at BETWEEN ? AND ?", $pdt)->fetchColumn();
$R['services'] = q('SELECT service_type, COUNT(*) n FROM appointments WHERE created_at BETWEEN ? AND ? GROUP BY service_type ORDER BY n DESC', $pdt)->fetchAll();

// ----- Feedback -----
$fb = safe_count('SELECT COUNT(*) FROM feedback WHERE created_at BETWEEN ? AND ?', $pdt);
$R['feedback'] = $fb ? q('SELECT category, COUNT(*) n, ROUND(AVG(rating), 1) avg_rating FROM feedback WHERE created_at BETWEEN ? AND ? GROUP BY category ORDER BY n DESC', $pdt)->fetchAll() : [];
$fbAvg = $fb ? (float)q('SELECT AVG(rating) FROM feedback WHERE created_at BETWEEN ? AND ?', $pdt)->fetchColumn() : 0;

// ----- CSV export of one section -----
$export = get('export');
if ($export !== '' && array_key_exists($export, REPORT_SECTIONS)) {
    log_activity('EXPORT', null, null, 'Report: ' . REPORT_SECTIONS[$export] . " ($from to $to)");
    $file = 'bhsms_' . $export . "_{$from}_{$to}.csv";
    switch ($export) {
        case 'summary':
            $rows = [];
            foreach ($R['summary'] as $label => $vals) { $rows[] = array_merge([$label], array_values($vals), [array_sum($vals)]); }
            send_csv($file, array_merge(['Indicator'], array_values($months), ['Total']), $rows);
        case 'population':
            send_csv($file, ['Age group', 'Male', 'Female', 'Total'], array_map(function ($r) { return [$r['age_group'], $r['male'], $r['female'], $r['total']]; }, $R['population']));
        case 'consultations':
            send_csv($file, ['Chief complaint', 'Count'], array_map(function ($r) { return [$r['complaint'], $r['n']]; }, $R['complaints']));
        case 'vaccinations':
            send_csv($file, ['Vaccine', 'Doses given', 'Residents vaccinated'], array_map(function ($r) { return [$r['vaccine_name'], $r['doses'], $r['residents']]; }, $R['vaccines']));
        case 'maternal':
            send_csv($file, ['Indicator', 'Value'], [['Pregnancies registered', $mat['registered']], ['Prenatal visits', $mat['visits']], ['Deliveries', $mat['deliveries']],
                ['Ongoing pregnancies (today)', $mat['ongoing']], ['High-risk (today)', $mat['high_risk']], ['Ongoing with 4+ prenatal visits', $mat['four_anc']], ['Child check-ups', $mat['checkups']]]);
        case 'medicines':
            send_csv($file, ['Medicine', 'Units given', 'Unit', 'Residents served'], array_map(function ($r) { return [trim($r['generic_name'] . ' ' . $r['strength'] . ' ' . $r['dosage_form']), $r['units'], $r['unit'], $r['residents']]; }, $R['medicines']));
        case 'appointments':
            send_csv($file, ['Status', 'Count'], array_map(function ($r) { return [$r['status'], $r['n']]; }, $R['appointments']));
        default:
            send_csv($file, ['Category', 'Feedback count', 'Average rating'], array_map(function ($r) { return [$r['category'], $r['n'], $r['avg_rating']]; }, $R['feedback']));
    }
}

/** Canvas + data for a Chart.js chart (the tables below each chart still work offline). */
function chart(string $id, string $type, array $labels, array $datasets, bool $stacked = false): string
{
    $palette = ['#0f766e', '#2563eb', '#d97706', '#7c3aed', '#dc2626', '#16a34a', '#0891b2', '#64748b'];
    foreach ($datasets as $i => &$d) {
        $c = $palette[$i % count($palette)];
        $d += ['backgroundColor' => in_array($type, ['doughnut', 'pie'], true) ? array_slice(array_merge($palette, $palette), 0, count($labels)) : $c, 'borderColor' => $c, 'borderWidth' => $type === 'line' ? 2 : 0, 'tension' => .3];
    }
    unset($d);
    $cfg = ['type' => $type, 'data' => ['labels' => array_values($labels), 'datasets' => $datasets],
            'options' => ['responsive' => true, 'maintainAspectRatio' => false, 'plugins' => ['legend' => ['display' => count($datasets) > 1 || in_array($type, ['doughnut', 'pie'], true), 'position' => 'bottom']],
                          'scales' => in_array($type, ['doughnut', 'pie'], true) ? new stdClass() : ['x' => ['stacked' => $stacked], 'y' => ['stacked' => $stacked, 'beginAtZero' => true, 'ticks' => ['precision' => 0]]]]];
    return '<div class="chart-box" style="height:260px"><canvas id="' . e($id) . '"></canvas></div>'
        . '<script>if (window.Chart) { new Chart(document.getElementById(' . json_encode($id) . '), ' . json_encode($cfg, JSON_HEX_TAG | JSON_HEX_AMP) . '); }</script>';
}
function export_link(string $s): string
{
    $q = $_GET;
    $q['export'] = $s;
    return '<a class="btn btn-sm no-print" href="?' . e(http_build_query($q)) . '">Export CSV</a>';
}

$use_charts = true;
$page_title = 'Reports & Analytics';
require __DIR__ . '/../../includes/header.php';
?>
<div class="card no-print">
    <form class="toolbar" method="get">
        <div><label>From</label><input type="date" name="from" value="<?= e($from) ?>" max="<?= today() ?>"></div>
        <div><label>To</label><input type="date" name="to" value="<?= e($to) ?>" max="<?= today() ?>"></div>
        <div class="grow"><label>Report</label><select name="section"><?= options(REPORT_SECTIONS, $section, 'All reports') ?></select></div>
        <button class="btn btn-primary">Generate</button>
        <a class="btn" href="?from=<?= date('Y-m-01') ?>&amp;to=<?= today() ?>">This month</a>
        <a class="btn" href="?from=<?= date('Y-01-01') ?>&amp;to=<?= today() ?>">This year</a>
        <a class="btn" href="?from=<?= date('Y-m-d', strtotime('-5 years')) ?>&amp;to=<?= today() ?>">Last 5 years</a>
        <button class="btn" type="button" data-print>Print / Save as PDF</button>
    </form>
</div>
<div class="alert alert-info">Report period: <strong><?= fmt_date($from) ?> – <?= fmt_date($to) ?></strong>. Generated <?= fmt_datetime(date('Y-m-d H:i:s')) ?> by <?= e(current_user()['full_name']) ?>. All figures are computed live from the records.</div>

<?php if ($show('summary')): ?>
<div class="card">
    <div class="card-header"><h3>Monthly service summary</h3><?= export_link('summary') ?></div>
    <?= chart('ch_summary', 'bar', $months, [
        ['label' => 'Consultations', 'data' => array_values($R['summary']['Consultations'])],
        ['label' => 'Vaccine doses', 'data' => array_values($R['summary']['Vaccine doses given'])],
        ['label' => 'Prenatal visits', 'data' => array_values($R['summary']['Prenatal visits'])],
        ['label' => 'Child check-ups', 'data' => array_values($R['summary']['Child check-ups'])],
    ]) ?>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Indicator</th><?php foreach ($months as $label): ?><th class="num"><?= e($label) ?></th><?php endforeach; ?><th class="num">Total</th></tr></thead>
        <tbody>
        <?php foreach ($R['summary'] as $label => $vals): ?>
            <tr><td><?= e($label) ?></td><?php foreach ($vals as $v): ?><td class="num"><?= (int)$v ?></td><?php endforeach; ?><td class="num"><strong><?= (int)array_sum($vals) ?></strong></td></tr>
        <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php endif; ?>

<?php if ($show('population')): ?>
<div class="card">
    <div class="card-header"><h3>Population (active residents, as of today)</h3><?= export_link('population') ?></div>
    <div class="stats">
        <div class="stat"><div class="label">Residents</div><div class="value"><?= (int)$pop['total'] ?></div></div>
        <div class="stat blue"><div class="label">Households</div><div class="value"><?= (int)$pop['households'] ?></div></div>
        <div class="stat purple"><div class="label">Senior citizens (60+)</div><div class="value"><?= (int)$pop['seniors'] ?></div></div>
        <div class="stat"><div class="label">Women 15–49 yrs</div><div class="value"><?= (int)$pop['wra'] ?></div></div>
        <div class="stat amber"><div class="label">PWD / 4Ps</div><div class="value"><?= (int)$pop['pwd'] ?> / <?= (int)$pop['fourps'] ?></div></div>
    </div>
    <div class="grid cols-2">
        <?= chart('ch_pop', 'bar', array_column($R['population'], 'age_group'), [
            ['label' => 'Male', 'data' => array_map('intval', array_column($R['population'], 'male'))],
            ['label' => 'Female', 'data' => array_map('intval', array_column($R['population'], 'female'))]], true) ?>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Age group</th><th class="num">Male</th><th class="num">Female</th><th class="num">Total</th></tr></thead>
            <tbody>
            <?php foreach ($R['population'] as $r): ?><tr><td><?= e($r['age_group']) ?></td><td class="num"><?= (int)$r['male'] ?></td><td class="num"><?= (int)$r['female'] ?></td><td class="num"><strong><?= (int)$r['total'] ?></strong></td></tr><?php endforeach; ?>
            <?php foreach ($byPurok as $r): ?><tr class="row-muted"><td colspan="3"><?= e($r['purok']) ?></td><td class="num"><?= (int)$r['n'] ?></td></tr><?php endforeach; ?>
            </tbody>
        </table></div>
    </div>
</div>
<?php endif; ?>

<?php if ($show('consultations')): ?>
<div class="card">
    <div class="card-header"><h3>Consultations</h3><?= export_link('consultations') ?></div>
    <div class="stats">
        <div class="stat"><div class="label">Total</div><div class="value"><?= (int)$cons['total'] ?></div></div>
        <div class="stat blue"><div class="label">Completed</div><div class="value"><?= (int)$cons['completed'] ?></div></div>
        <div class="stat purple"><div class="label">Referred</div><div class="value"><?= (int)$cons['referred'] ?></div></div>
        <div class="stat amber"><div class="label">Still open</div><div class="value"><?= (int)$cons['open_'] ?></div></div>
    </div>
    <div class="grid cols-2">
        <?= chart('ch_complaints', 'bar', array_column($R['complaints'], 'complaint'), [['label' => 'Patients', 'data' => array_map('intval', array_column($R['complaints'], 'n'))]]) ?>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Top chief complaints</th><th class="num">Count</th></tr></thead>
            <tbody>
            <?php foreach ($R['complaints'] as $r): ?><tr><td><?= e(ucfirst($r['complaint'])) ?></td><td class="num"><?= (int)$r['n'] ?></td></tr><?php endforeach; ?>
            <?php if (!$R['complaints']): ?><tr><td colspan="2" class="empty">No consultations in this period.</td></tr><?php endif; ?>
            </tbody>
        </table>
        <table class="table">
            <thead><tr><th>Top assessments (morbidity)</th><th class="num">Count</th></tr></thead>
            <tbody><?php foreach ($R['diagnoses'] as $r): ?><tr><td><?= e($r['assessment']) ?></td><td class="num"><?= (int)$r['n'] ?></td></tr><?php endforeach; ?></tbody>
        </table></div>
    </div>
</div>
<?php endif; ?>

<?php if ($show('vaccinations')): ?>
<div class="card">
    <div class="card-header"><h3>Immunization</h3><?= export_link('vaccinations') ?></div>
    <div class="stats">
        <div class="stat"><div class="label">Doses given</div><div class="value"><?= array_sum(array_map('intval', array_column($R['vaccines'], 'doses'))) ?></div></div>
        <div class="stat blue"><div class="label">Fully immunized (12–23 mos)</div><div class="value"><?= (int)$fic['fully'] ?> <small>/ <?= (int)$fic['children'] ?></small></div>
            <div class="sub"><?= $fic['children'] ? round($fic['fully'] / $fic['children'] * 100) . '% FIC rate' : 'No children 12–23 months' ?></div></div>
        <div class="stat <?= $overdueVacc ? 'red' : '' ?>"><div class="label">Overdue doses (today)</div><div class="value"><?= $overdueVacc ?></div></div>
    </div>
    <div class="grid cols-2">
        <?= chart('ch_vacc', 'bar', array_column($R['vaccines'], 'vaccine_name'), [['label' => 'Doses', 'data' => array_map('intval', array_column($R['vaccines'], 'doses'))]]) ?>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Vaccine</th><th class="num">Doses given</th><th class="num">Residents</th></tr></thead>
            <tbody><?php foreach ($R['vaccines'] as $r): ?><tr><td><?= e($r['vaccine_name']) ?></td><td class="num"><?= (int)$r['doses'] ?></td><td class="num"><?= (int)$r['residents'] ?></td></tr><?php endforeach; ?></tbody>
        </table></div>
    </div>
    <p class="hint">Fully immunized child = BCG, 3 doses Pentavalent, 3 doses OPV and at least 1 dose MMR, for children now 12–23 months old.</p>
</div>
<?php endif; ?>

<?php if ($show('maternal')): ?>
<div class="card">
    <div class="card-header"><h3>Maternal &amp; child health</h3><?= export_link('maternal') ?></div>
    <div class="stats">
        <div class="stat purple"><div class="label">Pregnancies registered</div><div class="value"><?= (int)$mat['registered'] ?></div></div>
        <div class="stat"><div class="label">Prenatal visits</div><div class="value"><?= (int)$mat['visits'] ?></div></div>
        <div class="stat blue"><div class="label">Deliveries</div><div class="value"><?= (int)$mat['deliveries'] ?></div></div>
        <div class="stat <?= $mat['high_risk'] ? 'red' : '' ?>"><div class="label">High-risk (ongoing)</div><div class="value"><?= (int)$mat['high_risk'] ?> <small>/ <?= (int)$mat['ongoing'] ?></small></div></div>
        <div class="stat"><div class="label">Ongoing with 4+ prenatal visits</div><div class="value"><?= (int)$mat['four_anc'] ?></div></div>
        <div class="stat amber"><div class="label">Child check-ups</div><div class="value"><?= (int)$mat['checkups'] ?></div></div>
    </div>
    <div class="grid cols-2">
        <?= chart('ch_nutri', 'doughnut', array_column($R['nutrition'], 'status'), [['label' => 'Children', 'data' => array_map('intval', array_column($R['nutrition'], 'n'))]]) ?>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Nutrition status (children 0–59 mos, latest)</th><th class="num">Children</th></tr></thead>
            <tbody><?php foreach ($R['nutrition'] as $r): ?><tr><td><?= $r['status'] === 'Not yet assessed' ? e($r['status']) : badge($r['status']) ?></td><td class="num"><?= (int)$r['n'] ?></td></tr><?php endforeach; ?></tbody>
        </table></div>
    </div>
</div>
<?php endif; ?>

<?php if ($show('medicines')): ?>
<div class="card">
    <div class="card-header"><h3>Medicine distribution</h3><?= export_link('medicines') ?></div>
    <div class="stats">
        <div class="stat"><div class="label">Units given</div><div class="value"><?= array_sum(array_map('intval', array_column($R['medicines'], 'units'))) ?></div></div>
        <div class="stat amber"><div class="label">Low stock (today)</div><div class="value"><?= (int)$stock['low'] ?></div></div>
        <div class="stat <?= $stock['out_'] ? 'red' : '' ?>"><div class="label">Out of stock (today)</div><div class="value"><?= (int)$stock['out_'] ?></div></div>
    </div>
    <div class="grid cols-2">
        <?= chart('ch_meds', 'bar', array_map(function ($r) { return $r['generic_name'] . ' ' . $r['strength']; }, $R['medicines']), [['label' => 'Units', 'data' => array_map('intval', array_column($R['medicines'], 'units'))]]) ?>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Medicine</th><th class="num">Units given</th><th class="num">Residents</th></tr></thead>
            <tbody>
            <?php foreach ($R['medicines'] as $r): ?><tr><td><?= e($r['generic_name']) ?> <span class="small muted"><?= e($r['strength']) ?> <?= e($r['dosage_form']) ?></span></td><td class="num"><?= (int)$r['units'] ?> <?= e($r['unit']) ?></td><td class="num"><?= (int)$r['residents'] ?></td></tr><?php endforeach; ?>
            <?php if (!$R['medicines']): ?><tr><td colspan="3" class="empty">No medicines given in this period.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>
</div>
<?php endif; ?>

<?php if ($show('appointments')): ?>
<div class="card">
    <div class="card-header"><h3>Appointments (requested in this period)</h3><?= export_link('appointments') ?></div>
    <div class="grid cols-2">
        <?= chart('ch_appt', 'doughnut', array_map('ucfirst', array_column($R['appointments'], 'status')), [['label' => 'Requests', 'data' => array_map('intval', array_column($R['appointments'], 'n'))]]) ?>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Status</th><th class="num">Count</th></tr></thead>
            <tbody>
            <?php foreach ($R['appointments'] as $r): ?><tr><td><?= badge($r['status']) ?></td><td class="num"><?= (int)$r['n'] ?></td></tr><?php endforeach; ?>
            <?php foreach ($R['services'] as $r): ?><tr class="row-muted"><td><?= e($r['service_type']) ?></td><td class="num"><?= (int)$r['n'] ?></td></tr><?php endforeach; ?>
            <?php if (!$R['appointments']): ?><tr><td colspan="2" class="empty">No requests in this period.</td></tr><?php endif; ?>
            </tbody>
        </table>
        <p class="hint">Average time from request to approval: <strong><?= $apptTime !== null && $apptTime !== false ? round((float)$apptTime) . ' hours' : '—' ?></strong></p></div>
    </div>
</div>
<?php endif; ?>

<?php if ($show('feedback')): ?>
<div class="card">
    <div class="card-header"><h3>Feedback &amp; ratings</h3><?= export_link('feedback') ?></div>
    <div class="stats">
        <div class="stat"><div class="label">Feedback received</div><div class="value"><?= $fb ?></div></div>
        <div class="stat blue"><div class="label">Average rating</div><div class="value"><?= $fb ? number_format($fbAvg, 1) : '—' ?> <small>/ 5</small></div><div class="sub"><?= stars($fbAvg) ?></div></div>
    </div>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Category</th><th class="num">Count</th><th>Average rating</th></tr></thead>
        <tbody>
        <?php foreach ($R['feedback'] as $r): ?><tr><td><?= e($r['category']) ?></td><td class="num"><?= (int)$r['n'] ?></td><td><?= e($r['avg_rating']) ?> <?= stars($r['avg_rating']) ?></td></tr><?php endforeach; ?>
        <?php if (!$R['feedback']): ?><tr><td colspan="3" class="empty">No feedback in this period.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
