<?php
/* STAFF login (Admin, BHW, Nurse, Municipal Health Officer). Residents log in on the homepage (index.php). */
require __DIR__ . '/includes/init.php';

if (current_user()) {
    redirect(home_path());
}

$error = '';
$username = '';

if (is_post()) {
    $username = input('username');
    $error = attempt_login($username, (string)($_POST['password'] ?? ''), STAFF,
        'This login is for health center staff only. Residents, please log in on the resident homepage.');
    if ($error === null) {
        redirect(home_path());
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Staff Login | <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
    <?php require __DIR__ . '/includes/head_fx.php'; ?>
</head>
<body class="entering">
<div class="fx-backdrop" aria-hidden="true"><span></span><span></span><span></span></div>
<div class="login-page">
    <div class="login-card">
        <div class="brand-logo">+</div>
        <h1><?= e(APP_NAME) ?> Staff Portal</h1>
        <p class="sub">For Administrators, Health Workers, Nurses, the Municipal Health Officer, HR and the Nutrition Action Officer</p>

        <?= render_flash() ?>
        <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>

        <form method="post" autocomplete="off">
            <?= csrf_field() ?>
            <?= field('Username', 'username', $username, 'text', 'required autofocus') ?>
            <?= field('Password', 'password', '', 'password', 'required') ?>
            <button class="btn btn-primary" type="submit">Log in</button>
        </form>

        <p class="small" style="text-align:center;margin-top:16px">New staff member? <a href="<?= e(url('staff_register.php')) ?>">Register a staff account</a><br>
            Are you a resident? <a href="<?= e(url('index.php')) ?>">Go to the resident homepage</a></p>

        <?php if (DEMO_MODE): ?>
            <div class="demo-box">
                <strong>Sample staff accounts</strong> (password: <code>password123</code>)<br>
                admin &middot; bhw_maria &middot; nurse_ana &middot; mho_reyes &middot; hr_luz &middot; nao_ben<br>
                Waiting for admin approval: bhw_jose &middot; nurse_carla
            </div>
        <?php endif; ?>
    </div>
</div>
<?php require __DIR__ . '/includes/fx.php'; ?>
<script src="<?= e(url('assets/js/app.js')) ?>"></script>
</body>
</html>
