        </main>
        <footer class="site-footer no-print">&copy; <?= date('Y') ?> <?= e(APP_FULL_NAME) ?></footer>
    </div>
</div>
<?php require __DIR__ . '/fx.php'; ?>
<script src="<?= e(url('assets/js/app.js')) ?>"></script>
</body>
</html>
