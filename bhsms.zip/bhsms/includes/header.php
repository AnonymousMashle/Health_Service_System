<?php
/*
 * Page layout (top). Before including, a page may set:
 *   $page_title  - text shown in the top bar
 *   $page_kicker - small text above the title (defaults to the menu section)
 *   $back_url    - where the Back button goes (false = no Back button). Defaults to the parent page.
 *   $use_charts  - true to load Chart.js
 *
 * IMPORTANT: every variable in this file starts with $_ so it never overwrites a variable of the page
 * that includes it. (The old version used $u, which replaced the user being edited in admin/user_form.php
 * with the logged-in admin.)
 */
$_me = current_user();
$page_title = $page_title ?? APP_NAME;
$_unread = $_me ? (int)q('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0', [$_me['user_id']])->fetchColumn() : 0;

// Sidebar menu for the current role: [label, path, badge count, icon]
$_menu = [];
if ($_me) {
    if ($_me['role'] === 'resident') {
        $_menu['My Health'] = [
            ['My Health Records', 'portal/index.php', 0, 'heart'],
            ['My Appointments', 'portal/appointments.php', 0, 'calendar'],
            ['Feedback', 'portal/feedback.php', 0, 'star'],
            ['Announcements', 'portal/index.php#news', 0, 'bell'],
        ];
    } else {
        if (in_array($_me['role'], HEALTH_STAFF, true)) {
            $_menu['Main'] = [['Dashboard', 'dashboard.php', 0, 'grid']];
        }
        $_sec = [];
        if (can('residents')) {
            $_sec[] = ['Residents', 'modules/residents/index.php', 0, 'users'];
            $_sec[] = ['Households', 'modules/residents/households.php', 0, 'home'];
        }
        if (can('residents', 'edit')) {
            $_pendingRegs = (int)q("SELECT COUNT(*) FROM users WHERE role = 'resident' AND status = 'pending'")->fetchColumn();
            $_sec[] = ['Account Verification', 'modules/residents/registrations.php', $_pendingRegs, 'check'];
        }
        if (can('consultations')) {
            $_sec[] = ['Consultations', 'modules/consultations/index.php', 0, 'pulse'];
        }
        if (can('vaccinations')) {
            $_sec[] = ['Vaccinations', 'modules/vaccinations/index.php', 0, 'shield'];
        }
        if (can('maternal')) {
            $_sec[] = ['Maternal Health', 'modules/maternal/index.php', 0, 'heart'];
            $_sec[] = ['Child Health', 'modules/maternal/children.php', 0, 'star'];
            $_sec[] = ['Scheduled Visits', 'modules/maternal/schedules.php', 0, 'calendar'];
        }
        $_menu['Health Services'] = $_sec;

        $_nut = [];
        if (can('nutrition')) {
            $_nut[] = ['Nutrition Dashboard', 'modules/nutrition/index.php', 0, 'apple'];
            $_nut[] = ['Operation Timbang (OPT+)', 'modules/nutrition/opt.php', 0, 'scale'];
            $_nut[] = ['Feeding Programs', 'modules/nutrition/programs.php', 0, 'bowl'];
            $_nut[] = ['Micronutrients', 'modules/nutrition/supplements.php', 0, 'pill'];
        }
        $_menu['Nutrition'] = $_nut;

        $_hr = [];
        if (can('hr')) {
            $_pendingLeave = safe_count("SELECT COUNT(*) FROM leave_requests WHERE status = 'pending'");
            $_hr[] = ['HR Dashboard', 'modules/hr/index.php', 0, 'briefcase'];
            $_hr[] = ['Personnel (201 Files)', 'modules/hr/personnel.php', 0, 'id'];
            $_hr[] = ['Attendance', 'modules/hr/attendance.php', 0, 'clock'];
            $_hr[] = ['Leave Requests', 'modules/hr/leaves.php', can('hr', 'approve') ? $_pendingLeave : 0, 'plane'];
            $_hr[] = ['Trainings', 'modules/hr/trainings.php', 0, 'award'];
        }
        if (can('hr', 'file_leave') && !can('hr', 'approve')) {
            $_hr[] = ['My Leave', 'modules/hr/my_leave.php', 0, 'plane'];
        }
        $_menu['Human Resource'] = $_hr;

        $_ops = [];
        if (can('inventory')) {
            $_ops[] = ['Medicine Inventory', 'modules/inventory/index.php', 0, 'box'];
        }
        if (can('appointments')) {
            $_ops[] = ['Appointments', 'modules/appointments/index.php', pending_appointments_count(), 'calendar'];
        }
        if (can('reports')) {
            $_ops[] = ['Reports & Analytics', 'modules/reports/index.php', 0, 'chart'];
        }
        $_menu['Operations'] = $_ops;

        $_pub = [];
        if (can('announcements')) {
            $_pub[] = ['Announcements', 'modules/announcements/index.php', 0, 'bell'];
        }
        if (can('feedback')) {
            $_pub[] = ['Resident Feedback', 'modules/feedback/index.php', safe_count("SELECT COUNT(*) FROM feedback WHERE status = 'pending'"), 'star'];
        }
        $_menu['Public Engagement'] = $_pub;

        if (can('users')) {
            $_pendingStaff = (int)q("SELECT COUNT(*) FROM users WHERE status = 'pending' AND role IN ('bhw', 'nurse', 'hr', 'nao')")->fetchColumn();
            $_menu['Administration'] = [
                ['Staff Approvals', 'admin/staff_approvals.php', $_pendingStaff, 'check'],
                ['User Accounts', 'admin/users.php', 0, 'key'],
                ['Activity Logs', 'admin/logs.php', 0, 'list'],
            ];
        }
    }
    $_menu['Account'] = [
        ['Notifications', 'notifications.php', $_unread, 'bell'],
        ['My Account', 'profile.php', 0, 'user'],
        ['Log out', 'logout.php', 0, 'power'],
    ];
}

// Hide links to modules that are not in this copy yet (e.g. a groupmate has not pushed that module)
foreach ($_menu as $_section => $_items) {
    $_menu[$_section] = array_values(array_filter($_items, function ($it) {
        return page_exists($it[1]);
    }));
}

// Highlight the menu item for this page (exact file first, otherwise same folder)
$_script = $_SERVER['SCRIPT_NAME'] ?? '';
$_activePath = $nav_active ?? null;          // a page may say which menu item it belongs to
$_activeSection = null;
foreach ($_menu as $_section => $_items) {
    foreach ($_items as $_it) {
        if ($_activePath !== null && $_it[1] === $_activePath) {
            $_activeSection = $_section;
        }
    }
}
foreach ($_menu as $_section => $_items) {
    if ($_activeSection !== null) {
        break;
    }
    foreach ($_items as $_it) {
        if (substr($_script, -strlen('/' . $_it[1])) === '/' . $_it[1]) {
            $_activePath = $_it[1];
            $_activeSection = $_section;
        }
    }
}
if ($_activePath === null) {
    foreach ($_menu as $_section => $_items) {
        foreach ($_items as $_it) {
            $_dir = dirname($_it[1]);
            if ($_activePath === null && $_dir !== '.' && strpos($_script, '/' . $_dir . '/') !== false) {
                $_activePath = $_it[1];
                $_activeSection = $_section;
            }
        }
    }
}

$_back = isset($back_url) ? $back_url : ($_me ? default_back_url() : null);
if ($_back && !preg_match('#^(https?://|/)#', $_back)) {
    $_back = url($_back);
}
$_kicker = $page_kicker ?? ($_activeSection ?: BARANGAY_NAME);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($page_title) ?> | <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= e(asset('assets/css/style.css')) ?>">
    <?php if (!empty($use_charts)): ?>
        <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <?php endif; ?>
    <?php require __DIR__ . '/head_fx.php'; ?>
</head>
<body class="app entering">
<div class="fx-backdrop" aria-hidden="true"><span></span><span></span><span></span></div>
<div class="layout">
    <aside class="sidebar" id="sidebar" data-lens-fixed>
        <div class="brand">
            <div class="brand-logo"><span>+</span></div>
            <div><strong><?= e(APP_NAME) ?></strong><small><?= e(BARANGAY_NAME) ?></small></div>
            <button class="sidebar-close" type="button" data-toggle-sidebar aria-label="Close menu">&times;</button>
        </div>
        <nav>
            <?php foreach ($_menu as $_section => $_items): if (!$_items) continue; ?>
                <div class="nav-section"><?= e($_section) ?></div>
                <?php foreach ($_items as $_it): ?>
                    <a href="<?= e(url($_it[1])) ?>" class="<?= $_it[1] === $_activePath ? 'active' : '' ?>">
                        <?= nav_icon($_it[3] ?? '') ?>
                        <span class="nav-label"><?= e($_it[0]) ?></span>
                        <?php if (!empty($_it[2])): ?><span class="nav-count"><?= (int)$_it[2] ?></span><?php endif; ?>
                    </a>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </nav>
    </aside>
    <div class="sidebar-scrim" data-toggle-sidebar></div>

    <div class="main">
        <header class="topbar" data-lens-fixed>
            <button class="menu-toggle" type="button" data-toggle-sidebar aria-label="Menu"><span></span><span></span><span></span></button>
            <?php if ($_back): ?>
                <a class="back-btn" href="<?= e($_back) ?>" data-back title="Back (Esc)">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg><span>Back</span>
                </a>
            <?php endif; ?>
            <div class="title-block">
                <small><?= e($_kicker) ?></small>
                <h1><?= e($page_title) ?></h1>
            </div>
            <?php if ($_me): ?>
                <div class="topbar-user">
                    <button class="icon-btn" type="button" data-lens-toggle title="Magnifier lens on/off (press L)" aria-pressed="true">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m15.5 15.5 5 5M8 10.5h5M10.5 8v5"/></svg>
                    </button>
                    <a class="icon-btn bell" href="<?= e(url('notifications.php')) ?>" title="Notifications">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 20a2 2 0 0 0 4 0"/></svg>
                        <?php if ($_unread): ?><span class="nav-count"><?= $_unread ?></span><?php endif; ?>
                    </a>
                    <a class="who" href="<?= e(url('profile.php')) ?>">
                        <span class="avatar"><?= e(strtoupper(substr($_me['full_name'], 0, 1))) ?></span>
                        <span><strong><?= e($_me['full_name']) ?></strong>
                        <small><?= e(ROLE_LABELS[$_me['role']] ?? $_me['role']) ?></small></span>
                    </a>
                </div>
            <?php endif; ?>
        </header>
        <main class="content" id="page">
            <?= render_flash() ?>
