<?php
/* Element used by the magnifier effect in assets/js/app.js. Included at the bottom of every page. */
?>
<div class="lens" id="lens" aria-hidden="true">
    <div class="lens-view"><div class="lens-stage"></div></div>
</div>
