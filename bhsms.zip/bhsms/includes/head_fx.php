<?php /* (kept for older pages that include it; the page transition no longer needs anything in <head>) */ ?>
