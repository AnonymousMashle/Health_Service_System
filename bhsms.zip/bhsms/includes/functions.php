<?php
/* =========================================================
   Helper functions used by every page
   ========================================================= */

/* ---------- Output & navigation ---------- */

/** Escape output (prevents XSS). Use on EVERYTHING printed from the database or user input. */
function e($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function url(string $path = ''): string
{
    return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
}

function redirect(string $path): void
{
    header('Location: ' . (preg_match('#^(https?://|/)#', $path) ? $path : url($path)));
    exit;
}

/** True if a page exists in this copy (modules made by groupmates may not be pushed yet). */
function page_exists(string $path): bool
{
    return file_exists(__DIR__ . '/../' . explode('?', $path)[0]);
}

/**
 * Where the Back / Close button goes when there is no browser history to return to.
 * A page can set $back_url before including header.php; otherwise this guesses the parent page:
 * form/view pages go to their module's list, module lists go to the role's home page.
 */
function default_back_url(): ?string
{
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    $base = rtrim(BASE_URL, '/') . '/';
    $rel = strpos($script, $base) === 0 ? substr($script, strlen($base)) : ltrim($script, '/');
    if ($rel === home_path() || $rel === 'dashboard.php') {
        return null;
    }
    $dir = dirname($rel);
    if ($dir !== '.' && basename($rel) !== 'index.php' && page_exists($dir . '/index.php')) {
        return url($dir . '/index.php');
    }
    return url(home_path());
}

/** Hidden field that remembers the current page, so an action can return here. */
function back_field(): string
{
    return '<input type="hidden" name="back" value="' . e($_SERVER['REQUEST_URI'] ?? '') . '">';
}

/** Page to return to after a POST action (only pages inside this app are allowed). */
function back_url(string $fallback): string
{
    $back = $_POST['back'] ?? '';
    return (is_string($back) && strpos($back, rtrim(BASE_URL, '/') . '/') === 0) ? $back : url($fallback);
}

/* ---------- Flash messages ---------- */

function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = [$type, $message];
}

function render_flash(): string
{
    $html = '';
    foreach ($_SESSION['flash'] ?? [] as $f) {
        $html .= '<div class="alert alert-' . e($f[0]) . '">' . e($f[1]) . '</div>';
    }
    unset($_SESSION['flash']);
    return $html;
}

function render_errors(array $errors): string
{
    if (!$errors) {
        return '';
    }
    $items = '';
    foreach ($errors as $err) {
        $items .= '<li>' . e($err) . '</li>';
    }
    return '<div class="alert alert-danger"><strong>Please fix the following:</strong><ul>' . $items . '</ul></div>';
}

/* ---------- Request input & CSRF ---------- */

/** True on a POST request; also checks the CSRF token. */
function is_post(): bool
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        return false;
    }
    verify_csrf();
    return true;
}

function input(string $key, $default = '')
{
    $v = $_POST[$key] ?? $default;
    return is_string($v) ? trim($v) : $v;
}

function get(string $key, $default = '')
{
    $v = $_GET[$key] ?? $default;
    return is_string($v) ? trim($v) : $default;
}

/** Empty string -> NULL (for optional database columns). */
function nullable($v)
{
    return ($v === '' || $v === null) ? null : $v;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . csrf_token() . '">';
}

function verify_csrf(): void
{
    if (!hash_equals($_SESSION['csrf'] ?? '', (string)($_POST['csrf'] ?? ''))) {
        http_response_code(400);
        exit('Your session expired or the form is invalid. Go back, refresh the page and try again.');
    }
}

/* ---------- Database helpers ---------- */

/** Insert an associative array into a table. Column names come from code, never from users. */
function db_insert(string $table, array $data): int
{
    $cols = implode(', ', array_keys($data));
    $ph   = implode(', ', array_fill(0, count($data), '?'));
    q("INSERT INTO $table ($cols) VALUES ($ph)", array_values($data));
    return (int)db()->lastInsertId();
}

function db_update(string $table, array $data, string $keyCol, $keyVal): void
{
    $set = implode(', ', array_map(function ($c) { return "$c = ?"; }, array_keys($data)));
    $values = array_values($data);
    $values[] = $keyVal;
    q("UPDATE $table SET $set WHERE $keyCol = ?", $values);
}

function is_duplicate_error(PDOException $e): bool
{
    return (int)($e->errorInfo[1] ?? 0) === 1062;
}

function is_fk_error(PDOException $e): bool
{
    return in_array((int)($e->errorInfo[1] ?? 0), [1451, 1452], true);
}

/* ---------- Audit log & notifications ---------- */

function log_activity(string $action, ?string $table = null, $recordId = null, string $details = ''): void
{
    q(
        'INSERT INTO activity_logs (user_id, action, table_name, record_id, details, ip_address) VALUES (?, ?, ?, ?, ?, ?)',
        [user_id(), $action, $table, $recordId, mb_substr($details, 0, 255), $_SERVER['REMOTE_ADDR'] ?? null]
    );
}

function notify(int $userId, string $title, string $message, ?string $link = null, bool $skipIfUnreadSame = false): void
{
    if ($skipIfUnreadSame) {
        $exists = q('SELECT 1 FROM notifications WHERE user_id = ? AND is_read = 0 AND title = ? AND message = ?', [$userId, $title, $message])->fetchColumn();
        if ($exists) {
            return;
        }
    }
    q('INSERT INTO notifications (user_id, title, message, link) VALUES (?, ?, ?, ?)', [$userId, $title, mb_substr($message, 0, 255), $link]);
}

function notify_roles(array $roles, string $title, string $message, ?string $link = null, bool $skipIfUnreadSame = false): void
{
    $in = implode(',', array_fill(0, count($roles), '?'));
    $ids = q("SELECT user_id FROM users WHERE status = 'active' AND role IN ($in)", $roles)->fetchAll(PDO::FETCH_COLUMN);
    foreach ($ids as $id) {
        notify((int)$id, $title, $message, $link, $skipIfUnreadSame);
    }
}

/** Notify the portal account of a resident (if they have one). */
function notify_resident(int $residentId, string $title, string $message, ?string $link = 'portal/index.php'): void
{
    $uid = q("SELECT user_id FROM users WHERE resident_id = ? AND status = 'active'", [$residentId])->fetchColumn();
    if ($uid) {
        notify((int)$uid, $title, $message, $link);
    }
}

/* ---------- Dates & ages ---------- */

function today(): string
{
    return date('Y-m-d');
}

function valid_date($d): bool
{
    if (!is_string($d) || $d === '') {
        return false;
    }
    $dt = DateTime::createFromFormat('Y-m-d', $d);
    return $dt && $dt->format('Y-m-d') === $d;
}

function fmt_date($d, string $format = 'M j, Y'): string
{
    return $d ? date($format, strtotime($d)) : '—';
}

function fmt_datetime($d): string
{
    return fmt_date($d, 'M j, Y g:i A');
}

function fmt_time($t): string
{
    return $t ? date('g:i A', strtotime($t)) : '—';
}

function age_years(?string $birthdate): int
{
    return $birthdate ? (new DateTime($birthdate))->diff(new DateTime('today'))->y : 0;
}

function age_months(?string $birthdate): int
{
    if (!$birthdate) {
        return 0;
    }
    $d = (new DateTime($birthdate))->diff(new DateTime('today'));
    return $d->y * 12 + $d->m;
}

/** "34 yrs", "8 mos", "12 days" */
function age_label(?string $birthdate): string
{
    if (!$birthdate) {
        return '';
    }
    $d = (new DateTime($birthdate))->diff(new DateTime('today'));
    if ($d->y >= 2) {
        return $d->y . ' yrs';
    }
    $months = $d->y * 12 + $d->m;
    if ($months >= 1) {
        return $months . ' mo' . ($months > 1 ? 's' : '');
    }
    return $d->days . ' day' . ($d->days == 1 ? '' : 's');
}

/** Age of gestation in weeks from the last menstrual period. */
function aog_weeks(?string $lmp, ?string $onDate = null): int
{
    if (!$lmp) {
        return 0;
    }
    $days = (new DateTime($lmp))->diff(new DateTime($onDate ?: 'today'))->days;
    return intdiv($days, 7);
}

/* ---------- Names & lookups ---------- */

function full_name(array $r): string
{
    $mi = !empty($r['middle_name']) ? ' ' . substr($r['middle_name'], 0, 1) . '.' : '';
    $suffix = !empty($r['suffix']) ? ' ' . $r['suffix'] : '';
    return $r['last_name'] . ', ' . $r['first_name'] . $mi . $suffix;
}

/** [resident_id => "Dela Cruz, Juan (41 yrs)"] for dropdowns. */
function resident_options(string $where = '1=1', array $params = []): array
{
    $rows = q("SELECT resident_id, first_name, middle_name, last_name, suffix, birthdate FROM residents
               WHERE status = 'active' AND ($where) ORDER BY last_name, first_name", $params)->fetchAll();
    $out = [];
    foreach ($rows as $r) {
        $out[$r['resident_id']] = full_name($r) . ' (' . age_label($r['birthdate']) . ')';
    }
    return $out;
}

/**
 * [household_id => "HH-2026-0001 — Head: Dela Cruz, Juan — 12 Pine St. (Purok 1)"] for dropdowns.
 * The household head is part of the label so staff can search a household by the head's name.
 */
function household_options(): array
{
    $out = [];
    $rows = q("SELECT h.household_id, h.household_no, h.street_address, h.purok,
                      hr.first_name, hr.middle_name, hr.last_name, hr.suffix,
                      (SELECT COUNT(*) FROM residents m WHERE m.household_id = h.household_id AND m.status IN ('active', 'pending')) AS members
               FROM households h LEFT JOIN residents hr ON hr.resident_id = h.head_resident_id
               ORDER BY h.household_no")->fetchAll();
    foreach ($rows as $h) {
        $head = $h['last_name'] ? 'Head: ' . full_name($h) : 'No head set';
        $out[$h['household_id']] = $h['household_no'] . ' — ' . $head . ' — ' . $h['street_address'] . ' (' . $h['purok'] . ')'
            . ' · ' . (int)$h['members'] . ' member' . ((int)$h['members'] === 1 ? '' : 's');
    }
    return $out;
}

/** Next household number: HH-<year>-0001 */
function next_household_no(): string
{
    $prefix = 'HH-' . date('Y') . '-';
    $last = q('SELECT MAX(household_no) FROM households WHERE household_no LIKE ?', [$prefix . '%'])->fetchColumn();
    $next = $last ? ((int)substr($last, -4)) + 1 : 1;
    return $prefix . str_pad((string)$next, 4, '0', STR_PAD_LEFT);
}

function create_household(string $street, string $purok): int
{
    $no = next_household_no();
    $id = db_insert('households', ['household_no' => $no, 'purok' => mb_substr($purok, 0, 50), 'street_address' => mb_substr($street, 0, 255), 'created_by' => user_id()]);
    log_activity('CREATE', 'households', $id, 'Added household ' . $no);
    return $id;
}

function staff_options(array $roles = ['bhw', 'nurse']): array
{
    $in = implode(',', array_fill(0, count($roles), '?'));
    $out = [];
    foreach (q("SELECT user_id, full_name, role FROM users WHERE status = 'active' AND role IN ($in) ORDER BY full_name", $roles)->fetchAll() as $u) {
        $out[$u['user_id']] = $u['full_name'] . ' (' . strtoupper($u['role']) . ')';
    }
    return $out;
}

/* ---------- Pagination ---------- */

function paginate(int $total, int $perPage = 15): array
{
    $pages = max(1, (int)ceil($total / $perPage));
    $page  = min($pages, max(1, (int)get('page', '1')));
    return ['page' => $page, 'pages' => $pages, 'per' => $perPage, 'offset' => ($page - 1) * $perPage, 'total' => $total];
}

function pagination_links(array $p): string
{
    if ($p['pages'] <= 1) {
        return '';
    }
    $qs = $_GET;
    $html = '<div class="pagination"><span class="muted small">' . $p['total'] . ' records</span>';
    for ($i = 1; $i <= $p['pages']; $i++) {
        if ($i != 1 && $i != $p['pages'] && abs($i - $p['page']) > 2) {
            if ($i == 2 || $i == $p['pages'] - 1) {
                $html .= '<span class="muted">…</span>';
            }
            continue;
        }
        $qs['page'] = $i;
        $html .= '<a class="' . ($i == $p['page'] ? 'active' : '') . '" href="?' . e(http_build_query($qs)) . '">' . $i . '</a>';
    }
    return $html . '</div>';
}

/* ---------- UI helpers ---------- */

/** COUNT query that returns 0 instead of crashing if a table is missing (e.g. an update SQL file was not imported yet). */
function safe_count(string $sql, array $params = []): int
{
    try {
        return (int)q($sql, $params)->fetchColumn();
    } catch (PDOException $e) {
        return 0;
    }
}

/** Small inline SVG icons for the menu (no icon font needed, works offline). */
function nav_icon(string $name): string
{
    $p = [
        'grid' => '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
        'users' => '<circle cx="9" cy="8" r="3.5"/><path d="M2 20c0-3.6 3.1-6 7-6s7 2.4 7 6"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18 14c2.4.6 4 2.6 4 6"/>',
        'home' => '<path d="M3 11 12 4l9 7"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
        'check' => '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
        'pulse' => '<path d="M3 12h4l2-6 4 12 2-6h6"/>',
        'shield' => '<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z"/><path d="M12 8v8M8 12h8"/>',
        'heart' => '<path d="M12 20s-8-4.6-8-10a4.5 4.5 0 0 1 8-2.8A4.5 4.5 0 0 1 20 10c0 5.4-8 10-8 10z"/>',
        'star' => '<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>',
        'calendar' => '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
        'apple' => '<path d="M12 7c-1-2-3-3-5-2-3 1.5-3.5 6-1.5 10S10 21 12 20c2 1 4.5 0 6.5-5S20 6.5 17 5c-2-1-4 0-5 2z"/><path d="M12 7c0-2 1-4 3-4"/>',
        'scale' => '<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M8 9a5 5 0 0 1 8 0"/><path d="m12 11 1.5-2.5"/>',
        'bowl' => '<path d="M3 11h18a9 9 0 0 1-18 0z"/><path d="M8 7c0-1.5 1-2 1-3.5M12 7c0-1.5 1-2 1-3.5M16 7c0-1.5 1-2 1-3.5"/>',
        'pill' => '<rect x="3" y="9" width="18" height="7" rx="3.5" transform="rotate(-35 12 12.5)"/><path d="m9.5 8.5 5 7"/>',
        'briefcase' => '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2M3 13h18"/>',
        'id' => '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2.5"/><path d="M5.5 17c.6-1.8 2-2.7 3.5-2.7s2.9.9 3.5 2.7M15 10h4M15 14h3"/>',
        'clock' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        'plane' => '<path d="M2 13l20-8-6 16-3-6z"/><path d="m13 15-4 4v-6"/>',
        'award' => '<circle cx="12" cy="9" r="6"/><path d="m8.5 14-1.5 7 5-3 5 3-1.5-7"/>',
        'box' => '<path d="M3 7.5 12 3l9 4.5v9L12 21l-9-4.5z"/><path d="M3 7.5 12 12l9-4.5M12 12v9"/>',
        'chart' => '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
        'key' => '<circle cx="8" cy="15" r="4"/><path d="m11 12 9-9M17 6l3 3M15 8l2 2"/>',
        'list' => '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
        'bell' => '<path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 20a2 2 0 0 0 4 0"/>',
        'user' => '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>',
        'power' => '<path d="M12 3v9"/><path d="M6.3 6.3a8 8 0 1 0 11.4 0"/>',
    ][$name] ?? '<circle cx="12" cy="12" r="3"/>';
    return '<svg class="ico" viewBox="0 0 24 24" aria-hidden="true">' . $p . '</svg>';
}


function badge(?string $status): string
{
    $colors = [
        'active' => 'green', 'completed' => 'green', 'complete' => 'green', 'done' => 'green', 'delivered' => 'green',
        'in stock' => 'green', 'normal' => 'green', 'low' => 'green', 'read' => 'gray',
        'approved' => 'blue', 'ongoing' => 'blue', 'scheduled' => 'blue',
        'pending' => 'amber', 'waiting' => 'amber', 'incomplete' => 'amber', 'low stock' => 'amber', 'moderate' => 'amber',
        'underweight' => 'amber', 'stunted' => 'amber', 'overweight' => 'amber', 'due soon' => 'amber',
        'rejected' => 'red', 'no-show' => 'red', 'missed' => 'red', 'out of stock' => 'red', 'high' => 'red',
        'severely underweight' => 'red', 'wasted' => 'red', 'overdue' => 'red', 'expired' => 'red',
        'referred' => 'purple',
        // HR
        'present' => 'green', 'late' => 'amber', 'half day' => 'amber', 'absent' => 'red', 'on leave' => 'purple',
        'official business' => 'blue', 'resigned' => 'gray', 'retired' => 'gray', 'terminated' => 'red', 'cancelled' => 'gray',
        // Nutrition
        'severely stunted' => 'red', 'severely wasted' => 'red', 'obese' => 'purple', 'planned' => 'gray',
        'enrolled' => 'blue', 'improved' => 'green', 'rehabilitated' => 'green', 'no change' => 'amber', 'worsened' => 'red', 'dropped' => 'gray',
    ];
    $s = (string)$status;
    $color = $colors[strtolower($s)] ?? 'gray';
    return '<span class="badge badge-' . $color . '">' . e(ucfirst($s)) . '</span>';
}

/** <option> tags. $items can be a list ['A','B'] or a map [value => label]. */
function options(array $items, $selected = null, $blank = '-- Select --'): string
{
    $isList = $items && array_keys($items) === range(0, count($items) - 1);
    $html = ($blank !== false) ? '<option value="">' . e($blank) . '</option>' : '';
    foreach ($items as $k => $label) {
        $v = $isList ? $label : $k;
        $sel = ((string)$v === (string)$selected) ? ' selected' : '';
        $html .= '<option value="' . e($v) . '"' . $sel . '>' . e($label) . '</option>';
    }
    return $html;
}

function field(string $label, string $name, $value = '', string $type = 'text', string $attrs = '', string $class = ''): string
{
    $id = 'f_' . preg_replace('/\W/', '_', $name);
    $req = strpos($attrs, 'required') !== false ? ' required' : '';
    if ($type === 'textarea') {
        $control = '<textarea id="' . $id . '" name="' . e($name) . '" ' . $attrs . '>' . e($value) . '</textarea>';
    } else {
        $control = '<input id="' . $id . '" type="' . e($type) . '" name="' . e($name) . '" value="' . e($value) . '" ' . $attrs . '>';
    }
    return '<div class="field' . $req . ' ' . e($class) . '"><label for="' . $id . '">' . e($label) . '</label>' . $control . '</div>';
}

function select_field(string $label, string $name, array $items, $selected = null, string $attrs = '', $blank = '-- Select --', string $class = ''): string
{
    $id = 'f_' . preg_replace('/\W/', '_', $name);
    $req = strpos($attrs, 'required') !== false ? ' required' : '';
    return '<div class="field' . $req . ' ' . e($class) . '"><label for="' . $id . '">' . e($label) . '</label>'
        . '<select id="' . $id . '" name="' . e($name) . '" ' . $attrs . '>' . options($items, $selected, $blank) . '</select></div>';
}

function checkbox(string $label, string $name, $checked): string
{
    return '<label class="check"><input type="checkbox" name="' . e($name) . '" value="1"' . ($checked ? ' checked' : '') . '> ' . e($label) . '</label>';
}

/** Small POST button (for delete / status changes). */
function post_button(string $action, string $label, array $hidden = [], string $class = 'btn btn-sm', string $confirm = ''): string
{
    $html = '<form method="post" action="' . e($action) . '" class="inline"' . ($confirm ? ' data-confirm="' . e($confirm) . '"' : '') . '>' . csrf_field() . back_field();
    foreach ($hidden as $k => $v) {
        $html .= '<input type="hidden" name="' . e($k) . '" value="' . e($v) . '">';
    }
    return $html . '<button type="submit" class="' . e($class) . '">' . e($label) . '</button></form>';
}

function pending_appointments_count(): int
{
    return (int)q("SELECT COUNT(*) FROM appointments WHERE status = 'pending'")->fetchColumn();
}

/* ---------- Shared query: vaccinations whose next dose is not yet recorded ---------- */

function due_vaccinations_sql(): string
{
    return "SELECT v.vaccination_id, v.resident_id, v.vaccine_id, v.dose_no, v.date_given, v.next_schedule,
                   vc.vaccine_name, vc.doses_required, r.first_name, r.middle_name, r.last_name, r.suffix, r.birthdate, r.contact_no
            FROM vaccinations v
            JOIN vaccines vc ON vc.vaccine_id = v.vaccine_id
            JOIN residents r ON r.resident_id = v.resident_id
            WHERE v.next_schedule IS NOT NULL AND r.status = 'active'
              AND NOT EXISTS (SELECT 1 FROM vaccinations v2
                              WHERE v2.resident_id = v.resident_id AND v2.vaccine_id = v.vaccine_id AND v2.dose_no > v.dose_no)";
}

/* ---------- Human Resource ---------- */

const POSITIONS = ['Barangay Health Worker', 'Barangay Nutrition Scholar', 'Midwife', 'Nurse I', 'Nurse II', 'Public Health Nurse',
                   'Municipal Health Officer', 'Nutrition Action Officer', 'Human Resource Officer', 'Medical Technologist',
                   'Sanitary Inspector', 'Dentist', 'Administrative Aide', 'Utility Worker', 'Barangay Health Emergency Response Team'];
const EMPLOYMENT_STATUS = ['Permanent', 'Casual', 'Contractual', 'Job Order', 'Volunteer'];
const PERSONNEL_STATUS = ['active', 'on leave', 'resigned', 'retired', 'terminated'];
const LEAVE_TYPES = ['Vacation', 'Sick', 'Emergency', 'Maternity', 'Paternity', 'Special Privilege', 'Solo Parent', 'Others'];
const ATTENDANCE_STATUS = ['Present', 'Late', 'Half day', 'Absent', 'On leave', 'Official business'];

/** Personnel record linked to the logged-in account (for My Leave), or null. */
function my_personnel(): ?array
{
    $p = q('SELECT * FROM personnel WHERE user_id = ?', [user_id()])->fetch();
    return $p ?: null;
}

/** [personnel_id => "Cruz, Maria — Barangay Health Worker"] */
function personnel_options(bool $activeOnly = true): array
{
    $out = [];
    $where = $activeOnly ? "WHERE status IN ('active', 'on leave')" : '';
    foreach (q("SELECT personnel_id, first_name, middle_name, last_name, suffix, position FROM personnel $where ORDER BY last_name, first_name")->fetchAll() as $p) {
        $out[$p['personnel_id']] = full_name($p) . ' — ' . $p['position'];
    }
    return $out;
}

/** Working days (Mon–Fri) between two dates, inclusive. */
function working_days(string $from, string $to): int
{
    $n = 0;
    for ($d = new DateTime($from), $end = new DateTime($to); $d <= $end; $d->modify('+1 day')) {
        if ((int)$d->format('N') <= 5) {
            $n++;
        }
    }
    return $n;
}

/** Shared validation for filing leave (also used by My Leave). */
function validate_leave(array $f): array
{
    $errors = [];
    if (!q("SELECT 1 FROM personnel WHERE personnel_id = ? AND status IN ('active', 'on leave')", [(int)$f['personnel_id']])->fetchColumn()) $errors[] = 'Choose an employee.';
    if (!in_array($f['leave_type'], LEAVE_TYPES, true)) $errors[] = 'Choose a leave type.';
    if (!valid_date($f['date_from']) || !valid_date($f['date_to'])) {
        $errors[] = 'Enter the leave dates.';
    } elseif ($f['date_to'] < $f['date_from']) {
        $errors[] = 'The end date is before the start date.';
    } elseif (working_days($f['date_from'], $f['date_to']) === 0) {
        $errors[] = 'The dates you chose are all weekends.';
    } elseif (q("SELECT 1 FROM leave_requests WHERE personnel_id = ? AND status IN ('pending', 'approved') AND date_from <= ? AND date_to >= ?",
                [(int)$f['personnel_id'], $f['date_to'], $f['date_from']])->fetchColumn()) {
        $errors[] = 'There is already a pending or approved leave on those dates.';
    }
    if ($f['reason'] === '') $errors[] = 'Give a reason for the leave.';
    return $errors;
}

function next_employee_no(): string
{
    $prefix = 'EMP-' . date('Y') . '-';
    $last = q('SELECT MAX(employee_no) FROM personnel WHERE employee_no LIKE ?', [$prefix . '%'])->fetchColumn();
    return $prefix . str_pad((string)(($last ? (int)substr($last, -4) : 0) + 1), 4, '0', STR_PAD_LEFT);
}

/* ---------- Nutrition ---------- */

const NUTRITION_STATUS = ['Normal', 'Underweight', 'Severely Underweight', 'Stunted', 'Severely Stunted',
                          'Wasted', 'Severely Wasted', 'Overweight', 'Obese'];
const SEVERE_STATUS = ['Severely Underweight', 'Severely Stunted', 'Severely Wasted'];
const SUPPLEMENT_TYPES = ['Vitamin A', 'Iron', 'Iron with Folic Acid', 'Micronutrient Powder', 'Deworming', 'Iodized Oil', 'Zinc', 'Calcium', 'Other'];
const PROGRAM_TYPES = ['Supplementary Feeding', 'Dietary Supplementation', 'Nutrition Education', 'Micronutrient Supplementation', 'Other'];

/**
 * WHO MUAC cut-offs for children 6–59 months: below 11.5 cm = severe acute malnutrition (SAM),
 * 11.5 to below 12.5 cm = moderate acute malnutrition (MAM). Returns a suggestion or null.
 */
function muac_assessment($muac, int $ageMonths): ?string
{
    if ($muac === null || $muac === '' || !is_numeric($muac) || $ageMonths < 6 || $ageMonths >= 60) {
        return null;
    }
    $m = (float)$muac;
    if ($m < 11.5) {
        return 'Severely Wasted';
    }
    if ($m < 12.5) {
        return 'Wasted';
    }
    return 'Normal';
}

/** Children 0–59 months for dropdowns, with their household head so they are easy to find. */
function child_options(): array
{
    $rows = q("SELECT r.resident_id, r.first_name, r.middle_name, r.last_name, r.suffix, r.birthdate, h.household_no,
                      hh.first_name AS hf, hh.last_name AS hl
               FROM residents r LEFT JOIN households h ON h.household_id = r.household_id
               LEFT JOIN residents hh ON hh.resident_id = h.head_resident_id
               WHERE r.status = 'active' AND r.birthdate > ? ORDER BY r.last_name, r.first_name",
              [date('Y-m-d', strtotime('-60 months'))])->fetchAll();
    $out = [];
    foreach ($rows as $r) {
        $out[$r['resident_id']] = full_name($r) . ' (' . age_label($r['birthdate']) . ')'
            . ($r['household_no'] ? ' — ' . $r['household_no'] . ($r['hl'] ? ', Head: ' . $r['hl'] . ', ' . $r['hf'] : '') : '');
    }
    return $out;
}

/** Latest OPT / growth measurement per child: SQL to JOIN as "lm". */
function latest_measure_join(string $alias = 'lm', string $residentCol = 'r.resident_id'): string
{
    return "LEFT JOIN child_monitoring $alias ON $alias.record_id = (SELECT cm.record_id FROM child_monitoring cm
             WHERE cm.resident_id = $residentCol ORDER BY cm.visit_date DESC, cm.record_id DESC LIMIT 1)";
}

/** Send a CSV download. */
function send_csv(string $filename, array $header, array $rows): void
{
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");   // so Excel opens UTF-8 correctly
    fputcsv($out, $header);
    foreach ($rows as $r) {
        fputcsv($out, $r);
    }
    fclose($out);
    exit;
}
