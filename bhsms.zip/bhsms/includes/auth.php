<?php
/* =========================================================
   Roles and permissions
   ========================================================= */

const ROLE_LABELS = [
    'admin'    => 'System Administrator',
    'bhw'      => 'Barangay Health Worker',
    'nurse'    => 'Health Center Nurse',
    'mho'      => 'Municipal Health Officer',
    'hr'       => 'Human Resource Officer',
    'nao'      => 'Nutrition Action Officer',
    'resident' => 'Resident',
];

const STAFF = ['admin', 'bhw', 'nurse', 'mho', 'hr', 'nao'];

// Staff who may see residents' health information. The HR officer is not included (Data Privacy Act).
const CLINICAL = ['admin', 'bhw', 'nurse', 'mho', 'nao'];

/*
 * Who can do what. 'view' = open the module, 'edit' = add/update records.
 * Change this table to change access for the whole system.
 */
const PERMISSIONS = [
    'residents'     => ['view' => CLINICAL, 'edit' => ['admin', 'bhw', 'nurse']],
    'consultations' => ['view' => CLINICAL, 'edit' => ['bhw', 'nurse'], 'assess' => ['nurse'], 'delete' => ['nurse']],
    'vaccinations'  => ['view' => CLINICAL, 'edit' => ['bhw', 'nurse'], 'manage' => ['admin', 'nurse']],
    'maternal'      => ['view' => CLINICAL, 'edit' => ['bhw', 'nurse']],
    'inventory'     => ['view' => CLINICAL, 'edit' => ['admin', 'nurse'], 'distribute' => ['bhw', 'nurse']],
    'appointments'  => ['view' => ['admin', 'bhw', 'nurse'], 'edit' => ['bhw', 'nurse']],
    'reports'       => ['view' => CLINICAL],
    // Human Resource: personnel 201 files, attendance, leave, trainings. Every staff member can file their own leave.
    'hr'            => ['view' => ['admin', 'hr', 'mho'], 'edit' => ['admin', 'hr'], 'approve' => ['hr', 'admin'], 'file_leave' => STAFF],
    // Nutrition: Operation Timbang Plus (OPT+), feeding programs, micronutrient supplementation
    'nutrition'     => ['view' => CLINICAL, 'edit' => ['nao', 'bhw', 'nurse'], 'manage' => ['nao', 'nurse']],
    'users'         => ['view' => ['admin'], 'edit' => ['admin']],
];

function current_user(): ?array
{
    return $_SESSION['user'] ?? null;
}

function user_id(): ?int
{
    return isset($_SESSION['user']) ? (int)$_SESSION['user']['user_id'] : null;
}

function user_role(): ?string
{
    return $_SESSION['user']['role'] ?? null;
}

function has_role(string ...$roles): bool
{
    return in_array(user_role(), $roles, true);
}

function can(string $module, string $action = 'view'): bool
{
    return in_array(user_role(), PERMISSIONS[$module][$action] ?? [], true);
}

function home_path(): string
{
    switch (user_role()) {
        case 'resident': return 'portal/index.php';
        case 'hr':       return 'modules/hr/index.php';
        case 'nao':      return 'modules/nutrition/index.php';
        default:         return 'dashboard.php';
    }
}

/** Login page for this area: residents use the homepage, staff use login.php */
function login_path(): string
{
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    return (user_role() === 'resident' || strpos($script, '/portal/') !== false) ? 'index.php' : 'login.php';
}

/**
 * Check a username/password and start the session.
 * Returns null on success, or an error message to show.
 * $allowedRoles keeps the two logins separate (resident homepage vs staff login).
 */
function attempt_login(string $username, string $password, array $allowedRoles, string $wrongPortalMessage): ?string
{
    if (($_SESSION['login_lock_until'] ?? 0) > time()) {
        return 'Too many failed attempts. Please wait a few minutes and try again.';
    }
    if ($username === '' || $password === '') {
        return 'Enter your username and password.';
    }

    $u = q('SELECT * FROM users WHERE username = ?', [$username])->fetch();
    if (!$u || !password_verify($password, $u['password_hash'])) {
        $_SESSION['login_attempts'] = ($_SESSION['login_attempts'] ?? 0) + 1;
        if ($_SESSION['login_attempts'] >= 5) {
            $_SESSION['login_lock_until'] = time() + 300;   // lock for 5 minutes
            $_SESSION['login_attempts'] = 0;
        }
        return 'Incorrect username or password.';
    }
    if (!in_array($u['role'], $allowedRoles, true)) {
        return $wrongPortalMessage;
    }
    if ($u['status'] === 'pending') {
        return $u['role'] === 'resident'
            ? 'Your account is still waiting for verification by the barangay health center. You can log in once a health worker approves it.'
            : 'Your ' . ROLE_LABELS[$u['role']] . ' account is still waiting for approval by the System Administrator.';
    }
    if ($u['status'] === 'rejected') {
        return 'Your registration was not approved' . ($u['remarks'] ? ': ' . $u['remarks'] : '.') . ' Please visit the health center for help.';
    }
    if ($u['status'] !== 'active') {
        return 'This account is inactive. Please contact the health center.';
    }

    // Upgrade old hashes automatically if PHP's default algorithm changes
    if (password_needs_rehash($u['password_hash'], PASSWORD_DEFAULT)) {
        q('UPDATE users SET password_hash = ? WHERE user_id = ?', [password_hash($password, PASSWORD_DEFAULT), $u['user_id']]);
    }
    session_regenerate_id(true);                  // prevents session fixation
    $_SESSION['user'] = [
        'user_id' => $u['user_id'], 'username' => $u['username'], 'full_name' => $u['full_name'], 'email' => $u['email'],
        'role' => $u['role'], 'resident_id' => $u['resident_id'], 'status' => $u['status'],
    ];
    $_SESSION['last_activity'] = time();
    unset($_SESSION['login_attempts'], $_SESSION['login_lock_until']);
    q('UPDATE users SET last_login = NOW() WHERE user_id = ?', [$u['user_id']]);
    log_activity('LOGIN', 'users', $u['user_id'], 'Logged in');
    return null;
}

/** Must be logged in. Re-reads the account each request so deactivated users are logged out. */
function require_login(): void
{
    if (!current_user()) {
        flash('warning', 'Please log in first.');
        redirect(login_path());
    }
    $u = q('SELECT user_id, username, full_name, email, role, resident_id, status FROM users WHERE user_id = ?', [user_id()])->fetch();
    if (!$u || $u['status'] !== 'active') {
        $target = login_path();
        session_unset();
        flash('danger', 'Your account is inactive. Contact the health center.');
        redirect($target);
    }
    $_SESSION['user'] = $u;
}

function require_perm(string $module, string $action = 'view'): void
{
    require_login();
    if (!can($module, $action)) {
        deny();
    }
}

function require_role(string ...$roles): void
{
    require_login();
    if (!has_role(...$roles)) {
        deny();
    }
}

function deny(): void
{
    http_response_code(403);
    $page_title = 'Access denied';
    require __DIR__ . '/header.php';
    echo '<div class="card"><h2>Access denied</h2><p>Your role (' . e(ROLE_LABELS[user_role()] ?? '') . ') cannot open this page.</p>'
        . '<a class="btn btn-primary" href="' . e(url(home_path())) . '">Go to home</a></div>';
    require __DIR__ . '/footer.php';
    exit;
}
