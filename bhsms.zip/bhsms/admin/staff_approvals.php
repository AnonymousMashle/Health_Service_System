<?php
/* Admin approves or rejects BHW / Nurse accounts that registered online. */
require __DIR__ . '/../includes/init.php';
require_perm('users', 'edit');

const APPROVABLE_ROLES = ['bhw' => 'Barangay Health Worker', 'nurse' => 'Health Center Nurse', 'hr' => 'Human Resource Officer', 'nao' => 'Nutrition Action Officer'];

if (is_post()) {
    $uid = (int)input('user_id');
    $action = input('action');
    $u = q("SELECT * FROM users WHERE user_id = ? AND status = 'pending' AND role IN ('bhw', 'nurse', 'hr', 'nao')", [$uid])->fetch();
    if (!$u) {
        flash('danger', 'That registration was already processed or does not exist.');
        redirect('admin/staff_approvals.php');
    }

    if ($action === 'approve') {
        // The admin may correct the user type before approving (e.g. a nurse who picked BHW by mistake)
        $role = input('role');
        if (!isset(APPROVABLE_ROLES[$role])) {
            flash('danger', 'Choose a valid user type.');
            redirect('admin/staff_approvals.php');
        }
        q("UPDATE users SET status = 'active', role = ?, remarks = NULL, verified_by = ?, verified_at = NOW() WHERE user_id = ?", [$role, user_id(), $uid]);
        notify($uid, 'Account approved', 'Welcome! Your ' . APPROVABLE_ROLES[$role] . ' account is now active.', null);
        log_activity('APPROVE', 'users', $uid, 'Approved ' . APPROVABLE_ROLES[$role] . ' account of ' . $u['full_name']
            . ($role !== $u['role'] ? ' (type changed from ' . strtoupper($u['role']) . ')' : ''));
        flash('success', $u['full_name'] . ' is approved as ' . APPROVABLE_ROLES[$role] . ' and can now log in.');
    } elseif ($action === 'reject') {
        $reason = input('remarks');
        if ($reason === '') {
            flash('danger', 'Give a reason for rejecting (the applicant sees it when logging in).');
            redirect('admin/staff_approvals.php');
        }
        q("UPDATE users SET status = 'rejected', remarks = ?, verified_by = ?, verified_at = NOW() WHERE user_id = ?", [$reason, user_id(), $uid]);
        log_activity('REJECT', 'users', $uid, 'Rejected staff registration of ' . $u['full_name'] . ': ' . $reason);
        flash('success', $u['full_name'] . "'s registration was rejected.");
    }
    redirect('admin/staff_approvals.php');
}

$pending = q("SELECT * FROM users WHERE status = 'pending' AND role IN ('bhw', 'nurse', 'hr', 'nao') ORDER BY created_at")->fetchAll();
$processed = q("SELECT u.*, v.full_name AS verifier FROM users u LEFT JOIN users v ON v.user_id = u.verified_by
                WHERE u.role IN ('bhw', 'nurse', 'hr', 'nao') AND u.verified_at IS NOT NULL ORDER BY u.verified_at DESC LIMIT 15")->fetchAll();

$page_title = 'Staff Approvals';
require __DIR__ . '/../includes/header.php';
?>
<div class="alert alert-info">
    BHWs, Nurses, HR and Nutrition Action Officers register at <strong><?= e(url('staff_register.php')) ?></strong>. Check their ID / PRC license number before approving.
    You can change the user type if they chose the wrong one.
</div>

<div class="card">
    <div class="card-header"><h3>Waiting for approval (<?= count($pending) ?>)</h3></div>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Registered</th><th>Name</th><th>Applied as</th><th>ID / License no.</th><th>Contact</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($pending as $p): ?>
            <tr>
                <td class="nowrap small"><?= fmt_datetime($p['created_at']) ?><div class="muted">@<?= e($p['username']) ?></div></td>
                <td><strong><?= e($p['full_name']) ?></strong></td>
                <td><span class="badge badge-<?= ['nurse' => 'purple', 'hr' => 'amber', 'nao' => 'green'][$p['role']] ?? 'blue' ?>"><?= e(APPROVABLE_ROLES[$p['role']]) ?></span></td>
                <td><?= e($p['id_number'] ?: '—') ?></td>
                <td class="small"><?= e($p['contact_no']) ?><div class="muted"><?= e($p['email']) ?></div></td>
                <td class="actions">
                    <details class="pop">
                        <summary class="btn btn-sm btn-success">Approve</summary>
                        <div class="pop-body">
                            <form method="post">
                                <?= csrf_field() ?>
                                <input type="hidden" name="user_id" value="<?= (int)$p['user_id'] ?>">
                                <input type="hidden" name="action" value="approve">
                                <?= select_field('Approve as', 'role', APPROVABLE_ROLES, $p['role'], 'required', false) ?>
                                <button class="btn btn-success btn-sm">Approve account</button>
                            </form>
                        </div>
                    </details>
                    <details class="pop">
                        <summary class="btn btn-sm btn-danger">Reject</summary>
                        <div class="pop-body">
                            <form method="post">
                                <?= csrf_field() ?>
                                <input type="hidden" name="user_id" value="<?= (int)$p['user_id'] ?>">
                                <input type="hidden" name="action" value="reject">
                                <?= field('Reason (shown to the applicant)', 'remarks', '', 'text', 'required maxlength="255" placeholder="e.g. License number could not be verified"') ?>
                                <button class="btn btn-danger btn-sm">Reject registration</button>
                            </form>
                        </div>
                    </details>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$pending): ?><tr><td colspan="6" class="empty">No staff registrations waiting for approval.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div>

<div class="card">
    <h3>Recently processed</h3>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Date</th><th>Name</th><th>Type</th><th>Result</th><th>Remarks</th><th>By</th></tr></thead>
        <tbody>
        <?php foreach ($processed as $p): ?>
            <tr>
                <td class="nowrap small"><?= fmt_datetime($p['verified_at']) ?></td>
                <td><?= e($p['full_name']) ?> <span class="small muted">@<?= e($p['username']) ?></span></td>
                <td><?= e(APPROVABLE_ROLES[$p['role']] ?? $p['role']) ?></td>
                <td><?= badge($p['status'] === 'rejected' ? 'rejected' : 'approved') ?></td>
                <td class="small"><?= e($p['remarks']) ?></td>
                <td class="small"><?= e($p['verifier']) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$processed): ?><tr><td colspan="6" class="empty">Nothing processed yet.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
