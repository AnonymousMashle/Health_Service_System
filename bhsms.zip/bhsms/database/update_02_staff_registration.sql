-- =====================================================================
--  UPDATE 02: Staff (BHW / Nurse) online registration with admin approval
--  Run AFTER update_01_registration.sql, and only if you imported bhsms.sql
--  before this update. (A fresh import of bhsms.sql already includes this.)
--
--  phpMyAdmin -> select database "bhsms" -> Import -> this file -> Go
-- =====================================================================

USE bhsms;

ALTER TABLE users
    ADD COLUMN contact_no VARCHAR(20) NULL AFTER email,
    ADD COLUMN id_number  VARCHAR(50) NULL AFTER contact_no;

-- Sample staff registrations waiting for approval (password: password123)
INSERT INTO users (username, password_hash, full_name, email, contact_no, id_number, role, status) VALUES
('bhw_jose',    '$2y$10$wCLysAYlxSkXiysDUQTu5OIC4cgDqkoN2/hi2jLHpApK.LLvdh6Y6', 'Jose Ramirez',      'jose@example.com',  '09231234510', 'BHW-2026-014', 'bhw',   'pending'),
('nurse_carla', '$2y$10$wCLysAYlxSkXiysDUQTu5OIC4cgDqkoN2/hi2jLHpApK.LLvdh6Y6', 'Carla Mendoza, RN', 'carla@example.com', '09241234511', '0712345',      'nurse', 'pending');
