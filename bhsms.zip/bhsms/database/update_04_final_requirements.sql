-- =====================================================================
--  BHSMS update 04 — final assessment requirements
--  * Resident photo + document attachments            (Criterion 2)
--  * Appointment reference numbers, "under review",
--    staff assignment and a status history log         (Criterion 3)
--  * Announcements / health advisories                 (Criterion 5)
--  * Resident feedback & ratings (with reference no.)  (Criterion 5)
--
--  Already imported bhsms.sql before?  Import THIS file (keeps your data).
--  Importing bhsms.sql fresh?  Not needed: bhsms.sql already includes it.
-- =====================================================================

USE bhsms;
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- 1. Resident photo and documents
-- ---------------------------------------------------------------------
ALTER TABLE residents ADD COLUMN IF NOT EXISTS photo_path VARCHAR(255) NULL AFTER occupation;

CREATE TABLE IF NOT EXISTS resident_documents (
    document_id    INT AUTO_INCREMENT PRIMARY KEY,
    resident_id    INT NOT NULL,
    title          VARCHAR(150) NOT NULL,
    doc_type       ENUM('Valid ID','Birth Certificate','PhilHealth ID / MDR','Laboratory Result','Medical Certificate',
                        'Referral Slip','Prescription','Barangay Certificate','Other') NOT NULL DEFAULT 'Other',
    file_path      VARCHAR(255) NOT NULL,             -- random file name inside uploads/documents/
    original_name  VARCHAR(255) NOT NULL,
    mime_type      VARCHAR(100) NOT NULL,
    file_size      INT NOT NULL,
    uploaded_by    INT NULL,
    uploaded_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_docs_resident (resident_id),
    CONSTRAINT fk_docs_resident FOREIGN KEY (resident_id)
        REFERENCES residents(resident_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_docs_uploaded_by FOREIGN KEY (uploaded_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 2. Appointment workflow: reference no., under review, assignment, history
--    Pending -> Under review (assigned) -> Approved / Rejected -> Completed / No-show
-- ---------------------------------------------------------------------
ALTER TABLE appointments
    MODIFY status ENUM('pending','under review','approved','rejected','completed','cancelled','no-show') NOT NULL DEFAULT 'pending';
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS reference_no VARCHAR(20) NULL AFTER appointment_id;
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS assigned_to  INT NULL AFTER requested_by;
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS reviewed_at  DATETIME NULL AFTER assigned_to;
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS completed_at DATETIME NULL AFTER approved_at;

UPDATE appointments SET reference_no = CONCAT('APT-', YEAR(created_at), '-', LPAD(appointment_id, 4, '0')) WHERE reference_no IS NULL;

ALTER TABLE appointments ADD UNIQUE INDEX IF NOT EXISTS uq_appt_ref (reference_no);

-- FK for the assigned staff member (skipped if it already exists)
SET @fk := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
            WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = 'appointments' AND CONSTRAINT_NAME = 'fk_appt_assigned');
SET @sql := IF(@fk = 0, 'ALTER TABLE appointments ADD CONSTRAINT fk_appt_assigned FOREIGN KEY (assigned_to) REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE', 'SELECT 1');
PREPARE st FROM @sql; EXECUTE st; DEALLOCATE PREPARE st;

-- Every status change with timestamp, who did it and remarks
CREATE TABLE IF NOT EXISTS appointment_logs (
    log_id          INT AUTO_INCREMENT PRIMARY KEY,
    appointment_id  INT NOT NULL,
    status          VARCHAR(20) NOT NULL,
    remarks         VARCHAR(255) NULL,
    changed_by      INT NULL,
    changed_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_appt_logs (appointment_id, changed_at),
    CONSTRAINT fk_appt_logs_appt FOREIGN KEY (appointment_id)
        REFERENCES appointments(appointment_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_appt_logs_user FOREIGN KEY (changed_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- History for the sample appointments (only if none yet)
INSERT INTO appointment_logs (appointment_id, status, remarks, changed_by, changed_at)
SELECT a.appointment_id, 'pending', 'Request submitted', a.requested_by, a.created_at
FROM appointments a WHERE NOT EXISTS (SELECT 1 FROM appointment_logs l WHERE l.appointment_id = a.appointment_id);

INSERT INTO appointment_logs (appointment_id, status, remarks, changed_by, changed_at)
SELECT a.appointment_id, IF(a.status = 'rejected', 'rejected', 'approved'), a.remarks, a.approved_by, a.approved_at
FROM appointments a
WHERE a.status IN ('approved', 'rejected', 'completed') AND a.approved_at IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM appointment_logs l WHERE l.appointment_id = a.appointment_id AND l.status <> 'pending');

INSERT INTO appointment_logs (appointment_id, status, remarks, changed_by, changed_at)
SELECT a.appointment_id, 'completed', 'Consultation recorded', a.approved_by, COALESCE(c.consultation_date, a.updated_at)
FROM appointments a LEFT JOIN consultations c ON c.appointment_id = a.appointment_id
WHERE a.status = 'completed'
  AND NOT EXISTS (SELECT 1 FROM appointment_logs l WHERE l.appointment_id = a.appointment_id AND l.status = 'completed');

-- ---------------------------------------------------------------------
-- 3. Announcements / health advisories (shown on the public homepage)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS announcements (
    announcement_id  INT AUTO_INCREMENT PRIMARY KEY,
    title            VARCHAR(150) NOT NULL,
    category         ENUM('Health Advisory','Announcement','Vaccination Drive','Event','Schedule Change') NOT NULL DEFAULT 'Announcement',
    body             TEXT NOT NULL,
    publish_date     DATE NOT NULL,
    expiry_date      DATE NULL,                         -- hidden from the public after this date
    is_published     TINYINT(1) NOT NULL DEFAULT 1,
    is_pinned        TINYINT(1) NOT NULL DEFAULT 0,
    created_by       INT NULL,
    created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_ann_publish (is_published, publish_date),
    CONSTRAINT fk_ann_created_by FOREIGN KEY (created_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

INSERT INTO announcements (title, category, body, publish_date, expiry_date, is_published, is_pinned, created_by)
SELECT * FROM (
    SELECT 'Dengue alert: search and destroy mosquito breeding sites' AS t, 'Health Advisory' AS c,
           'Dengue cases are rising during the rainy season. Cover water containers, clean gutters every week and use mosquito repellent. Go to the health center right away if you have fever for 2 days or more.' AS b,
           '2026-11-03' AS p, '2026-12-31' AS x, 1 AS pub, 1 AS pin, 3 AS u
    UNION ALL SELECT 'Measles-Rubella catch-up vaccination this Wednesday', 'Vaccination Drive',
           'Free MR vaccine for children 9 to 59 months old on Wednesday, 8:00 AM to 12:00 NN at the barangay health center. Bring the child''s vaccination card.',
           '2026-11-16', '2026-11-30', 1, 0, 3
    UNION ALL SELECT 'Health center closed on November 30 (Bonifacio Day)', 'Schedule Change',
           'The health center is closed on Monday, November 30. For emergencies, go to the nearest hospital.',
           '2026-11-20', '2026-12-01', 1, 0, 1
    UNION ALL SELECT 'Free blood pressure and blood sugar screening for seniors', 'Event',
           'Senior citizens can get free BP and blood sugar screening every Friday afternoon this December.',
           '2026-11-21', '2026-12-31', 1, 0, 3
) s
WHERE NOT EXISTS (SELECT 1 FROM announcements);

-- ---------------------------------------------------------------------
-- 4. Resident feedback & ratings
--    Pending -> Under review -> Resolved (staff response shown to the resident)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS feedback (
    feedback_id     INT AUTO_INCREMENT PRIMARY KEY,
    reference_no    VARCHAR(20) NOT NULL UNIQUE,        -- e.g. FB-2026-0001
    resident_id     INT NULL,
    user_id         INT NULL,
    category        ENUM('Service','Staff','Facility','Medicine Availability','Appointment','Other') NOT NULL DEFAULT 'Service',
    rating          TINYINT NOT NULL,                   -- 1 to 5 stars
    comments        TEXT NOT NULL,
    status          ENUM('pending','under review','resolved') NOT NULL DEFAULT 'pending',
    response        TEXT NULL,
    responded_by    INT NULL,
    responded_at    DATETIME NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_feedback_status (status),
    CONSTRAINT chk_feedback_rating CHECK (rating BETWEEN 1 AND 5),
    CONSTRAINT fk_feedback_resident FOREIGN KEY (resident_id)
        REFERENCES residents(resident_id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_feedback_user FOREIGN KEY (user_id)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_feedback_responded_by FOREIGN KEY (responded_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

INSERT INTO feedback (reference_no, resident_id, user_id, category, rating, comments, status, response, responded_by, responded_at, created_at)
SELECT * FROM (
    SELECT 'FB-2026-0001' AS r, 1 AS rid, 5 AS uid, 'Service' AS c, 5 AS rt,
           'Fast BP check and the nurse explained my medicines clearly.' AS cm, 'resolved' AS st,
           'Thank you, Mr. Dela Cruz! Keep taking your maintenance medicine.' AS rs, 3 AS rb, '2026-10-08 09:00:00' AS ra, '2026-10-07 18:20:00' AS ca
    UNION ALL SELECT 'FB-2026-0002', 6, 6, 'Medicine Availability', 3,
           'The ferrous sulfate ran out last month, I had to buy outside.', 'pending', NULL, NULL, NULL, '2026-11-12 10:05:00'
) s
WHERE NOT EXISTS (SELECT 1 FROM feedback)
  AND EXISTS (SELECT 1 FROM users WHERE user_id = 6);

SET FOREIGN_KEY_CHECKS = 1;
