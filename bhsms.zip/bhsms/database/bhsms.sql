-- =====================================================================
--  Barangay Health Services and Community Health Monitoring System
--  Database: bhsms
--  Target  : XAMPP (MariaDB 10.4+ / MySQL 5.7+), InnoDB, utf8mb4
--
--  How to import:
--    phpMyAdmin -> Import -> choose bhsms.sql -> Go
--    (the script creates the `bhsms` database itself)
--
--  Sample logins (all passwords: password123)
--    admin      - System Administrator
--    bhw_maria  - Barangay Health Worker
--    nurse_ana  - Barangay Health Center Nurse
--    mho_reyes  - Municipal Health Officer
--    res_juan   - Resident (Juan Dela Cruz)
--    res_liza   - Resident (Liza Santos, pregnant)
--    hr_luz     - Human Resource Officer
--    nao_ben    - Nutrition Action Officer
--  Requires MariaDB 10.4+ (the database that comes with XAMPP).
-- =====================================================================

SET NAMES utf8mb4;
SET time_zone = '+08:00';
SET FOREIGN_KEY_CHECKS = 0;

DROP DATABASE IF EXISTS bhsms;
CREATE DATABASE bhsms CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE bhsms;

-- =====================================================================
-- 0. ACCOUNTS & ROLES
-- =====================================================================

CREATE TABLE users (
    user_id        INT AUTO_INCREMENT PRIMARY KEY,
    username       VARCHAR(50)  NOT NULL UNIQUE,
    password_hash  VARCHAR(255) NOT NULL,              -- use password_hash() / password_verify()
    full_name      VARCHAR(150) NOT NULL,
    email          VARCHAR(150) NULL UNIQUE,
    contact_no     VARCHAR(20)  NULL,
    id_number      VARCHAR(50)  NULL,                   -- staff: PRC license no. (nurse) / BHW accreditation or employee ID
    role           ENUM('admin','bhw','nurse','mho','hr','nao','resident') NOT NULL,
    resident_id    INT NULL,                            -- only for role = 'resident'
    registered_address VARCHAR(255) NULL,               -- address typed during online registration
    status         ENUM('active','inactive','pending','rejected') NOT NULL DEFAULT 'active',
    remarks        VARCHAR(255) NULL,                   -- e.g. reason a registration was rejected
    verified_by    INT NULL,                            -- staff who approved/rejected the registration
    verified_at    DATETIME NULL,
    last_login     DATETIME NULL,
    created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_users_role (role),
    INDEX idx_users_status (status),
    CONSTRAINT fk_users_verified_by FOREIGN KEY (verified_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- 1. RESIDENT HEALTH REGISTRATION
-- =====================================================================

CREATE TABLE households (
    household_id      INT AUTO_INCREMENT PRIMARY KEY,
    household_no      VARCHAR(20)  NOT NULL UNIQUE,     -- e.g. HH-2026-0001
    purok             VARCHAR(50)  NOT NULL,
    street_address    VARCHAR(255) NOT NULL,
    head_resident_id  INT NULL,                         -- FK added after residents table
    created_by        INT NULL,
    created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_households_purok (purok),
    CONSTRAINT fk_households_created_by FOREIGN KEY (created_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE residents (
    resident_id     INT AUTO_INCREMENT PRIMARY KEY,
    household_id    INT NULL,
    first_name      VARCHAR(80)  NOT NULL,
    middle_name     VARCHAR(80)  NULL,
    last_name       VARCHAR(80)  NOT NULL,
    suffix          VARCHAR(10)  NULL,
    sex             ENUM('Male','Female') NOT NULL,
    birthdate       DATE NOT NULL,
    civil_status    ENUM('Single','Married','Widowed','Separated','Live-in') NOT NULL DEFAULT 'Single',
    relationship_to_head VARCHAR(30) NULL,              -- Head, Spouse, Son, Daughter, ...
    contact_no      VARCHAR(20)  NULL,
    philhealth_no   VARCHAR(20)  NULL UNIQUE,
    occupation      VARCHAR(100) NULL,
    is_4ps_member   TINYINT(1) NOT NULL DEFAULT 0,
    is_pwd          TINYINT(1) NOT NULL DEFAULT 0,
    is_senior       TINYINT(1) NOT NULL DEFAULT 0,
    status          ENUM('active','pending','transferred','deceased') NOT NULL DEFAULT 'active',  -- pending = registered online, not yet verified
    created_by      INT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_residents_name (last_name, first_name),
    INDEX idx_residents_birthdate (birthdate),
    CONSTRAINT fk_residents_household FOREIGN KEY (household_id)
        REFERENCES households(household_id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_residents_created_by FOREIGN KEY (created_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Circular links, added once both tables exist
ALTER TABLE households
    ADD CONSTRAINT fk_households_head FOREIGN KEY (head_resident_id)
        REFERENCES residents(resident_id) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE users
    ADD CONSTRAINT fk_users_resident FOREIGN KEY (resident_id)
        REFERENCES residents(resident_id) ON DELETE SET NULL ON UPDATE CASCADE;

CREATE TABLE health_profiles (
    profile_id           INT AUTO_INCREMENT PRIMARY KEY,
    resident_id          INT NOT NULL UNIQUE,           -- one profile per resident
    blood_type           ENUM('A+','A-','B+','B-','AB+','AB-','O+','O-','Unknown') NOT NULL DEFAULT 'Unknown',
    height_cm            DECIMAL(5,2) NULL,
    weight_kg            DECIMAL(5,2) NULL,
    allergies            TEXT NULL,
    existing_conditions  TEXT NULL,                     -- e.g. Hypertension, Diabetes
    maintenance_meds     TEXT NULL,
    disability           VARCHAR(150) NULL,
    is_smoker            TINYINT(1) NOT NULL DEFAULT 0,
    is_alcohol_drinker   TINYINT(1) NOT NULL DEFAULT 0,
    updated_by           INT NULL,
    updated_at           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_profiles_resident FOREIGN KEY (resident_id)
        REFERENCES residents(resident_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_profiles_updated_by FOREIGN KEY (updated_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE emergency_contacts (
    contact_id     INT AUTO_INCREMENT PRIMARY KEY,
    resident_id    INT NOT NULL,
    contact_name   VARCHAR(150) NOT NULL,
    relationship   VARCHAR(50)  NOT NULL,
    contact_no     VARCHAR(20)  NOT NULL,
    address        VARCHAR(255) NULL,
    created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_emergency_resident FOREIGN KEY (resident_id)
        REFERENCES residents(resident_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- 2. PATIENT CONSULTATION MANAGEMENT
-- =====================================================================

CREATE TABLE consultations (
    consultation_id    INT AUTO_INCREMENT PRIMARY KEY,
    resident_id        INT NOT NULL,
    appointment_id     INT NULL,                        -- FK added after appointments table
    consultation_date  DATETIME NOT NULL,
    chief_complaint    VARCHAR(255) NOT NULL,
    symptoms           TEXT NULL,
    blood_pressure     VARCHAR(10)  NULL,               -- e.g. 120/80
    temperature_c      DECIMAL(4,1) NULL,
    pulse_rate         SMALLINT NULL,
    respiratory_rate   SMALLINT NULL,
    weight_kg          DECIMAL(5,2) NULL,
    assessment         TEXT NULL,                       -- health worker's / nurse's assessment
    treatment_plan     TEXT NULL,
    referred_to        VARCHAR(150) NULL,               -- e.g. BGHMC, RHU
    status             ENUM('waiting','ongoing','completed','referred') NOT NULL DEFAULT 'completed',
    recorded_by        INT NULL,
    created_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_consult_date (consultation_date),
    INDEX idx_consult_resident (resident_id, consultation_date),
    CONSTRAINT fk_consult_resident FOREIGN KEY (resident_id)
        REFERENCES residents(resident_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_consult_recorded_by FOREIGN KEY (recorded_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- 3. VACCINATION MONITORING
-- =====================================================================

CREATE TABLE vaccines (
    vaccine_id       INT AUTO_INCREMENT PRIMARY KEY,
    vaccine_name     VARCHAR(100) NOT NULL UNIQUE,
    description      VARCHAR(255) NULL,
    target_group     ENUM('Infant','Child','Adult','Pregnant','Senior','All') NOT NULL DEFAULT 'All',
    doses_required   TINYINT NOT NULL DEFAULT 1,
    interval_days    SMALLINT NULL,                     -- days between doses (for next schedule)
    is_active        TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE vaccinations (
    vaccination_id   INT AUTO_INCREMENT PRIMARY KEY,
    resident_id      INT NOT NULL,
    vaccine_id       INT NOT NULL,
    dose_no          TINYINT NOT NULL DEFAULT 1,
    date_given       DATE NOT NULL,
    next_schedule    DATE NULL,                         -- NULL when series is complete
    batch_lot_no     VARCHAR(50) NULL,
    site_given       VARCHAR(50) NULL,                  -- e.g. Left deltoid
    administered_by  INT NULL,
    remarks          VARCHAR(255) NULL,
    created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_vacc_dose (resident_id, vaccine_id, dose_no),
    INDEX idx_vacc_next (next_schedule),
    INDEX idx_vacc_date (date_given),
    CONSTRAINT fk_vacc_resident FOREIGN KEY (resident_id)
        REFERENCES residents(resident_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_vacc_vaccine FOREIGN KEY (vaccine_id)
        REFERENCES vaccines(vaccine_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_vacc_admin_by FOREIGN KEY (administered_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- 4. MATERNAL AND CHILD HEALTH MONITORING
-- =====================================================================

CREATE TABLE pregnancies (
    pregnancy_id    INT AUTO_INCREMENT PRIMARY KEY,
    resident_id     INT NOT NULL,
    lmp             DATE NOT NULL,                      -- last menstrual period
    edd             DATE NOT NULL,                      -- expected delivery date (LMP + 280 days)
    gravida         TINYINT NOT NULL DEFAULT 1,         -- number of pregnancies
    para            TINYINT NOT NULL DEFAULT 0,         -- number of births
    risk_level      ENUM('Low','Moderate','High') NOT NULL DEFAULT 'Low',
    risk_notes      VARCHAR(255) NULL,
    status          ENUM('ongoing','delivered','miscarriage','transferred') NOT NULL DEFAULT 'ongoing',
    delivery_date   DATE NULL,
    delivery_place  VARCHAR(150) NULL,
    registered_by   INT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_preg_status (status),
    CONSTRAINT fk_preg_resident FOREIGN KEY (resident_id)
        REFERENCES residents(resident_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_preg_registered_by FOREIGN KEY (registered_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE prenatal_visits (
    visit_id          INT AUTO_INCREMENT PRIMARY KEY,
    pregnancy_id      INT NOT NULL,
    visit_date        DATE NOT NULL,
    aog_weeks         TINYINT NULL,                     -- age of gestation
    blood_pressure    VARCHAR(10) NULL,
    weight_kg         DECIMAL(5,2) NULL,
    fundal_height_cm  DECIMAL(4,1) NULL,
    fetal_heart_rate  SMALLINT NULL,
    findings          TEXT NULL,
    supplements_given VARCHAR(255) NULL,                -- e.g. Ferrous sulfate + Folic acid
    next_visit        DATE NULL,
    recorded_by       INT NULL,
    created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_prenatal_next (next_visit),
    CONSTRAINT fk_prenatal_pregnancy FOREIGN KEY (pregnancy_id)
        REFERENCES pregnancies(pregnancy_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_prenatal_recorded_by FOREIGN KEY (recorded_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE child_monitoring (
    record_id          INT AUTO_INCREMENT PRIMARY KEY,
    resident_id        INT NOT NULL,                    -- the child
    visit_date         DATE NOT NULL,
    weight_kg          DECIMAL(5,2) NULL,
    height_cm          DECIMAL(5,2) NULL,
    muac_cm            DECIMAL(4,1) NULL,               -- mid-upper arm circumference
    nutrition_status   ENUM('Normal','Underweight','Severely Underweight','Stunted','Severely Stunted',
                            'Wasted','Severely Wasted','Overweight','Obese') NULL,
    milestones         VARCHAR(255) NULL,
    remarks            TEXT NULL,
    next_visit         DATE NULL,
    recorded_by        INT NULL,
    created_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_child_next (next_visit),
    CONSTRAINT fk_child_resident FOREIGN KEY (resident_id)
        REFERENCES residents(resident_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_child_recorded_by FOREIGN KEY (recorded_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Scheduled health visits (home visits, prenatal, child check-ups, follow-ups)
CREATE TABLE health_visit_schedules (
    schedule_id      INT AUTO_INCREMENT PRIMARY KEY,
    resident_id      INT NOT NULL,
    visit_type       ENUM('Prenatal','Postnatal','Child Check-up','Home Visit','Follow-up') NOT NULL,
    scheduled_date   DATE NOT NULL,
    assigned_to      INT NULL,                          -- BHW or nurse
    status           ENUM('scheduled','done','missed','cancelled') NOT NULL DEFAULT 'scheduled',
    notes            VARCHAR(255) NULL,
    created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_hvs_date (scheduled_date, status),
    CONSTRAINT fk_hvs_resident FOREIGN KEY (resident_id)
        REFERENCES residents(resident_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_hvs_assigned FOREIGN KEY (assigned_to)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- 5. MEDICINE INVENTORY
-- =====================================================================

CREATE TABLE medicines (
    medicine_id    INT AUTO_INCREMENT PRIMARY KEY,
    generic_name   VARCHAR(150) NOT NULL,
    brand_name     VARCHAR(150) NULL,
    dosage_form    ENUM('Tablet','Capsule','Syrup','Suspension','Drops','Ointment','Injection','Sachet','Other') NOT NULL,
    strength       VARCHAR(50)  NULL,                   -- e.g. 500 mg
    unit           VARCHAR(20)  NOT NULL DEFAULT 'pcs', -- pcs, bottle, sachet
    reorder_level  INT NOT NULL DEFAULT 50,             -- low-stock threshold
    is_active      TINYINT(1) NOT NULL DEFAULT 1,
    created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_medicine (generic_name, dosage_form, strength)
) ENGINE=InnoDB;

-- STOCK-IN: each delivery/batch
CREATE TABLE medicine_stock (
    stock_id           INT AUTO_INCREMENT PRIMARY KEY,
    medicine_id        INT NOT NULL,
    batch_no           VARCHAR(50) NOT NULL,
    quantity_received  INT NOT NULL,
    quantity_remaining INT NOT NULL,                    -- decrease on every distribution
    expiry_date        DATE NOT NULL,
    date_received      DATE NOT NULL,
    source             VARCHAR(150) NULL,               -- e.g. DOH-CAR, City Health Office
    received_by        INT NULL,
    created_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_stock_expiry (expiry_date),
    CONSTRAINT chk_stock_qty CHECK (quantity_remaining >= 0 AND quantity_remaining <= quantity_received),
    CONSTRAINT fk_stock_medicine FOREIGN KEY (medicine_id)
        REFERENCES medicines(medicine_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_stock_received_by FOREIGN KEY (received_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- STOCK-OUT: medicine given to residents
CREATE TABLE medicine_distribution (
    distribution_id    INT AUTO_INCREMENT PRIMARY KEY,
    stock_id           INT NOT NULL,
    medicine_id        INT NOT NULL,
    resident_id        INT NOT NULL,
    consultation_id    INT NULL,
    quantity           INT NOT NULL,
    distribution_date  DATE NOT NULL,
    instructions       VARCHAR(255) NULL,               -- e.g. 1 tab every 6 hrs for 3 days
    given_by           INT NULL,
    created_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_dist_date (distribution_date),
    CONSTRAINT chk_dist_qty CHECK (quantity > 0),
    CONSTRAINT fk_dist_stock FOREIGN KEY (stock_id)
        REFERENCES medicine_stock(stock_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_dist_medicine FOREIGN KEY (medicine_id)
        REFERENCES medicines(medicine_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_dist_resident FOREIGN KEY (resident_id)
        REFERENCES residents(resident_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_dist_consult FOREIGN KEY (consultation_id)
        REFERENCES consultations(consultation_id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_dist_given_by FOREIGN KEY (given_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Adjustments other than distribution (expired, damaged, returned)
CREATE TABLE stock_adjustments (
    adjustment_id   INT AUTO_INCREMENT PRIMARY KEY,
    stock_id        INT NOT NULL,
    adjustment_type ENUM('Expired','Damaged','Lost','Returned','Correction') NOT NULL,
    quantity        INT NOT NULL,                       -- negative = removed, positive = added back
    reason          VARCHAR(255) NULL,
    adjusted_by     INT NULL,
    adjusted_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_adj_stock FOREIGN KEY (stock_id)
        REFERENCES medicine_stock(stock_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_adj_by FOREIGN KEY (adjusted_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- 6. APPOINTMENT MANAGEMENT
-- =====================================================================

CREATE TABLE appointments (
    appointment_id   INT AUTO_INCREMENT PRIMARY KEY,
    resident_id      INT NOT NULL,
    service_type     ENUM('General Consultation','Vaccination','Prenatal Check-up','Child Check-up','Family Planning','Medicine Request','Other') NOT NULL,
    preferred_date   DATE NOT NULL,
    preferred_time   TIME NULL,
    reason           VARCHAR(255) NULL,
    status           ENUM('pending','approved','rejected','completed','cancelled','no-show') NOT NULL DEFAULT 'pending',
    scheduled_date   DATE NULL,                         -- final date set on approval
    scheduled_time   TIME NULL,
    remarks          VARCHAR(255) NULL,                 -- reason for rejection, notes
    requested_by     INT NULL,                          -- user who submitted (resident or staff)
    approved_by      INT NULL,
    approved_at      DATETIME NULL,
    created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_appt_status (status),
    INDEX idx_appt_sched (scheduled_date),
    CONSTRAINT fk_appt_resident FOREIGN KEY (resident_id)
        REFERENCES residents(resident_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_appt_requested_by FOREIGN KEY (requested_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_appt_approved_by FOREIGN KEY (approved_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

ALTER TABLE consultations
    ADD CONSTRAINT fk_consult_appointment FOREIGN KEY (appointment_id)
        REFERENCES appointments(appointment_id) ON DELETE SET NULL ON UPDATE CASCADE;

-- =====================================================================
-- SYSTEM: notifications & audit trail
-- =====================================================================

CREATE TABLE notifications (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT NOT NULL,
    title           VARCHAR(150) NOT NULL,
    message         VARCHAR(255) NOT NULL,
    link            VARCHAR(255) NULL,
    is_read         TINYINT(1) NOT NULL DEFAULT 0,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_notif_user (user_id, is_read),
    CONSTRAINT fk_notif_user FOREIGN KEY (user_id)
        REFERENCES users(user_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE activity_logs (
    log_id      INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NULL,
    action      VARCHAR(50)  NOT NULL,                  -- LOGIN, CREATE, UPDATE, DELETE, ...
    table_name  VARCHAR(50)  NULL,
    record_id   INT NULL,
    details     VARCHAR(255) NULL,
    ip_address  VARCHAR(45)  NULL,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_logs_user (user_id),
    INDEX idx_logs_date (created_at),
    CONSTRAINT fk_logs_user FOREIGN KEY (user_id)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- 7. HEALTH REPORTS & ANALYTICS (views)
--    Query these from PHP like normal tables: SELECT * FROM v_dashboard_summary;
-- =====================================================================

-- Resident list with computed age and household info
CREATE VIEW v_resident_details AS
SELECT r.resident_id,
       CONCAT(r.last_name, ', ', r.first_name, IFNULL(CONCAT(' ', r.middle_name), '')) AS full_name,
       r.sex,
       r.birthdate,
       TIMESTAMPDIFF(YEAR, r.birthdate, CURDATE())  AS age,
       TIMESTAMPDIFF(MONTH, r.birthdate, CURDATE()) AS age_months,
       r.civil_status,
       r.contact_no,
       r.status,
       h.household_no,
       h.purok
FROM residents r
LEFT JOIN households h ON h.household_id = r.household_id;

-- Dashboard cards
CREATE VIEW v_dashboard_summary AS
SELECT
    (SELECT COUNT(*) FROM residents WHERE status = 'active')                         AS total_residents,
    (SELECT COUNT(*) FROM households)                                                AS total_households,
    (SELECT COUNT(*) FROM consultations
       WHERE YEAR(consultation_date) = YEAR(CURDATE())
         AND MONTH(consultation_date) = MONTH(CURDATE()))                            AS consultations_this_month,
    (SELECT COUNT(*) FROM pregnancies WHERE status = 'ongoing')                      AS active_pregnancies,
    (SELECT COUNT(*) FROM appointments WHERE status = 'pending')                     AS pending_appointments,
    (SELECT COUNT(*) FROM vaccinations
       WHERE next_schedule BETWEEN CURDATE() AND CURDATE() + INTERVAL 7 DAY)         AS vaccinations_due_7_days;

-- Monthly consultations
CREATE VIEW v_monthly_consultations AS
SELECT DATE_FORMAT(consultation_date, '%Y-%m') AS month,
       COUNT(*)                                AS total_consultations,
       SUM(status = 'referred')                AS referred
FROM consultations
GROUP BY DATE_FORMAT(consultation_date, '%Y-%m');

-- Vaccination completion per resident per vaccine
CREATE VIEW v_vaccination_status AS
SELECT v.resident_id,
       CONCAT(r.last_name, ', ', r.first_name) AS full_name,
       vc.vaccine_id,
       vc.vaccine_name,
       vc.doses_required,
       COUNT(v.vaccination_id)                 AS doses_received,
       MAX(v.date_given)                       AS last_dose_date,
       MAX(v.next_schedule)                    AS next_schedule,
       CASE WHEN COUNT(v.vaccination_id) >= vc.doses_required
            THEN 'Complete' ELSE 'Incomplete' END AS completion_status
FROM vaccinations v
JOIN vaccines  vc ON vc.vaccine_id  = v.vaccine_id
JOIN residents r  ON r.resident_id  = v.resident_id
GROUP BY v.resident_id, r.last_name, r.first_name, vc.vaccine_id, vc.vaccine_name, vc.doses_required;

-- Vaccination coverage per vaccine
CREATE VIEW v_vaccination_coverage AS
SELECT vc.vaccine_id,
       vc.vaccine_name,
       vc.target_group,
       COUNT(DISTINCT v.resident_id) AS residents_vaccinated,
       COUNT(v.vaccination_id)       AS total_doses_given
FROM vaccines vc
LEFT JOIN vaccinations v ON v.vaccine_id = vc.vaccine_id
GROUP BY vc.vaccine_id, vc.vaccine_name, vc.target_group;

-- Current stock per medicine with low-stock flag
CREATE VIEW v_medicine_stock_levels AS
SELECT m.medicine_id,
       m.generic_name,
       m.brand_name,
       m.dosage_form,
       m.strength,
       m.unit,
       m.reorder_level,
       IFNULL(SUM(CASE WHEN s.expiry_date >= CURDATE() THEN s.quantity_remaining END), 0) AS usable_stock,
       IFNULL(SUM(CASE WHEN s.expiry_date <  CURDATE() THEN s.quantity_remaining END), 0) AS expired_stock,
       MIN(CASE WHEN s.quantity_remaining > 0 AND s.expiry_date >= CURDATE()
                THEN s.expiry_date END)                                                   AS nearest_expiry,
       CASE
           WHEN IFNULL(SUM(CASE WHEN s.expiry_date >= CURDATE() THEN s.quantity_remaining END), 0) = 0
                THEN 'Out of Stock'
           WHEN IFNULL(SUM(CASE WHEN s.expiry_date >= CURDATE() THEN s.quantity_remaining END), 0) <= m.reorder_level
                THEN 'Low Stock'
           ELSE 'In Stock'
       END AS stock_status
FROM medicines m
LEFT JOIN medicine_stock s ON s.medicine_id = m.medicine_id
WHERE m.is_active = 1
GROUP BY m.medicine_id, m.generic_name, m.brand_name, m.dosage_form, m.strength, m.unit, m.reorder_level;

-- Monthly medicine distribution
CREATE VIEW v_monthly_medicine_distribution AS
SELECT DATE_FORMAT(d.distribution_date, '%Y-%m') AS month,
       m.medicine_id,
       m.generic_name,
       SUM(d.quantity)                            AS total_quantity,
       COUNT(DISTINCT d.resident_id)              AS residents_served
FROM medicine_distribution d
JOIN medicines m ON m.medicine_id = d.medicine_id
GROUP BY DATE_FORMAT(d.distribution_date, '%Y-%m'), m.medicine_id, m.generic_name;

-- Maternal & child statistics
CREATE VIEW v_maternal_child_stats AS
SELECT
    (SELECT COUNT(*) FROM pregnancies WHERE status = 'ongoing')                          AS ongoing_pregnancies,
    (SELECT COUNT(*) FROM pregnancies WHERE status = 'ongoing' AND risk_level = 'High')  AS high_risk_pregnancies,
    (SELECT COUNT(*) FROM pregnancies WHERE status = 'delivered'
        AND YEAR(delivery_date) = YEAR(CURDATE()))                                       AS deliveries_this_year,
    (SELECT COUNT(*) FROM prenatal_visits
        WHERE YEAR(visit_date) = YEAR(CURDATE()))                                        AS prenatal_visits_this_year,
    (SELECT COUNT(*) FROM residents
        WHERE status = 'active' AND TIMESTAMPDIFF(YEAR, birthdate, CURDATE()) < 5)       AS children_under_5,
    (SELECT COUNT(DISTINCT resident_id) FROM child_monitoring
        WHERE nutrition_status IS NOT NULL AND nutrition_status <> 'Normal')             AS children_with_nutrition_concerns;

-- Upcoming schedules (next 30 days) from all modules, for a calendar / reminder page
CREATE VIEW v_upcoming_schedules AS
SELECT 'Vaccination' AS schedule_type, v.resident_id, v.next_schedule AS schedule_date,
       CONCAT(vc.vaccine_name, ' dose ', v.dose_no + 1) AS details
FROM vaccinations v
JOIN vaccines vc ON vc.vaccine_id = v.vaccine_id
WHERE v.next_schedule BETWEEN CURDATE() AND CURDATE() + INTERVAL 30 DAY
UNION ALL
SELECT 'Prenatal', p.resident_id, pv.next_visit, CONCAT('Prenatal visit (AOG ', IFNULL(pv.aog_weeks, '?'), ' wks)')
FROM prenatal_visits pv
JOIN pregnancies p ON p.pregnancy_id = pv.pregnancy_id
WHERE p.status = 'ongoing' AND pv.next_visit BETWEEN CURDATE() AND CURDATE() + INTERVAL 30 DAY
UNION ALL
SELECT 'Child Check-up', c.resident_id, c.next_visit, 'Growth monitoring'
FROM child_monitoring c
WHERE c.next_visit BETWEEN CURDATE() AND CURDATE() + INTERVAL 30 DAY
UNION ALL
SELECT 'Appointment', a.resident_id, a.scheduled_date, a.service_type
FROM appointments a
WHERE a.status = 'approved' AND a.scheduled_date BETWEEN CURDATE() AND CURDATE() + INTERVAL 30 DAY
UNION ALL
SELECT hvs.visit_type, hvs.resident_id, hvs.scheduled_date, IFNULL(hvs.notes, '')
FROM health_visit_schedules hvs
WHERE hvs.status = 'scheduled' AND hvs.scheduled_date BETWEEN CURDATE() AND CURDATE() + INTERVAL 30 DAY;

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================================
-- SAMPLE DATA
-- =====================================================================

-- Staff accounts (password for all: password123)
INSERT INTO users (user_id, username, password_hash, full_name, email, role, resident_id) VALUES
(1, 'admin',     '$2y$10$wCLysAYlxSkXiysDUQTu5OIC4cgDqkoN2/hi2jLHpApK.LLvdh6Y6', 'System Administrator',  'admin@bhsms.local', 'admin', NULL),
(2, 'bhw_maria', '$2y$10$wCLysAYlxSkXiysDUQTu5OIC4cgDqkoN2/hi2jLHpApK.LLvdh6Y6', 'Maria Cruz',            'maria@bhsms.local', 'bhw',   NULL),
(3, 'nurse_ana', '$2y$10$wCLysAYlxSkXiysDUQTu5OIC4cgDqkoN2/hi2jLHpApK.LLvdh6Y6', 'Ana Villanueva, RN',    'ana@bhsms.local',   'nurse', NULL),
(4, 'mho_reyes', '$2y$10$wCLysAYlxSkXiysDUQTu5OIC4cgDqkoN2/hi2jLHpApK.LLvdh6Y6', 'Dr. Ramon Reyes',       'reyes@bhsms.local', 'mho',   NULL);

-- Households (heads set after residents are inserted)
INSERT INTO households (household_id, household_no, purok, street_address, created_by) VALUES
(1, 'HH-2026-0001', 'Purok 1', '12 Pine St.',        2),
(2, 'HH-2026-0002', 'Purok 1', '45 Sampaguita St.',  2),
(3, 'HH-2026-0003', 'Purok 2', '8 Mabini St.',       2),
(4, 'HH-2026-0004', 'Purok 3', '101 Rizal Ave.',     2);

INSERT INTO residents (resident_id, household_id, first_name, middle_name, last_name, sex, birthdate, civil_status, relationship_to_head, contact_no, philhealth_no, occupation, is_4ps_member, is_senior, created_by) VALUES
-- Household 1: Dela Cruz
(1,  1, 'Juan',     'Santos',  'Dela Cruz', 'Male',   '1985-03-14', 'Married', 'Head',     '09171234501', '01-123456789-1', 'Driver',     0, 0, 2),
(2,  1, 'Rosa',     'Lim',     'Dela Cruz', 'Female', '1988-07-22', 'Married', 'Spouse',   '09171234502', '01-123456789-2', 'Vendor',     0, 0, 2),
(3,  1, 'Miguel',   'Lim',     'Dela Cruz', 'Male',   '2025-02-10', 'Single',  'Son',      NULL,          NULL,             NULL,         0, 0, 2),
(4,  1, 'Bea',      'Lim',     'Dela Cruz', 'Female', '2019-11-05', 'Single',  'Daughter', NULL,          NULL,             'Student',    0, 0, 2),
-- Household 2: Santos
(5,  2, 'Carlos',   'Ramos',   'Santos',    'Male',   '1993-01-30', 'Married', 'Head',     '09181234503', '01-223456789-1', 'Carpenter',  1, 0, 2),
(6,  2, 'Liza',     'Mendoza', 'Santos',    'Female', '1996-05-18', 'Married', 'Spouse',   '09181234504', '01-223456789-2', 'Housewife',  1, 0, 2),
(7,  2, 'Joshua',   'Mendoza', 'Santos',    'Male',   '2023-08-12', 'Single',  'Son',      NULL,          NULL,             NULL,         1, 0, 2),
-- Household 3: Bautista
(8,  3, 'Ernesto',  'Gomez',   'Bautista',  'Male',   '1955-09-09', 'Widowed', 'Head',     '09191234505', '01-323456789-1', 'Retired',    0, 1, 2),
(9,  3, 'Grace',    'Torres',  'Bautista',  'Female', '1982-12-01', 'Single',  'Daughter', '09191234506', '01-323456789-2', 'Teacher',    0, 0, 2),
-- Household 4: Aquino
(10, 4, 'Paolo',    'Diaz',    'Aquino',    'Male',   '1990-04-25', 'Live-in', 'Head',     '09201234507', '01-423456789-1', 'Call center agent', 0, 0, 2),
(11, 4, 'Kristine', 'Flores',  'Aquino',    'Female', '1999-10-03', 'Live-in', 'Partner',  '09201234508', NULL,             'Cashier',    0, 0, 2),
(12, 4, 'Althea',   'Flores',  'Aquino',    'Female', '2026-06-20', 'Single',  'Daughter', NULL,          NULL,             NULL,         0, 0, 2);

UPDATE households SET head_resident_id = 1  WHERE household_id = 1;
UPDATE households SET head_resident_id = 5  WHERE household_id = 2;
UPDATE households SET head_resident_id = 8  WHERE household_id = 3;
UPDATE households SET head_resident_id = 10 WHERE household_id = 4;

-- Resident portal accounts
INSERT INTO users (user_id, username, password_hash, full_name, email, role, resident_id) VALUES
(5, 'res_juan', '$2y$10$wCLysAYlxSkXiysDUQTu5OIC4cgDqkoN2/hi2jLHpApK.LLvdh6Y6', 'Juan Dela Cruz', 'juan@example.com', 'resident', 1),
(6, 'res_liza', '$2y$10$wCLysAYlxSkXiysDUQTu5OIC4cgDqkoN2/hi2jLHpApK.LLvdh6Y6', 'Liza Santos',    'liza@example.com', 'resident', 6);

INSERT INTO health_profiles (resident_id, blood_type, height_cm, weight_kg, allergies, existing_conditions, maintenance_meds, is_smoker, updated_by) VALUES
(1,  'O+',  168.0, 72.5, NULL,           'Hypertension',             'Amlodipine 5 mg once daily', 1, 3),
(2,  'A+',  155.0, 58.0, 'Seafood',      NULL,                       NULL,                         0, 3),
(3,  'O+',   76.0,  9.8, NULL,           NULL,                       NULL,                         0, 3),
(4,  'A+',  118.0, 21.0, NULL,           'Asthma',                   'Salbutamol inhaler as needed', 0, 3),
(5,  'B+',  170.0, 68.0, NULL,           NULL,                       NULL,                         1, 3),
(6,  'B+',  152.0, 55.5, 'Penicillin',   NULL,                       NULL,                         0, 3),
(7,  'B+',   88.0, 11.2, NULL,           NULL,                       NULL,                         0, 3),
(8,  'AB+', 162.0, 64.0, NULL,           'Diabetes Type 2, Hypertension', 'Metformin 500 mg, Losartan 50 mg', 0, 3),
(9,  'O-',  158.0, 52.0, NULL,           NULL,                       NULL,                         0, 3),
(10, 'A-',  175.0, 80.0, NULL,           NULL,                       NULL,                         0, 3),
(11, 'O+',  157.0, 50.0, NULL,           NULL,                       NULL,                         0, 3),
(12, 'O+',   60.0,  6.4, NULL,           NULL,                       NULL,                         0, 3);

INSERT INTO emergency_contacts (resident_id, contact_name, relationship, contact_no, address) VALUES
(1,  'Rosa Dela Cruz',     'Spouse',   '09171234502', '12 Pine St.'),
(2,  'Juan Dela Cruz',     'Spouse',   '09171234501', '12 Pine St.'),
(5,  'Liza Santos',        'Spouse',   '09181234504', '45 Sampaguita St.'),
(6,  'Carlos Santos',      'Spouse',   '09181234503', '45 Sampaguita St.'),
(8,  'Grace Bautista',     'Daughter', '09191234506', '8 Mabini St.'),
(9,  'Ernesto Bautista',   'Father',   '09191234505', '8 Mabini St.'),
(10, 'Kristine Aquino',    'Partner',  '09201234508', '101 Rizal Ave.'),
(11, 'Paolo Aquino',       'Partner',  '09201234507', '101 Rizal Ave.');

-- Appointments (inserted before consultations so they can be linked)
INSERT INTO appointments (appointment_id, resident_id, service_type, preferred_date, preferred_time, reason, status, scheduled_date, scheduled_time, remarks, requested_by, approved_by, approved_at) VALUES
(1, 1,  'General Consultation', '2026-10-06', '09:00:00', 'BP check and maintenance refill', 'completed', '2026-10-06', '09:00:00', NULL,                      5, 3, '2026-10-03 10:15:00'),
(2, 6,  'Prenatal Check-up',    '2026-11-20', '08:30:00', 'Monthly prenatal check-up',       'approved',  '2026-11-20', '08:30:00', NULL,                      6, 3, '2026-11-10 14:00:00'),
(3, 1,  'Medicine Request',     '2026-11-14', '10:00:00', 'Amlodipine refill',               'pending',   NULL,         NULL,       NULL,                      5, NULL, NULL),
(4, 3,  'Vaccination',          '2026-11-18', '09:00:00', 'MMR 2nd dose',                    'approved',  '2026-11-18', '09:00:00', NULL,                      2, 3, '2026-11-11 09:30:00'),
(5, 10, 'General Consultation', '2026-11-08', '13:00:00', 'Back pain',                       'rejected',  NULL,         NULL,       'Center closed (holiday). Please rebook.', 2, 3, '2026-11-06 08:00:00');

INSERT INTO consultations (consultation_id, resident_id, appointment_id, consultation_date, chief_complaint, symptoms, blood_pressure, temperature_c, pulse_rate, respiratory_rate, weight_kg, assessment, treatment_plan, referred_to, status, recorded_by) VALUES
(1,  4,  NULL, '2026-07-08 09:20:00', 'Cough and colds',       'Productive cough x3 days, runny nose',        NULL,     37.6, 98,  22, 20.5, 'Acute upper respiratory infection',           'Paracetamol syrup, increase fluids, rest',           NULL,     'completed', 3),
(2,  8,  NULL, '2026-07-21 10:05:00', 'Dizziness',             'Dizzy upon standing, mild headache',          '150/95', 36.7, 84,  18, 64.0, 'Uncontrolled hypertension',                   'Continue Losartan, low-salt diet, recheck in 2 wks', NULL,     'completed', 3),
(3,  5,  NULL, '2026-08-03 14:30:00', 'Wound on left foot',    'Laceration from nail, 2 cm',                  '120/80', 36.9, 80,  18, 68.0, 'Puncture wound, clean',                       'Wound cleaning, dressing; tetanus toxoid given',     NULL,     'completed', 3),
(4,  2,  NULL, '2026-08-19 08:45:00', 'Fever',                 'Fever 2 days, body malaise',                  '110/70', 38.4, 102, 20, 57.5, 'Fever, rule out dengue',                      'Paracetamol, CBC requested',                         'City Health Office', 'referred', 3),
(5,  8,  NULL, '2026-09-02 09:10:00', 'Follow-up BP',          'No complaints',                               '135/85', 36.5, 78,  18, 63.5, 'Hypertension, improving',                     'Continue meds',                                      NULL,     'completed', 3),
(6,  7,  NULL, '2026-09-15 10:40:00', 'Diarrhea',              'Loose stools 4x/day since yesterday',         NULL,     37.2, 110, 26, 11.0, 'Acute gastroenteritis, mild dehydration',     'ORS, Zinc supplement, monitor',                      NULL,     'completed', 3),
(7,  10, NULL, '2026-10-01 15:00:00', 'Headache',              'Tension-type headache, long work hours',      '125/80', 36.6, 76,  16, 80.0, 'Tension headache',                            'Paracetamol PRN, adequate sleep',                    NULL,     'completed', 2),
(8,  1,  1,    '2026-10-06 09:05:00', 'BP check and refill',   'Occasional headache',                         '140/90', 36.6, 82,  18, 72.0, 'Hypertension stage 1',                        'Refill Amlodipine, smoking cessation counseling',    NULL,     'completed', 3),
(9,  9,  NULL, '2026-10-22 11:30:00', 'Sore throat',           'Painful swallowing, no cough',                '110/70', 37.8, 90,  18, 52.0, 'Acute pharyngitis',                           'Amoxicillin 500 mg TID x7 days, warm gargle',        NULL,     'completed', 3),
(10, 4,  NULL, '2026-11-04 08:50:00', 'Wheezing',              'Wheezing at night, triggered by cold weather', NULL,    36.8, 100, 24, 21.0, 'Mild asthma exacerbation',                    'Salbutamol nebulization, refill inhaler',            NULL,     'completed', 3),
(11, 11, NULL, '2026-11-10 13:20:00', 'Abdominal pain',        'Epigastric pain after meals',                 '110/70', 36.7, 74,  16, 50.0, 'Dyspepsia',                                   'Antacid, small frequent meals',                      NULL,     'completed', 3);

-- Vaccine master list (based on DOH immunization program)
INSERT INTO vaccines (vaccine_id, vaccine_name, description, target_group, doses_required, interval_days) VALUES
(1,  'BCG',                     'Bacille Calmette-Guerin (tuberculosis), at birth',          'Infant',   1, NULL),
(2,  'Hepatitis B',             'Birth dose within 24 hours',                                 'Infant',   1, NULL),
(3,  'Pentavalent (DPT-HepB-Hib)', '6, 10 and 14 weeks',                                      'Infant',   3, 28),
(4,  'OPV',                     'Oral polio vaccine, 6, 10 and 14 weeks',                     'Infant',   3, 28),
(5,  'IPV',                     'Inactivated polio vaccine',                                  'Infant',   2, 112),
(6,  'PCV',                     'Pneumococcal conjugate vaccine',                             'Infant',   3, 28),
(7,  'MMR',                     'Measles, mumps, rubella, 9 and 12 months',                   'Infant',   2, 90),
(8,  'Td',                      'Tetanus-diphtheria for pregnant women / wounds',             'Pregnant', 2, 28),
(9,  'Influenza',               'Annual flu vaccine',                                         'Senior',   1, NULL),
(10, 'Pneumococcal (PPV23)',    'For seniors 60 and above',                                   'Senior',   1, NULL);

INSERT INTO vaccinations (resident_id, vaccine_id, dose_no, date_given, next_schedule, batch_lot_no, site_given, administered_by, remarks) VALUES
-- Miguel (born 2025-02-10): complete infant series, MMR 2 pending
(3, 1, 1, '2025-02-10', NULL,         'BCG-2501', 'Right deltoid', 3, 'Given at birth'),
(3, 2, 1, '2025-02-10', NULL,         'HB-2501',  'Left thigh',    3, 'Given at birth'),
(3, 3, 1, '2025-03-24', '2025-04-21', 'PV-2502',  'Left thigh',    3, NULL),
(3, 3, 2, '2025-04-21', '2025-05-19', 'PV-2502',  'Left thigh',    3, NULL),
(3, 3, 3, '2025-05-19', NULL,         'PV-2503',  'Left thigh',    3, NULL),
(3, 4, 1, '2025-03-24', '2025-04-21', 'OPV-2502', 'Oral',          3, NULL),
(3, 4, 2, '2025-04-21', '2025-05-19', 'OPV-2502', 'Oral',          3, NULL),
(3, 4, 3, '2025-05-19', NULL,         'OPV-2503', 'Oral',          3, NULL),
(3, 7, 1, '2025-11-10', '2026-11-18', 'MMR-2511', 'Right arm',     3, '2nd dose rescheduled'),
-- Joshua (born 2023-08-12): complete
(7, 3, 1, '2023-09-23', '2023-10-21', 'PV-2309',  'Left thigh',    3, NULL),
(7, 3, 2, '2023-10-21', '2023-11-18', 'PV-2310',  'Left thigh',    3, NULL),
(7, 3, 3, '2023-11-18', NULL,         'PV-2311',  'Left thigh',    3, NULL),
(7, 7, 1, '2024-05-12', '2024-08-12', 'MMR-2405', 'Right arm',     3, NULL),
(7, 7, 2, '2024-08-12', NULL,         'MMR-2408', 'Right arm',     3, NULL),
-- Althea (born 2026-06-20): infant series in progress
(12, 1, 1, '2026-06-20', NULL,         'BCG-2606', 'Right deltoid', 3, 'Given at birth'),
(12, 2, 1, '2026-06-20', NULL,         'HB-2606',  'Left thigh',    3, 'Given at birth'),
(12, 3, 1, '2026-08-01', '2026-08-29', 'PV-2608',  'Left thigh',    3, NULL),
(12, 3, 2, '2026-08-29', '2026-09-26', 'PV-2608',  'Left thigh',    3, NULL),
(12, 3, 3, '2026-09-26', NULL,         'PV-2609',  'Left thigh',    3, NULL),
(12, 6, 1, '2026-08-01', '2026-08-29', 'PCV-2608', 'Right thigh',   3, NULL),
(12, 6, 2, '2026-08-29', '2026-11-16', 'PCV-2608', 'Right thigh',   3, 'Delayed - child had fever'),
-- Liza (pregnant): Td
(6, 8, 1, '2026-09-10', '2026-11-20', 'TD-2609',  'Left deltoid',  3, 'Prenatal'),
-- Carlos: Td after wound
(5, 8, 1, '2026-08-03', '2026-08-31', 'TD-2608',  'Left deltoid',  3, 'Wound prophylaxis'),
(5, 8, 2, '2026-08-31', NULL,         'TD-2608',  'Left deltoid',  3, NULL),
-- Ernesto (senior)
(8, 9,  1, '2026-04-15', NULL,        'FLU-2604', 'Left deltoid',  3, 'Annual'),
(8, 10, 1, '2026-04-15', NULL,        'PPV-2604', 'Right deltoid', 3, NULL);

-- Maternal health: Liza (pregnant) and Kristine (delivered Althea)
INSERT INTO pregnancies (pregnancy_id, resident_id, lmp, edd, gravida, para, risk_level, risk_notes, status, delivery_date, delivery_place, registered_by) VALUES
(1, 6,  '2026-05-01', '2027-02-05', 2, 1, 'Low',      NULL,                        'ongoing',   NULL,         NULL,                          2),
(2, 11, '2025-09-15', '2026-06-22', 1, 0, 'Moderate', 'First pregnancy, mild anemia', 'delivered', '2026-06-20', 'Baguio General Hospital', 2);

INSERT INTO prenatal_visits (pregnancy_id, visit_date, aog_weeks, blood_pressure, weight_kg, fundal_height_cm, fetal_heart_rate, findings, supplements_given, next_visit, recorded_by) VALUES
(1, '2026-07-10', 10, '110/70', 54.0, NULL, NULL, 'Normal first-trimester visit',  'Folic acid',                     '2026-08-14', 3),
(1, '2026-08-14', 15, '110/70', 55.0, 14.0, 148,  'Normal',                        'Ferrous sulfate + Folic acid',   '2026-09-10', 3),
(1, '2026-09-10', 19, '100/70', 56.0, 18.0, 145,  'Normal, Td 1 given',            'Ferrous sulfate + Folic acid',   '2026-10-15', 3),
(1, '2026-10-15', 24, '110/80', 57.5, 23.0, 142,  'Normal fetal movement',         'Ferrous sulfate + Calcium',      '2026-11-20', 3),
(2, '2026-03-05', 24, '100/60', 47.0, 23.0, 150,  'Pale conjunctiva, Hgb 10.2',    'Ferrous sulfate (double dose)',  '2026-04-05', 3),
(2, '2026-05-10', 34, '110/70', 52.0, 32.0, 140,  'Improved, cephalic presentation', 'Ferrous sulfate',              '2026-06-07', 3);

INSERT INTO child_monitoring (resident_id, visit_date, weight_kg, height_cm, muac_cm, nutrition_status, milestones, remarks, next_visit, recorded_by) VALUES
(3,  '2026-05-12', 9.2,  73.0, 14.0, 'Normal',      'Walks with support',      NULL,                          '2026-08-12', 2),
(3,  '2026-08-12', 9.6,  75.5, 14.2, 'Normal',      'Walks alone, few words',  NULL,                          '2026-11-12', 2),
(7,  '2026-06-20', 10.8, 86.0, 13.8, 'Underweight', 'Speaks in phrases',       'Enrolled in feeding program', '2026-09-20', 2),
(7,  '2026-09-20', 11.2, 88.0, 14.0, 'Underweight', NULL,                      'Slight improvement',          '2026-12-01', 2),
(12, '2026-08-01', 4.9,  56.0, NULL, 'Normal',      'Social smile',            'Exclusively breastfed',       '2026-10-01', 2),
(12, '2026-10-01', 6.1,  59.5, NULL, 'Normal',      'Holds head up',           NULL,                          '2026-12-01', 2);

INSERT INTO health_visit_schedules (resident_id, visit_type, scheduled_date, assigned_to, status, notes) VALUES
(6,  'Prenatal',       '2026-11-20', 3, 'scheduled', '24-28 wk check, CBC'),
(7,  'Home Visit',     '2026-11-25', 2, 'scheduled', 'Feeding program follow-up'),
(8,  'Follow-up',      '2026-11-17', 2, 'scheduled', 'BP monitoring'),
(12, 'Postnatal',      '2026-07-01', 2, 'done',      'Mother and baby doing well'),
(3,  'Child Check-up', '2026-11-12', 2, 'scheduled', 'Quarterly growth monitoring');

-- Medicine inventory
INSERT INTO medicines (medicine_id, generic_name, brand_name, dosage_form, strength, unit, reorder_level) VALUES
(1,  'Paracetamol',            'Biogesic',  'Tablet',     '500 mg',      'pcs',    200),
(2,  'Paracetamol',            'Tempra',    'Syrup',      '120 mg/5 mL', 'bottle', 20),
(3,  'Amoxicillin',            NULL,        'Capsule',    '500 mg',      'pcs',    150),
(4,  'Amlodipine',             NULL,        'Tablet',     '5 mg',        'pcs',    100),
(5,  'Losartan',               NULL,        'Tablet',     '50 mg',       'pcs',    100),
(6,  'Metformin',              NULL,        'Tablet',     '500 mg',      'pcs',    100),
(7,  'Oral Rehydration Salts', 'ORS',       'Sachet',     '20.5 g',      'sachet', 50),
(8,  'Zinc Sulfate',           NULL,        'Syrup',      '20 mg/5 mL',  'bottle', 15),
(9,  'Ferrous Sulfate + Folic Acid', NULL,  'Tablet',     '60 mg/400 mcg', 'pcs',  200),
(10, 'Salbutamol',             'Ventolin',  'Other',      '100 mcg inhaler', 'pcs', 10),
(11, 'Aluminum Hydroxide + Magnesium Hydroxide', 'Kremil-S', 'Tablet', NULL,  'pcs',  50);

INSERT INTO medicine_stock (stock_id, medicine_id, batch_no, quantity_received, quantity_remaining, expiry_date, date_received, source, received_by) VALUES
(1,  1,  'PCM-2601',  1000, 640, '2028-01-31', '2026-01-15', 'DOH-CAR',            3),
(2,  2,  'PCS-2603',    50,  12, '2027-03-31', '2026-03-10', 'DOH-CAR',            3),   -- low stock
(3,  3,  'AMX-2602',   500, 380, '2027-12-31', '2026-02-20', 'City Health Office', 3),
(4,  4,  'AML-2604',   300,  60, '2027-10-31', '2026-04-01', 'City Health Office', 3),   -- low stock
(5,  5,  'LOS-2604',   300, 210, '2027-10-31', '2026-04-01', 'City Health Office', 3),
(6,  6,  'MET-2604',   300, 225, '2027-09-30', '2026-04-01', 'City Health Office', 3),
(7,  7,  'ORS-2505',   100,  10, '2026-09-30', '2025-05-10', 'DOH-CAR',            3),   -- expired batch
(8,  7,  'ORS-2607',   100,  85, '2028-06-30', '2026-07-01', 'DOH-CAR',            3),
(9,  8,  'ZNC-2606',    30,  27, '2027-12-31', '2026-06-15', 'DOH-CAR',            3),
(10, 9,  'FSF-2605',   600, 470, '2028-05-31', '2026-05-20', 'DOH-CAR',            3),
(11, 10, 'SAL-2606',    12,   0, '2027-06-30', '2026-06-01', 'City Health Office', 3),   -- out of stock
(12, 11, 'KRS-2608',   100,  90, '2028-08-31', '2026-08-05', 'Donation',           3);

INSERT INTO medicine_distribution (stock_id, medicine_id, resident_id, consultation_id, quantity, distribution_date, instructions, given_by) VALUES
(2,  2,  4,  1,    1,  '2026-07-08', '5 mL every 4-6 hrs for fever',            3),
(5,  5,  8,  2,    30, '2026-07-21', '1 tab once daily',                        3),
(1,  1,  2,  4,    10, '2026-08-19', '1 tab every 4-6 hrs for fever',           3),
(5,  5,  8,  5,    30, '2026-09-02', '1 tab once daily',                        3),
(6,  6,  8,  5,    60, '2026-09-02', '1 tab twice daily after meals',           3),
(8,  7,  7,  6,    5,  '2026-09-15', '1 sachet in 200 mL water after each loose stool', 3),
(9,  8,  7,  6,    1,  '2026-09-15', '5 mL once daily for 14 days',             3),
(1,  1,  10, 7,    6,  '2026-10-01', '1 tab every 6 hrs as needed',             2),
(4,  4,  1,  8,    30, '2026-10-06', '1 tab once daily',                        3),
(3,  3,  9,  9,    21, '2026-10-22', '1 cap every 8 hrs for 7 days',            3),
(11, 10, 4,  10,   1,  '2026-11-04', '2 puffs as needed for wheezing',          3),
(12, 11, 11, 11,   10, '2026-11-10', '1 tab chewed after meals',                3),
(10, 9,  6,  NULL, 30, '2026-10-15', '1 tab daily (prenatal)',                  3);

INSERT INTO stock_adjustments (stock_id, adjustment_type, quantity, reason, adjusted_by) VALUES
(7, 'Expired', -10, 'Batch ORS-2505 expired 2026-09-30, for disposal', 3);

INSERT INTO notifications (user_id, title, message, link, is_read) VALUES
(3, 'New appointment request', 'Juan Dela Cruz requested a Medicine Request on 2026-11-14.', 'modules/appointments/index.php', 0),
(5, 'Appointment approved',    'Your General Consultation on 2026-10-06 was approved.',     'portal/appointments.php',            1),
(6, 'Appointment approved',    'Your Prenatal Check-up on 2026-11-20 at 8:30 AM was approved.', 'portal/appointments.php',        0),
(3, 'Low stock alert',         'Amlodipine 5 mg is below reorder level.',                     'modules/inventory/index.php',        0),
(3, 'Out of stock',            'Salbutamol inhaler is out of stock.',                         'modules/inventory/index.php',        0);

INSERT INTO activity_logs (user_id, action, table_name, record_id, details, ip_address) VALUES
(1, 'LOGIN',  NULL,            NULL, 'Admin logged in',                       '127.0.0.1'),
(2, 'CREATE', 'residents',     12,   'Registered newborn Althea Aquino',      '127.0.0.1'),
(3, 'CREATE', 'consultations', 11,   'Recorded consultation for Kristine Aquino', '127.0.0.1'),
(3, 'UPDATE', 'appointments',  2,    'Approved prenatal check-up',            '127.0.0.1'),
(5, 'CREATE', 'appointments',  3,    'Resident requested medicine refill',    '127.0.0.1');

-- Online registrations waiting for verification (password: password123)
--  * Grace Bautista matches her existing resident record (#9)
--  * Mark Villanueva is a new resident not yet in the registry
INSERT INTO residents (resident_id, household_id, first_name, middle_name, last_name, sex, birthdate, civil_status, contact_no, status) VALUES
(13, NULL, 'Mark', 'Reyes', 'Villanueva', 'Male', '1998-02-14', 'Single', '09221234509', 'pending');

INSERT INTO users (user_id, username, password_hash, full_name, email, role, resident_id, registered_address, status) VALUES
(7, 'res_grace', '$2y$10$wCLysAYlxSkXiysDUQTu5OIC4cgDqkoN2/hi2jLHpApK.LLvdh6Y6', 'Grace Bautista',  'grace@example.com', 'resident', 9,  '8 Mabini St., Purok 2',     'pending'),
(8, 'res_mark',  '$2y$10$wCLysAYlxSkXiysDUQTu5OIC4cgDqkoN2/hi2jLHpApK.LLvdh6Y6', 'Mark Villanueva', 'mark@example.com',  'resident', 13, '23 Bonifacio St., Purok 3', 'pending');

-- Staff who registered online, waiting for the admin's approval (password: password123)
INSERT INTO users (user_id, username, password_hash, full_name, email, contact_no, id_number, role, status) VALUES
(9,  'bhw_jose',   '$2y$10$wCLysAYlxSkXiysDUQTu5OIC4cgDqkoN2/hi2jLHpApK.LLvdh6Y6', 'Jose Ramirez',     'jose@example.com',   '09231234510', 'BHW-2026-014', 'bhw',   'pending'),
(10, 'nurse_carla', '$2y$10$wCLysAYlxSkXiysDUQTu5OIC4cgDqkoN2/hi2jLHpApK.LLvdh6Y6', 'Carla Mendoza, RN', 'carla@example.com', '09241234511', '0712345',      'nurse', 'pending');

-- =====================================================================
-- 8. HUMAN RESOURCE + NUTRITION (same as update_03_hr_nutrition.sql)
-- =====================================================================
SET FOREIGN_KEY_CHECKS = 0;


-- ---------------------------------------------------------------------
-- HUMAN RESOURCE
-- ---------------------------------------------------------------------

-- Personnel 201 file (one row per health center worker; may be linked to a login account)
CREATE TABLE IF NOT EXISTS personnel (
    personnel_id        INT AUTO_INCREMENT PRIMARY KEY,
    user_id             INT NULL UNIQUE,                 -- login account of this worker (optional)
    employee_no         VARCHAR(30)  NOT NULL UNIQUE,    -- e.g. EMP-2026-0001
    first_name          VARCHAR(80)  NOT NULL,
    middle_name         VARCHAR(80)  NULL,
    last_name           VARCHAR(80)  NOT NULL,
    suffix              VARCHAR(10)  NULL,
    sex                 ENUM('Male','Female') NOT NULL,
    birthdate           DATE NULL,
    civil_status        ENUM('Single','Married','Widowed','Separated','Live-in') NULL,
    position            VARCHAR(100) NOT NULL,           -- Barangay Health Worker, Nurse, Midwife, BNS, ...
    employment_status   ENUM('Permanent','Casual','Contractual','Job Order','Volunteer') NOT NULL DEFAULT 'Volunteer',
    date_hired          DATE NULL,
    assigned_area       VARCHAR(100) NULL,               -- purok / catchment area
    monthly_rate        DECIMAL(10,2) NULL,              -- salary or honorarium
    contact_no          VARCHAR(20)  NULL,
    email               VARCHAR(150) NULL,
    address             VARCHAR(255) NULL,
    tin_no              VARCHAR(20)  NULL,
    philhealth_no       VARCHAR(20)  NULL,
    license_no          VARCHAR(30)  NULL,               -- PRC license / BHW accreditation
    license_expiry      DATE NULL,
    emergency_contact   VARCHAR(150) NULL,
    emergency_contact_no VARCHAR(20) NULL,
    status              ENUM('active','on leave','resigned','retired','terminated') NOT NULL DEFAULT 'active',
    remarks             TEXT NULL,
    created_by          INT NULL,
    created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_personnel_name (last_name, first_name),
    INDEX idx_personnel_status (status),
    CONSTRAINT fk_personnel_user FOREIGN KEY (user_id)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_personnel_created_by FOREIGN KEY (created_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Daily attendance / duty log
CREATE TABLE IF NOT EXISTS personnel_attendance (
    attendance_id   INT AUTO_INCREMENT PRIMARY KEY,
    personnel_id    INT NOT NULL,
    work_date       DATE NOT NULL,
    time_in         TIME NULL,
    time_out        TIME NULL,
    status          ENUM('Present','Late','Half day','Absent','On leave','Official business') NOT NULL DEFAULT 'Present',
    remarks         VARCHAR(255) NULL,
    recorded_by     INT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_attendance_day (personnel_id, work_date),
    INDEX idx_attendance_date (work_date),
    CONSTRAINT fk_attendance_personnel FOREIGN KEY (personnel_id)
        REFERENCES personnel(personnel_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_attendance_recorded_by FOREIGN KEY (recorded_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Leave applications (any staff files, HR approves)
CREATE TABLE IF NOT EXISTS leave_requests (
    leave_id        INT AUTO_INCREMENT PRIMARY KEY,
    personnel_id    INT NOT NULL,
    leave_type      ENUM('Vacation','Sick','Emergency','Maternity','Paternity','Special Privilege','Solo Parent','Others') NOT NULL,
    date_from       DATE NOT NULL,
    date_to         DATE NOT NULL,
    days            DECIMAL(4,1) NOT NULL,
    reason          VARCHAR(255) NOT NULL,
    status          ENUM('pending','approved','rejected','cancelled') NOT NULL DEFAULT 'pending',
    remarks         VARCHAR(255) NULL,                   -- HR's note / reason for rejection
    filed_by        INT NULL,
    reviewed_by     INT NULL,
    reviewed_at     DATETIME NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_leave_status (status),
    INDEX idx_leave_dates (date_from, date_to),
    CONSTRAINT fk_leave_personnel FOREIGN KEY (personnel_id)
        REFERENCES personnel(personnel_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_leave_filed_by FOREIGN KEY (filed_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_leave_reviewed_by FOREIGN KEY (reviewed_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Trainings and seminars attended
CREATE TABLE IF NOT EXISTS personnel_trainings (
    training_id     INT AUTO_INCREMENT PRIMARY KEY,
    personnel_id    INT NOT NULL,
    title           VARCHAR(200) NOT NULL,
    provider        VARCHAR(150) NULL,                   -- DOH, NNC, Municipal Health Office, ...
    date_from       DATE NOT NULL,
    date_to         DATE NULL,
    hours           DECIMAL(5,1) NULL,
    certificate_no  VARCHAR(50)  NULL,
    created_by      INT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_training_personnel FOREIGN KEY (personnel_id)
        REFERENCES personnel(personnel_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_training_created_by FOREIGN KEY (created_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- NUTRITION (Nutrition Action Officer)
--   Operation Timbang Plus measurements are saved in the existing
--   child_monitoring table, so Child Health and Nutrition share them.
-- ---------------------------------------------------------------------


-- Feeding / nutrition programs (e.g. Supplementary Feeding Program, Dietary Supplementation Program)
CREATE TABLE IF NOT EXISTS nutrition_programs (
    program_id      INT AUTO_INCREMENT PRIMARY KEY,
    program_name    VARCHAR(150) NOT NULL,
    program_type    ENUM('Supplementary Feeding','Dietary Supplementation','Nutrition Education','Micronutrient Supplementation','Other') NOT NULL,
    target_group    VARCHAR(100) NULL,                   -- e.g. Underweight children 6-59 months
    start_date      DATE NOT NULL,
    end_date        DATE NULL,
    sessions_planned INT NULL,                           -- e.g. 120 feeding days
    venue           VARCHAR(150) NULL,
    funding_source  VARCHAR(100) NULL,
    description     TEXT NULL,
    status          ENUM('planned','ongoing','completed','cancelled') NOT NULL DEFAULT 'planned',
    created_by      INT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_program_created_by FOREIGN KEY (created_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS program_beneficiaries (
    beneficiary_id      INT AUTO_INCREMENT PRIMARY KEY,
    program_id          INT NOT NULL,
    resident_id         INT NOT NULL,
    enrolled_date       DATE NOT NULL,
    baseline_weight_kg  DECIMAL(5,2) NULL,
    baseline_height_cm  DECIMAL(5,2) NULL,
    baseline_status     VARCHAR(30) NULL,
    latest_weight_kg    DECIMAL(5,2) NULL,
    latest_status       VARCHAR(30) NULL,
    outcome             ENUM('enrolled','improved','rehabilitated','no change','worsened','dropped') NOT NULL DEFAULT 'enrolled',
    remarks             VARCHAR(255) NULL,
    created_by          INT NULL,
    created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_program_resident (program_id, resident_id),
    CONSTRAINT fk_benef_program FOREIGN KEY (program_id)
        REFERENCES nutrition_programs(program_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_benef_resident FOREIGN KEY (resident_id)
        REFERENCES residents(resident_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_benef_created_by FOREIGN KEY (created_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- One feeding day / session and who attended it
CREATE TABLE IF NOT EXISTS program_sessions (
    session_id      INT AUTO_INCREMENT PRIMARY KEY,
    program_id      INT NOT NULL,
    session_date    DATE NOT NULL,
    menu            VARCHAR(255) NULL,                   -- food served / topic discussed
    notes           VARCHAR(255) NULL,
    recorded_by     INT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_program_day (program_id, session_date),
    CONSTRAINT fk_session_program FOREIGN KEY (program_id)
        REFERENCES nutrition_programs(program_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_session_recorded_by FOREIGN KEY (recorded_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS session_attendance (
    session_id      INT NOT NULL,
    beneficiary_id  INT NOT NULL,
    weight_kg       DECIMAL(5,2) NULL,                   -- optional weigh-in on that day
    PRIMARY KEY (session_id, beneficiary_id),
    CONSTRAINT fk_att_session FOREIGN KEY (session_id)
        REFERENCES program_sessions(session_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_att_beneficiary FOREIGN KEY (beneficiary_id)
        REFERENCES program_beneficiaries(beneficiary_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Vitamin A, iron, micronutrient powder, deworming, ...
CREATE TABLE IF NOT EXISTS micronutrient_supplements (
    supplement_id   INT AUTO_INCREMENT PRIMARY KEY,
    resident_id     INT NOT NULL,
    supplement_type ENUM('Vitamin A','Iron','Iron with Folic Acid','Micronutrient Powder','Deworming','Iodized Oil','Zinc','Calcium','Other') NOT NULL,
    dose            VARCHAR(60) NULL,                    -- e.g. 100,000 IU / 200,000 IU / 400 mg
    date_given      DATE NOT NULL,
    next_due        DATE NULL,
    remarks         VARCHAR(255) NULL,
    given_by        INT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_supp_resident (resident_id),
    INDEX idx_supp_due (next_due),
    CONSTRAINT fk_supp_resident FOREIGN KEY (resident_id)
        REFERENCES residents(resident_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_supp_given_by FOREIGN KEY (given_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- SAMPLE DATA (password for the new accounts: password123)
-- ---------------------------------------------------------------------
INSERT INTO users (username, password_hash, full_name, email, contact_no, id_number, role, status)
SELECT * FROM (SELECT 'hr_luz' AS u, '$2y$10$wCLysAYlxSkXiysDUQTu5OIC4cgDqkoN2/hi2jLHpApK.LLvdh6Y6' AS p, 'Luzviminda Garcia' AS n,
                      'luz@bhsms.local' AS e, '09251234512' AS c, 'HR-2026-001' AS i, 'hr' AS r, 'active' AS s) x
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'hr_luz');

INSERT INTO users (username, password_hash, full_name, email, contact_no, id_number, role, status)
SELECT * FROM (SELECT 'nao_ben' AS u, '$2y$10$wCLysAYlxSkXiysDUQTu5OIC4cgDqkoN2/hi2jLHpApK.LLvdh6Y6' AS p, 'Benjamin Torres, RND' AS n,
                      'ben@bhsms.local' AS e, '09261234513' AS c, 'NAO-2026-001' AS i, 'nao' AS r, 'active' AS s) x
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'nao_ben');

-- 201 files of the existing staff accounts
INSERT INTO personnel (user_id, employee_no, first_name, last_name, sex, position, employment_status, date_hired, assigned_area, contact_no, email, license_no, status, created_by)
SELECT u.user_id, d.emp, d.fn, d.ln, d.sex, d.pos, d.es, d.hired, d.area, d.contact, u.email, d.lic, 'active', 1
FROM (
    SELECT 'bhw_maria' AS uname, 'EMP-2026-0001' AS emp, 'Maria' AS fn, 'Cruz' AS ln, 'Female' AS sex, 'Barangay Health Worker' AS pos, 'Volunteer' AS es, '2019-06-03' AS hired, 'Purok 1-2' AS area, '09171110001' AS contact, 'BHW-2019-007' AS lic
    UNION ALL SELECT 'nurse_ana', 'EMP-2026-0002', 'Ana', 'Villanueva', 'Female', 'Nurse I', 'Permanent', '2021-01-11', 'Health Center', '09171110002', '0654321'
    UNION ALL SELECT 'mho_reyes', 'EMP-2026-0003', 'Ramon', 'Reyes', 'Male', 'Municipal Health Officer', 'Permanent', '2015-03-02', 'Municipality', '09171110003', '0123456'
    UNION ALL SELECT 'hr_luz', 'EMP-2026-0004', 'Luzviminda', 'Garcia', 'Female', 'Human Resource Officer', 'Permanent', '2018-08-15', 'Health Center', '09251234512', NULL
    UNION ALL SELECT 'nao_ben', 'EMP-2026-0005', 'Benjamin', 'Torres', 'Male', 'Nutrition Action Officer', 'Permanent', '2020-02-17', 'Municipality', '09261234513', 'RND-0098765'
) d JOIN users u ON u.username = d.uname
WHERE NOT EXISTS (SELECT 1 FROM personnel p WHERE p.employee_no = d.emp);

INSERT INTO personnel (employee_no, first_name, last_name, sex, position, employment_status, date_hired, assigned_area, contact_no, status, created_by)
SELECT 'EMP-2026-0006', 'Teresita', 'Lopez', 'Female', 'Barangay Nutrition Scholar', 'Volunteer', '2022-07-01', 'Purok 3', '09171110006', 'active', 1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM personnel WHERE employee_no = 'EMP-2026-0006');

INSERT INTO personnel_trainings (personnel_id, title, provider, date_from, date_to, hours, created_by)
SELECT p.personnel_id, 'Philippine Integrated Management of Acute Malnutrition (PIMAM)', 'National Nutrition Council', '2026-03-09', '2026-03-11', 24, 1
FROM personnel p WHERE p.employee_no = 'EMP-2026-0005'
  AND NOT EXISTS (SELECT 1 FROM personnel_trainings t WHERE t.personnel_id = p.personnel_id);

INSERT INTO leave_requests (personnel_id, leave_type, date_from, date_to, days, reason, status, filed_by)
SELECT p.personnel_id, 'Vacation', '2026-12-22', '2026-12-23', 2, 'Family gathering in the province', 'pending', p.user_id
FROM personnel p WHERE p.employee_no = 'EMP-2026-0001'
  AND NOT EXISTS (SELECT 1 FROM leave_requests l WHERE l.personnel_id = p.personnel_id);

INSERT INTO nutrition_programs (program_name, program_type, target_group, start_date, end_date, sessions_planned, venue, funding_source, description, status, created_by)
SELECT 'Supplementary Feeding Program 2026', 'Supplementary Feeding', 'Underweight children 2-5 years old', '2026-09-01', '2026-12-18', 60,
       'Barangay Day Care Center', 'LGU / DSWD', 'Hot meals 5 days a week with monthly weighing.', 'ongoing', 1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM nutrition_programs WHERE program_name = 'Supplementary Feeding Program 2026');

INSERT INTO program_beneficiaries (program_id, resident_id, enrolled_date, baseline_weight_kg, baseline_height_cm, baseline_status, latest_weight_kg, latest_status, outcome, created_by)
SELECT np.program_id, 7, '2026-09-01', 10.8, 86.0, 'Underweight', 11.2, 'Underweight', 'improved', 1
FROM nutrition_programs np WHERE np.program_name = 'Supplementary Feeding Program 2026'
  AND EXISTS (SELECT 1 FROM residents WHERE resident_id = 7)
  AND NOT EXISTS (SELECT 1 FROM program_beneficiaries b WHERE b.program_id = np.program_id AND b.resident_id = 7);

INSERT INTO micronutrient_supplements (resident_id, supplement_type, dose, date_given, next_due, remarks, given_by)
SELECT 3, 'Vitamin A', '200,000 IU', '2026-05-12', '2026-11-12', 'Garantisadong Pambata', 2 FROM DUAL
WHERE EXISTS (SELECT 1 FROM residents WHERE resident_id = 3)
  AND NOT EXISTS (SELECT 1 FROM micronutrient_supplements WHERE resident_id = 3);
INSERT INTO micronutrient_supplements (resident_id, supplement_type, dose, date_given, next_due, remarks, given_by)
SELECT 7, 'Deworming', 'Albendazole 400 mg', '2026-07-20', '2027-01-20', NULL, 2 FROM DUAL
WHERE EXISTS (SELECT 1 FROM residents WHERE resident_id = 7)
  AND NOT EXISTS (SELECT 1 FROM micronutrient_supplements WHERE resident_id = 7);

-- =====================================================================
-- 9. FINAL REQUIREMENTS (same as update_04_final_requirements.sql):
--    resident photo & documents, appointment reference no. / under review / history,
--    announcements & health advisories, resident feedback & ratings
-- =====================================================================
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- 1. Resident photo and documents
-- ---------------------------------------------------------------------
ALTER TABLE residents ADD COLUMN IF NOT EXISTS photo_path VARCHAR(255) NULL AFTER occupation;

CREATE TABLE IF NOT EXISTS resident_documents (
    document_id    INT AUTO_INCREMENT PRIMARY KEY,
    resident_id    INT NOT NULL,
    title          VARCHAR(150) NOT NULL,
    doc_type       ENUM('Valid ID','Birth Certificate','PhilHealth ID / MDR','Laboratory Result','Medical Certificate',
                        'Referral Slip','Prescription','Barangay Certificate','Other') NOT NULL DEFAULT 'Other',
    file_path      VARCHAR(255) NOT NULL,             -- random file name inside uploads/documents/
    original_name  VARCHAR(255) NOT NULL,
    mime_type      VARCHAR(100) NOT NULL,
    file_size      INT NOT NULL,
    uploaded_by    INT NULL,
    uploaded_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_docs_resident (resident_id),
    CONSTRAINT fk_docs_resident FOREIGN KEY (resident_id)
        REFERENCES residents(resident_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_docs_uploaded_by FOREIGN KEY (uploaded_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 2. Appointment workflow: reference no., under review, assignment, history
--    Pending -> Under review (assigned) -> Approved / Rejected -> Completed / No-show
-- ---------------------------------------------------------------------
ALTER TABLE appointments
    MODIFY status ENUM('pending','under review','approved','rejected','completed','cancelled','no-show') NOT NULL DEFAULT 'pending';
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS reference_no VARCHAR(20) NULL AFTER appointment_id;
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS assigned_to  INT NULL AFTER requested_by;
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS reviewed_at  DATETIME NULL AFTER assigned_to;
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS completed_at DATETIME NULL AFTER approved_at;

UPDATE appointments SET reference_no = CONCAT('APT-', YEAR(created_at), '-', LPAD(appointment_id, 4, '0')) WHERE reference_no IS NULL;

ALTER TABLE appointments ADD UNIQUE INDEX IF NOT EXISTS uq_appt_ref (reference_no);

-- FK for the assigned staff member (skipped if it already exists)
SET @fk := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
            WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = 'appointments' AND CONSTRAINT_NAME = 'fk_appt_assigned');
SET @sql := IF(@fk = 0, 'ALTER TABLE appointments ADD CONSTRAINT fk_appt_assigned FOREIGN KEY (assigned_to) REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE', 'SELECT 1');
PREPARE st FROM @sql; EXECUTE st; DEALLOCATE PREPARE st;

-- Every status change with timestamp, who did it and remarks
CREATE TABLE IF NOT EXISTS appointment_logs (
    log_id          INT AUTO_INCREMENT PRIMARY KEY,
    appointment_id  INT NOT NULL,
    status          VARCHAR(20) NOT NULL,
    remarks         VARCHAR(255) NULL,
    changed_by      INT NULL,
    changed_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_appt_logs (appointment_id, changed_at),
    CONSTRAINT fk_appt_logs_appt FOREIGN KEY (appointment_id)
        REFERENCES appointments(appointment_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_appt_logs_user FOREIGN KEY (changed_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- History for the sample appointments (only if none yet)
INSERT INTO appointment_logs (appointment_id, status, remarks, changed_by, changed_at)
SELECT a.appointment_id, 'pending', 'Request submitted', a.requested_by, a.created_at
FROM appointments a WHERE NOT EXISTS (SELECT 1 FROM appointment_logs l WHERE l.appointment_id = a.appointment_id);

INSERT INTO appointment_logs (appointment_id, status, remarks, changed_by, changed_at)
SELECT a.appointment_id, IF(a.status = 'rejected', 'rejected', 'approved'), a.remarks, a.approved_by, a.approved_at
FROM appointments a
WHERE a.status IN ('approved', 'rejected', 'completed') AND a.approved_at IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM appointment_logs l WHERE l.appointment_id = a.appointment_id AND l.status <> 'pending');

INSERT INTO appointment_logs (appointment_id, status, remarks, changed_by, changed_at)
SELECT a.appointment_id, 'completed', 'Consultation recorded', a.approved_by, COALESCE(c.consultation_date, a.updated_at)
FROM appointments a LEFT JOIN consultations c ON c.appointment_id = a.appointment_id
WHERE a.status = 'completed'
  AND NOT EXISTS (SELECT 1 FROM appointment_logs l WHERE l.appointment_id = a.appointment_id AND l.status = 'completed');

-- ---------------------------------------------------------------------
-- 3. Announcements / health advisories (shown on the public homepage)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS announcements (
    announcement_id  INT AUTO_INCREMENT PRIMARY KEY,
    title            VARCHAR(150) NOT NULL,
    category         ENUM('Health Advisory','Announcement','Vaccination Drive','Event','Schedule Change') NOT NULL DEFAULT 'Announcement',
    body             TEXT NOT NULL,
    publish_date     DATE NOT NULL,
    expiry_date      DATE NULL,                         -- hidden from the public after this date
    is_published     TINYINT(1) NOT NULL DEFAULT 1,
    is_pinned        TINYINT(1) NOT NULL DEFAULT 0,
    created_by       INT NULL,
    created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_ann_publish (is_published, publish_date),
    CONSTRAINT fk_ann_created_by FOREIGN KEY (created_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

INSERT INTO announcements (title, category, body, publish_date, expiry_date, is_published, is_pinned, created_by)
SELECT * FROM (
    SELECT 'Dengue alert: search and destroy mosquito breeding sites' AS t, 'Health Advisory' AS c,
           'Dengue cases are rising during the rainy season. Cover water containers, clean gutters every week and use mosquito repellent. Go to the health center right away if you have fever for 2 days or more.' AS b,
           '2026-11-03' AS p, '2026-12-31' AS x, 1 AS pub, 1 AS pin, 3 AS u
    UNION ALL SELECT 'Measles-Rubella catch-up vaccination this Wednesday', 'Vaccination Drive',
           'Free MR vaccine for children 9 to 59 months old on Wednesday, 8:00 AM to 12:00 NN at the barangay health center. Bring the child''s vaccination card.',
           '2026-11-16', '2026-11-30', 1, 0, 3
    UNION ALL SELECT 'Health center closed on November 30 (Bonifacio Day)', 'Schedule Change',
           'The health center is closed on Monday, November 30. For emergencies, go to the nearest hospital.',
           '2026-11-20', '2026-12-01', 1, 0, 1
    UNION ALL SELECT 'Free blood pressure and blood sugar screening for seniors', 'Event',
           'Senior citizens can get free BP and blood sugar screening every Friday afternoon this December.',
           '2026-11-21', '2026-12-31', 1, 0, 3
) s
WHERE NOT EXISTS (SELECT 1 FROM announcements);

-- ---------------------------------------------------------------------
-- 4. Resident feedback & ratings
--    Pending -> Under review -> Resolved (staff response shown to the resident)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS feedback (
    feedback_id     INT AUTO_INCREMENT PRIMARY KEY,
    reference_no    VARCHAR(20) NOT NULL UNIQUE,        -- e.g. FB-2026-0001
    resident_id     INT NULL,
    user_id         INT NULL,
    category        ENUM('Service','Staff','Facility','Medicine Availability','Appointment','Other') NOT NULL DEFAULT 'Service',
    rating          TINYINT NOT NULL,                   -- 1 to 5 stars
    comments        TEXT NOT NULL,
    status          ENUM('pending','under review','resolved') NOT NULL DEFAULT 'pending',
    response        TEXT NULL,
    responded_by    INT NULL,
    responded_at    DATETIME NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_feedback_status (status),
    CONSTRAINT chk_feedback_rating CHECK (rating BETWEEN 1 AND 5),
    CONSTRAINT fk_feedback_resident FOREIGN KEY (resident_id)
        REFERENCES residents(resident_id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_feedback_user FOREIGN KEY (user_id)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_feedback_responded_by FOREIGN KEY (responded_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

INSERT INTO feedback (reference_no, resident_id, user_id, category, rating, comments, status, response, responded_by, responded_at, created_at)
SELECT * FROM (
    SELECT 'FB-2026-0001' AS r, 1 AS rid, 5 AS uid, 'Service' AS c, 5 AS rt,
           'Fast BP check and the nurse explained my medicines clearly.' AS cm, 'resolved' AS st,
           'Thank you, Mr. Dela Cruz! Keep taking your maintenance medicine.' AS rs, 3 AS rb, '2026-10-08 09:00:00' AS ra, '2026-10-07 18:20:00' AS ca
    UNION ALL SELECT 'FB-2026-0002', 6, 6, 'Medicine Availability', 3,
           'The ferrous sulfate ran out last month, I had to buy outside.', 'pending', NULL, NULL, NULL, '2026-11-12 10:05:00'
) s
WHERE NOT EXISTS (SELECT 1 FROM feedback)
  AND EXISTS (SELECT 1 FROM users WHERE user_id = 6);

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================================
-- END OF FILE
-- =====================================================================
