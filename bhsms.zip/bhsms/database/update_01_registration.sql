-- =====================================================================
--  UPDATE 01: Resident online registration
--  Run this ONLY if you already imported bhsms.sql before this update.
--  (A fresh import of bhsms.sql already includes these changes.)
--
--  phpMyAdmin -> select database "bhsms" -> Import -> this file -> Go
--  Existing data is kept.
-- =====================================================================

USE bhsms;

ALTER TABLE users
    MODIFY status ENUM('active','inactive','pending','rejected') NOT NULL DEFAULT 'active',
    ADD COLUMN registered_address VARCHAR(255) NULL AFTER resident_id,
    ADD COLUMN remarks VARCHAR(255) NULL AFTER status,
    ADD COLUMN verified_by INT NULL AFTER remarks,
    ADD COLUMN verified_at DATETIME NULL AFTER verified_by,
    ADD INDEX idx_users_status (status),
    ADD CONSTRAINT fk_users_verified_by FOREIGN KEY (verified_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE residents
    MODIFY status ENUM('active','pending','transferred','deceased') NOT NULL DEFAULT 'active';

-- Sample registrations waiting for verification (password: password123)
INSERT INTO users (username, password_hash, full_name, email, role, resident_id, registered_address, status)
SELECT 'res_grace', '$2y$10$wCLysAYlxSkXiysDUQTu5OIC4cgDqkoN2/hi2jLHpApK.LLvdh6Y6', 'Grace Bautista', 'grace@example.com',
       'resident', r.resident_id, '8 Mabini St., Purok 2', 'pending'
FROM residents r
WHERE r.first_name = 'Grace' AND r.last_name = 'Bautista'
  AND NOT EXISTS (SELECT 1 FROM users u WHERE u.username = 'res_grace' OR u.resident_id = r.resident_id)
LIMIT 1;

INSERT INTO residents (household_id, first_name, middle_name, last_name, sex, birthdate, civil_status, contact_no, status)
VALUES (NULL, 'Mark', 'Reyes', 'Villanueva', 'Male', '1998-02-14', 'Single', '09221234509', 'pending');

INSERT INTO users (username, password_hash, full_name, email, role, resident_id, registered_address, status)
VALUES ('res_mark', '$2y$10$wCLysAYlxSkXiysDUQTu5OIC4cgDqkoN2/hi2jLHpApK.LLvdh6Y6', 'Mark Villanueva', 'mark@example.com',
        'resident', LAST_INSERT_ID(), '23 Bonifacio St., Purok 3', 'pending');
