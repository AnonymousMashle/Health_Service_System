-- =====================================================================
--  UPDATE 03: Human Resource Officer + Nutrition Action Officer
--  Run AFTER update_02_staff_registration.sql, and only if you imported
--  bhsms.sql before this update. (A fresh import of bhsms.sql already
--  includes everything in this file.)
--
--  phpMyAdmin -> select database "bhsms" -> Import -> this file -> Go
--  Existing data is kept.
-- =====================================================================

USE bhsms;
SET FOREIGN_KEY_CHECKS = 0;

-- Two new user types
ALTER TABLE users
    MODIFY role ENUM('admin','bhw','nurse','mho','hr','nao','resident') NOT NULL;

-- ---------------------------------------------------------------------
-- HUMAN RESOURCE
-- ---------------------------------------------------------------------

-- Personnel 201 file (one row per health center worker; may be linked to a login account)
CREATE TABLE IF NOT EXISTS personnel (
    personnel_id        INT AUTO_INCREMENT PRIMARY KEY,
    user_id             INT NULL UNIQUE,                 -- login account of this worker (optional)
    employee_no         VARCHAR(30)  NOT NULL UNIQUE,    -- e.g. EMP-2026-0001
    first_name          VARCHAR(80)  NOT NULL,
    middle_name         VARCHAR(80)  NULL,
    last_name           VARCHAR(80)  NOT NULL,
    suffix              VARCHAR(10)  NULL,
    sex                 ENUM('Male','Female') NOT NULL,
    birthdate           DATE NULL,
    civil_status        ENUM('Single','Married','Widowed','Separated','Live-in') NULL,
    position            VARCHAR(100) NOT NULL,           -- Barangay Health Worker, Nurse, Midwife, BNS, ...
    employment_status   ENUM('Permanent','Casual','Contractual','Job Order','Volunteer') NOT NULL DEFAULT 'Volunteer',
    date_hired          DATE NULL,
    assigned_area       VARCHAR(100) NULL,               -- purok / catchment area
    monthly_rate        DECIMAL(10,2) NULL,              -- salary or honorarium
    contact_no          VARCHAR(20)  NULL,
    email               VARCHAR(150) NULL,
    address             VARCHAR(255) NULL,
    tin_no              VARCHAR(20)  NULL,
    philhealth_no       VARCHAR(20)  NULL,
    license_no          VARCHAR(30)  NULL,               -- PRC license / BHW accreditation
    license_expiry      DATE NULL,
    emergency_contact   VARCHAR(150) NULL,
    emergency_contact_no VARCHAR(20) NULL,
    status              ENUM('active','on leave','resigned','retired','terminated') NOT NULL DEFAULT 'active',
    remarks             TEXT NULL,
    created_by          INT NULL,
    created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_personnel_name (last_name, first_name),
    INDEX idx_personnel_status (status),
    CONSTRAINT fk_personnel_user FOREIGN KEY (user_id)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_personnel_created_by FOREIGN KEY (created_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Daily attendance / duty log
CREATE TABLE IF NOT EXISTS personnel_attendance (
    attendance_id   INT AUTO_INCREMENT PRIMARY KEY,
    personnel_id    INT NOT NULL,
    work_date       DATE NOT NULL,
    time_in         TIME NULL,
    time_out        TIME NULL,
    status          ENUM('Present','Late','Half day','Absent','On leave','Official business') NOT NULL DEFAULT 'Present',
    remarks         VARCHAR(255) NULL,
    recorded_by     INT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_attendance_day (personnel_id, work_date),
    INDEX idx_attendance_date (work_date),
    CONSTRAINT fk_attendance_personnel FOREIGN KEY (personnel_id)
        REFERENCES personnel(personnel_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_attendance_recorded_by FOREIGN KEY (recorded_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Leave applications (any staff files, HR approves)
CREATE TABLE IF NOT EXISTS leave_requests (
    leave_id        INT AUTO_INCREMENT PRIMARY KEY,
    personnel_id    INT NOT NULL,
    leave_type      ENUM('Vacation','Sick','Emergency','Maternity','Paternity','Special Privilege','Solo Parent','Others') NOT NULL,
    date_from       DATE NOT NULL,
    date_to         DATE NOT NULL,
    days            DECIMAL(4,1) NOT NULL,
    reason          VARCHAR(255) NOT NULL,
    status          ENUM('pending','approved','rejected','cancelled') NOT NULL DEFAULT 'pending',
    remarks         VARCHAR(255) NULL,                   -- HR's note / reason for rejection
    filed_by        INT NULL,
    reviewed_by     INT NULL,
    reviewed_at     DATETIME NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_leave_status (status),
    INDEX idx_leave_dates (date_from, date_to),
    CONSTRAINT fk_leave_personnel FOREIGN KEY (personnel_id)
        REFERENCES personnel(personnel_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_leave_filed_by FOREIGN KEY (filed_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_leave_reviewed_by FOREIGN KEY (reviewed_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Trainings and seminars attended
CREATE TABLE IF NOT EXISTS personnel_trainings (
    training_id     INT AUTO_INCREMENT PRIMARY KEY,
    personnel_id    INT NOT NULL,
    title           VARCHAR(200) NOT NULL,
    provider        VARCHAR(150) NULL,                   -- DOH, NNC, Municipal Health Office, ...
    date_from       DATE NOT NULL,
    date_to         DATE NULL,
    hours           DECIMAL(5,1) NULL,
    certificate_no  VARCHAR(50)  NULL,
    created_by      INT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_training_personnel FOREIGN KEY (personnel_id)
        REFERENCES personnel(personnel_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_training_created_by FOREIGN KEY (created_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- NUTRITION (Nutrition Action Officer)
--   Operation Timbang Plus measurements are saved in the existing
--   child_monitoring table, so Child Health and Nutrition share them.
-- ---------------------------------------------------------------------

ALTER TABLE child_monitoring
    MODIFY nutrition_status ENUM('Normal','Underweight','Severely Underweight','Stunted','Severely Stunted',
                                 'Wasted','Severely Wasted','Overweight','Obese') NULL;

-- Feeding / nutrition programs (e.g. Supplementary Feeding Program, Dietary Supplementation Program)
CREATE TABLE IF NOT EXISTS nutrition_programs (
    program_id      INT AUTO_INCREMENT PRIMARY KEY,
    program_name    VARCHAR(150) NOT NULL,
    program_type    ENUM('Supplementary Feeding','Dietary Supplementation','Nutrition Education','Micronutrient Supplementation','Other') NOT NULL,
    target_group    VARCHAR(100) NULL,                   -- e.g. Underweight children 6-59 months
    start_date      DATE NOT NULL,
    end_date        DATE NULL,
    sessions_planned INT NULL,                           -- e.g. 120 feeding days
    venue           VARCHAR(150) NULL,
    funding_source  VARCHAR(100) NULL,
    description     TEXT NULL,
    status          ENUM('planned','ongoing','completed','cancelled') NOT NULL DEFAULT 'planned',
    created_by      INT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_program_created_by FOREIGN KEY (created_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS program_beneficiaries (
    beneficiary_id      INT AUTO_INCREMENT PRIMARY KEY,
    program_id          INT NOT NULL,
    resident_id         INT NOT NULL,
    enrolled_date       DATE NOT NULL,
    baseline_weight_kg  DECIMAL(5,2) NULL,
    baseline_height_cm  DECIMAL(5,2) NULL,
    baseline_status     VARCHAR(30) NULL,
    latest_weight_kg    DECIMAL(5,2) NULL,
    latest_status       VARCHAR(30) NULL,
    outcome             ENUM('enrolled','improved','rehabilitated','no change','worsened','dropped') NOT NULL DEFAULT 'enrolled',
    remarks             VARCHAR(255) NULL,
    created_by          INT NULL,
    created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_program_resident (program_id, resident_id),
    CONSTRAINT fk_benef_program FOREIGN KEY (program_id)
        REFERENCES nutrition_programs(program_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_benef_resident FOREIGN KEY (resident_id)
        REFERENCES residents(resident_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_benef_created_by FOREIGN KEY (created_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- One feeding day / session and who attended it
CREATE TABLE IF NOT EXISTS program_sessions (
    session_id      INT AUTO_INCREMENT PRIMARY KEY,
    program_id      INT NOT NULL,
    session_date    DATE NOT NULL,
    menu            VARCHAR(255) NULL,                   -- food served / topic discussed
    notes           VARCHAR(255) NULL,
    recorded_by     INT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_program_day (program_id, session_date),
    CONSTRAINT fk_session_program FOREIGN KEY (program_id)
        REFERENCES nutrition_programs(program_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_session_recorded_by FOREIGN KEY (recorded_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS session_attendance (
    session_id      INT NOT NULL,
    beneficiary_id  INT NOT NULL,
    weight_kg       DECIMAL(5,2) NULL,                   -- optional weigh-in on that day
    PRIMARY KEY (session_id, beneficiary_id),
    CONSTRAINT fk_att_session FOREIGN KEY (session_id)
        REFERENCES program_sessions(session_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_att_beneficiary FOREIGN KEY (beneficiary_id)
        REFERENCES program_beneficiaries(beneficiary_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Vitamin A, iron, micronutrient powder, deworming, ...
CREATE TABLE IF NOT EXISTS micronutrient_supplements (
    supplement_id   INT AUTO_INCREMENT PRIMARY KEY,
    resident_id     INT NOT NULL,
    supplement_type ENUM('Vitamin A','Iron','Iron with Folic Acid','Micronutrient Powder','Deworming','Iodized Oil','Zinc','Calcium','Other') NOT NULL,
    dose            VARCHAR(60) NULL,                    -- e.g. 100,000 IU / 200,000 IU / 400 mg
    date_given      DATE NOT NULL,
    next_due        DATE NULL,
    remarks         VARCHAR(255) NULL,
    given_by        INT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_supp_resident (resident_id),
    INDEX idx_supp_due (next_due),
    CONSTRAINT fk_supp_resident FOREIGN KEY (resident_id)
        REFERENCES residents(resident_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_supp_given_by FOREIGN KEY (given_by)
        REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- SAMPLE DATA (password for the new accounts: password123)
-- ---------------------------------------------------------------------
INSERT INTO users (username, password_hash, full_name, email, contact_no, id_number, role, status)
SELECT * FROM (SELECT 'hr_luz' AS u, '$2y$10$wCLysAYlxSkXiysDUQTu5OIC4cgDqkoN2/hi2jLHpApK.LLvdh6Y6' AS p, 'Luzviminda Garcia' AS n,
                      'luz@bhsms.local' AS e, '09251234512' AS c, 'HR-2026-001' AS i, 'hr' AS r, 'active' AS s) x
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'hr_luz');

INSERT INTO users (username, password_hash, full_name, email, contact_no, id_number, role, status)
SELECT * FROM (SELECT 'nao_ben' AS u, '$2y$10$wCLysAYlxSkXiysDUQTu5OIC4cgDqkoN2/hi2jLHpApK.LLvdh6Y6' AS p, 'Benjamin Torres, RND' AS n,
                      'ben@bhsms.local' AS e, '09261234513' AS c, 'NAO-2026-001' AS i, 'nao' AS r, 'active' AS s) x
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'nao_ben');

-- 201 files of the existing staff accounts
INSERT INTO personnel (user_id, employee_no, first_name, last_name, sex, position, employment_status, date_hired, assigned_area, contact_no, email, license_no, status, created_by)
SELECT u.user_id, d.emp, d.fn, d.ln, d.sex, d.pos, d.es, d.hired, d.area, d.contact, u.email, d.lic, 'active', 1
FROM (
    SELECT 'bhw_maria' AS uname, 'EMP-2026-0001' AS emp, 'Maria' AS fn, 'Cruz' AS ln, 'Female' AS sex, 'Barangay Health Worker' AS pos, 'Volunteer' AS es, '2019-06-03' AS hired, 'Purok 1-2' AS area, '09171110001' AS contact, 'BHW-2019-007' AS lic
    UNION ALL SELECT 'nurse_ana', 'EMP-2026-0002', 'Ana', 'Villanueva', 'Female', 'Nurse I', 'Permanent', '2021-01-11', 'Health Center', '09171110002', '0654321'
    UNION ALL SELECT 'mho_reyes', 'EMP-2026-0003', 'Ramon', 'Reyes', 'Male', 'Municipal Health Officer', 'Permanent', '2015-03-02', 'Municipality', '09171110003', '0123456'
    UNION ALL SELECT 'hr_luz', 'EMP-2026-0004', 'Luzviminda', 'Garcia', 'Female', 'Human Resource Officer', 'Permanent', '2018-08-15', 'Health Center', '09251234512', NULL
    UNION ALL SELECT 'nao_ben', 'EMP-2026-0005', 'Benjamin', 'Torres', 'Male', 'Nutrition Action Officer', 'Permanent', '2020-02-17', 'Municipality', '09261234513', 'RND-0098765'
) d JOIN users u ON u.username = d.uname
WHERE NOT EXISTS (SELECT 1 FROM personnel p WHERE p.employee_no = d.emp);

INSERT INTO personnel (employee_no, first_name, last_name, sex, position, employment_status, date_hired, assigned_area, contact_no, status, created_by)
SELECT 'EMP-2026-0006', 'Teresita', 'Lopez', 'Female', 'Barangay Nutrition Scholar', 'Volunteer', '2022-07-01', 'Purok 3', '09171110006', 'active', 1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM personnel WHERE employee_no = 'EMP-2026-0006');

INSERT INTO personnel_trainings (personnel_id, title, provider, date_from, date_to, hours, created_by)
SELECT p.personnel_id, 'Philippine Integrated Management of Acute Malnutrition (PIMAM)', 'National Nutrition Council', '2026-03-09', '2026-03-11', 24, 1
FROM personnel p WHERE p.employee_no = 'EMP-2026-0005'
  AND NOT EXISTS (SELECT 1 FROM personnel_trainings t WHERE t.personnel_id = p.personnel_id);

INSERT INTO leave_requests (personnel_id, leave_type, date_from, date_to, days, reason, status, filed_by)
SELECT p.personnel_id, 'Vacation', '2026-12-22', '2026-12-23', 2, 'Family gathering in the province', 'pending', p.user_id
FROM personnel p WHERE p.employee_no = 'EMP-2026-0001'
  AND NOT EXISTS (SELECT 1 FROM leave_requests l WHERE l.personnel_id = p.personnel_id);

INSERT INTO nutrition_programs (program_name, program_type, target_group, start_date, end_date, sessions_planned, venue, funding_source, description, status, created_by)
SELECT 'Supplementary Feeding Program 2026', 'Supplementary Feeding', 'Underweight children 2-5 years old', '2026-09-01', '2026-12-18', 60,
       'Barangay Day Care Center', 'LGU / DSWD', 'Hot meals 5 days a week with monthly weighing.', 'ongoing', 1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM nutrition_programs WHERE program_name = 'Supplementary Feeding Program 2026');

INSERT INTO program_beneficiaries (program_id, resident_id, enrolled_date, baseline_weight_kg, baseline_height_cm, baseline_status, latest_weight_kg, latest_status, outcome, created_by)
SELECT np.program_id, 7, '2026-09-01', 10.8, 86.0, 'Underweight', 11.2, 'Underweight', 'improved', 1
FROM nutrition_programs np WHERE np.program_name = 'Supplementary Feeding Program 2026'
  AND EXISTS (SELECT 1 FROM residents WHERE resident_id = 7)
  AND NOT EXISTS (SELECT 1 FROM program_beneficiaries b WHERE b.program_id = np.program_id AND b.resident_id = 7);

INSERT INTO micronutrient_supplements (resident_id, supplement_type, dose, date_given, next_due, remarks, given_by)
SELECT 3, 'Vitamin A', '200,000 IU', '2026-05-12', '2026-11-12', 'Garantisadong Pambata', 2 FROM DUAL
WHERE EXISTS (SELECT 1 FROM residents WHERE resident_id = 3)
  AND NOT EXISTS (SELECT 1 FROM micronutrient_supplements WHERE resident_id = 3);
INSERT INTO micronutrient_supplements (resident_id, supplement_type, dose, date_given, next_due, remarks, given_by)
SELECT 7, 'Deworming', 'Albendazole 400 mg', '2026-07-20', '2027-01-20', NULL, 2 FROM DUAL
WHERE EXISTS (SELECT 1 FROM residents WHERE resident_id = 7)
  AND NOT EXISTS (SELECT 1 FROM micronutrient_supplements WHERE resident_id = 7);
