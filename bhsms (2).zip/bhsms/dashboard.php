<?php
require __DIR__ . '/includes/init.php';
require_role(...STAFF);

$s = q('SELECT * FROM v_dashboard_summary')->fetch();

$overdueVacc = (int)q('SELECT COUNT(*) FROM (' . due_vaccinations_sql() . ' AND v.next_schedule < CURDATE()) x')->fetchColumn();
$lowStock = q("SELECT * FROM v_medicine_stock_levels WHERE stock_status <> 'In Stock' ORDER BY usable_stock LIMIT 8")->fetchAll();
$upcoming = q("SELECT u.*, r.first_name, r.middle_name, r.last_name, r.suffix
               FROM v_upcoming_schedules u JOIN residents r ON r.resident_id = u.resident_id
               ORDER BY u.schedule_date LIMIT 10")->fetchAll();
$pending = q("SELECT a.*, r.first_name, r.middle_name, r.last_name, r.suffix
              FROM appointments a JOIN residents r ON r.resident_id = a.resident_id
              WHERE a.status = 'pending' ORDER BY a.preferred_date LIMIT 5")->fetchAll();
$recent = q("SELECT c.consultation_id, c.consultation_date, c.chief_complaint, c.status,
                    r.first_name, r.middle_name, r.last_name, r.suffix
             FROM consultations c JOIN residents r ON r.resident_id = c.resident_id
             ORDER BY c.consultation_date DESC LIMIT 6")->fetchAll();

$hour = (int)date('G');
$greet = $hour < 12 ? 'Good morning' : ($hour < 18 ? 'Good afternoon' : 'Good evening');

$page_title = 'Dashboard';
require __DIR__ . '/includes/header.php';
?>
<div class="page-head">
    <div>
        <h2><?= e($greet) ?>, <?= e(current_user()['full_name']) ?></h2>
        <div class="muted"><?= date('l, F j, Y') ?></div>
    </div>
    <div class="btn-group">
        <?php if (can('residents', 'edit')): ?><a class="btn" href="<?= e(url('modules/residents/form.php')) ?>">+ Register resident</a><?php endif; ?>
        <?php if (can('consultations', 'edit')): ?><a class="btn btn-primary" href="<?= e(url('modules/consultations/form.php')) ?>">+ New consultation</a><?php endif; ?>
    </div>
</div>

<div class="stats">
    <a class="stat" href="<?= e(url('modules/residents/index.php')) ?>"><div class="label">Registered residents</div><div class="value"><?= (int)$s['total_residents'] ?></div></a>
    <a class="stat blue" href="<?= e(url('modules/residents/households.php')) ?>"><div class="label">Households</div><div class="value"><?= (int)$s['total_households'] ?></div></a>
    <a class="stat" href="<?= e(url('modules/consultations/index.php')) ?>"><div class="label">Consultations this month</div><div class="value"><?= (int)$s['consultations_this_month'] ?></div></a>
    <a class="stat purple" href="<?= e(url('modules/maternal/index.php')) ?>"><div class="label">Active pregnancies</div><div class="value"><?= (int)$s['active_pregnancies'] ?></div></a>
    <a class="stat amber" href="<?= e(url(can('appointments') ? 'modules/appointments/index.php' : 'dashboard.php')) ?>"><div class="label">Pending appointments</div><div class="value"><?= (int)$s['pending_appointments'] ?></div></a>
    <a class="stat <?= $overdueVacc ? 'red' : 'blue' ?>" href="<?= e(url('modules/vaccinations/index.php?tab=due')) ?>"><div class="label">Vaccines due (7 days) / overdue</div><div class="value"><?= (int)$s['vaccinations_due_7_days'] ?> / <?= $overdueVacc ?></div></a>
</div>

<div class="grid cols-2">
    <div class="card">
        <div class="card-header"><h3>Upcoming schedules (next 30 days)</h3></div>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Date</th><th>Resident</th><th>Type</th><th>Details</th></tr></thead>
            <tbody>
            <?php foreach ($upcoming as $row): ?>
                <tr>
                    <td class="nowrap"><?= fmt_date($row['schedule_date']) ?></td>
                    <td><a href="<?= e(url('modules/residents/view.php?id=' . $row['resident_id'])) ?>"><?= e(full_name($row)) ?></a></td>
                    <td><?= badge($row['schedule_type']) ?></td>
                    <td class="small"><?= e($row['details']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$upcoming): ?><tr><td colspan="4" class="empty">No schedules in the next 30 days.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>

    <div class="card">
        <div class="card-header"><h3>Medicine stock alerts</h3><a class="btn btn-sm" href="<?= e(url('modules/inventory/index.php')) ?>">Inventory</a></div>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Medicine</th><th class="num">Usable stock</th><th class="num">Reorder at</th><th>Status</th></tr></thead>
            <tbody>
            <?php foreach ($lowStock as $m): ?>
                <tr>
                    <td><?= e($m['generic_name']) ?> <span class="muted small"><?= e($m['strength']) ?> <?= e($m['dosage_form']) ?></span></td>
                    <td class="num"><?= (int)$m['usable_stock'] ?> <?= e($m['unit']) ?></td>
                    <td class="num"><?= (int)$m['reorder_level'] ?></td>
                    <td><?= badge($m['stock_status']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$lowStock): ?><tr><td colspan="4" class="empty">All medicines are in stock.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>

    <div class="card">
        <div class="card-header"><h3>Pending appointment requests</h3>
            <?php if (can('appointments')): ?><a class="btn btn-sm" href="<?= e(url('modules/appointments/index.php')) ?>">View all</a><?php endif; ?></div>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Preferred date</th><th>Resident</th><th>Service</th></tr></thead>
            <tbody>
            <?php foreach ($pending as $a): ?>
                <tr>
                    <td class="nowrap"><?= fmt_date($a['preferred_date']) ?> <span class="muted small"><?= fmt_time($a['preferred_time']) ?></span></td>
                    <td><?= e(full_name($a)) ?></td>
                    <td><?= e($a['service_type']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$pending): ?><tr><td colspan="3" class="empty">No pending requests.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>

    <div class="card">
        <div class="card-header"><h3>Recent consultations</h3><a class="btn btn-sm" href="<?= e(url('modules/consultations/index.php')) ?>">View all</a></div>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Date</th><th>Patient</th><th>Complaint</th><th>Status</th></tr></thead>
            <tbody>
            <?php foreach ($recent as $c): ?>
                <tr>
                    <td class="nowrap"><?= fmt_date($c['consultation_date']) ?></td>
                    <td><a href="<?= e(url('modules/consultations/view.php?id=' . $c['consultation_id'])) ?>"><?= e(full_name($c)) ?></a></td>
                    <td><?= e($c['chief_complaint']) ?></td>
                    <td><?= badge($c['status']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$recent): ?><tr><td colspan="4" class="empty">No consultations yet.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
