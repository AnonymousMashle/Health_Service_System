<?php
require __DIR__ . '/includes/init.php';
redirect(current_user() ? home_path() : 'login.php');
