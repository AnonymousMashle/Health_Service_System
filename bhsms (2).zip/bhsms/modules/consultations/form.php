<?php
require __DIR__ . '/../../includes/init.php';
require_perm('consultations', 'edit');

$id = (int)get('id');
$canAssess = can('consultations', 'assess');   // only the nurse writes the assessment & treatment
$statuses = ['waiting' => 'Waiting', 'ongoing' => 'Ongoing', 'completed' => 'Completed', 'referred' => 'Referred'];

$c = [
    'resident_id' => get('resident_id'), 'appointment_id' => get('appointment_id'),
    'consultation_date' => date('Y-m-d\TH:i'), 'chief_complaint' => '', 'symptoms' => '',
    'blood_pressure' => '', 'temperature_c' => '', 'pulse_rate' => '', 'respiratory_rate' => '', 'weight_kg' => '',
    'assessment' => '', 'treatment_plan' => '', 'referred_to' => '',
    'status' => $canAssess ? 'completed' : 'waiting',
];

if ($id) {
    $row = q('SELECT * FROM consultations WHERE consultation_id = ?', [$id])->fetch();
    if (!$row) {
        flash('danger', 'Consultation not found.');
        redirect('modules/consultations/index.php');
    }
    $c = $row;
    $c['consultation_date'] = date('Y-m-d\TH:i', strtotime($row['consultation_date']));
}

// Started from an approved appointment
$appt = null;
if (!$id && $c['appointment_id'] !== '') {
    $appt = q("SELECT * FROM appointments WHERE appointment_id = ? AND status = 'approved'", [$c['appointment_id']])->fetch();
    if ($appt) {
        $c['resident_id'] = $appt['resident_id'];
        $c['chief_complaint'] = $appt['reason'] ?: $appt['service_type'];
    } else {
        $c['appointment_id'] = '';
    }
}

$errors = [];

if (is_post()) {
    $fields = ['resident_id', 'consultation_date', 'chief_complaint', 'symptoms', 'blood_pressure', 'temperature_c',
               'pulse_rate', 'respiratory_rate', 'weight_kg', 'status'];
    $assessFields = ['assessment', 'treatment_plan', 'referred_to'];
    foreach ($fields as $f) { $c[$f] = input($f); }
    if ($canAssess) {
        foreach ($assessFields as $f) { $c[$f] = input($f); }
    }

    if (!q("SELECT 1 FROM residents WHERE resident_id = ? AND status = 'active'", [$c['resident_id']])->fetchColumn()) {
        $errors[] = 'Select a patient.';
    }
    $dt = DateTime::createFromFormat('Y-m-d\TH:i', $c['consultation_date']);
    if (!$dt) {
        $errors[] = 'Enter a valid consultation date and time.';
    } elseif ($dt > new DateTime('+1 hour')) {
        $errors[] = 'Consultation date cannot be in the future.';
    }
    if ($c['chief_complaint'] === '') $errors[] = 'Chief complaint is required.';
    if ($c['blood_pressure'] !== '' && !preg_match('#^\d{2,3}/\d{2,3}$#', $c['blood_pressure'])) $errors[] = 'Blood pressure must look like 120/80.';
    $ranges = ['temperature_c' => ['Temperature', 30, 45], 'pulse_rate' => ['Pulse rate', 20, 250],
               'respiratory_rate' => ['Respiratory rate', 5, 80], 'weight_kg' => ['Weight', 0.5, 300]];
    foreach ($ranges as $f => [$label, $min, $max]) {
        if ($c[$f] !== '' && (!is_numeric($c[$f]) || $c[$f] < $min || $c[$f] > $max)) {
            $errors[] = "$label must be between $min and $max.";
        }
    }
    if (!isset($statuses[$c['status']])) $errors[] = 'Select a status.';
    if ($canAssess && $c['status'] === 'referred' && $c['referred_to'] === '') $errors[] = 'Enter where the patient is referred to.';

    if (!$errors) {
        $data = [];
        foreach ($fields as $f) { $data[$f] = nullable($c[$f]); }
        $data['consultation_date'] = $dt->format('Y-m-d H:i:s');
        if ($canAssess) {
            foreach ($assessFields as $f) { $data[$f] = nullable($c[$f]); }
        }

        if ($id) {
            db_update('consultations', $data, 'consultation_id', $id);
            log_activity('UPDATE', 'consultations', $id, 'Updated consultation');
        } else {
            $data['recorded_by'] = user_id();
            $data['appointment_id'] = $appt ? $appt['appointment_id'] : null;
            $id = db_insert('consultations', $data);
            if ($appt) {
                q("UPDATE appointments SET status = 'completed' WHERE appointment_id = ?", [$appt['appointment_id']]);
            }
            log_activity('CREATE', 'consultations', $id, 'Recorded consultation: ' . $c['chief_complaint']);

            // A BHW recorded the intake -> let the nurses know someone is waiting
            if (!$canAssess && in_array($c['status'], ['waiting', 'ongoing'], true)) {
                notify_roles(['nurse'], 'Patient waiting for assessment', 'A new consultation intake needs your assessment.', 'modules/consultations/form.php?id=' . $id);
            }
        }
        flash('success', 'Consultation saved.');
        redirect('modules/consultations/view.php?id=' . $id);
    }
}

$page_title = $id ? 'Edit Consultation' : 'New Consultation';
require __DIR__ . '/../../includes/header.php';
$lock = $canAssess ? '' : 'disabled';
?>
<?= render_errors($errors) ?>
<?php if ($appt): ?><div class="alert alert-info">From appointment #<?= (int)$appt['appointment_id'] ?> (<?= e($appt['service_type']) ?>). It will be marked completed when you save.</div><?php endif; ?>

<form method="post" class="card">
    <?= csrf_field() ?>
    <fieldset>
        <legend>Consultation registration</legend>
        <div class="form-grid">
            <?= select_field('Patient', 'resident_id', resident_options(), $c['resident_id'], 'required class="searchable"', '-- Select patient --', 'span-2') ?>
            <?= field('Date & time', 'consultation_date', $c['consultation_date'], 'datetime-local', 'required') ?>
            <?= select_field('Status', 'status', $statuses, $c['status'], 'required', false) ?>
            <?= field('Chief complaint', 'chief_complaint', $c['chief_complaint'], 'text', 'required maxlength="255" placeholder="e.g. Fever and cough"', 'full') ?>
            <?= field('Symptoms & history', 'symptoms', $c['symptoms'], 'textarea', 'placeholder="Onset, duration, other symptoms"', 'full') ?>
        </div>
    </fieldset>

    <fieldset>
        <legend>Vital signs</legend>
        <div class="form-grid">
            <?= field('Blood pressure (mmHg)', 'blood_pressure', $c['blood_pressure'], 'text', 'maxlength="7" placeholder="120/80"') ?>
            <?= field('Temperature (°C)', 'temperature_c', $c['temperature_c'], 'number', 'step="0.1" min="30" max="45"') ?>
            <?= field('Pulse rate (bpm)', 'pulse_rate', $c['pulse_rate'], 'number', 'min="20" max="250"') ?>
            <?= field('Respiratory rate (/min)', 'respiratory_rate', $c['respiratory_rate'], 'number', 'min="5" max="80"') ?>
            <?= field('Weight (kg)', 'weight_kg', $c['weight_kg'], 'number', 'step="0.1" min="0.5" max="300"') ?>
        </div>
    </fieldset>

    <fieldset>
        <legend>Health worker's assessment</legend>
        <?php if (!$canAssess): ?><div class="alert alert-info">The nurse completes this part.</div><?php endif; ?>
        <div class="form-grid">
            <?= field('Assessment / impression', 'assessment', $c['assessment'], 'textarea', $lock, 'full') ?>
            <?= field('Treatment plan / advice', 'treatment_plan', $c['treatment_plan'], 'textarea', $lock, 'full') ?>
            <?= field('Referred to', 'referred_to', $c['referred_to'], 'text', $lock . ' maxlength="150" placeholder="e.g. City Health Office, BGHMC"') ?>
        </div>
    </fieldset>

    <div class="form-actions">
        <a class="btn" href="<?= $id ? 'view.php?id=' . $id : 'index.php' ?>">Cancel</a>
        <button class="btn btn-primary" type="submit">Save consultation</button>
    </div>
</form>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
