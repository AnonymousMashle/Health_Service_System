<?php
require __DIR__ . '/../../includes/init.php';
require_perm('consultations');

$id = (int)get('id');

if (is_post() && input('action') === 'delete') {
    if (!can('consultations', 'delete')) deny();
    q('DELETE FROM consultations WHERE consultation_id = ?', [$id]);
    log_activity('DELETE', 'consultations', $id, 'Deleted consultation');
    flash('success', 'Consultation deleted.');
    redirect('modules/consultations/index.php');
}

$c = q('SELECT c.*, r.first_name, r.middle_name, r.last_name, r.suffix, r.sex, r.birthdate, r.contact_no, u.full_name AS recorder
        FROM consultations c JOIN residents r ON r.resident_id = c.resident_id
        LEFT JOIN users u ON u.user_id = c.recorded_by WHERE c.consultation_id = ?', [$id])->fetch();
if (!$c) {
    flash('danger', 'Consultation not found.');
    redirect('modules/consultations/index.php');
}
$hp = q('SELECT allergies, existing_conditions, maintenance_meds FROM health_profiles WHERE resident_id = ?', [$c['resident_id']])->fetch();
$meds = q('SELECT d.*, m.generic_name, m.strength, m.dosage_form, m.unit FROM medicine_distribution d
           JOIN medicines m ON m.medicine_id = d.medicine_id WHERE d.consultation_id = ?', [$id])->fetchAll();
$history = q('SELECT consultation_id, consultation_date, chief_complaint, assessment FROM consultations
              WHERE resident_id = ? AND consultation_id <> ? ORDER BY consultation_date DESC LIMIT 5', [$c['resident_id'], $id])->fetchAll();

$page_title = 'Consultation Record';
require __DIR__ . '/../../includes/header.php';
?>
<div class="page-head">
    <div>
        <h2><a href="<?= e(url('modules/residents/view.php?id=' . $c['resident_id'])) ?>"><?= e(full_name($c)) ?></a> <?= badge($c['status']) ?></h2>
        <div class="muted"><?= e($c['sex']) ?>, <?= e(age_label($c['birthdate'])) ?> &middot; <?= fmt_datetime($c['consultation_date']) ?> &middot; Recorded by <?= e($c['recorder'] ?: '—') ?></div>
    </div>
    <div class="btn-group no-print">
        <?php if (can('inventory', 'distribute')): ?><a class="btn btn-primary" href="<?= e(url('modules/inventory/distribute.php?consultation_id=' . $id)) ?>">Dispense medicine</a><?php endif; ?>
        <?php if (can('consultations', 'edit')): ?><a class="btn" href="form.php?id=<?= $id ?>">Edit</a><?php endif; ?>
        <button class="btn" data-print>Print</button>
        <?php if (can('consultations', 'delete')): ?><?= post_button('view.php?id=' . $id, 'Delete', ['action' => 'delete'], 'btn btn-danger', 'Delete this consultation record?') ?><?php endif; ?>
    </div>
</div>

<?php if ($hp && $hp['allergies']): ?><div class="alert alert-danger"><strong>Allergies:</strong> <?= e($hp['allergies']) ?></div><?php endif; ?>

<div class="grid cols-2 mb">
    <div class="card">
        <h3>Complaint</h3>
        <dl class="info">
            <dt>Chief complaint</dt><dd><?= e($c['chief_complaint']) ?></dd>
            <dt>Symptoms</dt><dd><?= nl2br(e($c['symptoms'] ?: '—')) ?></dd>
            <dt>Existing conditions</dt><dd><?= e($hp['existing_conditions'] ?? '—') ?: '—' ?></dd>
            <dt>Maintenance meds</dt><dd><?= e($hp['maintenance_meds'] ?? '—') ?: '—' ?></dd>
        </dl>
    </div>
    <div class="card">
        <h3>Vital signs</h3>
        <dl class="info">
            <dt>Blood pressure</dt><dd><?= e($c['blood_pressure'] ?: '—') ?></dd>
            <dt>Temperature</dt><dd><?= $c['temperature_c'] ? e($c['temperature_c']) . ' °C' : '—' ?></dd>
            <dt>Pulse rate</dt><dd><?= $c['pulse_rate'] ? e($c['pulse_rate']) . ' bpm' : '—' ?></dd>
            <dt>Respiratory rate</dt><dd><?= $c['respiratory_rate'] ? e($c['respiratory_rate']) . ' /min' : '—' ?></dd>
            <dt>Weight</dt><dd><?= $c['weight_kg'] ? e($c['weight_kg']) . ' kg' : '—' ?></dd>
        </dl>
    </div>
</div>

<div class="card">
    <h3>Assessment &amp; treatment</h3>
    <dl class="info">
        <dt>Assessment</dt><dd><?= nl2br(e($c['assessment'] ?: 'Not yet assessed')) ?></dd>
        <dt>Treatment / advice</dt><dd><?= nl2br(e($c['treatment_plan'] ?: '—')) ?></dd>
        <dt>Referred to</dt><dd><?= e($c['referred_to'] ?: '—') ?></dd>
    </dl>
</div>

<div class="grid cols-2">
    <div class="card">
        <h3>Medicines dispensed</h3>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Medicine</th><th class="num">Qty</th><th>Instructions</th></tr></thead>
            <tbody>
            <?php foreach ($meds as $m): ?>
                <tr><td><?= e($m['generic_name']) ?> <span class="small muted"><?= e($m['strength']) ?></span></td>
                    <td class="num"><?= (int)$m['quantity'] ?> <?= e($m['unit']) ?></td><td><?= e($m['instructions']) ?></td></tr>
            <?php endforeach; ?>
            <?php if (!$meds): ?><tr><td colspan="3" class="empty">No medicines dispensed for this visit.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>
    <div class="card no-print">
        <h3>Previous consultations</h3>
        <?php foreach ($history as $h): ?>
            <div style="margin-bottom:8px"><a href="view.php?id=<?= (int)$h['consultation_id'] ?>"><?= fmt_date($h['consultation_date']) ?></a> — <?= e($h['chief_complaint']) ?>
                <div class="small muted"><?= e($h['assessment']) ?></div></div>
        <?php endforeach; ?>
        <?php if (!$history): ?><p class="muted">First consultation on record.</p><?php endif; ?>
    </div>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
