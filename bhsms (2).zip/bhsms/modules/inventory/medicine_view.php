<?php
require __DIR__ . '/../../includes/init.php';
require_perm('inventory');

const REMOVE_TYPES = ['Expired', 'Damaged', 'Lost'];

$id = (int)get('id');
$m = q('SELECT * FROM v_medicine_stock_levels WHERE medicine_id = ?', [$id])->fetch()
    ?: q('SELECT m.*, 0 AS usable_stock, 0 AS expired_stock, NULL AS nearest_expiry, \'Inactive\' AS stock_status FROM medicines m WHERE medicine_id = ?', [$id])->fetch();
if (!$m) {
    flash('danger', 'Medicine not found.');
    redirect('modules/inventory/index.php');
}
$errors = [];

// Stock adjustment (expired / damaged / lost / returned / correction)
if (is_post() && input('action') === 'adjust') {
    if (!can('inventory', 'edit')) deny();
    $stockId = (int)input('stock_id');
    $type = input('adjustment_type');
    $qty = input('quantity');
    $direction = input('direction');
    $reason = input('reason');

    if (!in_array($type, ['Expired', 'Damaged', 'Lost', 'Returned', 'Correction'], true)) $errors[] = 'Select an adjustment type.';
    if (!ctype_digit((string)$qty) || (int)$qty < 1) $errors[] = 'Quantity must be at least 1.';
    if ($type === 'Correction' && $reason === '') $errors[] = 'Explain the reason for a correction.';

    if (!$errors) {
        $delta = in_array($type, REMOVE_TYPES, true) ? -(int)$qty
               : ($type === 'Returned' ? (int)$qty : ($direction === 'remove' ? -(int)$qty : (int)$qty));
        db()->beginTransaction();
        $batch = q('SELECT * FROM medicine_stock WHERE stock_id = ? AND medicine_id = ? FOR UPDATE', [$stockId, $id])->fetch();
        $newQty = $batch ? (int)$batch['quantity_remaining'] + $delta : -1;
        if (!$batch) {
            $errors[] = 'Select a batch.';
        } elseif ($newQty < 0) {
            $errors[] = 'The batch only has ' . (int)$batch['quantity_remaining'] . ' left.';
        } elseif ($newQty > (int)$batch['quantity_received']) {
            $errors[] = 'Remaining stock cannot be more than the ' . (int)$batch['quantity_received'] . ' received in this batch.';
        }
        if ($errors) {
            db()->rollBack();
        } else {
            q('UPDATE medicine_stock SET quantity_remaining = ? WHERE stock_id = ?', [$newQty, $stockId]);
            $adjId = db_insert('stock_adjustments', ['stock_id' => $stockId, 'adjustment_type' => $type, 'quantity' => $delta,
                                                     'reason' => nullable($reason), 'adjusted_by' => user_id()]);
            db()->commit();
            log_activity('UPDATE', 'stock_adjustments', $adjId, "$type adjustment of $delta on batch " . $batch['batch_no']);
            flash('success', "Batch {$batch['batch_no']} adjusted ($type, " . ($delta > 0 ? '+' : '') . "$delta).");
            redirect('modules/inventory/medicine_view.php?id=' . $id . '#batches');
        }
    }
}

$batches = q('SELECT s.*, u.full_name AS receiver FROM medicine_stock s LEFT JOIN users u ON u.user_id = s.received_by
              WHERE s.medicine_id = ? ORDER BY (s.quantity_remaining > 0) DESC, s.expiry_date', [$id])->fetchAll();
$dist = q('SELECT d.*, r.first_name, r.middle_name, r.last_name, r.suffix, s.batch_no, u.full_name AS giver
           FROM medicine_distribution d JOIN residents r ON r.resident_id = d.resident_id JOIN medicine_stock s ON s.stock_id = d.stock_id
           LEFT JOIN users u ON u.user_id = d.given_by WHERE d.medicine_id = ? ORDER BY d.distribution_date DESC, d.distribution_id DESC LIMIT 50', [$id])->fetchAll();
$adjs = q('SELECT a.*, s.batch_no, u.full_name AS adjuster FROM stock_adjustments a JOIN medicine_stock s ON s.stock_id = a.stock_id
           LEFT JOIN users u ON u.user_id = a.adjusted_by WHERE s.medicine_id = ? ORDER BY a.adjusted_at DESC', [$id])->fetchAll();
$batchOptions = [];
foreach ($batches as $b) {
    $batchOptions[$b['stock_id']] = $b['batch_no'] . ' — ' . $b['quantity_remaining'] . ' left, exp. ' . fmt_date($b['expiry_date']);
}

$page_title = 'Medicine Details';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<div class="page-head">
    <div>
        <h2><?= e($m['generic_name']) ?> <?= badge($m['stock_status']) ?></h2>
        <div class="muted"><?= e($m['brand_name'] ? $m['brand_name'] . ' · ' : '') ?><?= e($m['dosage_form']) ?> <?= e($m['strength']) ?> &middot; unit: <?= e($m['unit']) ?></div>
    </div>
    <div class="btn-group">
        <?php if (can('inventory', 'distribute') && $m['usable_stock'] > 0): ?><a class="btn btn-primary" href="distribute.php?medicine_id=<?= $id ?>">Dispense</a><?php endif; ?>
        <?php if (can('inventory', 'edit')): ?>
            <a class="btn" href="stock_in.php?medicine_id=<?= $id ?>">Receive stock</a>
            <a class="btn" href="medicine_form.php?id=<?= $id ?>">Edit</a>
        <?php endif; ?>
    </div>
</div>

<div class="stats">
    <div class="stat"><div class="label">Usable stock</div><div class="value"><?= (int)$m['usable_stock'] ?></div></div>
    <div class="stat amber"><div class="label">Reorder level</div><div class="value"><?= (int)$m['reorder_level'] ?></div></div>
    <div class="stat red"><div class="label">Expired (not yet disposed)</div><div class="value"><?= (int)$m['expired_stock'] ?></div></div>
    <div class="stat blue"><div class="label">Nearest expiry</div><div class="value" style="font-size:18px"><?= fmt_date($m['nearest_expiry']) ?></div></div>
</div>

<div class="card">
    <div class="tabs" data-tabs>
        <button class="active" data-tab="batches">Batches (<?= count($batches) ?>)</button>
        <button data-tab="distribution">Distribution history (<?= count($dist) ?>)</button>
        <button data-tab="adjustments">Adjustments (<?= count($adjs) ?>)</button>
    </div>

    <div class="tab-panel active" id="tab-batches">
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Batch</th><th>Received</th><th class="num">Qty received</th><th class="num">Remaining</th><th>Expiry</th><th>Source</th><th>Received by</th></tr></thead>
            <tbody>
            <?php foreach ($batches as $b): $expired = $b['expiry_date'] < today(); ?>
                <tr class="<?= $expired && $b['quantity_remaining'] > 0 ? 'row-danger' : '' ?>">
                    <td><strong><?= e($b['batch_no']) ?></strong></td>
                    <td><?= fmt_date($b['date_received']) ?></td>
                    <td class="num"><?= (int)$b['quantity_received'] ?></td>
                    <td class="num"><?= (int)$b['quantity_remaining'] ?></td>
                    <td><?= fmt_date($b['expiry_date']) ?> <?= $expired ? badge('Expired') : '' ?></td>
                    <td><?= e($b['source'] ?: '—') ?></td>
                    <td class="small"><?= e($b['receiver'] ?: '—') ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$batches): ?><tr><td colspan="7" class="empty">No stock received yet.</td></tr><?php endif; ?>
            </tbody>
        </table></div>

        <?php if ($batches && can('inventory', 'edit')): ?>
            <h3 style="margin-top:20px">Adjust a batch</h3>
            <form method="post">
                <?= csrf_field() ?><input type="hidden" name="action" value="adjust">
                <div class="form-grid">
                    <?= select_field('Batch', 'stock_id', $batchOptions, '', 'required', '-- Select batch --', 'span-2') ?>
                    <?= select_field('Type', 'adjustment_type', ['Expired' => 'Expired (remove)', 'Damaged' => 'Damaged (remove)', 'Lost' => 'Lost (remove)', 'Returned' => 'Returned (add back)', 'Correction' => 'Correction (count error)'], '', 'required') ?>
                    <div data-show-when="adjustment_type=Correction">
                        <?= select_field('Direction', 'direction', ['add' => 'Add to stock', 'remove' => 'Remove from stock'], 'remove', '', false) ?>
                    </div>
                    <?= field('Quantity', 'quantity', '', 'number', 'required min="1"') ?>
                    <?= field('Reason', 'reason', '', 'text', 'maxlength="255"', 'span-2') ?>
                </div>
                <div class="form-actions"><button class="btn btn-primary">Save adjustment</button></div>
            </form>
        <?php endif; ?>
    </div>

    <div class="tab-panel" id="tab-distribution">
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Date</th><th>Resident</th><th>Batch</th><th class="num">Qty</th><th>Instructions</th><th>Given by</th></tr></thead>
            <tbody>
            <?php foreach ($dist as $r): ?>
                <tr>
                    <td class="nowrap"><?= fmt_date($r['distribution_date']) ?></td>
                    <td><a href="<?= e(url('modules/residents/view.php?id=' . $r['resident_id'])) ?>"><?= e(full_name($r)) ?></a></td>
                    <td class="small"><?= e($r['batch_no']) ?></td>
                    <td class="num"><?= (int)$r['quantity'] ?></td>
                    <td class="small"><?= e($r['instructions']) ?></td>
                    <td class="small"><?= e($r['giver'] ?: '—') ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$dist): ?><tr><td colspan="6" class="empty">Not yet dispensed.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>

    <div class="tab-panel" id="tab-adjustments">
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Date</th><th>Batch</th><th>Type</th><th class="num">Change</th><th>Reason</th><th>By</th></tr></thead>
            <tbody>
            <?php foreach ($adjs as $a): ?>
                <tr>
                    <td class="nowrap"><?= fmt_datetime($a['adjusted_at']) ?></td>
                    <td><?= e($a['batch_no']) ?></td>
                    <td><?= e($a['adjustment_type']) ?></td>
                    <td class="num <?= $a['quantity'] < 0 ? 'text-danger' : 'text-success' ?>"><?= $a['quantity'] > 0 ? '+' : '' ?><?= (int)$a['quantity'] ?></td>
                    <td><?= e($a['reason']) ?></td>
                    <td class="small"><?= e($a['adjuster'] ?: '—') ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$adjs): ?><tr><td colspan="6" class="empty">No adjustments.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
