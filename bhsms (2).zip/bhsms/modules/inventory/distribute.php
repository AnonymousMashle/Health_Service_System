<?php
require __DIR__ . '/../../includes/init.php';
require_perm('inventory', 'distribute');

$d = ['resident_id' => get('resident_id'), 'medicine_id' => get('medicine_id'), 'quantity' => '', 'distribution_date' => today(),
      'instructions' => '', 'consultation_id' => get('consultation_id')];

// Dispensing for a consultation: patient is fixed
$consult = null;
if ($d['consultation_id'] !== '') {
    $consult = q('SELECT c.consultation_id, c.resident_id, c.consultation_date, c.chief_complaint, c.treatment_plan,
                         r.first_name, r.middle_name, r.last_name, r.suffix
                  FROM consultations c JOIN residents r ON r.resident_id = c.resident_id WHERE c.consultation_id = ?', [$d['consultation_id']])->fetch();
    if ($consult) {
        $d['resident_id'] = $consult['resident_id'];
    } else {
        $d['consultation_id'] = '';
    }
}

$stockRows = q("SELECT * FROM v_medicine_stock_levels WHERE usable_stock > 0 ORDER BY generic_name")->fetchAll();
$medOptions = [];
$medInfo = [];
foreach ($stockRows as $m) {
    $medOptions[$m['medicine_id']] = $m['generic_name'] . ' ' . $m['strength'] . ' ' . $m['dosage_form'] . ' — ' . $m['usable_stock'] . ' ' . $m['unit'] . ' available';
    $medInfo[$m['medicine_id']] = $m;
}
$errors = [];

if (is_post()) {
    foreach (['resident_id', 'medicine_id', 'quantity', 'distribution_date', 'instructions'] as $f) { $d[$f] = input($f); }
    if ($consult) {
        $d['resident_id'] = $consult['resident_id'];
    }
    if (!q("SELECT 1 FROM residents WHERE resident_id = ? AND status = 'active'", [$d['resident_id']])->fetchColumn()) $errors[] = 'Select a resident.';
    if (!isset($medInfo[$d['medicine_id']])) $errors[] = 'Select a medicine that is in stock.';
    if (!ctype_digit((string)$d['quantity']) || (int)$d['quantity'] < 1) $errors[] = 'Quantity must be at least 1.';
    if (!valid_date($d['distribution_date']) || $d['distribution_date'] > today()) $errors[] = 'Date must be a valid date, not in the future.';

    if (!$errors) {
        $qty = (int)$d['quantity'];
        db()->beginTransaction();
        try {
            // Lock usable batches, earliest expiry first (FEFO: first-expiry, first-out)
            $batches = q('SELECT stock_id, quantity_remaining FROM medicine_stock
                          WHERE medicine_id = ? AND quantity_remaining > 0 AND expiry_date >= CURDATE()
                          ORDER BY expiry_date, stock_id FOR UPDATE', [$d['medicine_id']])->fetchAll();
            $available = array_sum(array_column($batches, 'quantity_remaining'));
            if ($available < $qty) {
                throw new RuntimeException("Only $available " . $medInfo[$d['medicine_id']]['unit'] . ' available.');
            }
            $left = $qty;
            foreach ($batches as $b) {
                if ($left <= 0) break;
                $take = min($left, (int)$b['quantity_remaining']);
                q('UPDATE medicine_stock SET quantity_remaining = quantity_remaining - ? WHERE stock_id = ?', [$take, $b['stock_id']]);
                db_insert('medicine_distribution', [
                    'stock_id' => $b['stock_id'], 'medicine_id' => $d['medicine_id'], 'resident_id' => $d['resident_id'],
                    'consultation_id' => $consult ? $consult['consultation_id'] : null, 'quantity' => $take,
                    'distribution_date' => $d['distribution_date'], 'instructions' => nullable($d['instructions']), 'given_by' => user_id(),
                ]);
                $left -= $take;
            }
            db()->commit();
        } catch (RuntimeException $e) {
            db()->rollBack();
            $errors[] = $e->getMessage();
        }

        if (!$errors) {
            $m = $medInfo[$d['medicine_id']];
            log_activity('CREATE', 'medicine_distribution', null, 'Dispensed ' . $qty . ' ' . $m['unit'] . ' ' . $m['generic_name'] . ' to resident #' . $d['resident_id']);

            // Low-stock alert to nurse/admin
            $level = q('SELECT * FROM v_medicine_stock_levels WHERE medicine_id = ?', [$d['medicine_id']])->fetch();
            if ($level && $level['stock_status'] !== 'In Stock') {
                notify_roles(['nurse', 'admin'], $level['stock_status'] === 'Out of Stock' ? 'Out of stock' : 'Low stock alert',
                    $level['generic_name'] . ' ' . $level['strength'] . ' has ' . $level['usable_stock'] . ' ' . $level['unit'] . ' left (reorder at ' . $level['reorder_level'] . ').',
                    'modules/inventory/medicine_view.php?id=' . $level['medicine_id'], true);
            }
            flash('success', 'Dispensed ' . $qty . ' ' . $m['unit'] . ' of ' . $m['generic_name'] . '.');
            redirect('modules/inventory/distribute.php' . ($consult ? '?consultation_id=' . $consult['consultation_id'] : ''));
        }
    }
}

$recentWhere = $consult ? 'WHERE d.consultation_id = ' . (int)$consult['consultation_id'] : '';
$recent = q("SELECT d.*, m.generic_name, m.strength, m.unit, s.batch_no, r.first_name, r.middle_name, r.last_name, r.suffix, u.full_name AS giver
             FROM medicine_distribution d JOIN medicines m ON m.medicine_id = d.medicine_id JOIN medicine_stock s ON s.stock_id = d.stock_id
             JOIN residents r ON r.resident_id = d.resident_id LEFT JOIN users u ON u.user_id = d.given_by
             $recentWhere ORDER BY d.distribution_date DESC, d.distribution_id DESC LIMIT 25")->fetchAll();

$page_title = 'Dispense Medicine (Stock-out)';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<?php if ($consult): ?>
    <div class="alert alert-info">
        Dispensing for <strong><?= e(full_name($consult)) ?></strong> — consultation on <?= fmt_datetime($consult['consultation_date']) ?> (<?= e($consult['chief_complaint']) ?>).
        <?php if ($consult['treatment_plan']): ?><br>Treatment plan: <?= e($consult['treatment_plan']) ?><?php endif; ?>
        <a href="<?= e(url('modules/consultations/view.php?id=' . $consult['consultation_id'])) ?>">Back to consultation</a>
    </div>
<?php endif; ?>

<form method="post" class="card">
    <?= csrf_field() ?>
    <div class="form-grid">
        <?php if ($consult): ?>
            <?= field('Patient', 'patient_display', full_name($consult), 'text', 'disabled', 'span-2') ?>
        <?php else: ?>
            <?= select_field('Resident', 'resident_id', resident_options(), $d['resident_id'], 'required class="searchable"', '-- Select resident --', 'span-2') ?>
        <?php endif; ?>
        <?= select_field('Medicine', 'medicine_id', $medOptions, $d['medicine_id'], 'required class="searchable"', '-- Select medicine --', 'span-2') ?>
        <?= field('Quantity', 'quantity', $d['quantity'], 'number', 'required min="1"') ?>
        <?= field('Date', 'distribution_date', $d['distribution_date'], 'date', 'required max="' . today() . '"') ?>
        <?= field('Instructions', 'instructions', $d['instructions'], 'text', 'maxlength="255" placeholder="e.g. 1 tablet every 6 hours for 3 days"', 'span-2') ?>
    </div>
    <p class="hint">Stock is taken from the batch that expires first. Expired batches are never dispensed.</p>
    <div class="form-actions">
        <a class="btn" href="index.php">Back to inventory</a>
        <button class="btn btn-primary">Dispense</button>
    </div>
</form>

<div class="card">
    <h3><?= $consult ? 'Dispensed for this consultation' : 'Recent distribution records' ?></h3>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Date</th><th>Resident</th><th>Medicine</th><th>Batch</th><th class="num">Qty</th><th>Instructions</th><th>Given by</th></tr></thead>
        <tbody>
        <?php foreach ($recent as $r): ?>
            <tr>
                <td class="nowrap"><?= fmt_date($r['distribution_date']) ?></td>
                <td><a href="<?= e(url('modules/residents/view.php?id=' . $r['resident_id'] . '#medicines')) ?>"><?= e(full_name($r)) ?></a></td>
                <td><?= e($r['generic_name']) ?> <span class="small muted"><?= e($r['strength']) ?></span></td>
                <td class="small"><?= e($r['batch_no']) ?></td>
                <td class="num"><?= (int)$r['quantity'] ?> <?= e($r['unit']) ?></td>
                <td class="small"><?= e($r['instructions']) ?></td>
                <td class="small"><?= e($r['giver'] ?: '—') ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$recent): ?><tr><td colspan="7" class="empty">Nothing dispensed yet.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
