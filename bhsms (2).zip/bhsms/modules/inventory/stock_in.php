<?php
require __DIR__ . '/../../includes/init.php';
require_perm('inventory', 'edit');

$s = ['medicine_id' => get('medicine_id'), 'batch_no' => '', 'quantity_received' => '', 'expiry_date' => '', 'date_received' => today(), 'source' => ''];
$errors = [];

$medOptions = [];
foreach (q('SELECT medicine_id, generic_name, brand_name, strength, dosage_form FROM medicines WHERE is_active = 1 ORDER BY generic_name')->fetchAll() as $m) {
    $medOptions[$m['medicine_id']] = $m['generic_name'] . ($m['brand_name'] ? ' (' . $m['brand_name'] . ')' : '') . ' ' . $m['strength'] . ' ' . $m['dosage_form'];
}

if (is_post()) {
    foreach (array_keys($s) as $f) { $s[$f] = input($f); }
    if (!isset($medOptions[$s['medicine_id']])) $errors[] = 'Select a medicine.';
    if ($s['batch_no'] === '') $errors[] = 'Batch number is required.';
    if (!ctype_digit((string)$s['quantity_received']) || (int)$s['quantity_received'] < 1) $errors[] = 'Quantity must be at least 1.';
    if (!valid_date($s['date_received']) || $s['date_received'] > today()) $errors[] = 'Date received must be a valid date, not in the future.';
    if (!valid_date($s['expiry_date']) || $s['expiry_date'] <= today()) $errors[] = 'Expiry date must be in the future. Do not receive expired stock.';

    if (!$errors) {
        $id = db_insert('medicine_stock', [
            'medicine_id' => $s['medicine_id'], 'batch_no' => $s['batch_no'],
            'quantity_received' => (int)$s['quantity_received'], 'quantity_remaining' => (int)$s['quantity_received'],
            'expiry_date' => $s['expiry_date'], 'date_received' => $s['date_received'],
            'source' => nullable($s['source']), 'received_by' => user_id(),
        ]);
        log_activity('CREATE', 'medicine_stock', $id, 'Stock-in ' . $s['quantity_received'] . ' of ' . $medOptions[$s['medicine_id']]);
        flash('success', 'Received ' . $s['quantity_received'] . ' units of ' . $medOptions[$s['medicine_id']] . '.');
        redirect('modules/inventory/stock_in.php');
    }
}

$recent = q('SELECT s.*, m.generic_name, m.strength, m.unit, u.full_name AS receiver FROM medicine_stock s
             JOIN medicines m ON m.medicine_id = s.medicine_id LEFT JOIN users u ON u.user_id = s.received_by
             ORDER BY s.date_received DESC, s.stock_id DESC LIMIT 20')->fetchAll();

$page_title = 'Receive Stock (Stock-in)';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<form method="post" class="card">
    <?= csrf_field() ?>
    <div class="form-grid">
        <?= select_field('Medicine', 'medicine_id', $medOptions, $s['medicine_id'], 'required class="searchable"', '-- Select medicine --', 'span-2') ?>
        <?= field('Batch / lot no.', 'batch_no', $s['batch_no'], 'text', 'required maxlength="50"') ?>
        <?= field('Quantity received', 'quantity_received', $s['quantity_received'], 'number', 'required min="1"') ?>
        <?= field('Expiry date', 'expiry_date', $s['expiry_date'], 'date', 'required min="' . date('Y-m-d', strtotime('+1 day')) . '"') ?>
        <?= field('Date received', 'date_received', $s['date_received'], 'date', 'required max="' . today() . '"') ?>
        <?= field('Source / supplier', 'source', $s['source'], 'text', 'maxlength="150" list="sources" placeholder="DOH-CAR, City Health Office, Donation"', 'span-2') ?>
    </div>
    <datalist id="sources"><option value="DOH-CAR"><option value="City Health Office"><option value="Donation"><option value="LGU Purchase"></datalist>
    <div class="form-actions">
        <a class="btn" href="index.php">Back to inventory</a>
        <button class="btn btn-primary">Save stock-in</button>
    </div>
</form>

<div class="card">
    <h3>Recent stock-in</h3>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Date</th><th>Medicine</th><th>Batch</th><th class="num">Received</th><th class="num">Remaining</th><th>Expiry</th><th>Source</th><th>Received by</th></tr></thead>
        <tbody>
        <?php foreach ($recent as $r): ?>
            <tr>
                <td class="nowrap"><?= fmt_date($r['date_received']) ?></td>
                <td><a href="medicine_view.php?id=<?= (int)$r['medicine_id'] ?>"><?= e($r['generic_name']) ?></a> <span class="small muted"><?= e($r['strength']) ?></span></td>
                <td><?= e($r['batch_no']) ?></td>
                <td class="num"><?= (int)$r['quantity_received'] ?> <?= e($r['unit']) ?></td>
                <td class="num"><?= (int)$r['quantity_remaining'] ?></td>
                <td class="nowrap <?= $r['expiry_date'] < today() ? 'text-danger' : '' ?>"><?= fmt_date($r['expiry_date']) ?></td>
                <td><?= e($r['source'] ?: '—') ?></td>
                <td class="small"><?= e($r['receiver'] ?: '—') ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
