<?php
require __DIR__ . '/../../includes/init.php';
require_perm('inventory');

$status = get('status');
$search = get('q');
$where = ['1=1'];
$params = [];
if ($status !== '') { $where[] = 'stock_status = ?'; $params[] = $status; }
if ($search !== '') { $where[] = '(generic_name LIKE ? OR brand_name LIKE ?)'; array_push($params, "%$search%", "%$search%"); }
$w = implode(' AND ', $where);
$rows = q("SELECT * FROM v_medicine_stock_levels WHERE $w ORDER BY FIELD(stock_status, 'Out of Stock', 'Low Stock', 'In Stock'), generic_name", $params)->fetchAll();

$counts = ['In Stock' => 0, 'Low Stock' => 0, 'Out of Stock' => 0];
foreach (q('SELECT stock_status, COUNT(*) AS n FROM v_medicine_stock_levels GROUP BY stock_status')->fetchAll() as $c) {
    $counts[$c['stock_status']] = (int)$c['n'];
}
$expiring = q('SELECT s.*, m.generic_name, m.strength, m.unit FROM medicine_stock s JOIN medicines m ON m.medicine_id = s.medicine_id
               WHERE s.quantity_remaining > 0 AND s.expiry_date < CURDATE() + INTERVAL 90 DAY ORDER BY s.expiry_date')->fetchAll();
$dispensedMonth = (int)q("SELECT COALESCE(SUM(quantity), 0) FROM medicine_distribution
                          WHERE distribution_date >= DATE_FORMAT(CURDATE(), '%Y-%m-01')")->fetchColumn();

$page_title = 'Medicine Inventory';
require __DIR__ . '/../../includes/header.php';
?>
<div class="stats">
    <a class="stat" href="index.php?status=In+Stock"><div class="label">In stock</div><div class="value"><?= $counts['In Stock'] ?></div></a>
    <a class="stat amber" href="index.php?status=Low+Stock"><div class="label">Low stock</div><div class="value"><?= $counts['Low Stock'] ?></div></a>
    <a class="stat red" href="index.php?status=Out+of+Stock"><div class="label">Out of stock</div><div class="value"><?= $counts['Out of Stock'] ?></div></a>
    <div class="stat blue"><div class="label">Units dispensed this month</div><div class="value"><?= $dispensedMonth ?></div></div>
</div>

<?php if ($expiring): ?>
<div class="card">
    <h3>Expired or expiring within 90 days</h3>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Medicine</th><th>Batch</th><th class="num">Remaining</th><th>Expiry</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($expiring as $b): $expired = $b['expiry_date'] < today(); ?>
            <tr class="<?= $expired ? 'row-danger' : 'row-warning' ?>">
                <td><?= e($b['generic_name']) ?> <span class="small muted"><?= e($b['strength']) ?></span></td>
                <td><?= e($b['batch_no']) ?></td>
                <td class="num"><?= (int)$b['quantity_remaining'] ?> <?= e($b['unit']) ?></td>
                <td><?= fmt_date($b['expiry_date']) ?> <?= badge($expired ? 'Expired' : 'Due soon') ?></td>
                <td class="actions"><a class="btn btn-sm" href="medicine_view.php?id=<?= (int)$b['medicine_id'] ?>#batches"><?= $expired && can('inventory', 'edit') ? 'Dispose' : 'View' ?></a></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h3>Available medicines</h3>
        <div class="btn-group">
            <?php if (can('inventory', 'distribute')): ?><a class="btn btn-primary" href="distribute.php">Dispense (stock-out)</a><?php endif; ?>
            <?php if (can('inventory', 'edit')): ?>
                <a class="btn" href="stock_in.php">Receive stock (stock-in)</a>
                <a class="btn" href="medicine_form.php">+ Add medicine</a>
            <?php endif; ?>
        </div>
    </div>
    <form class="toolbar" method="get">
        <div class="grow"><label>Search</label><input type="search" name="q" value="<?= e($search) ?>" placeholder="Generic or brand name"></div>
        <div><label>Stock status</label><select name="status"><?= options(['In Stock', 'Low Stock', 'Out of Stock'], $status, 'All') ?></select></div>
        <button class="btn">Filter</button>
    </form>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Medicine</th><th>Form / strength</th><th class="num">Usable stock</th><th class="num">Reorder level</th><th>Nearest expiry</th><th class="num">Expired qty</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $m): ?>
            <tr>
                <td><a href="medicine_view.php?id=<?= (int)$m['medicine_id'] ?>"><strong><?= e($m['generic_name']) ?></strong></a>
                    <?= $m['brand_name'] ? '<div class="small muted">' . e($m['brand_name']) . '</div>' : '' ?></td>
                <td><?= e($m['dosage_form']) ?> <?= e($m['strength']) ?></td>
                <td class="num"><strong><?= (int)$m['usable_stock'] ?></strong> <?= e($m['unit']) ?></td>
                <td class="num"><?= (int)$m['reorder_level'] ?></td>
                <td><?= fmt_date($m['nearest_expiry']) ?></td>
                <td class="num <?= $m['expired_stock'] ? 'text-danger' : '' ?>"><?= (int)$m['expired_stock'] ?></td>
                <td><?= badge($m['stock_status']) ?></td>
                <td class="actions"><a class="btn btn-sm" href="medicine_view.php?id=<?= (int)$m['medicine_id'] ?>">View</a></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="8" class="empty">No medicines found.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
