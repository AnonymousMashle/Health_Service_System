<?php
require __DIR__ . '/../../includes/init.php';
require_perm('inventory', 'edit');

const DOSAGE_FORMS = ['Tablet', 'Capsule', 'Syrup', 'Suspension', 'Drops', 'Ointment', 'Injection', 'Sachet', 'Other'];

$id = (int)get('id');
$m = ['generic_name' => '', 'brand_name' => '', 'dosage_form' => 'Tablet', 'strength' => '', 'unit' => 'pcs', 'reorder_level' => 50, 'is_active' => 1];
if ($id) {
    $m = q('SELECT * FROM medicines WHERE medicine_id = ?', [$id])->fetch();
    if (!$m) {
        flash('danger', 'Medicine not found.');
        redirect('modules/inventory/index.php');
    }
}
$errors = [];

if (is_post()) {
    foreach (['generic_name', 'brand_name', 'dosage_form', 'strength', 'unit', 'reorder_level'] as $f) { $m[$f] = input($f); }
    $m['is_active'] = isset($_POST['is_active']) ? 1 : 0;
    if ($m['generic_name'] === '') $errors[] = 'Generic name is required.';
    if (!in_array($m['dosage_form'], DOSAGE_FORMS, true)) $errors[] = 'Select a dosage form.';
    if ($m['unit'] === '') $errors[] = 'Unit is required.';
    if (!ctype_digit((string)$m['reorder_level'])) $errors[] = 'Reorder level must be a whole number.';

    if (!$errors) {
        $data = ['generic_name' => $m['generic_name'], 'brand_name' => nullable($m['brand_name']), 'dosage_form' => $m['dosage_form'],
                 'strength' => nullable($m['strength']), 'unit' => $m['unit'], 'reorder_level' => (int)$m['reorder_level'], 'is_active' => $m['is_active']];
        try {
            if ($id) {
                db_update('medicines', $data, 'medicine_id', $id);
                log_activity('UPDATE', 'medicines', $id, 'Updated medicine ' . $data['generic_name']);
            } else {
                $id = db_insert('medicines', $data);
                log_activity('CREATE', 'medicines', $id, 'Added medicine ' . $data['generic_name']);
            }
            flash('success', 'Medicine saved.');
            redirect('modules/inventory/medicine_view.php?id=' . $id);
        } catch (PDOException $e) {
            if (!is_duplicate_error($e)) throw $e;
            $errors[] = 'This medicine (same name, form and strength) already exists.';
        }
    }
}

$page_title = $id ? 'Edit Medicine' : 'Add Medicine';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<form method="post" class="card">
    <?= csrf_field() ?>
    <div class="form-grid">
        <?= field('Generic name', 'generic_name', $m['generic_name'], 'text', 'required maxlength="150"') ?>
        <?= field('Brand name', 'brand_name', $m['brand_name'], 'text', 'maxlength="150"') ?>
        <?= select_field('Dosage form', 'dosage_form', DOSAGE_FORMS, $m['dosage_form'], 'required', false) ?>
        <?= field('Strength', 'strength', $m['strength'], 'text', 'maxlength="50" placeholder="500 mg"') ?>
        <?= field('Unit', 'unit', $m['unit'], 'text', 'required maxlength="20" list="units"') ?>
        <div class="field required">
            <label for="f_reorder_level">Reorder level</label>
            <input id="f_reorder_level" type="number" name="reorder_level" min="0" value="<?= e($m['reorder_level']) ?>" required>
            <div class="hint">"Low stock" alert when usable stock reaches this number.</div>
        </div>
        <div class="field"><label>&nbsp;</label><?= checkbox('Active (shown in inventory)', 'is_active', $m['is_active']) ?></div>
    </div>
    <datalist id="units"><option value="pcs"><option value="bottle"><option value="sachet"><option value="tube"><option value="vial"><option value="box"></datalist>
    <div class="form-actions">
        <a class="btn" href="<?= $id ? 'medicine_view.php?id=' . $id : 'index.php' ?>">Cancel</a>
        <button class="btn btn-primary">Save medicine</button>
    </div>
</form>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
