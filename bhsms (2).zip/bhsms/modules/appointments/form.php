<?php
/* Staff books an appointment for a resident (walk-in or phone request). It is approved immediately. */
require __DIR__ . '/../../includes/init.php';
require_perm('appointments', 'edit');

$services = ['General Consultation', 'Vaccination', 'Prenatal Check-up', 'Child Check-up', 'Family Planning', 'Medicine Request', 'Other'];
$a = ['resident_id' => get('resident_id'), 'service_type' => '', 'scheduled_date' => today(), 'scheduled_time' => '08:00', 'reason' => '', 'remarks' => ''];
$errors = [];

if (is_post()) {
    foreach (array_keys($a) as $f) { $a[$f] = input($f); }
    if (!q("SELECT 1 FROM residents WHERE resident_id = ? AND status = 'active'", [$a['resident_id']])->fetchColumn()) $errors[] = 'Select a resident.';
    if (!in_array($a['service_type'], $services, true)) $errors[] = 'Select a service.';
    if (!valid_date($a['scheduled_date']) || $a['scheduled_date'] < today()) $errors[] = 'Date must be today or later.';
    if (!preg_match('/^\d{2}:\d{2}$/', $a['scheduled_time'])) $errors[] = 'Enter a valid time.';

    if (!$errors) {
        $id = db_insert('appointments', [
            'resident_id' => $a['resident_id'], 'service_type' => $a['service_type'],
            'preferred_date' => $a['scheduled_date'], 'preferred_time' => $a['scheduled_time'] . ':00',
            'scheduled_date' => $a['scheduled_date'], 'scheduled_time' => $a['scheduled_time'] . ':00',
            'reason' => nullable($a['reason']), 'remarks' => nullable($a['remarks']), 'status' => 'approved',
            'requested_by' => user_id(), 'approved_by' => user_id(), 'approved_at' => date('Y-m-d H:i:s'),
        ]);
        log_activity('CREATE', 'appointments', $id, 'Booked ' . $a['service_type'] . ' on ' . $a['scheduled_date']);
        notify_resident((int)$a['resident_id'], 'Appointment scheduled',
            'Your ' . $a['service_type'] . ' is scheduled on ' . fmt_date($a['scheduled_date']) . ' at ' . fmt_time($a['scheduled_time']) . '.', 'portal/appointments.php');
        flash('success', 'Appointment booked.');
        redirect('modules/appointments/index.php?status=approved');
    }
}

$page_title = 'Book Appointment';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<form method="post" class="card">
    <?= csrf_field() ?>
    <div class="form-grid">
        <?= select_field('Resident', 'resident_id', resident_options(), $a['resident_id'], 'required class="searchable"', '-- Select resident --', 'span-2') ?>
        <?= select_field('Service', 'service_type', $services, $a['service_type'], 'required') ?>
        <?= field('Date', 'scheduled_date', $a['scheduled_date'], 'date', 'required min="' . today() . '"') ?>
        <?= field('Time', 'scheduled_time', $a['scheduled_time'], 'time', 'required') ?>
        <?= field('Reason', 'reason', $a['reason'], 'text', 'maxlength="255"', 'span-2') ?>
        <?= field('Remarks', 'remarks', $a['remarks'], 'text', 'maxlength="255"', 'span-2') ?>
    </div>
    <div class="form-actions">
        <a class="btn" href="index.php">Cancel</a>
        <button class="btn btn-primary">Book appointment</button>
    </div>
</form>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
