<?php
/* Handles approve / reject / complete / no-show / cancel for staff. POST only. */
require __DIR__ . '/../../includes/init.php';
require_perm('appointments', 'edit');

if (!is_post()) {
    redirect('modules/appointments/index.php');
}

$id = (int)input('appointment_id');
$action = input('action');
$remarks = input('remarks');
$a = q('SELECT a.*, r.first_name, r.last_name FROM appointments a JOIN residents r ON r.resident_id = a.resident_id WHERE a.appointment_id = ?', [$id])->fetch();
$back = back_url('modules/appointments/index.php');

if (!$a) {
    flash('danger', 'Appointment not found.');
    redirect($back);
}

// Which status each action needs, and what it becomes
$rules = [
    'approve'  => ['from' => ['pending'], 'to' => 'approved'],
    'reject'   => ['from' => ['pending'], 'to' => 'rejected'],
    'complete' => ['from' => ['approved'], 'to' => 'completed'],
    'no-show'  => ['from' => ['approved'], 'to' => 'no-show'],
    'cancel'   => ['from' => ['pending', 'approved'], 'to' => 'cancelled'],
];
if (!isset($rules[$action]) || !in_array($a['status'], $rules[$action]['from'], true)) {
    flash('danger', 'That action is not allowed for a ' . $a['status'] . ' appointment.');
    redirect($back);
}
$newStatus = $rules[$action]['to'];
$name = $a['first_name'] . ' ' . $a['last_name'];

if ($action === 'approve') {
    $date = input('scheduled_date');
    $time = input('scheduled_time');
    if (!valid_date($date) || $date < today() || !preg_match('/^\d{2}:\d{2}$/', $time)) {
        flash('danger', 'Enter a valid schedule date (today or later) and time.');
        redirect($back);
    }
    q("UPDATE appointments SET status = 'approved', scheduled_date = ?, scheduled_time = ?, remarks = ?, approved_by = ?, approved_at = NOW()
       WHERE appointment_id = ?", [$date, $time . ':00', nullable($remarks), user_id(), $id]);
    notify_resident((int)$a['resident_id'], 'Appointment approved',
        'Your ' . $a['service_type'] . ' is scheduled on ' . fmt_date($date) . ' at ' . fmt_time($time) . '.' . ($remarks ? ' Note: ' . $remarks : ''),
        'portal/appointments.php');
} elseif ($action === 'reject') {
    if ($remarks === '') {
        flash('danger', 'Give a reason for rejecting the request.');
        redirect($back);
    }
    q("UPDATE appointments SET status = 'rejected', remarks = ?, approved_by = ?, approved_at = NOW() WHERE appointment_id = ?", [$remarks, user_id(), $id]);
    notify_resident((int)$a['resident_id'], 'Appointment request declined', 'Your ' . $a['service_type'] . ' request was declined: ' . $remarks, 'portal/appointments.php');
} else {
    q('UPDATE appointments SET status = ? WHERE appointment_id = ?', [$newStatus, $id]);
    if ($action === 'cancel') {
        notify_resident((int)$a['resident_id'], 'Appointment cancelled', 'Your ' . $a['service_type'] . ' appointment was cancelled by the health center.', 'portal/appointments.php');
    }
}

log_activity('UPDATE', 'appointments', $id, ucfirst($newStatus) . ' appointment of ' . $name);
flash('success', 'Appointment of ' . $name . ' marked as ' . $newStatus . '.');
redirect($back);
