<?php
require __DIR__ . '/../../includes/init.php';
require_perm('appointments');

$status = get('status', 'pending');
$validStatuses = ['pending', 'approved', 'completed', 'rejected', 'cancelled', 'no-show'];
if ($status !== 'all' && !in_array($status, $validStatuses, true)) $status = 'pending';
$date = get('date');
$service = get('service');

$counts = array_fill_keys($validStatuses, 0);
foreach (q('SELECT status, COUNT(*) AS n FROM appointments GROUP BY status')->fetchAll() as $c) {
    $counts[$c['status']] = (int)$c['n'];
}

$where = ['1=1'];
$params = [];
if ($status !== 'all') { $where[] = 'a.status = ?'; $params[] = $status; }
if (valid_date($date)) { $where[] = 'COALESCE(a.scheduled_date, a.preferred_date) = ?'; $params[] = $date; }
if ($service !== '')   { $where[] = 'a.service_type = ?'; $params[] = $service; }
$w = implode(' AND ', $where);
$order = $status === 'pending' ? 'a.preferred_date, a.preferred_time' : 'COALESCE(a.scheduled_date, a.preferred_date) ' . (in_array($status, ['approved'], true) ? 'ASC' : 'DESC');
$join = 'FROM appointments a JOIN residents r ON r.resident_id = a.resident_id LEFT JOIN users ap ON ap.user_id = a.approved_by';
$pg = paginate((int)q("SELECT COUNT(*) $join WHERE $w", $params)->fetchColumn(), 20);
$rows = q("SELECT a.*, r.first_name, r.middle_name, r.last_name, r.suffix, r.contact_no, r.birthdate, ap.full_name AS approver
           $join WHERE $w ORDER BY $order LIMIT {$pg['per']} OFFSET {$pg['offset']}", $params)->fetchAll();

$services = ['General Consultation', 'Vaccination', 'Prenatal Check-up', 'Child Check-up', 'Family Planning', 'Medicine Request', 'Other'];
$canEdit = can('appointments', 'edit');

$page_title = 'Appointments';
require __DIR__ . '/../../includes/header.php';
?>
<div class="card">
    <div class="card-header">
        <div class="tabs" style="margin:0;border:0">
            <?php foreach (array_merge($validStatuses, ['all']) as $st): ?>
                <a class="<?= $status === $st ? 'active' : '' ?>" href="index.php?status=<?= e($st) ?>"><?= e(ucfirst($st)) ?><?= $st !== 'all' ? ' (' . $counts[$st] . ')' : '' ?></a>
            <?php endforeach; ?>
        </div>
        <?php if ($canEdit): ?><a class="btn btn-primary" href="form.php">+ Book for a resident</a><?php endif; ?>
    </div>

    <form class="toolbar" method="get">
        <input type="hidden" name="status" value="<?= e($status) ?>">
        <div><label>Date</label><input type="date" name="date" value="<?= e($date) ?>"></div>
        <div><label>Service</label><select name="service"><?= options($services, $service, 'All') ?></select></div>
        <button class="btn">Filter</button>
        <a class="btn" href="index.php?status=approved&date=<?= today() ?>">Today's schedule</a>
    </form>

    <div class="table-wrap"><table class="table">
        <thead><tr><th>Date &amp; time</th><th>Resident</th><th>Service</th><th>Reason</th><th>Status</th><th>Remarks</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $a):
            $when = $a['scheduled_date'] ?: $a['preferred_date'];
            $time = $a['scheduled_time'] ?: $a['preferred_time']; ?>
            <tr>
                <td class="nowrap"><?= fmt_date($when) ?><div class="small muted"><?= fmt_time($time) ?><?= $a['status'] === 'pending' ? ' (preferred)' : '' ?></div></td>
                <td><a href="<?= e(url('modules/residents/view.php?id=' . $a['resident_id'] . '#appointments')) ?>"><?= e(full_name($a)) ?></a>
                    <div class="small muted"><?= e($a['contact_no']) ?></div></td>
                <td><?= e($a['service_type']) ?></td>
                <td class="small"><?= e($a['reason']) ?></td>
                <td><?= badge($a['status']) ?><?= $a['approver'] ? '<div class="small muted">by ' . e($a['approver']) . '</div>' : '' ?></td>
                <td class="small"><?= e($a['remarks']) ?></td>
                <td class="actions">
                <?php if ($canEdit && $a['status'] === 'pending'): ?>
                    <details class="pop">
                        <summary class="btn btn-sm btn-success">Approve</summary>
                        <div class="pop-body">
                            <form method="post" action="action.php">
                                <?= csrf_field() ?><?= back_field() ?>
                                <input type="hidden" name="appointment_id" value="<?= (int)$a['appointment_id'] ?>">
                                <input type="hidden" name="action" value="approve">
                                <?= field('Schedule date', 'scheduled_date', $a['preferred_date'] >= today() ? $a['preferred_date'] : today(), 'date', 'required min="' . today() . '"') ?>
                                <?= field('Time', 'scheduled_time', $a['preferred_time'] ? substr($a['preferred_time'], 0, 5) : '08:00', 'time', 'required') ?>
                                <?= field('Note to resident', 'remarks', '', 'text', 'maxlength="255"') ?>
                                <button class="btn btn-success btn-sm">Confirm approval</button>
                            </form>
                        </div>
                    </details>
                    <details class="pop">
                        <summary class="btn btn-sm btn-danger">Reject</summary>
                        <div class="pop-body">
                            <form method="post" action="action.php">
                                <?= csrf_field() ?><?= back_field() ?>
                                <input type="hidden" name="appointment_id" value="<?= (int)$a['appointment_id'] ?>">
                                <input type="hidden" name="action" value="reject">
                                <?= field('Reason for rejecting', 'remarks', '', 'text', 'required maxlength="255"') ?>
                                <button class="btn btn-danger btn-sm">Reject request</button>
                            </form>
                        </div>
                    </details>
                <?php elseif ($canEdit && $a['status'] === 'approved'): ?>
                    <?php if (can('consultations', 'edit')): ?>
                        <a class="btn btn-sm btn-primary" href="<?= e(url('modules/consultations/form.php?appointment_id=' . $a['appointment_id'])) ?>">Start consultation</a>
                    <?php endif; ?>
                    <?= post_button('action.php', 'Done', ['appointment_id' => $a['appointment_id'], 'action' => 'complete'], 'btn btn-sm btn-success') ?>
                    <?= post_button('action.php', 'No-show', ['appointment_id' => $a['appointment_id'], 'action' => 'no-show'], 'btn btn-sm', 'Mark as no-show?') ?>
                    <?= post_button('action.php', 'Cancel', ['appointment_id' => $a['appointment_id'], 'action' => 'cancel'], 'btn btn-sm btn-danger', 'Cancel this appointment?') ?>
                <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="7" class="empty">No appointments here.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
    <?= pagination_links($pg) ?>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
