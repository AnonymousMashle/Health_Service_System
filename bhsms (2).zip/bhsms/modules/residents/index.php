<?php
require __DIR__ . '/../../includes/init.php';
require_perm('residents');

$search = get('q');
$purok  = get('purok');
$sex    = get('sex');
$status = get('status', 'active');

$where = ['1=1'];
$params = [];
if ($search !== '') {
    $where[] = "(r.first_name LIKE ? OR r.last_name LIKE ? OR CONCAT(r.first_name, ' ', r.last_name) LIKE ? OR h.household_no LIKE ? OR r.philhealth_no LIKE ?)";
    $like = '%' . $search . '%';
    array_push($params, $like, $like, $like, $like, $like);
}
if ($purok !== '') { $where[] = 'h.purok = ?'; $params[] = $purok; }
if ($sex !== '')   { $where[] = 'r.sex = ?';   $params[] = $sex; }
if ($status !== '') { $where[] = 'r.status = ?'; $params[] = $status; }
$w = implode(' AND ', $where);

$from = 'FROM residents r LEFT JOIN households h ON h.household_id = r.household_id';
$pg = paginate((int)q("SELECT COUNT(*) $from WHERE $w", $params)->fetchColumn());
$rows = q("SELECT r.*, h.household_no, h.purok $from WHERE $w ORDER BY r.last_name, r.first_name LIMIT {$pg['per']} OFFSET {$pg['offset']}", $params)->fetchAll();
$puroks = q('SELECT DISTINCT purok FROM households ORDER BY purok')->fetchAll(PDO::FETCH_COLUMN);

$page_title = 'Residents';
require __DIR__ . '/../../includes/header.php';
?>
<div class="card">
    <div class="card-header">
        <h3>Resident health registry</h3>
        <?php if (can('residents', 'edit')): ?>
            <a class="btn btn-primary" href="form.php">+ Register resident</a>
        <?php endif; ?>
    </div>

    <form class="toolbar" method="get">
        <div class="grow"><label>Search</label><input type="search" name="q" value="<?= e($search) ?>" placeholder="Name, household no. or PhilHealth no."></div>
        <div><label>Purok</label><select name="purok"><?= options($puroks, $purok, 'All') ?></select></div>
        <div><label>Sex</label><select name="sex"><?= options(['Male', 'Female'], $sex, 'All') ?></select></div>
        <div><label>Status</label><select name="status"><?= options(['active', 'transferred', 'deceased'], $status, 'All') ?></select></div>
        <button class="btn">Filter</button>
        <a class="btn" href="index.php">Reset</a>
    </form>

    <div class="table-wrap"><table class="table">
        <thead><tr><th>Name</th><th>Sex</th><th>Age</th><th>Household</th><th>Purok</th><th>Contact</th><th>Tags</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r): ?>
            <tr>
                <td><a href="view.php?id=<?= (int)$r['resident_id'] ?>"><strong><?= e(full_name($r)) ?></strong></a></td>
                <td><?= e($r['sex']) ?></td>
                <td class="nowrap"><?= e(age_label($r['birthdate'])) ?></td>
                <td><?= e($r['household_no'] ?? '—') ?></td>
                <td><?= e($r['purok'] ?? '—') ?></td>
                <td><?= e($r['contact_no'] ?: '—') ?></td>
                <td class="small">
                    <?= $r['is_senior'] ? '<span class="badge badge-purple">Senior</span> ' : '' ?>
                    <?= $r['is_pwd'] ? '<span class="badge badge-blue">PWD</span> ' : '' ?>
                    <?= $r['is_4ps_member'] ? '<span class="badge badge-amber">4Ps</span>' : '' ?>
                </td>
                <td><?= badge($r['status']) ?></td>
                <td class="actions">
                    <a class="btn btn-sm" href="view.php?id=<?= (int)$r['resident_id'] ?>">View</a>
                    <?php if (can('residents', 'edit')): ?><a class="btn btn-sm" href="form.php?id=<?= (int)$r['resident_id'] ?>">Edit</a><?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="9" class="empty">No residents found.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
    <?= pagination_links($pg) ?>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
