<?php
require __DIR__ . '/../../includes/init.php';
require_perm('residents', 'edit');

const CIVIL_STATUS = ['Single', 'Married', 'Widowed', 'Separated', 'Live-in'];
const BLOOD_TYPES  = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-', 'Unknown'];
const RELATIONSHIPS = ['Head', 'Spouse', 'Partner', 'Son', 'Daughter', 'Father', 'Mother', 'Sibling', 'Grandchild', 'Relative', 'Other'];

$id = (int)get('id');

$resFields = ['household_id', 'first_name', 'middle_name', 'last_name', 'suffix', 'sex', 'birthdate', 'civil_status',
              'relationship_to_head', 'contact_no', 'philhealth_no', 'occupation', 'status'];
$resChecks = ['is_4ps_member', 'is_pwd'];
$hpFields  = ['blood_type', 'height_cm', 'weight_kg', 'allergies', 'existing_conditions', 'maintenance_meds', 'disability'];
$hpChecks  = ['is_smoker', 'is_alcohol_drinker'];

// Defaults for a new resident
$r = array_fill_keys(array_merge($resFields, $resChecks), '');
$r['household_id'] = get('household_id');
$r['civil_status'] = 'Single';
$r['status'] = 'active';
$hp = array_fill_keys(array_merge($hpFields, $hpChecks), '');
$hp['blood_type'] = 'Unknown';
$contacts = [];

if ($id) {
    $r = q('SELECT * FROM residents WHERE resident_id = ?', [$id])->fetch();
    if (!$r) {
        flash('danger', 'Resident not found.');
        redirect('modules/residents/index.php');
    }
    $hp = q('SELECT * FROM health_profiles WHERE resident_id = ?', [$id])->fetch() ?: $hp;
    $contacts = q('SELECT * FROM emergency_contacts WHERE resident_id = ? ORDER BY contact_id', [$id])->fetchAll();
}

$errors = [];

if (is_post()) {
    foreach ($resFields as $f) { $r[$f] = input($f); }
    foreach ($resChecks as $f) { $r[$f] = isset($_POST[$f]) ? 1 : 0; }
    foreach ($hpFields as $f)  { $hp[$f] = input($f); }
    foreach ($hpChecks as $f)  { $hp[$f] = isset($_POST[$f]) ? 1 : 0; }

    $contacts = [];
    foreach ((array)($_POST['ec_name'] ?? []) as $i => $name) {
        $c = [
            'contact_name' => trim((string)$name),
            'relationship' => trim((string)($_POST['ec_relationship'][$i] ?? '')),
            'contact_no'   => trim((string)($_POST['ec_contact_no'][$i] ?? '')),
            'address'      => trim((string)($_POST['ec_address'][$i] ?? '')),
        ];
        if ($c['contact_name'] !== '' || $c['contact_no'] !== '') {
            $contacts[] = $c;
        }
    }

    // ----- Validation -----
    if ($r['first_name'] === '') $errors[] = 'First name is required.';
    if ($r['last_name'] === '')  $errors[] = 'Last name is required.';
    if (!in_array($r['sex'], ['Male', 'Female'], true)) $errors[] = 'Select a sex.';
    if (!valid_date($r['birthdate'])) {
        $errors[] = 'Enter a valid birthdate.';
    } elseif ($r['birthdate'] > today()) {
        $errors[] = 'Birthdate cannot be in the future.';
    }
    if (!in_array($r['civil_status'], CIVIL_STATUS, true)) $errors[] = 'Select a civil status.';
    if (!in_array($r['status'], ['active', 'transferred', 'deceased'], true)) $r['status'] = 'active';
    if ($r['contact_no'] !== '' && !preg_match('/^(09\d{9}|\+639\d{9})$/', $r['contact_no'])) {
        $errors[] = 'Contact number must look like 09171234567.';
    }
    if ($r['household_id'] !== '' && !q('SELECT 1 FROM households WHERE household_id = ?', [$r['household_id']])->fetchColumn()) {
        $errors[] = 'Selected household does not exist.';
    }
    foreach (['height_cm' => [30, 250], 'weight_kg' => [1, 300]] as $f => [$min, $max]) {
        if ($hp[$f] !== '' && (!is_numeric($hp[$f]) || $hp[$f] < $min || $hp[$f] > $max)) {
            $errors[] = ($f === 'height_cm' ? 'Height' : 'Weight') . " must be between $min and $max.";
        }
    }
    if (!in_array($hp['blood_type'], BLOOD_TYPES, true)) $hp['blood_type'] = 'Unknown';
    foreach ($contacts as $c) {
        if ($c['contact_name'] === '' || $c['relationship'] === '' || $c['contact_no'] === '') {
            $errors[] = 'Each emergency contact needs a name, relationship and contact number.';
            break;
        }
    }

    // ----- Save -----
    if (!$errors) {
        $data = [];
        foreach ($resFields as $f) { $data[$f] = nullable($r[$f]); }
        foreach ($resChecks as $f) { $data[$f] = $r[$f]; }
        $data['is_senior'] = age_years($r['birthdate']) >= 60 ? 1 : 0;   // computed automatically

        $hpData = [];
        foreach ($hpFields as $f) { $hpData[$f] = nullable($hp[$f]); }
        foreach ($hpChecks as $f) { $hpData[$f] = $hp[$f]; }
        $hpData['blood_type'] = $hp['blood_type'];
        $hpData['updated_by'] = user_id();

        $origId = $id;
        db()->beginTransaction();
        try {
            if ($id) {
                db_update('residents', $data, 'resident_id', $id);
                $action = 'UPDATE';
            } else {
                $data['created_by'] = user_id();
                $id = db_insert('residents', $data);
                $action = 'CREATE';
            }

            if (q('SELECT 1 FROM health_profiles WHERE resident_id = ?', [$id])->fetchColumn()) {
                db_update('health_profiles', $hpData, 'resident_id', $id);
            } else {
                db_insert('health_profiles', $hpData + ['resident_id' => $id]);
            }

            q('DELETE FROM emergency_contacts WHERE resident_id = ?', [$id]);
            foreach ($contacts as $c) {
                db_insert('emergency_contacts', ['resident_id' => $id] + array_map('nullable', $c));
            }

            if ($r['relationship_to_head'] === 'Head' && $r['household_id'] !== '') {
                q('UPDATE households SET head_resident_id = ? WHERE household_id = ?', [$id, $r['household_id']]);
            }

            db()->commit();
            log_activity($action, 'residents', $id, ($action === 'CREATE' ? 'Registered ' : 'Updated ') . $r['first_name'] . ' ' . $r['last_name']);
            flash('success', 'Resident record saved.');
            redirect('modules/residents/view.php?id=' . $id);
        } catch (PDOException $e) {
            db()->rollBack();
            $id = $origId;
            if (!is_duplicate_error($e)) {
                throw $e;
            }
            $errors[] = 'That PhilHealth number is already registered to another resident.';
        }
    }
}

// Always show at least 2 emergency contact rows
while (count($contacts) < 2) {
    $contacts[] = ['contact_name' => '', 'relationship' => '', 'contact_no' => '', 'address' => ''];
}

$page_title = $id ? 'Edit Resident' : 'Register Resident';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<form method="post" class="card">
    <?= csrf_field() ?>

    <fieldset>
        <legend>Resident information</legend>
        <div class="form-grid">
            <?= select_field('Household', 'household_id', household_options(), $r['household_id'], 'class="searchable"', '-- No household yet --', 'span-2') ?>
            <?= select_field('Relationship to household head', 'relationship_to_head', RELATIONSHIPS, $r['relationship_to_head'], '', '-- Select --') ?>
            <?= field('First name', 'first_name', $r['first_name'], 'text', 'required maxlength="80"') ?>
            <?= field('Middle name', 'middle_name', $r['middle_name'], 'text', 'maxlength="80"') ?>
            <?= field('Last name', 'last_name', $r['last_name'], 'text', 'required maxlength="80"') ?>
            <?= field('Suffix', 'suffix', $r['suffix'], 'text', 'maxlength="10" placeholder="Jr., Sr., III"') ?>
            <?= select_field('Sex', 'sex', ['Male', 'Female'], $r['sex'], 'required') ?>
            <?= field('Birthdate', 'birthdate', $r['birthdate'], 'date', 'required max="' . today() . '"') ?>
            <?= select_field('Civil status', 'civil_status', CIVIL_STATUS, $r['civil_status'], 'required', false) ?>
            <?= field('Contact number', 'contact_no', $r['contact_no'], 'tel', 'maxlength="13" placeholder="09XXXXXXXXX"') ?>
            <?= field('PhilHealth number', 'philhealth_no', $r['philhealth_no'], 'text', 'maxlength="20"') ?>
            <?= field('Occupation', 'occupation', $r['occupation'], 'text', 'maxlength="100"') ?>
            <?php if ($id): ?>
                <?= select_field('Record status', 'status', ['active' => 'Active', 'transferred' => 'Transferred', 'deceased' => 'Deceased'], $r['status'], '', false) ?>
            <?php else: ?>
                <input type="hidden" name="status" value="active">
            <?php endif; ?>
            <div class="field full">
                <?= checkbox('4Ps member', 'is_4ps_member', $r['is_4ps_member']) ?>
                <?= checkbox('Person with disability (PWD)', 'is_pwd', $r['is_pwd']) ?>
                <span class="hint">Senior citizen (60+) is detected automatically from the birthdate.</span>
            </div>
        </div>
    </fieldset>

    <fieldset>
        <legend>Basic health profile</legend>
        <div class="form-grid">
            <?= select_field('Blood type', 'blood_type', BLOOD_TYPES, $hp['blood_type'], '', false) ?>
            <?= field('Height (cm)', 'height_cm', $hp['height_cm'], 'number', 'step="0.1" min="30" max="250"') ?>
            <?= field('Weight (kg)', 'weight_kg', $hp['weight_kg'], 'number', 'step="0.1" min="1" max="300"') ?>
            <?= field('Disability (if any)', 'disability', $hp['disability'], 'text', 'maxlength="150"') ?>
            <?= field('Allergies', 'allergies', $hp['allergies'], 'textarea', 'placeholder="Food, drug or other allergies"') ?>
            <?= field('Existing conditions', 'existing_conditions', $hp['existing_conditions'], 'textarea', 'placeholder="e.g. Hypertension, Diabetes, Asthma"') ?>
            <?= field('Maintenance medicines', 'maintenance_meds', $hp['maintenance_meds'], 'textarea') ?>
            <div class="field">
                <label>Lifestyle</label>
                <?= checkbox('Smoker', 'is_smoker', $hp['is_smoker']) ?><br>
                <?= checkbox('Drinks alcohol', 'is_alcohol_drinker', $hp['is_alcohol_drinker']) ?>
            </div>
        </div>
    </fieldset>

    <fieldset>
        <legend>Emergency contacts</legend>
        <?php foreach ($contacts as $i => $c): ?>
            <div class="form-grid" style="margin-bottom:12px">
                <?= field('Contact name', 'ec_name[]', $c['contact_name'], 'text', 'maxlength="150"') ?>
                <?= field('Relationship', 'ec_relationship[]', $c['relationship'], 'text', 'maxlength="50" placeholder="Spouse, Parent..."') ?>
                <?= field('Contact number', 'ec_contact_no[]', $c['contact_no'], 'tel', 'maxlength="20"') ?>
                <?= field('Address', 'ec_address[]', $c['address'], 'text', 'maxlength="255"') ?>
            </div>
        <?php endforeach; ?>
        <div class="hint">Leave a row blank if not needed.</div>
    </fieldset>

    <div class="form-actions">
        <a class="btn" href="<?= $id ? 'view.php?id=' . $id : 'index.php' ?>">Cancel</a>
        <button class="btn btn-primary" type="submit">Save resident</button>
    </div>
</form>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
