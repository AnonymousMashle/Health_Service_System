<?php
require __DIR__ . '/../../includes/init.php';
require_perm('residents');

$id = (int)get('id');
$r = q('SELECT r.*, h.household_no, h.purok, h.street_address FROM residents r
        LEFT JOIN households h ON h.household_id = r.household_id WHERE r.resident_id = ?', [$id])->fetch();
if (!$r) {
    flash('danger', 'Resident not found.');
    redirect('modules/residents/index.php');
}
$hp = q('SELECT * FROM health_profiles WHERE resident_id = ?', [$id])->fetch();
$contacts = q('SELECT * FROM emergency_contacts WHERE resident_id = ? ORDER BY contact_id', [$id])->fetchAll();
$members = $r['household_id']
    ? q('SELECT resident_id, first_name, middle_name, last_name, suffix, birthdate, relationship_to_head FROM residents
         WHERE household_id = ? AND resident_id <> ? AND status = ? ORDER BY birthdate', [$r['household_id'], $id, 'active'])->fetchAll()
    : [];
$account = q('SELECT user_id, username, status FROM users WHERE resident_id = ?', [$id])->fetch();
$ageMonths = age_months($r['birthdate']);

$page_title = 'Resident Profile';
require __DIR__ . '/../../includes/header.php';
?>
<div class="page-head">
    <div>
        <h2><?= e(full_name($r)) ?> <?= badge($r['status']) ?></h2>
        <div class="muted"><?= e($r['sex']) ?> &middot; <?= e(age_label($r['birthdate'])) ?> old &middot; Resident ID #<?= (int)$r['resident_id'] ?>
            <?= $r['is_senior'] ? ' &middot; <span class="badge badge-purple">Senior</span>' : '' ?>
            <?= $r['is_pwd'] ? ' <span class="badge badge-blue">PWD</span>' : '' ?>
            <?= $r['is_4ps_member'] ? ' <span class="badge badge-amber">4Ps</span>' : '' ?>
        </div>
    </div>
    <div class="btn-group no-print">
        <?php if (can('consultations', 'edit')): ?><a class="btn btn-primary" href="<?= e(url('modules/consultations/form.php?resident_id=' . $id)) ?>">+ Consultation</a><?php endif; ?>
        <?php if (can('vaccinations', 'edit')): ?><a class="btn" href="<?= e(url('modules/vaccinations/form.php?resident_id=' . $id)) ?>">+ Vaccination</a><?php endif; ?>
        <?php if (can('maternal', 'edit') && $r['sex'] === 'Female' && age_years($r['birthdate']) >= 10): ?><a class="btn" href="<?= e(url('modules/maternal/pregnancy_form.php?resident_id=' . $id)) ?>">+ Pregnancy</a><?php endif; ?>
        <?php if (can('maternal', 'edit') && $ageMonths < 72): ?><a class="btn" href="<?= e(url('modules/maternal/child_view.php?id=' . $id)) ?>">Child monitoring</a><?php endif; ?>
        <?php if (can('inventory', 'distribute')): ?><a class="btn" href="<?= e(url('modules/inventory/distribute.php?resident_id=' . $id)) ?>">Give medicine</a><?php endif; ?>
        <?php if (can('residents', 'edit')): ?><a class="btn" href="form.php?id=<?= $id ?>">Edit</a><?php endif; ?>
        <button class="btn" data-print>Print</button>
    </div>
</div>

<div class="grid cols-2 mb">
    <div class="card">
        <h3>Personal information</h3>
        <dl class="info">
            <dt>Birthdate</dt><dd><?= fmt_date($r['birthdate']) ?></dd>
            <dt>Civil status</dt><dd><?= e($r['civil_status']) ?></dd>
            <dt>Contact number</dt><dd><?= e($r['contact_no'] ?: '—') ?></dd>
            <dt>PhilHealth no.</dt><dd><?= e($r['philhealth_no'] ?: '—') ?></dd>
            <dt>Occupation</dt><dd><?= e($r['occupation'] ?: '—') ?></dd>
            <dt>Household</dt><dd><?php if ($r['household_no']): ?><a href="households.php?edit=<?= (int)$r['household_id'] ?>"><?= e($r['household_no']) ?></a> — <?= e($r['street_address']) ?>, <?= e($r['purok']) ?> (<?= e($r['relationship_to_head'] ?: 'Member') ?>)<?php else: ?>—<?php endif; ?></dd>
            <dt>Portal account</dt><dd>
                <?php if ($account): ?><?= e($account['username']) ?> <?= badge($account['status']) ?>
                <?php elseif (can('users', 'edit')): ?><a href="<?= e(url('admin/user_form.php?role=resident&resident_id=' . $id)) ?>">Create resident login</a>
                <?php else: ?>None<?php endif; ?></dd>
        </dl>
    </div>
    <div class="card">
        <h3>Health profile</h3>
        <?php if ($hp): ?>
        <dl class="info">
            <dt>Blood type</dt><dd><?= e($hp['blood_type']) ?></dd>
            <dt>Height / Weight</dt><dd><?= $hp['height_cm'] ? e($hp['height_cm']) . ' cm' : '—' ?> / <?= $hp['weight_kg'] ? e($hp['weight_kg']) . ' kg' : '—' ?>
                <?php if ($hp['height_cm'] && $hp['weight_kg'] && age_years($r['birthdate']) >= 18): $bmi = $hp['weight_kg'] / pow($hp['height_cm'] / 100, 2); ?>
                    <span class="muted small">(BMI <?= number_format($bmi, 1) ?>)</span>
                <?php endif; ?></dd>
            <dt>Allergies</dt><dd class="<?= $hp['allergies'] ? 'text-danger' : '' ?>"><?= e($hp['allergies'] ?: 'None recorded') ?></dd>
            <dt>Existing conditions</dt><dd><?= e($hp['existing_conditions'] ?: 'None recorded') ?></dd>
            <dt>Maintenance meds</dt><dd><?= e($hp['maintenance_meds'] ?: '—') ?></dd>
            <dt>Disability</dt><dd><?= e($hp['disability'] ?: '—') ?></dd>
            <dt>Lifestyle</dt><dd><?= $hp['is_smoker'] ? 'Smoker' : 'Non-smoker' ?>, <?= $hp['is_alcohol_drinker'] ? 'drinks alcohol' : 'no alcohol' ?></dd>
        </dl>
        <?php else: ?><p class="muted">No health profile yet.</p><?php endif; ?>
    </div>
    <div class="card">
        <h3>Emergency contacts</h3>
        <?php foreach ($contacts as $c): ?>
            <p style="margin:0 0 10px"><strong><?= e($c['contact_name']) ?></strong> (<?= e($c['relationship']) ?>)<br>
                <?= e($c['contact_no']) ?><?= $c['address'] ? ' &middot; ' . e($c['address']) : '' ?></p>
        <?php endforeach; ?>
        <?php if (!$contacts): ?><p class="muted">No emergency contacts.</p><?php endif; ?>
    </div>
    <div class="card">
        <h3>Household members</h3>
        <?php foreach ($members as $m): ?>
            <div><a href="view.php?id=<?= (int)$m['resident_id'] ?>"><?= e(full_name($m)) ?></a>
                <span class="muted small"><?= e($m['relationship_to_head']) ?> &middot; <?= e(age_label($m['birthdate'])) ?></span></div>
        <?php endforeach; ?>
        <?php if (!$members): ?><p class="muted">No other members.</p><?php endif; ?>
    </div>
</div>

<div class="card">
    <?php $rid = $id; $is_staff = true; require __DIR__ . '/../../includes/partials/resident_records.php'; ?>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
