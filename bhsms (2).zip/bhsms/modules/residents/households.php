<?php
require __DIR__ . '/../../includes/init.php';
require_perm('residents');

$canEdit = can('residents', 'edit');
$editId = (int)get('edit');
$showForm = $editId || get('new') === '1';
$errors = [];
$h = ['household_no' => '', 'purok' => '', 'street_address' => '', 'head_resident_id' => ''];

if ($editId) {
    $h = q('SELECT * FROM households WHERE household_id = ?', [$editId])->fetch();
    if (!$h) {
        flash('danger', 'Household not found.');
        redirect('modules/residents/households.php');
    }
}

if (is_post()) {
    if (!$canEdit) deny();
    $action = input('action');

    if ($action === 'delete' && has_role('admin', 'nurse')) {
        $hid = (int)input('household_id');
        $count = (int)q('SELECT COUNT(*) FROM residents WHERE household_id = ?', [$hid])->fetchColumn();
        if ($count > 0) {
            flash('danger', 'Cannot delete a household that still has members. Move or update the members first.');
        } else {
            q('DELETE FROM households WHERE household_id = ?', [$hid]);
            log_activity('DELETE', 'households', $hid, 'Deleted household');
            flash('success', 'Household deleted.');
        }
        redirect('modules/residents/households.php');
    }

    if ($action === 'save') {
        foreach (['household_no', 'purok', 'street_address', 'head_resident_id'] as $f) {
            $h[$f] = input($f);
        }
        if ($h['household_no'] === '') {
            // Auto-number: HH-<year>-0001
            $prefix = 'HH-' . date('Y') . '-';
            $last = q('SELECT MAX(household_no) FROM households WHERE household_no LIKE ?', [$prefix . '%'])->fetchColumn();
            $next = $last ? ((int)substr($last, -4)) + 1 : 1;
            $h['household_no'] = $prefix . str_pad((string)$next, 4, '0', STR_PAD_LEFT);
        }
        if ($h['purok'] === '') $errors[] = 'Purok is required.';
        if ($h['street_address'] === '') $errors[] = 'Street address is required.';
        if ($h['head_resident_id'] !== '' && $editId &&
            !q('SELECT 1 FROM residents WHERE resident_id = ? AND household_id = ?', [$h['head_resident_id'], $editId])->fetchColumn()) {
            $errors[] = 'The household head must be a member of this household.';
        }

        if (!$errors) {
            $data = [
                'household_no' => $h['household_no'],
                'purok' => $h['purok'],
                'street_address' => $h['street_address'],
                'head_resident_id' => $editId ? nullable($h['head_resident_id']) : null,
            ];
            try {
                if ($editId) {
                    db_update('households', $data, 'household_id', $editId);
                    if ($data['head_resident_id']) {
                        q("UPDATE residents SET relationship_to_head = 'Head' WHERE resident_id = ?", [$data['head_resident_id']]);
                    }
                    log_activity('UPDATE', 'households', $editId, 'Updated household ' . $h['household_no']);
                } else {
                    $data['created_by'] = user_id();
                    $editId = db_insert('households', $data);
                    log_activity('CREATE', 'households', $editId, 'Added household ' . $h['household_no']);
                }
                flash('success', 'Household ' . $h['household_no'] . ' saved.');
                redirect('modules/residents/households.php?edit=' . $editId);
            } catch (PDOException $e) {
                if (!is_duplicate_error($e)) throw $e;
                $errors[] = 'Household number ' . $h['household_no'] . ' already exists.';
            }
        }
        $showForm = true;
    }
}

// List
$search = get('q');
$purok = get('purok');
$where = ['1=1'];
$params = [];
if ($search !== '') {
    $where[] = '(h.household_no LIKE ? OR h.street_address LIKE ? OR hr.last_name LIKE ?)';
    $like = "%$search%";
    array_push($params, $like, $like, $like);
}
if ($purok !== '') { $where[] = 'h.purok = ?'; $params[] = $purok; }
$w = implode(' AND ', $where);
$from = 'FROM households h LEFT JOIN residents hr ON hr.resident_id = h.head_resident_id';
$pg = paginate((int)q("SELECT COUNT(*) $from WHERE $w", $params)->fetchColumn());
$rows = q("SELECT h.*, hr.first_name, hr.middle_name, hr.last_name, hr.suffix,
                  (SELECT COUNT(*) FROM residents m WHERE m.household_id = h.household_id AND m.status = 'active') AS members
           $from WHERE $w ORDER BY h.household_no LIMIT {$pg['per']} OFFSET {$pg['offset']}", $params)->fetchAll();
$puroks = q('SELECT DISTINCT purok FROM households ORDER BY purok')->fetchAll(PDO::FETCH_COLUMN);

$members = $editId ? q('SELECT * FROM residents WHERE household_id = ? ORDER BY birthdate', [$editId])->fetchAll() : [];
$memberOptions = [];
foreach ($members as $m) {
    $memberOptions[$m['resident_id']] = full_name($m);
}

$page_title = 'Households';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>

<?php if ($showForm && ($canEdit || $editId)): ?>
<div class="card">
    <div class="card-header">
        <h3><?= $editId ? 'Household ' . e($h['household_no']) : 'Add household' ?></h3>
        <a class="btn btn-sm" href="households.php">Close</a>
    </div>
    <?php if (!$canEdit): ?>
        <p class="muted"><?= e($h['street_address']) ?>, <?= e($h['purok']) ?></p>
    <?php else: ?>
    <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save">
        <div class="form-grid">
            <?= field('Household no.', 'household_no', $h['household_no'], 'text', 'maxlength="20" placeholder="Leave blank to auto-number"') ?>
            <?= field('Purok / Zone', 'purok', $h['purok'], 'text', 'required maxlength="50" list="purok-list"') ?>
            <?= field('Street address', 'street_address', $h['street_address'], 'text', 'required maxlength="255"', 'span-2') ?>
            <?php if ($editId): ?>
                <?= select_field('Household head', 'head_resident_id', $memberOptions, $h['head_resident_id'], '', '-- None --') ?>
            <?php endif; ?>
        </div>
        <datalist id="purok-list"><?php foreach ($puroks as $p): ?><option value="<?= e($p) ?>"><?php endforeach; ?></datalist>
        <div class="form-actions"><button class="btn btn-primary">Save household</button></div>
    </form>
    <?php endif; ?>

    <?php if ($editId): ?>
        <div class="card-header" style="margin-top:18px">
            <h3>Members (<?= count($members) ?>)</h3>
            <?php if ($canEdit): ?><a class="btn btn-sm btn-primary" href="form.php?household_id=<?= $editId ?>">+ Add member</a><?php endif; ?>
        </div>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Name</th><th>Relationship</th><th>Sex</th><th>Age</th><th>Status</th></tr></thead>
            <tbody>
            <?php foreach ($members as $m): ?>
                <tr>
                    <td><a href="view.php?id=<?= (int)$m['resident_id'] ?>"><?= e(full_name($m)) ?></a></td>
                    <td><?= e($m['relationship_to_head'] ?: '—') ?></td>
                    <td><?= e($m['sex']) ?></td>
                    <td><?= e(age_label($m['birthdate'])) ?></td>
                    <td><?= badge($m['status']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$members): ?><tr><td colspan="5" class="empty">No members yet.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
        <?php if (!$members && has_role('admin', 'nurse')): ?>
            <div class="form-actions"><?= post_button('households.php', 'Delete household', ['action' => 'delete', 'household_id' => $editId], 'btn btn-danger', 'Delete this household?') ?></div>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h3>Household registry</h3>
        <?php if ($canEdit): ?><a class="btn btn-primary" href="households.php?new=1">+ Add household</a><?php endif; ?>
    </div>
    <form class="toolbar" method="get">
        <div class="grow"><label>Search</label><input type="search" name="q" value="<?= e($search) ?>" placeholder="Household no., street or head's last name"></div>
        <div><label>Purok</label><select name="purok"><?= options($puroks, $purok, 'All') ?></select></div>
        <button class="btn">Filter</button>
    </form>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Household no.</th><th>Head</th><th>Address</th><th>Purok</th><th class="num">Members</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $row): ?>
            <tr>
                <td><strong><?= e($row['household_no']) ?></strong></td>
                <td><?= $row['last_name'] ? e(full_name($row)) : '<span class="muted">Not set</span>' ?></td>
                <td><?= e($row['street_address']) ?></td>
                <td><?= e($row['purok']) ?></td>
                <td class="num"><?= (int)$row['members'] ?></td>
                <td class="actions"><a class="btn btn-sm" href="households.php?edit=<?= (int)$row['household_id'] ?>"><?= $canEdit ? 'Open' : 'Members' ?></a></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="6" class="empty">No households found.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
    <?= pagination_links($pg) ?>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
