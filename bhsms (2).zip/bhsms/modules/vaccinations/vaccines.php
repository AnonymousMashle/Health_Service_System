<?php
require __DIR__ . '/../../includes/init.php';
require_perm('vaccinations', 'manage');

const TARGET_GROUPS = ['Infant', 'Child', 'Adult', 'Pregnant', 'Senior', 'All'];

$editId = (int)get('edit');
$vac = ['vaccine_name' => '', 'description' => '', 'target_group' => 'All', 'doses_required' => 1, 'interval_days' => '', 'is_active' => 1];
if ($editId) {
    $vac = q('SELECT * FROM vaccines WHERE vaccine_id = ?', [$editId])->fetch() ?: $vac;
}
$errors = [];

if (is_post()) {
    foreach (['vaccine_name', 'description', 'target_group', 'doses_required', 'interval_days'] as $f) {
        $vac[$f] = input($f);
    }
    $vac['is_active'] = isset($_POST['is_active']) ? 1 : 0;

    if ($vac['vaccine_name'] === '') $errors[] = 'Vaccine name is required.';
    if (!in_array($vac['target_group'], TARGET_GROUPS, true)) $errors[] = 'Select a target group.';
    if (!ctype_digit((string)$vac['doses_required']) || $vac['doses_required'] < 1 || $vac['doses_required'] > 10) $errors[] = 'Doses required must be 1 to 10.';
    if ($vac['interval_days'] !== '' && (!ctype_digit((string)$vac['interval_days']) || $vac['interval_days'] > 3650)) $errors[] = 'Interval must be a number of days.';

    if (!$errors) {
        $data = [
            'vaccine_name' => $vac['vaccine_name'], 'description' => nullable($vac['description']),
            'target_group' => $vac['target_group'], 'doses_required' => (int)$vac['doses_required'],
            'interval_days' => nullable($vac['interval_days']), 'is_active' => $vac['is_active'],
        ];
        try {
            if ($editId) {
                db_update('vaccines', $data, 'vaccine_id', $editId);
                log_activity('UPDATE', 'vaccines', $editId, 'Updated vaccine ' . $data['vaccine_name']);
            } else {
                $newId = db_insert('vaccines', $data);
                log_activity('CREATE', 'vaccines', $newId, 'Added vaccine ' . $data['vaccine_name']);
            }
            flash('success', 'Vaccine saved.');
            redirect('modules/vaccinations/vaccines.php');
        } catch (PDOException $e) {
            if (!is_duplicate_error($e)) throw $e;
            $errors[] = 'A vaccine with that name already exists.';
        }
    }
}

$rows = q('SELECT vc.*, (SELECT COUNT(*) FROM vaccinations v WHERE v.vaccine_id = vc.vaccine_id) AS doses_given
           FROM vaccines vc ORDER BY vc.is_active DESC, vc.vaccine_name')->fetchAll();

$page_title = 'Vaccine List';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<div class="grid cols-2">
    <div class="card">
        <div class="card-header"><h3>Vaccines</h3><a class="btn btn-sm" href="index.php">Back to records</a></div>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Vaccine</th><th>Target</th><th class="num">Doses</th><th class="num">Interval</th><th class="num">Given</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr class="<?= $r['is_active'] ? '' : 'row-warning' ?>">
                    <td><strong><?= e($r['vaccine_name']) ?></strong><?= $r['is_active'] ? '' : ' ' . badge('inactive') ?><div class="small muted"><?= e($r['description']) ?></div></td>
                    <td><?= e($r['target_group']) ?></td>
                    <td class="num"><?= (int)$r['doses_required'] ?></td>
                    <td class="num"><?= $r['interval_days'] ? (int)$r['interval_days'] . ' days' : '—' ?></td>
                    <td class="num"><?= (int)$r['doses_given'] ?></td>
                    <td class="actions"><a class="btn btn-sm" href="vaccines.php?edit=<?= (int)$r['vaccine_id'] ?>">Edit</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
    </div>
    <div class="card">
        <h3><?= $editId ? 'Edit vaccine' : 'Add vaccine' ?></h3>
        <form method="post">
            <?= csrf_field() ?>
            <div class="form-grid">
                <?= field('Vaccine name', 'vaccine_name', $vac['vaccine_name'], 'text', 'required maxlength="100"', 'full') ?>
                <?= field('Description', 'description', $vac['description'], 'text', 'maxlength="255"', 'full') ?>
                <?= select_field('Target group', 'target_group', TARGET_GROUPS, $vac['target_group'], 'required', false) ?>
                <?= field('Doses required', 'doses_required', $vac['doses_required'], 'number', 'required min="1" max="10"') ?>
                <?= field('Days between doses', 'interval_days', $vac['interval_days'], 'number', 'min="0" max="3650"') ?>
                <div class="field"><label>&nbsp;</label><?= checkbox('Active', 'is_active', $vac['is_active']) ?></div>
            </div>
            <div class="form-actions">
                <?php if ($editId): ?><a class="btn" href="vaccines.php">Cancel</a><?php endif; ?>
                <button class="btn btn-primary">Save vaccine</button>
            </div>
        </form>
    </div>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
