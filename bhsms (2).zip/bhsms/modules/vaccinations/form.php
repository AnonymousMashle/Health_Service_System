<?php
require __DIR__ . '/../../includes/init.php';
require_perm('vaccinations', 'edit');

$id = (int)get('id');
$v = ['resident_id' => get('resident_id'), 'vaccine_id' => get('vaccine_id'), 'dose_no' => '', 'date_given' => today(),
      'next_schedule' => '', 'batch_lot_no' => '', 'site_given' => '', 'remarks' => ''];

if ($id) {
    $v = q('SELECT * FROM vaccinations WHERE vaccination_id = ?', [$id])->fetch();
    if (!$v) {
        flash('danger', 'Vaccination record not found.');
        redirect('modules/vaccinations/index.php');
    }
}

$vaccines = q('SELECT * FROM vaccines WHERE is_active = 1 OR vaccine_id = ? ORDER BY vaccine_name', [$v['vaccine_id'] ?: 0])->fetchAll();
$vaccineOptions = [];
foreach ($vaccines as $vc) {
    $vaccineOptions[$vc['vaccine_id']] = $vc['vaccine_name'] . ' (' . $vc['doses_required'] . ' dose' . ($vc['doses_required'] > 1 ? 's' : '') . ')';
}
$errors = [];

if (is_post()) {
    if (input('action') === 'delete') {
        if (!can('vaccinations', 'manage')) deny();
        q('DELETE FROM vaccinations WHERE vaccination_id = ?', [$id]);
        log_activity('DELETE', 'vaccinations', $id, 'Deleted vaccination record');
        flash('success', 'Vaccination record deleted.');
        redirect('modules/residents/view.php?id=' . $v['resident_id'] . '#vaccinations');
    }

    foreach (array_keys($v) as $f) {
        if (array_key_exists($f, $_POST)) $v[$f] = input($f);
    }

    $vac = q('SELECT * FROM vaccines WHERE vaccine_id = ?', [$v['vaccine_id']])->fetch();
    if (!q("SELECT 1 FROM residents WHERE resident_id = ? AND status = 'active'", [$v['resident_id']])->fetchColumn()) $errors[] = 'Select a resident.';
    if (!$vac) $errors[] = 'Select a vaccine.';
    if (!valid_date($v['date_given']) || $v['date_given'] > today()) $errors[] = 'Date given must be a valid date, not in the future.';
    if ($v['next_schedule'] !== '' && (!valid_date($v['next_schedule']) || $v['next_schedule'] <= $v['date_given'])) {
        $errors[] = 'Next schedule must be a date after the date given.';
    }
    if ($v['dose_no'] !== '' && (!ctype_digit((string)$v['dose_no']) || $v['dose_no'] < 1 || $v['dose_no'] > 20)) $errors[] = 'Dose number is not valid.';

    if (!$errors) {
        // Dose number: next dose for this resident + vaccine when left blank
        if ($v['dose_no'] === '') {
            $v['dose_no'] = 1 + (int)q('SELECT COALESCE(MAX(dose_no), 0) FROM vaccinations WHERE resident_id = ? AND vaccine_id = ? AND vaccination_id <> ?',
                                       [$v['resident_id'], $v['vaccine_id'], $id])->fetchColumn();
        }
        // Next schedule: date given + interval, if the series is not yet complete
        if ($v['next_schedule'] === '' && (int)$v['dose_no'] < (int)$vac['doses_required'] && $vac['interval_days']) {
            $v['next_schedule'] = date('Y-m-d', strtotime($v['date_given'] . ' +' . (int)$vac['interval_days'] . ' days'));
        }

        $data = [
            'resident_id' => $v['resident_id'], 'vaccine_id' => $v['vaccine_id'], 'dose_no' => (int)$v['dose_no'],
            'date_given' => $v['date_given'], 'next_schedule' => nullable($v['next_schedule']),
            'batch_lot_no' => nullable($v['batch_lot_no']), 'site_given' => nullable($v['site_given']), 'remarks' => nullable($v['remarks']),
        ];
        try {
            if ($id) {
                db_update('vaccinations', $data, 'vaccination_id', $id);
                log_activity('UPDATE', 'vaccinations', $id, 'Updated ' . $vac['vaccine_name'] . ' dose ' . $data['dose_no']);
            } else {
                $data['administered_by'] = user_id();
                $id = db_insert('vaccinations', $data);
                log_activity('CREATE', 'vaccinations', $id, 'Recorded ' . $vac['vaccine_name'] . ' dose ' . $data['dose_no']);
                if ($data['next_schedule']) {
                    notify_resident((int)$data['resident_id'], 'Next vaccination schedule',
                        $vac['vaccine_name'] . ' dose ' . ($data['dose_no'] + 1) . ' is scheduled on ' . fmt_date($data['next_schedule']) . '.');
                }
            }
            flash('success', 'Vaccination saved: ' . $vac['vaccine_name'] . ' dose ' . $data['dose_no'] . '.');
            redirect('modules/residents/view.php?id=' . $data['resident_id'] . '#vaccinations');
        } catch (PDOException $e) {
            if (!is_duplicate_error($e)) throw $e;
            $errors[] = 'Dose ' . $data['dose_no'] . ' of ' . $vac['vaccine_name'] . ' is already recorded for this resident.';
        }
    }
}

$page_title = $id ? 'Edit Vaccination' : 'Record Vaccination';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<form method="post" class="card">
    <?= csrf_field() ?>
    <div class="form-grid">
        <?= select_field('Resident', 'resident_id', resident_options(), $v['resident_id'], 'required class="searchable"', '-- Select resident --', 'span-2') ?>
        <?= select_field('Vaccine', 'vaccine_id', $vaccineOptions, $v['vaccine_id'], 'required') ?>
        <div class="field">
            <label for="f_dose_no">Dose number</label>
            <input id="f_dose_no" type="number" name="dose_no" min="1" max="20" value="<?= e($v['dose_no']) ?>" placeholder="Auto">
            <div class="hint">Leave blank to use the next dose automatically.</div>
        </div>
        <?= field('Date given', 'date_given', $v['date_given'], 'date', 'required max="' . today() . '"') ?>
        <div class="field">
            <label for="f_next_schedule">Next schedule</label>
            <input id="f_next_schedule" type="date" name="next_schedule" value="<?= e($v['next_schedule']) ?>">
            <div class="hint">Leave blank to compute from the vaccine's interval.</div>
        </div>
        <?= field('Batch / lot no.', 'batch_lot_no', $v['batch_lot_no'], 'text', 'maxlength="50"') ?>
        <?= field('Site given', 'site_given', $v['site_given'], 'text', 'maxlength="50" list="sites"') ?>
        <?= field('Remarks', 'remarks', $v['remarks'], 'text', 'maxlength="255"', 'full') ?>
    </div>
    <datalist id="sites"><option value="Left deltoid"><option value="Right deltoid"><option value="Left thigh"><option value="Right thigh"><option value="Oral"><option value="Right arm"><option value="Left arm"></datalist>

    <div class="form-actions">
        <a class="btn" href="index.php">Cancel</a>
        <button class="btn btn-primary" type="submit">Save vaccination</button>
    </div>
</form>

<?php if ($id && can('vaccinations', 'manage')): ?>
    <form method="post" data-confirm="Delete this vaccination record?" class="form-actions">
        <?= csrf_field() ?><input type="hidden" name="action" value="delete">
        <button class="btn btn-danger">Delete record</button>
    </form>
<?php endif; ?>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
