<?php
require __DIR__ . '/../../includes/init.php';
require_perm('vaccinations');

$tab = get('tab', 'records') === 'due' ? 'due' : 'records';
$vaccineList = [];
foreach (q('SELECT vaccine_id, vaccine_name FROM vaccines ORDER BY vaccine_name')->fetchAll() as $v) {
    $vaccineList[$v['vaccine_id']] = $v['vaccine_name'];
}

if ($tab === 'records') {
    $search = get('q');
    $vaccine = get('vaccine_id');
    $from = get('from');
    $to = get('to');
    $where = ['1=1'];
    $params = [];
    if ($search !== '') {
        $where[] = "(r.first_name LIKE ? OR r.last_name LIKE ? OR CONCAT(r.first_name, ' ', r.last_name) LIKE ? OR v.batch_lot_no LIKE ?)";
        $like = "%$search%";
        array_push($params, $like, $like, $like, $like);
    }
    if ($vaccine !== '') { $where[] = 'v.vaccine_id = ?'; $params[] = $vaccine; }
    if (valid_date($from)) { $where[] = 'v.date_given >= ?'; $params[] = $from; }
    if (valid_date($to))   { $where[] = 'v.date_given <= ?'; $params[] = $to; }
    $w = implode(' AND ', $where);
    $join = 'FROM vaccinations v JOIN residents r ON r.resident_id = v.resident_id JOIN vaccines vc ON vc.vaccine_id = v.vaccine_id LEFT JOIN users u ON u.user_id = v.administered_by';
    $pg = paginate((int)q("SELECT COUNT(*) $join WHERE $w", $params)->fetchColumn());
    $rows = q("SELECT v.*, vc.vaccine_name, vc.doses_required, r.first_name, r.middle_name, r.last_name, r.suffix, r.birthdate, u.full_name AS given_by
               $join WHERE $w ORDER BY v.date_given DESC, v.vaccination_id DESC LIMIT {$pg['per']} OFFSET {$pg['offset']}", $params)->fetchAll();
} else {
    $range = (int)get('days', '30');
    if (!in_array($range, [7, 30, 90], true)) $range = 30;
    $rows = q(due_vaccinations_sql() . ' AND v.next_schedule <= CURDATE() + INTERVAL ' . $range . ' DAY ORDER BY v.next_schedule')->fetchAll();
}

$page_title = 'Vaccination Monitoring';
require __DIR__ . '/../../includes/header.php';
?>
<div class="card">
    <div class="card-header">
        <div class="tabs" style="margin:0;border:0">
            <a href="index.php?tab=records" class="<?= $tab === 'records' ? 'active' : '' ?>">Vaccination records</a>
            <a href="index.php?tab=due" class="<?= $tab === 'due' ? 'active' : '' ?>">Due &amp; overdue doses</a>
        </div>
        <div class="btn-group">
            <?php if (can('vaccinations', 'manage')): ?><a class="btn" href="vaccines.php">Vaccine list</a><?php endif; ?>
            <?php if (can('vaccinations', 'edit')): ?><a class="btn btn-primary" href="form.php">+ Record vaccination</a><?php endif; ?>
        </div>
    </div>

<?php if ($tab === 'records'): ?>
    <form class="toolbar" method="get">
        <input type="hidden" name="tab" value="records">
        <div class="grow"><label>Search</label><input type="search" name="q" value="<?= e($search) ?>" placeholder="Name or lot number"></div>
        <div><label>Vaccine</label><select name="vaccine_id"><?= options($vaccineList, $vaccine, 'All') ?></select></div>
        <div><label>From</label><input type="date" name="from" value="<?= e($from) ?>"></div>
        <div><label>To</label><input type="date" name="to" value="<?= e($to) ?>"></div>
        <button class="btn">Filter</button>
    </form>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Date given</th><th>Resident</th><th>Age</th><th>Vaccine</th><th>Dose</th><th>Next schedule</th><th>Given by</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $v): ?>
            <tr>
                <td class="nowrap"><?= fmt_date($v['date_given']) ?></td>
                <td><a href="<?= e(url('modules/residents/view.php?id=' . $v['resident_id'] . '#vaccinations')) ?>"><?= e(full_name($v)) ?></a></td>
                <td class="nowrap"><?= e(age_label($v['birthdate'])) ?></td>
                <td><?= e($v['vaccine_name']) ?></td>
                <td><?= (int)$v['dose_no'] ?> of <?= (int)$v['doses_required'] ?></td>
                <td><?= fmt_date($v['next_schedule']) ?></td>
                <td class="small"><?= e($v['given_by'] ?: '—') ?></td>
                <td class="actions"><?php if (can('vaccinations', 'edit')): ?><a class="btn btn-sm" href="form.php?id=<?= (int)$v['vaccination_id'] ?>">Edit</a><?php endif; ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="8" class="empty">No vaccination records found.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
    <?= pagination_links($pg) ?>

<?php else: ?>
    <form class="toolbar" method="get">
        <input type="hidden" name="tab" value="due">
        <div><label>Show doses due within</label><select name="days" onchange="this.form.submit()"><?= options([7 => 'Next 7 days', 30 => 'Next 30 days', 90 => 'Next 90 days'], $range, false) ?></select></div>
        <span class="muted small">Overdue doses are always shown (highlighted in red).</span>
    </form>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Due date</th><th>Resident</th><th>Age</th><th>Contact</th><th>Vaccine</th><th>Next dose</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $v): $overdue = $v['next_schedule'] < today(); ?>
            <tr class="<?= $overdue ? 'row-danger' : '' ?>">
                <td class="nowrap"><?= fmt_date($v['next_schedule']) ?></td>
                <td><a href="<?= e(url('modules/residents/view.php?id=' . $v['resident_id'] . '#vaccinations')) ?>"><?= e(full_name($v)) ?></a></td>
                <td class="nowrap"><?= e(age_label($v['birthdate'])) ?></td>
                <td><?= e($v['contact_no'] ?: '—') ?></td>
                <td><?= e($v['vaccine_name']) ?></td>
                <td>Dose <?= (int)$v['dose_no'] + 1 ?> of <?= (int)$v['doses_required'] ?></td>
                <td><?= badge($overdue ? 'Overdue' : 'Due soon') ?></td>
                <td class="actions"><?php if (can('vaccinations', 'edit')): ?>
                    <a class="btn btn-sm btn-primary" href="form.php?resident_id=<?= (int)$v['resident_id'] ?>&vaccine_id=<?= (int)$v['vaccine_id'] ?>">Record dose</a><?php endif; ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="8" class="empty">No doses due in this period.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
<?php endif; ?>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
