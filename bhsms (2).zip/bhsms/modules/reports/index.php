<?php
require __DIR__ . '/../../includes/init.php';
require_perm('reports');

$year = (int)get('year', date('Y'));
$years = q("SELECT DISTINCT YEAR(consultation_date) AS y FROM consultations
            UNION SELECT YEAR(date_given) FROM vaccinations UNION SELECT YEAR(CURDATE()) ORDER BY 1 DESC")->fetchAll(PDO::FETCH_COLUMN);
if (!in_array($year, array_map('intval', $years), true)) $year = (int)date('Y');
$months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** Fill a 12-month array from rows of [m => month number, n => value]. */
function by_month(array $rows): array
{
    $out = array_fill(0, 12, 0);
    foreach ($rows as $r) {
        $out[(int)$r['m'] - 1] = (int)$r['n'];
    }
    return $out;
}

// ----- 1. Registered residents -----
$res = q("SELECT COUNT(*) AS total, SUM(sex = 'Male') AS male, SUM(sex = 'Female') AS female, SUM(is_senior) AS seniors,
                 SUM(is_pwd) AS pwd, SUM(is_4ps_member) AS fourps,
                 SUM(TIMESTAMPDIFF(YEAR, birthdate, CURDATE()) < 5) AS under5
          FROM residents WHERE status = 'active'")->fetch();
$households = (int)q('SELECT COUNT(*) FROM households')->fetchColumn();
$ageGroups = q("SELECT CASE
                    WHEN TIMESTAMPDIFF(YEAR, birthdate, CURDATE()) < 5 THEN '0-4'
                    WHEN TIMESTAMPDIFF(YEAR, birthdate, CURDATE()) < 15 THEN '5-14'
                    WHEN TIMESTAMPDIFF(YEAR, birthdate, CURDATE()) < 25 THEN '15-24'
                    WHEN TIMESTAMPDIFF(YEAR, birthdate, CURDATE()) < 60 THEN '25-59'
                    ELSE '60+' END AS grp,
                  SUM(sex = 'Male') AS male, SUM(sex = 'Female') AS female
                FROM residents WHERE status = 'active' GROUP BY grp")->fetchAll();
$ageOrder = ['0-4', '5-14', '15-24', '25-59', '60+'];
$ageMale = $ageFemale = array_fill_keys($ageOrder, 0);
foreach ($ageGroups as $g) {
    $ageMale[$g['grp']] = (int)$g['male'];
    $ageFemale[$g['grp']] = (int)$g['female'];
}
$byPurok = q("SELECT COALESCE(h.purok, 'No household') AS purok, COUNT(*) AS n FROM residents r
              LEFT JOIN households h ON h.household_id = r.household_id WHERE r.status = 'active' GROUP BY purok ORDER BY purok")->fetchAll();

// ----- 2. Monthly consultations -----
$consMonthly = by_month(q('SELECT MONTH(consultation_date) AS m, COUNT(*) AS n FROM consultations WHERE YEAR(consultation_date) = ? GROUP BY m', [$year])->fetchAll());
$consTotal = array_sum($consMonthly);
$referred = (int)q("SELECT COUNT(*) FROM consultations WHERE YEAR(consultation_date) = ? AND status = 'referred'", [$year])->fetchColumn();
$topComplaints = q('SELECT chief_complaint, COUNT(*) AS n FROM consultations WHERE YEAR(consultation_date) = ?
                    GROUP BY chief_complaint ORDER BY n DESC LIMIT 10', [$year])->fetchAll();

// ----- 3. Vaccination coverage -----
$coverage = q('SELECT * FROM v_vaccination_coverage ORDER BY residents_vaccinated DESC, vaccine_name')->fetchAll();
$vaccMonthly = by_month(q('SELECT MONTH(date_given) AS m, COUNT(*) AS n FROM vaccinations WHERE YEAR(date_given) = ? GROUP BY m', [$year])->fetchAll());
$vaccStatus = q("SELECT completion_status, COUNT(*) AS n FROM v_vaccination_status GROUP BY completion_status")->fetchAll(PDO::FETCH_KEY_PAIR);
$infants = (int)q("SELECT COUNT(*) FROM residents WHERE status = 'active' AND TIMESTAMPDIFF(MONTH, birthdate, CURDATE()) BETWEEN 12 AND 23")->fetchColumn();
// Fully immunized child (12-23 months): BCG, Hep B, 3 Pentavalent, 3 OPV and at least 1 MMR
$fic = (int)q("SELECT COUNT(*) FROM residents r WHERE r.status = 'active' AND TIMESTAMPDIFF(MONTH, r.birthdate, CURDATE()) BETWEEN 12 AND 23
               AND (SELECT COUNT(DISTINCT vc.vaccine_name) FROM vaccinations v JOIN vaccines vc ON vc.vaccine_id = v.vaccine_id
                    WHERE v.resident_id = r.resident_id AND (
                        vc.vaccine_name IN ('BCG', 'Hepatitis B', 'MMR')
                        OR (vc.vaccine_name LIKE 'Pentavalent%' AND v.dose_no = 3)
                        OR (vc.vaccine_name = 'OPV' AND v.dose_no = 3))) = 5")->fetchColumn();

// ----- 4. Medicine distribution -----
$medMonthly = by_month(q('SELECT MONTH(distribution_date) AS m, SUM(quantity) AS n FROM medicine_distribution WHERE YEAR(distribution_date) = ? GROUP BY m', [$year])->fetchAll());
$topMeds = q('SELECT m.generic_name, m.strength, m.unit, SUM(d.quantity) AS qty, COUNT(DISTINCT d.resident_id) AS people
              FROM medicine_distribution d JOIN medicines m ON m.medicine_id = d.medicine_id
              WHERE YEAR(d.distribution_date) = ? GROUP BY m.medicine_id, m.generic_name, m.strength, m.unit ORDER BY qty DESC LIMIT 10', [$year])->fetchAll();
$stockSummary = q('SELECT stock_status, COUNT(*) AS n FROM v_medicine_stock_levels GROUP BY stock_status')->fetchAll(PDO::FETCH_KEY_PAIR);

// ----- 5. Maternal & child -----
$mc = q('SELECT * FROM v_maternal_child_stats')->fetch();
$riskRows = q("SELECT risk_level, COUNT(*) AS n FROM pregnancies WHERE status = 'ongoing' GROUP BY risk_level")->fetchAll(PDO::FETCH_KEY_PAIR);
$prenatalMonthly = by_month(q('SELECT MONTH(visit_date) AS m, COUNT(*) AS n FROM prenatal_visits WHERE YEAR(visit_date) = ? GROUP BY m', [$year])->fetchAll());
$nutrition = q("SELECT cm.nutrition_status, COUNT(*) AS n FROM child_monitoring cm
                WHERE cm.record_id = (SELECT c2.record_id FROM child_monitoring c2 WHERE c2.resident_id = cm.resident_id ORDER BY c2.visit_date DESC, c2.record_id DESC LIMIT 1)
                  AND cm.nutrition_status IS NOT NULL GROUP BY cm.nutrition_status")->fetchAll(PDO::FETCH_KEY_PAIR);

$use_charts = true;
$page_title = 'Health Reports & Analytics';
require __DIR__ . '/../../includes/header.php';
?>
<div class="page-head">
    <div>
        <h2>Health report — <?= $year ?></h2>
        <div class="muted"><?= e(BARANGAY_NAME) ?> &middot; generated <?= fmt_datetime(date('Y-m-d H:i:s')) ?> by <?= e(current_user()['full_name']) ?></div>
    </div>
    <form class="btn-group no-print" method="get">
        <select name="year" onchange="this.form.submit()" style="width:auto"><?= options(array_combine($years, $years), $year, false) ?></select>
        <button type="button" class="btn" data-print>Print / Save as PDF</button>
    </form>
</div>

<div class="card no-print">
    <strong>Download CSV (opens in Excel):</strong>
    <a class="btn btn-sm" href="export.php?report=residents">Resident masterlist</a>
    <a class="btn btn-sm" href="export.php?report=consultations&year=<?= $year ?>">Consultations <?= $year ?></a>
    <a class="btn btn-sm" href="export.php?report=vaccinations&year=<?= $year ?>">Vaccinations <?= $year ?></a>
    <a class="btn btn-sm" href="export.php?report=medicines&year=<?= $year ?>">Medicine distribution <?= $year ?></a>
    <a class="btn btn-sm" href="export.php?report=pregnancies">Pregnancies</a>
    <a class="btn btn-sm" href="export.php?report=inventory">Current inventory</a>
</div>

<h3>1. Registered residents</h3>
<div class="stats">
    <div class="stat"><div class="label">Active residents</div><div class="value"><?= (int)$res['total'] ?></div></div>
    <div class="stat blue"><div class="label">Households</div><div class="value"><?= $households ?></div></div>
    <div class="stat"><div class="label">Male / Female</div><div class="value"><?= (int)$res['male'] ?> / <?= (int)$res['female'] ?></div></div>
    <div class="stat purple"><div class="label">Senior citizens</div><div class="value"><?= (int)$res['seniors'] ?></div></div>
    <div class="stat amber"><div class="label">Children under 5</div><div class="value"><?= (int)$res['under5'] ?></div></div>
    <div class="stat"><div class="label">PWD / 4Ps</div><div class="value"><?= (int)$res['pwd'] ?> / <?= (int)$res['fourps'] ?></div></div>
</div>
<div class="grid cols-2 mb">
    <div class="card"><h3>Population by age group and sex</h3><div class="chart-box"><canvas id="ageChart"></canvas></div></div>
    <div class="card"><h3>Residents per purok</h3>
        <table class="table"><thead><tr><th>Purok</th><th class="num">Residents</th></tr></thead><tbody>
        <?php foreach ($byPurok as $p): ?><tr><td><?= e($p['purok']) ?></td><td class="num"><?= (int)$p['n'] ?></td></tr><?php endforeach; ?>
        </tbody></table>
    </div>
</div>

<h3>2. Monthly consultations</h3>
<div class="grid cols-2 mb">
    <div class="card"><h3><?= $consTotal ?> consultations in <?= $year ?> (<?= $referred ?> referred)</h3><div class="chart-box"><canvas id="consChart"></canvas></div></div>
    <div class="card"><h3>Top chief complaints</h3>
        <table class="table"><thead><tr><th>Complaint</th><th class="num">Cases</th></tr></thead><tbody>
        <?php foreach ($topComplaints as $t): ?><tr><td><?= e($t['chief_complaint']) ?></td><td class="num"><?= (int)$t['n'] ?></td></tr><?php endforeach; ?>
        <?php if (!$topComplaints): ?><tr><td colspan="2" class="empty">No consultations this year.</td></tr><?php endif; ?>
        </tbody></table>
    </div>
</div>

<h3>3. Vaccination coverage</h3>
<div class="stats">
    <div class="stat"><div class="label">Doses given in <?= $year ?></div><div class="value"><?= array_sum($vaccMonthly) ?></div></div>
    <div class="stat"><div class="label">Completed series</div><div class="value"><?= (int)($vaccStatus['Complete'] ?? 0) ?></div></div>
    <div class="stat amber"><div class="label">Incomplete series</div><div class="value"><?= (int)($vaccStatus['Incomplete'] ?? 0) ?></div></div>
    <div class="stat blue"><div class="label">Fully immunized (12–23 mos)</div><div class="value"><?= $fic ?> / <?= $infants ?></div></div>
</div>
<div class="grid cols-2 mb">
    <div class="card"><h3>Residents vaccinated per vaccine</h3><div class="chart-box"><canvas id="vaccChart"></canvas></div></div>
    <div class="card"><h3>Coverage table</h3>
        <table class="table"><thead><tr><th>Vaccine</th><th>Target</th><th class="num">Residents</th><th class="num">Doses</th></tr></thead><tbody>
        <?php foreach ($coverage as $c): ?><tr><td><?= e($c['vaccine_name']) ?></td><td><?= e($c['target_group']) ?></td><td class="num"><?= (int)$c['residents_vaccinated'] ?></td><td class="num"><?= (int)$c['total_doses_given'] ?></td></tr><?php endforeach; ?>
        </tbody></table>
    </div>
</div>

<h3>4. Medicine distribution</h3>
<div class="grid cols-2 mb">
    <div class="card"><h3>Units dispensed per month (<?= array_sum($medMonthly) ?> total)</h3><div class="chart-box"><canvas id="medChart"></canvas></div></div>
    <div class="card"><h3>Most dispensed medicines</h3>
        <table class="table"><thead><tr><th>Medicine</th><th class="num">Quantity</th><th class="num">Residents</th></tr></thead><tbody>
        <?php foreach ($topMeds as $m): ?><tr><td><?= e($m['generic_name']) ?> <span class="small muted"><?= e($m['strength']) ?></span></td><td class="num"><?= (int)$m['qty'] ?> <?= e($m['unit']) ?></td><td class="num"><?= (int)$m['people'] ?></td></tr><?php endforeach; ?>
        <?php if (!$topMeds): ?><tr><td colspan="3" class="empty">No medicines dispensed this year.</td></tr><?php endif; ?>
        </tbody></table>
        <p class="small">Stock now: <?= (int)($stockSummary['In Stock'] ?? 0) ?> in stock, <?= (int)($stockSummary['Low Stock'] ?? 0) ?> low, <?= (int)($stockSummary['Out of Stock'] ?? 0) ?> out of stock.</p>
    </div>
</div>

<h3>5. Maternal and child health</h3>
<div class="stats">
    <div class="stat purple"><div class="label">Ongoing pregnancies</div><div class="value"><?= (int)$mc['ongoing_pregnancies'] ?></div></div>
    <div class="stat red"><div class="label">High-risk</div><div class="value"><?= (int)$mc['high_risk_pregnancies'] ?></div></div>
    <div class="stat"><div class="label">Deliveries this year</div><div class="value"><?= (int)$mc['deliveries_this_year'] ?></div></div>
    <div class="stat blue"><div class="label">Prenatal visits (<?= $year ?>)</div><div class="value"><?= array_sum($prenatalMonthly) ?></div></div>
    <div class="stat amber"><div class="label">Children with nutrition concerns</div><div class="value"><?= (int)$mc['children_with_nutrition_concerns'] ?></div></div>
</div>
<div class="grid cols-2 mb">
    <div class="card"><h3>Prenatal visits per month</h3><div class="chart-box"><canvas id="prenatalChart"></canvas></div></div>
    <div class="card">
        <h3>Ongoing pregnancies by risk</h3>
        <table class="table"><tbody>
        <?php foreach (['Low', 'Moderate', 'High'] as $rk): ?><tr><td><?= badge($rk) ?></td><td class="num"><?= (int)($riskRows[$rk] ?? 0) ?></td></tr><?php endforeach; ?>
        </tbody></table>
        <h3 style="margin-top:16px">Children's latest nutrition status</h3>
        <table class="table"><tbody>
        <?php foreach ($nutrition as $st => $n): ?><tr><td><?= badge($st) ?></td><td class="num"><?= (int)$n ?></td></tr><?php endforeach; ?>
        <?php if (!$nutrition): ?><tr><td class="empty">No growth records yet.</td></tr><?php endif; ?>
        </tbody></table>
    </div>
</div>

<script>
(function () {
    if (typeof Chart === 'undefined') {
        document.querySelectorAll('.chart-box').forEach(function (b) { b.innerHTML = '<p class="muted">Charts need an internet connection (Chart.js). The tables still show the data.</p>'; b.style.height = 'auto'; });
        return;
    }
    var months = <?= json_encode($months) ?>;
    var teal = '#0f766e', amber = '#d97706', pink = '#db2777', blue = '#2563eb';
    var base = { maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } };
    function bar(id, labels, data, color, opts) {
        new Chart(document.getElementById(id), { type: 'bar', data: { labels: labels, datasets: [{ data: data, backgroundColor: color, borderRadius: 4 }] }, options: opts || base });
    }
    new Chart(document.getElementById('ageChart'), {
        type: 'bar',
        data: { labels: <?= json_encode($ageOrder) ?>, datasets: [
            { label: 'Male', data: <?= json_encode(array_values($ageMale)) ?>, backgroundColor: blue, borderRadius: 4 },
            { label: 'Female', data: <?= json_encode(array_values($ageFemale)) ?>, backgroundColor: pink, borderRadius: 4 }] },
        options: { maintainAspectRatio: false, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } }
    });
    bar('consChart', months, <?= json_encode($consMonthly) ?>, teal);
    bar('vaccChart', <?= json_encode(array_column($coverage, 'vaccine_name')) ?>, <?= json_encode(array_map('intval', array_column($coverage, 'residents_vaccinated'))) ?>, blue,
        { indexAxis: 'y', maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { beginAtZero: true, ticks: { precision: 0 } } } });
    bar('medChart', months, <?= json_encode($medMonthly) ?>, amber);
    bar('prenatalChart', months, <?= json_encode($prenatalMonthly) ?>, pink);
})();
</script>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
