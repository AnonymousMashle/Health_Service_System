<?php
/* CSV downloads for the Reports page. Opens directly in Excel. */
require __DIR__ . '/../../includes/init.php';
require_perm('reports');

$report = get('report');
$year = (int)get('year', date('Y'));

$reports = [
    'residents' => [
        'title' => 'resident_masterlist',
        'sql' => "SELECT r.resident_id AS 'ID', r.last_name AS 'Last name', r.first_name AS 'First name', r.middle_name AS 'Middle name',
                         r.sex AS 'Sex', r.birthdate AS 'Birthdate', TIMESTAMPDIFF(YEAR, r.birthdate, CURDATE()) AS 'Age',
                         r.civil_status AS 'Civil status', h.household_no AS 'Household', h.purok AS 'Purok', r.contact_no AS 'Contact',
                         r.philhealth_no AS 'PhilHealth', IF(r.is_senior, 'Yes', 'No') AS 'Senior', IF(r.is_pwd, 'Yes', 'No') AS 'PWD',
                         IF(r.is_4ps_member, 'Yes', 'No') AS '4Ps', hp.blood_type AS 'Blood type', hp.existing_conditions AS 'Conditions'
                  FROM residents r LEFT JOIN households h ON h.household_id = r.household_id
                  LEFT JOIN health_profiles hp ON hp.resident_id = r.resident_id
                  WHERE r.status = 'active' ORDER BY r.last_name, r.first_name",
        'params' => [],
    ],
    'consultations' => [
        'title' => "consultations_$year",
        'sql' => "SELECT c.consultation_date AS 'Date', CONCAT(r.last_name, ', ', r.first_name) AS 'Patient', r.sex AS 'Sex',
                         TIMESTAMPDIFF(YEAR, r.birthdate, c.consultation_date) AS 'Age', c.chief_complaint AS 'Chief complaint',
                         c.blood_pressure AS 'BP', c.temperature_c AS 'Temp', c.assessment AS 'Assessment',
                         c.treatment_plan AS 'Treatment', c.referred_to AS 'Referred to', c.status AS 'Status', u.full_name AS 'Recorded by'
                  FROM consultations c JOIN residents r ON r.resident_id = c.resident_id LEFT JOIN users u ON u.user_id = c.recorded_by
                  WHERE YEAR(c.consultation_date) = ? ORDER BY c.consultation_date",
        'params' => [$year],
    ],
    'vaccinations' => [
        'title' => "vaccinations_$year",
        'sql' => "SELECT v.date_given AS 'Date given', CONCAT(r.last_name, ', ', r.first_name) AS 'Resident', r.birthdate AS 'Birthdate',
                         vc.vaccine_name AS 'Vaccine', v.dose_no AS 'Dose', vc.doses_required AS 'Doses required',
                         v.next_schedule AS 'Next schedule', v.batch_lot_no AS 'Lot no.', u.full_name AS 'Given by'
                  FROM vaccinations v JOIN residents r ON r.resident_id = v.resident_id JOIN vaccines vc ON vc.vaccine_id = v.vaccine_id
                  LEFT JOIN users u ON u.user_id = v.administered_by WHERE YEAR(v.date_given) = ? ORDER BY v.date_given",
        'params' => [$year],
    ],
    'medicines' => [
        'title' => "medicine_distribution_$year",
        'sql' => "SELECT d.distribution_date AS 'Date', m.generic_name AS 'Medicine', m.strength AS 'Strength', s.batch_no AS 'Batch',
                         d.quantity AS 'Quantity', m.unit AS 'Unit', CONCAT(r.last_name, ', ', r.first_name) AS 'Resident',
                         d.instructions AS 'Instructions', u.full_name AS 'Given by'
                  FROM medicine_distribution d JOIN medicines m ON m.medicine_id = d.medicine_id JOIN medicine_stock s ON s.stock_id = d.stock_id
                  JOIN residents r ON r.resident_id = d.resident_id LEFT JOIN users u ON u.user_id = d.given_by
                  WHERE YEAR(d.distribution_date) = ? ORDER BY d.distribution_date",
        'params' => [$year],
    ],
    'pregnancies' => [
        'title' => 'pregnancies',
        'sql' => "SELECT CONCAT(r.last_name, ', ', r.first_name) AS 'Mother', TIMESTAMPDIFF(YEAR, r.birthdate, CURDATE()) AS 'Age',
                         p.lmp AS 'LMP', p.edd AS 'EDD', p.gravida AS 'G', p.para AS 'P', p.risk_level AS 'Risk', p.risk_notes AS 'Risk notes',
                         (SELECT COUNT(*) FROM prenatal_visits pv WHERE pv.pregnancy_id = p.pregnancy_id) AS 'Prenatal visits',
                         p.status AS 'Status', p.delivery_date AS 'Delivered', p.delivery_place AS 'Place'
                  FROM pregnancies p JOIN residents r ON r.resident_id = p.resident_id ORDER BY p.status, p.edd",
        'params' => [],
    ],
    'inventory' => [
        'title' => 'medicine_inventory',
        'sql' => "SELECT generic_name AS 'Medicine', brand_name AS 'Brand', dosage_form AS 'Form', strength AS 'Strength',
                         usable_stock AS 'Usable stock', unit AS 'Unit', reorder_level AS 'Reorder level',
                         expired_stock AS 'Expired qty', nearest_expiry AS 'Nearest expiry', stock_status AS 'Status'
                  FROM v_medicine_stock_levels ORDER BY generic_name",
        'params' => [],
    ],
];

if (!isset($reports[$report])) {
    flash('danger', 'Unknown report.');
    redirect('modules/reports/index.php');
}

$r = $reports[$report];
$stmt = q($r['sql'], $r['params']);
log_activity('EXPORT', null, null, 'Exported ' . $r['title'] . '.csv');

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $r['title'] . '_' . date('Ymd') . '.csv"');
$out = fopen('php://output', 'w');
fwrite($out, "\xEF\xBB\xBF");   // UTF-8 BOM so Excel shows ñ and other characters correctly
$first = true;
while ($row = $stmt->fetch()) {
    if ($first) {
        fputcsv($out, array_keys($row));
        $first = false;
    }
    fputcsv($out, array_values($row));
}
if ($first) {
    fputcsv($out, ['No records']);
}
fclose($out);
