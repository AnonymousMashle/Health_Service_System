<?php
require __DIR__ . '/../../includes/init.php';
require_perm('maternal');

$id = (int)get('id');
$p = q('SELECT p.*, r.first_name, r.middle_name, r.last_name, r.suffix, r.birthdate, r.contact_no, u.full_name AS registrar
        FROM pregnancies p JOIN residents r ON r.resident_id = p.resident_id LEFT JOIN users u ON u.user_id = p.registered_by
        WHERE p.pregnancy_id = ?', [$id])->fetch();
if (!$p) {
    flash('danger', 'Pregnancy record not found.');
    redirect('modules/maternal/index.php');
}
$errors = [];
$visit = ['visit_date' => today(), 'aog_weeks' => '', 'blood_pressure' => '', 'weight_kg' => '', 'fundal_height_cm' => '',
          'fetal_heart_rate' => '', 'findings' => '', 'supplements_given' => '', 'next_visit' => ''];

if (is_post()) {
    if (!can('maternal', 'edit')) deny();
    $action = input('action');

    if ($action === 'delete_visit') {
        q('DELETE FROM prenatal_visits WHERE visit_id = ? AND pregnancy_id = ?', [(int)input('visit_id'), $id]);
        log_activity('DELETE', 'prenatal_visits', (int)input('visit_id'), 'Deleted prenatal visit');
        flash('success', 'Visit deleted.');
        redirect('modules/maternal/pregnancy_view.php?id=' . $id);
    }

    if ($action === 'add_visit') {
        foreach (array_keys($visit) as $f) { $visit[$f] = input($f); }
        if (!valid_date($visit['visit_date']) || $visit['visit_date'] > today() || $visit['visit_date'] < $p['lmp']) $errors[] = 'Visit date must be between the LMP and today.';
        if ($visit['blood_pressure'] !== '' && !preg_match('#^\d{2,3}/\d{2,3}$#', $visit['blood_pressure'])) $errors[] = 'Blood pressure must look like 110/70.';
        if ($visit['next_visit'] !== '' && (!valid_date($visit['next_visit']) || $visit['next_visit'] <= $visit['visit_date'])) $errors[] = 'Next visit must be after the visit date.';
        foreach (['weight_kg' => [20, 200], 'fundal_height_cm' => [0, 50], 'fetal_heart_rate' => [60, 220], 'aog_weeks' => [0, 45]] as $f => [$min, $max]) {
            if ($visit[$f] !== '' && (!is_numeric($visit[$f]) || $visit[$f] < $min || $visit[$f] > $max)) $errors[] = str_replace('_', ' ', ucfirst($f)) . " must be between $min and $max.";
        }
        if (!$errors) {
            $data = array_map('nullable', $visit);
            if ($data['aog_weeks'] === null) {
                $data['aog_weeks'] = aog_weeks($p['lmp'], $visit['visit_date']);
            }
            $data['pregnancy_id'] = $id;
            $data['recorded_by'] = user_id();
            $vid = db_insert('prenatal_visits', $data);
            log_activity('CREATE', 'prenatal_visits', $vid, 'Recorded prenatal visit (AOG ' . $data['aog_weeks'] . ' wks)');
            if ($data['next_visit']) {
                notify_resident((int)$p['resident_id'], 'Next prenatal visit', 'Your next prenatal check-up is on ' . fmt_date($data['next_visit']) . '.');
            }
            flash('success', 'Prenatal visit recorded.');
            redirect('modules/maternal/pregnancy_view.php?id=' . $id);
        }
    }
}

$visits = q('SELECT pv.*, u.full_name AS recorder FROM prenatal_visits pv LEFT JOIN users u ON u.user_id = pv.recorded_by
             WHERE pv.pregnancy_id = ? ORDER BY pv.visit_date DESC', [$id])->fetchAll();
$tdDoses = q("SELECT v.dose_no, v.date_given FROM vaccinations v JOIN vaccines vc ON vc.vaccine_id = v.vaccine_id
              WHERE v.resident_id = ? AND vc.vaccine_name LIKE 'Td%' AND v.date_given >= ? ORDER BY v.dose_no", [$p['resident_id'], $p['lmp']])->fetchAll();
$ongoing = $p['status'] === 'ongoing';
$aog = aog_weeks($p['lmp']);
$trimester = $aog < 14 ? '1st' : ($aog < 28 ? '2nd' : '3rd');

$page_title = 'Pregnancy Record';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<div class="page-head">
    <div>
        <h2><a href="<?= e(url('modules/residents/view.php?id=' . $p['resident_id'])) ?>"><?= e(full_name($p)) ?></a> <?= badge($p['status']) ?> <?= badge($p['risk_level']) ?></h2>
        <div class="muted"><?= age_years($p['birthdate']) ?> yrs old &middot; G<?= (int)$p['gravida'] ?> P<?= (int)$p['para'] ?>
            <?php if ($ongoing): ?> &middot; <strong><?= $aog ?> weeks</strong> (<?= $trimester ?> trimester)<?php endif; ?></div>
    </div>
    <div class="btn-group no-print">
        <?php if (can('maternal', 'edit')): ?><a class="btn" href="pregnancy_form.php?id=<?= $id ?>">Edit / update outcome</a><?php endif; ?>
        <?php if (can('vaccinations', 'edit')): ?><a class="btn" href="<?= e(url('modules/vaccinations/form.php?resident_id=' . $p['resident_id'])) ?>">+ Td vaccine</a><?php endif; ?>
        <button class="btn" data-print>Print</button>
    </div>
</div>

<div class="grid cols-2 mb">
    <div class="card">
        <h3>Pregnancy details</h3>
        <dl class="info">
            <dt>LMP</dt><dd><?= fmt_date($p['lmp']) ?></dd>
            <dt>EDD</dt><dd><?= fmt_date($p['edd']) ?><?php if ($ongoing): $days = (int)((strtotime($p['edd']) - strtotime(today())) / 86400); ?> <span class="muted small">(<?= $days >= 0 ? $days . ' days to go' : abs($days) . ' days past EDD' ?>)</span><?php endif; ?></dd>
            <dt>Risk notes</dt><dd><?= e($p['risk_notes'] ?: '—') ?></dd>
            <dt>Contact</dt><dd><?= e($p['contact_no'] ?: '—') ?></dd>
            <dt>Registered by</dt><dd><?= e($p['registrar'] ?: '—') ?></dd>
            <?php if ($p['status'] === 'delivered'): ?>
                <dt>Delivered</dt><dd><?= fmt_date($p['delivery_date']) ?> at <?= e($p['delivery_place'] ?: '—') ?></dd>
            <?php endif; ?>
        </dl>
    </div>
    <div class="card">
        <h3>Checklist</h3>
        <dl class="info">
            <dt>Prenatal visits</dt><dd><?= count($visits) ?> <span class="muted small">(WHO recommends at least 8 contacts)</span></dd>
            <dt>Td vaccine this pregnancy</dt><dd><?= $tdDoses ? implode(', ', array_map(function ($d) { return 'Dose ' . $d['dose_no'] . ' (' . fmt_date($d['date_given']) . ')'; }, $tdDoses)) : '<span class="text-danger">None yet</span>' ?></dd>
            <dt>Last visit</dt><dd><?= $visits ? fmt_date($visits[0]['visit_date']) : '—' ?></dd>
            <dt>Next visit</dt><dd><?= $visits && $visits[0]['next_visit'] ? fmt_date($visits[0]['next_visit']) : '—' ?></dd>
        </dl>
    </div>
</div>

<?php if ($ongoing && can('maternal', 'edit')): ?>
<div class="card no-print">
    <h3>Record prenatal visit</h3>
    <form method="post">
        <?= csrf_field() ?><input type="hidden" name="action" value="add_visit">
        <div class="form-grid">
            <?= field('Visit date', 'visit_date', $visit['visit_date'], 'date', 'required max="' . today() . '"') ?>
            <?= field('AOG (weeks)', 'aog_weeks', $visit['aog_weeks'], 'number', 'min="0" max="45" placeholder="Auto: ' . $aog . '"') ?>
            <?= field('Blood pressure', 'blood_pressure', $visit['blood_pressure'], 'text', 'maxlength="7" placeholder="110/70"') ?>
            <?= field('Weight (kg)', 'weight_kg', $visit['weight_kg'], 'number', 'step="0.1"') ?>
            <?= field('Fundal height (cm)', 'fundal_height_cm', $visit['fundal_height_cm'], 'number', 'step="0.1"') ?>
            <?= field('Fetal heart rate (bpm)', 'fetal_heart_rate', $visit['fetal_heart_rate'], 'number') ?>
            <?= field('Supplements given', 'supplements_given', $visit['supplements_given'], 'text', 'maxlength="255" placeholder="Ferrous sulfate + Folic acid"') ?>
            <?= field('Next visit', 'next_visit', $visit['next_visit'], 'date') ?>
            <?= field('Findings / advice', 'findings', $visit['findings'], 'textarea', '', 'full') ?>
        </div>
        <div class="form-actions"><button class="btn btn-primary">Save visit</button></div>
    </form>
</div>
<?php endif; ?>

<div class="card">
    <h3>Prenatal visit records</h3>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Date</th><th>AOG</th><th>BP</th><th class="num">Weight</th><th class="num">Fundal ht.</th><th class="num">FHR</th><th>Findings</th><th>Supplements</th><th>Next visit</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($visits as $v): ?>
            <tr>
                <td class="nowrap"><?= fmt_date($v['visit_date']) ?></td>
                <td><?= $v['aog_weeks'] !== null ? (int)$v['aog_weeks'] . ' wks' : '—' ?></td>
                <td><?= e($v['blood_pressure'] ?: '—') ?></td>
                <td class="num"><?= e($v['weight_kg'] ?? '—') ?></td>
                <td class="num"><?= e($v['fundal_height_cm'] ?? '—') ?></td>
                <td class="num"><?= e($v['fetal_heart_rate'] ?? '—') ?></td>
                <td><?= e($v['findings']) ?><div class="small muted"><?= e($v['recorder']) ?></div></td>
                <td class="small"><?= e($v['supplements_given']) ?></td>
                <td class="nowrap"><?= fmt_date($v['next_visit']) ?></td>
                <td class="actions"><?php if (can('maternal', 'edit')): ?><?= post_button('pregnancy_view.php?id=' . $id, 'Delete', ['action' => 'delete_visit', 'visit_id' => $v['visit_id']], 'btn btn-sm btn-danger', 'Delete this visit?') ?><?php endif; ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$visits): ?><tr><td colspan="10" class="empty">No prenatal visits recorded yet.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
