<?php
require __DIR__ . '/../../includes/init.php';
require_perm('maternal');

const NUTRITION = ['Normal', 'Underweight', 'Severely Underweight', 'Stunted', 'Wasted', 'Overweight'];

$id = (int)get('id');
$child = q('SELECT r.*, h.household_no, h.purok FROM residents r LEFT JOIN households h ON h.household_id = r.household_id
            WHERE r.resident_id = ?', [$id])->fetch();
if (!$child) {
    flash('danger', 'Child not found.');
    redirect('modules/maternal/children.php');
}
$errors = [];
$rec = ['visit_date' => today(), 'weight_kg' => '', 'height_cm' => '', 'muac_cm' => '', 'nutrition_status' => '',
        'milestones' => '', 'remarks' => '', 'next_visit' => ''];

if (is_post()) {
    if (!can('maternal', 'edit')) deny();
    if (input('action') === 'delete') {
        q('DELETE FROM child_monitoring WHERE record_id = ? AND resident_id = ?', [(int)input('record_id'), $id]);
        log_activity('DELETE', 'child_monitoring', (int)input('record_id'), 'Deleted growth record');
        flash('success', 'Record deleted.');
        redirect('modules/maternal/child_view.php?id=' . $id);
    }

    foreach (array_keys($rec) as $f) { $rec[$f] = input($f); }
    if (!valid_date($rec['visit_date']) || $rec['visit_date'] > today() || $rec['visit_date'] < $child['birthdate']) $errors[] = 'Visit date must be between the birthdate and today.';
    if (!is_numeric($rec['weight_kg']) || $rec['weight_kg'] <= 0 || $rec['weight_kg'] > 60) $errors[] = 'Weight (kg) is required and must be realistic.';
    if ($rec['height_cm'] !== '' && (!is_numeric($rec['height_cm']) || $rec['height_cm'] < 30 || $rec['height_cm'] > 150)) $errors[] = 'Height must be 30–150 cm.';
    if ($rec['muac_cm'] !== '' && (!is_numeric($rec['muac_cm']) || $rec['muac_cm'] < 5 || $rec['muac_cm'] > 30)) $errors[] = 'MUAC must be 5–30 cm.';
    if ($rec['nutrition_status'] !== '' && !in_array($rec['nutrition_status'], NUTRITION, true)) $errors[] = 'Select a nutrition status.';
    if ($rec['next_visit'] !== '' && (!valid_date($rec['next_visit']) || $rec['next_visit'] <= $rec['visit_date'])) $errors[] = 'Next visit must be after the visit date.';

    if (!$errors) {
        $data = array_map('nullable', $rec);
        $data['resident_id'] = $id;
        $data['recorded_by'] = user_id();
        $rid = db_insert('child_monitoring', $data);
        log_activity('CREATE', 'child_monitoring', $rid, 'Growth record: ' . $rec['weight_kg'] . ' kg');
        if (in_array($rec['nutrition_status'], ['Severely Underweight', 'Wasted'], true)) {
            notify_roles(['nurse'], 'Child nutrition alert', $child['first_name'] . ' ' . $child['last_name'] . ' was recorded as ' . $rec['nutrition_status'] . '.', 'modules/maternal/child_view.php?id=' . $id);
        }
        if ($data['next_visit']) {
            // Notify the parent's portal account (household head or any adult member with an account)
            $parents = q("SELECT DISTINCT u.user_id FROM users u JOIN residents p ON p.resident_id = u.resident_id
                          WHERE u.status = 'active' AND p.household_id = ? AND TIMESTAMPDIFF(YEAR, p.birthdate, CURDATE()) >= 18", [$child['household_id']])->fetchAll(PDO::FETCH_COLUMN);
            foreach ($parents as $uid) {
                notify((int)$uid, 'Child check-up schedule', $child['first_name'] . "'s next check-up is on " . fmt_date($data['next_visit']) . '.', 'portal/index.php?member=' . $id);
            }
        }
        flash('success', 'Growth record saved.');
        redirect('modules/maternal/child_view.php?id=' . $id);
    }
}

$records = q('SELECT cm.*, u.full_name AS recorder FROM child_monitoring cm LEFT JOIN users u ON u.user_id = cm.recorded_by
              WHERE cm.resident_id = ? ORDER BY cm.visit_date DESC', [$id])->fetchAll();
$vacc = q('SELECT * FROM v_vaccination_status WHERE resident_id = ? ORDER BY vaccine_name', [$id])->fetchAll();
$chartRows = array_reverse($records);
$use_charts = count($records) > 1;

$page_title = 'Child Health Record';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<div class="page-head">
    <div>
        <h2><a href="<?= e(url('modules/residents/view.php?id=' . $id)) ?>"><?= e(full_name($child)) ?></a></h2>
        <div class="muted"><?= e($child['sex']) ?> &middot; <?= e(age_label($child['birthdate'])) ?> old (born <?= fmt_date($child['birthdate']) ?>)
            <?= $child['household_no'] ? ' &middot; ' . e($child['household_no']) . ', ' . e($child['purok']) : '' ?></div>
    </div>
    <div class="btn-group no-print">
        <?php if (can('vaccinations', 'edit')): ?><a class="btn" href="<?= e(url('modules/vaccinations/form.php?resident_id=' . $id)) ?>">+ Vaccination</a><?php endif; ?>
        <button class="btn" data-print>Print</button>
    </div>
</div>

<div class="grid cols-2 mb">
    <?php if (can('maternal', 'edit')): ?>
    <div class="card no-print">
        <h3>Record growth monitoring visit</h3>
        <form method="post">
            <?= csrf_field() ?>
            <div class="form-grid">
                <?= field('Visit date', 'visit_date', $rec['visit_date'], 'date', 'required max="' . today() . '"') ?>
                <?= field('Weight (kg)', 'weight_kg', $rec['weight_kg'], 'number', 'required step="0.01" min="0.5" max="60"') ?>
                <?= field('Height / length (cm)', 'height_cm', $rec['height_cm'], 'number', 'step="0.1"') ?>
                <?= field('MUAC (cm)', 'muac_cm', $rec['muac_cm'], 'number', 'step="0.1"') ?>
                <?= select_field('Nutrition status', 'nutrition_status', NUTRITION, $rec['nutrition_status'], '', '-- Not assessed --') ?>
                <?= field('Next visit', 'next_visit', $rec['next_visit'], 'date') ?>
                <?= field('Milestones', 'milestones', $rec['milestones'], 'text', 'maxlength="255" placeholder="e.g. Sits without support"', 'full') ?>
                <?= field('Remarks', 'remarks', $rec['remarks'], 'textarea', '', 'full') ?>
            </div>
            <div class="form-actions"><button class="btn btn-primary">Save record</button></div>
        </form>
    </div>
    <?php endif; ?>
    <div class="card">
        <h3>Growth chart (weight)</h3>
        <?php if ($use_charts): ?>
            <div class="chart-box"><canvas id="growthChart"></canvas></div>
        <?php else: ?><p class="muted">At least two visits are needed to draw the chart.</p><?php endif; ?>
        <h3 style="margin-top:18px">Vaccination status</h3>
        <?php foreach ($vacc as $v): ?>
            <div><?= e($v['vaccine_name']) ?>: <?= (int)$v['doses_received'] ?>/<?= (int)$v['doses_required'] ?> <?= badge($v['completion_status']) ?></div>
        <?php endforeach; ?>
        <?php if (!$vacc): ?><p class="muted">No vaccinations recorded.</p><?php endif; ?>
    </div>
</div>

<div class="card">
    <h3>Growth monitoring history</h3>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Date</th><th>Age then</th><th class="num">Weight</th><th class="num">Height</th><th class="num">MUAC</th><th>Nutrition</th><th>Milestones / remarks</th><th>Next visit</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($records as $r):
            $ageThen = (new DateTime($child['birthdate']))->diff(new DateTime($r['visit_date'])); ?>
            <tr>
                <td class="nowrap"><?= fmt_date($r['visit_date']) ?></td>
                <td class="nowrap"><?= $ageThen->y * 12 + $ageThen->m ?> mos</td>
                <td class="num"><?= e($r['weight_kg']) ?> kg</td>
                <td class="num"><?= $r['height_cm'] ? e($r['height_cm']) . ' cm' : '—' ?></td>
                <td class="num"><?= $r['muac_cm'] ? e($r['muac_cm']) . ' cm' : '—' ?></td>
                <td><?= $r['nutrition_status'] ? badge($r['nutrition_status']) : '—' ?></td>
                <td class="small"><?= e($r['milestones']) ?><?= $r['milestones'] && $r['remarks'] ? '<br>' : '' ?><?= e($r['remarks']) ?></td>
                <td class="nowrap"><?= fmt_date($r['next_visit']) ?></td>
                <td class="actions"><?php if (can('maternal', 'edit')): ?><?= post_button('child_view.php?id=' . $id, 'Delete', ['action' => 'delete', 'record_id' => $r['record_id']], 'btn btn-sm btn-danger', 'Delete this record?') ?><?php endif; ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$records): ?><tr><td colspan="9" class="empty">No growth records yet.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div>

<?php if ($use_charts): ?>
<script>
new Chart(document.getElementById('growthChart'), {
    type: 'line',
    data: {
        labels: <?= json_encode(array_map(function ($r) { return fmt_date($r['visit_date'], 'M Y'); }, $chartRows)) ?>,
        datasets: [{ label: 'Weight (kg)', data: <?= json_encode(array_map(function ($r) { return (float)$r['weight_kg']; }, $chartRows)) ?>,
                     borderColor: '#0f766e', backgroundColor: '#0f766e', tension: .3 }]
    },
    options: { maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { title: { display: true, text: 'kg' } } } }
});
</script>
<?php endif; ?>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
