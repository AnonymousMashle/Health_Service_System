<?php
require __DIR__ . '/../../includes/init.php';
require_perm('maternal', 'edit');

$id = (int)get('id');
$p = ['resident_id' => get('resident_id'), 'lmp' => '', 'edd' => '', 'gravida' => 1, 'para' => 0, 'risk_level' => 'Low',
      'risk_notes' => '', 'status' => 'ongoing', 'delivery_date' => '', 'delivery_place' => ''];
if ($id) {
    $p = q('SELECT * FROM pregnancies WHERE pregnancy_id = ?', [$id])->fetch();
    if (!$p) {
        flash('danger', 'Pregnancy record not found.');
        redirect('modules/maternal/index.php');
    }
}
$errors = [];

if (is_post()) {
    foreach (['resident_id', 'lmp', 'edd', 'gravida', 'para', 'risk_level', 'risk_notes', 'status', 'delivery_date', 'delivery_place'] as $f) {
        $p[$f] = input($f);
    }
    $mother = q("SELECT * FROM residents WHERE resident_id = ? AND status = 'active'", [$p['resident_id']])->fetch();
    if (!$mother || $mother['sex'] !== 'Female') $errors[] = 'Select a female resident.';
    if (!valid_date($p['lmp']) || $p['lmp'] > today()) $errors[] = 'Enter a valid LMP (not in the future).';
    if ($p['edd'] === '' && valid_date($p['lmp'])) {
        $p['edd'] = date('Y-m-d', strtotime($p['lmp'] . ' +280 days'));   // Naegele's rule
    }
    if (!valid_date($p['edd']) || $p['edd'] <= $p['lmp']) $errors[] = 'EDD must be after the LMP.';
    if (!ctype_digit((string)$p['gravida']) || $p['gravida'] < 1) $errors[] = 'Gravida must be at least 1.';
    if (!ctype_digit((string)$p['para']) || $p['para'] >= $p['gravida']) $errors[] = 'Para must be less than gravida.';
    if (!in_array($p['risk_level'], ['Low', 'Moderate', 'High'], true)) $errors[] = 'Select a risk level.';
    if (!in_array($p['status'], ['ongoing', 'delivered', 'miscarriage', 'transferred'], true)) $errors[] = 'Select a status.';
    if ($p['status'] === 'delivered' && !valid_date($p['delivery_date'])) $errors[] = 'Enter the delivery date.';
    if ($p['status'] === 'ongoing' && !$errors &&
        q("SELECT 1 FROM pregnancies WHERE resident_id = ? AND status = 'ongoing' AND pregnancy_id <> ?", [$p['resident_id'], $id])->fetchColumn()) {
        $errors[] = 'This resident already has an ongoing pregnancy record.';
    }

    if (!$errors) {
        $data = [
            'resident_id' => $p['resident_id'], 'lmp' => $p['lmp'], 'edd' => $p['edd'],
            'gravida' => (int)$p['gravida'], 'para' => (int)$p['para'], 'risk_level' => $p['risk_level'],
            'risk_notes' => nullable($p['risk_notes']), 'status' => $p['status'],
            'delivery_date' => $p['status'] === 'delivered' ? $p['delivery_date'] : null,
            'delivery_place' => $p['status'] === 'delivered' ? nullable($p['delivery_place']) : null,
        ];
        if ($id) {
            db_update('pregnancies', $data, 'pregnancy_id', $id);
            log_activity('UPDATE', 'pregnancies', $id, 'Updated pregnancy record (' . $data['status'] . ')');
        } else {
            $data['registered_by'] = user_id();
            $id = db_insert('pregnancies', $data);
            log_activity('CREATE', 'pregnancies', $id, 'Registered pregnancy of ' . $mother['first_name'] . ' ' . $mother['last_name']);
            if ($data['risk_level'] === 'High') {
                notify_roles(['nurse', 'mho'], 'High-risk pregnancy registered', $mother['first_name'] . ' ' . $mother['last_name'] . ' was registered as high-risk.', 'modules/maternal/pregnancy_view.php?id=' . $id);
            }
        }
        flash('success', 'Pregnancy record saved.');
        redirect('modules/maternal/pregnancy_view.php?id=' . $id);
    }
}

$page_title = $id ? 'Edit Pregnancy' : 'Register Pregnancy';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<form method="post" class="card">
    <?= csrf_field() ?>
    <fieldset>
        <legend>Pregnancy registration</legend>
        <div class="form-grid">
            <?= select_field('Mother', 'resident_id', resident_options("sex = 'Female' AND TIMESTAMPDIFF(YEAR, birthdate, CURDATE()) BETWEEN 10 AND 60"), $p['resident_id'], 'required class="searchable"', '-- Select resident --', 'span-2') ?>
            <?= field('Last menstrual period (LMP)', 'lmp', $p['lmp'], 'date', 'required max="' . today() . '"') ?>
            <div class="field required">
                <label for="f_edd">Expected delivery date (EDD)</label>
                <input id="f_edd" type="date" name="edd" value="<?= e($p['edd']) ?>">
                <div class="hint">Filled in automatically from the LMP (+280 days).</div>
            </div>
            <?= field('Gravida (no. of pregnancies incl. this)', 'gravida', $p['gravida'], 'number', 'required min="1" max="20"') ?>
            <?= field('Para (no. of births)', 'para', $p['para'], 'number', 'required min="0" max="19"') ?>
            <?= select_field('Risk level', 'risk_level', ['Low', 'Moderate', 'High'], $p['risk_level'], 'required', false) ?>
            <?= field('Risk notes', 'risk_notes', $p['risk_notes'], 'text', 'maxlength="255" placeholder="e.g. Hypertension, age over 35, anemia"', 'span-2') ?>
        </div>
    </fieldset>
    <fieldset>
        <legend>Outcome</legend>
        <div class="form-grid">
            <?= select_field('Status', 'status', ['ongoing' => 'Ongoing', 'delivered' => 'Delivered', 'miscarriage' => 'Miscarriage', 'transferred' => 'Transferred'], $p['status'], 'required', false) ?>
            <div data-show-when="status=delivered" style="display:contents">
                <?= field('Delivery date', 'delivery_date', $p['delivery_date'], 'date', 'max="' . today() . '"') ?>
                <?= field('Place of delivery', 'delivery_place', $p['delivery_place'], 'text', 'maxlength="150"', 'span-2') ?>
            </div>
        </div>
        <div class="hint">After delivery, register the newborn in Residents so you can track vaccinations and growth.</div>
    </fieldset>
    <div class="form-actions">
        <a class="btn" href="<?= $id ? 'pregnancy_view.php?id=' . $id : 'index.php' ?>">Cancel</a>
        <button class="btn btn-primary" type="submit">Save</button>
    </div>
</form>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
