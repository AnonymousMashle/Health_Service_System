<?php
require __DIR__ . '/../../includes/init.php';
require_perm('maternal');

$nutrition = get('nutrition');
$search = get('q');
$maxAge = (int)get('max_age', '60');          // months
if (!in_array($maxAge, [12, 24, 60, 72], true)) $maxAge = 60;

$where = ["r.status = 'active'", 'TIMESTAMPDIFF(MONTH, r.birthdate, CURDATE()) < ' . $maxAge];
$params = [];
if ($search !== '') {
    $where[] = "(r.first_name LIKE ? OR r.last_name LIKE ? OR CONCAT(r.first_name, ' ', r.last_name) LIKE ?)";
    $like = "%$search%";
    array_push($params, $like, $like, $like);
}
if ($nutrition === 'none') {
    $where[] = 'cm.record_id IS NULL';
} elseif ($nutrition !== '') {
    $where[] = 'cm.nutrition_status = ?';
    $params[] = $nutrition;
}
$w = implode(' AND ', $where);

// Latest growth-monitoring record of each child
$rows = q("SELECT r.resident_id, r.first_name, r.middle_name, r.last_name, r.suffix, r.sex, r.birthdate, h.purok,
                  cm.visit_date, cm.weight_kg, cm.height_cm, cm.nutrition_status, cm.next_visit
           FROM residents r
           LEFT JOIN households h ON h.household_id = r.household_id
           LEFT JOIN child_monitoring cm ON cm.record_id = (
                SELECT c2.record_id FROM child_monitoring c2 WHERE c2.resident_id = r.resident_id
                ORDER BY c2.visit_date DESC, c2.record_id DESC LIMIT 1)
           WHERE $w ORDER BY r.birthdate DESC", $params)->fetchAll();

$page_title = 'Child Health Monitoring';
require __DIR__ . '/../../includes/header.php';
?>
<div class="card">
    <div class="card-header"><h3>Children (latest growth record)</h3></div>
    <form class="toolbar" method="get">
        <div class="grow"><label>Search</label><input type="search" name="q" value="<?= e($search) ?>" placeholder="Child's name"></div>
        <div><label>Age</label><select name="max_age"><?= options([12 => 'Under 1 year', 24 => 'Under 2 years', 60 => 'Under 5 years', 72 => 'Under 6 years'], $maxAge, false) ?></select></div>
        <div><label>Nutrition status</label><select name="nutrition"><?= options(['none' => 'No record yet', 'Normal' => 'Normal', 'Underweight' => 'Underweight', 'Severely Underweight' => 'Severely Underweight', 'Stunted' => 'Stunted', 'Wasted' => 'Wasted', 'Overweight' => 'Overweight'], $nutrition, 'All') ?></select></div>
        <button class="btn">Filter</button>
    </form>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Child</th><th>Sex</th><th>Age</th><th>Purok</th><th>Last visit</th><th class="num">Weight</th><th class="num">Height</th><th>Nutrition</th><th>Next visit</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $c): $late = $c['next_visit'] && $c['next_visit'] < today(); ?>
            <tr class="<?= in_array($c['nutrition_status'], ['Severely Underweight', 'Wasted'], true) ? 'row-danger' : '' ?>">
                <td><a href="child_view.php?id=<?= (int)$c['resident_id'] ?>"><strong><?= e(full_name($c)) ?></strong></a></td>
                <td><?= e($c['sex']) ?></td>
                <td class="nowrap"><?= e(age_label($c['birthdate'])) ?></td>
                <td><?= e($c['purok'] ?? '—') ?></td>
                <td class="nowrap"><?= fmt_date($c['visit_date']) ?></td>
                <td class="num"><?= $c['weight_kg'] ? e($c['weight_kg']) . ' kg' : '—' ?></td>
                <td class="num"><?= $c['height_cm'] ? e($c['height_cm']) . ' cm' : '—' ?></td>
                <td><?= $c['nutrition_status'] ? badge($c['nutrition_status']) : '<span class="muted">—</span>' ?></td>
                <td class="nowrap <?= $late ? 'text-danger' : '' ?>"><?= fmt_date($c['next_visit']) ?><?= $late ? ' (late)' : '' ?></td>
                <td class="actions"><a class="btn btn-sm" href="child_view.php?id=<?= (int)$c['resident_id'] ?>">Open</a></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="10" class="empty">No children match the filter.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
