<?php
require __DIR__ . '/../../includes/init.php';
require_perm('maternal');

const VISIT_TYPES = ['Prenatal', 'Postnatal', 'Child Check-up', 'Home Visit', 'Follow-up'];
$canEdit = can('maternal', 'edit');
$errors = [];
$s = ['resident_id' => get('resident_id'), 'visit_type' => '', 'scheduled_date' => '', 'assigned_to' => (string)user_id(), 'notes' => ''];

if (is_post()) {
    if (!$canEdit) deny();
    $action = input('action');

    if ($action === 'status') {
        $newStatus = input('status');
        if (in_array($newStatus, ['scheduled', 'done', 'missed', 'cancelled'], true)) {
            q('UPDATE health_visit_schedules SET status = ? WHERE schedule_id = ?', [$newStatus, (int)input('schedule_id')]);
            log_activity('UPDATE', 'health_visit_schedules', (int)input('schedule_id'), 'Marked visit ' . $newStatus);
            flash('success', 'Visit marked as ' . $newStatus . '.');
        }
        redirect(back_url('modules/maternal/schedules.php'));
    }

    if ($action === 'add') {
        foreach (array_keys($s) as $f) { $s[$f] = input($f); }
        if (!q("SELECT 1 FROM residents WHERE resident_id = ? AND status = 'active'", [$s['resident_id']])->fetchColumn()) $errors[] = 'Select a resident.';
        if (!in_array($s['visit_type'], VISIT_TYPES, true)) $errors[] = 'Select a visit type.';
        if (!valid_date($s['scheduled_date'])) $errors[] = 'Enter a valid schedule date.';
        if (!$errors) {
            $sid = db_insert('health_visit_schedules', [
                'resident_id' => $s['resident_id'], 'visit_type' => $s['visit_type'], 'scheduled_date' => $s['scheduled_date'],
                'assigned_to' => nullable($s['assigned_to']), 'notes' => nullable($s['notes']),
            ]);
            log_activity('CREATE', 'health_visit_schedules', $sid, 'Scheduled ' . $s['visit_type'] . ' on ' . $s['scheduled_date']);
            if ($s['assigned_to'] && (int)$s['assigned_to'] !== user_id()) {
                notify((int)$s['assigned_to'], 'New visit assigned to you', $s['visit_type'] . ' on ' . fmt_date($s['scheduled_date']) . '.', 'modules/maternal/schedules.php?mine=1');
            }
            flash('success', 'Visit scheduled.');
            redirect('modules/maternal/schedules.php');
        }
    }
}

$status = get('status', 'scheduled');
$type = get('type');
$mine = get('mine') === '1';
$where = ['1=1'];
$params = [];
if ($status !== '') { $where[] = 's.status = ?'; $params[] = $status; }
if ($type !== '')   { $where[] = 's.visit_type = ?'; $params[] = $type; }
if ($mine)          { $where[] = 's.assigned_to = ?'; $params[] = user_id(); }
$w = implode(' AND ', $where);
$rows = q("SELECT s.*, r.first_name, r.middle_name, r.last_name, r.suffix, r.contact_no, h.purok, h.street_address, u.full_name AS assignee
           FROM health_visit_schedules s JOIN residents r ON r.resident_id = s.resident_id
           LEFT JOIN households h ON h.household_id = r.household_id LEFT JOIN users u ON u.user_id = s.assigned_to
           WHERE $w ORDER BY s.scheduled_date, s.schedule_id LIMIT 200", $params)->fetchAll();

$page_title = 'Scheduled Health Visits';
require __DIR__ . '/../../includes/header.php';
?>
<?= render_errors($errors) ?>
<?php if ($canEdit): ?>
<div class="card">
    <h3>Schedule a visit</h3>
    <form method="post">
        <?= csrf_field() ?><input type="hidden" name="action" value="add">
        <div class="form-grid">
            <?= select_field('Resident', 'resident_id', resident_options(), $s['resident_id'], 'required class="searchable"', '-- Select resident --', 'span-2') ?>
            <?= select_field('Visit type', 'visit_type', VISIT_TYPES, $s['visit_type'], 'required') ?>
            <?= field('Date', 'scheduled_date', $s['scheduled_date'], 'date', 'required min="' . today() . '"') ?>
            <?= select_field('Assigned to', 'assigned_to', staff_options(), $s['assigned_to'], '', '-- Unassigned --') ?>
            <?= field('Notes', 'notes', $s['notes'], 'text', 'maxlength="255"', 'span-2') ?>
        </div>
        <div class="form-actions"><button class="btn btn-primary">Add to schedule</button></div>
    </form>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-header"><h3>Visit schedule</h3></div>
    <form class="toolbar" method="get">
        <div><label>Status</label><select name="status"><?= options(['scheduled', 'done', 'missed', 'cancelled'], $status, 'All') ?></select></div>
        <div><label>Type</label><select name="type"><?= options(VISIT_TYPES, $type, 'All') ?></select></div>
        <label class="check" style="margin-bottom:8px"><input type="checkbox" name="mine" value="1" <?= $mine ? 'checked' : '' ?>> Assigned to me</label>
        <button class="btn">Filter</button>
    </form>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Date</th><th>Resident</th><th>Address</th><th>Type</th><th>Assigned to</th><th>Notes</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r): $late = $r['status'] === 'scheduled' && $r['scheduled_date'] < today(); ?>
            <tr class="<?= $late ? 'row-warning' : '' ?>">
                <td class="nowrap"><?= fmt_date($r['scheduled_date']) ?><?= $r['scheduled_date'] === today() ? ' <span class="badge badge-blue">Today</span>' : '' ?></td>
                <td><a href="<?= e(url('modules/residents/view.php?id=' . $r['resident_id'])) ?>"><?= e(full_name($r)) ?></a><div class="small muted"><?= e($r['contact_no']) ?></div></td>
                <td class="small"><?= e(trim(($r['street_address'] ?? '') . ', ' . ($r['purok'] ?? ''), ', ')) ?></td>
                <td><?= e($r['visit_type']) ?></td>
                <td class="small"><?= e($r['assignee'] ?: '—') ?></td>
                <td class="small"><?= e($r['notes']) ?></td>
                <td><?= badge($r['status']) ?></td>
                <td class="actions">
                    <?php if ($canEdit && $r['status'] === 'scheduled'): ?>
                        <?= post_button('schedules.php', 'Done', ['action' => 'status', 'status' => 'done', 'schedule_id' => $r['schedule_id']], 'btn btn-sm btn-success') ?>
                        <?= post_button('schedules.php', 'Missed', ['action' => 'status', 'status' => 'missed', 'schedule_id' => $r['schedule_id']], 'btn btn-sm') ?>
                        <?= post_button('schedules.php', 'Cancel', ['action' => 'status', 'status' => 'cancelled', 'schedule_id' => $r['schedule_id']], 'btn btn-sm btn-danger', 'Cancel this visit?') ?>
                    <?php elseif ($canEdit): ?>
                        <?= post_button('schedules.php', 'Reopen', ['action' => 'status', 'status' => 'scheduled', 'schedule_id' => $r['schedule_id']], 'btn btn-sm') ?>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="8" class="empty">No visits found.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
