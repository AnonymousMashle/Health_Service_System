<?php
require __DIR__ . '/includes/init.php';

if (current_user()) {
    redirect(home_path());
}

$error = '';
$username = '';

if (is_post()) {
    $username = input('username');
    $password = (string)($_POST['password'] ?? '');

    if (($_SESSION['login_lock_until'] ?? 0) > time()) {
        $error = 'Too many failed attempts. Please wait a few minutes and try again.';
    } elseif ($username === '' || $password === '') {
        $error = 'Enter your username and password.';
    } else {
        $u = q('SELECT * FROM users WHERE username = ?', [$username])->fetch();

        if ($u && password_verify($password, $u['password_hash'])) {
            if ($u['status'] !== 'active') {
                $error = 'This account is inactive. Contact the administrator.';
            } else {
                // Upgrade old hashes automatically if PHP's default algorithm changes
                if (password_needs_rehash($u['password_hash'], PASSWORD_DEFAULT)) {
                    q('UPDATE users SET password_hash = ? WHERE user_id = ?', [password_hash($password, PASSWORD_DEFAULT), $u['user_id']]);
                }

                session_regenerate_id(true);           // prevents session fixation
                unset($u['password_hash']);
                $_SESSION['user'] = $u;
                $_SESSION['last_activity'] = time();
                unset($_SESSION['login_attempts'], $_SESSION['login_lock_until']);

                q('UPDATE users SET last_login = NOW() WHERE user_id = ?', [$u['user_id']]);
                log_activity('LOGIN', 'users', $u['user_id'], 'Logged in');
                redirect(home_path());
            }
        } else {
            $_SESSION['login_attempts'] = ($_SESSION['login_attempts'] ?? 0) + 1;
            if ($_SESSION['login_attempts'] >= 5) {
                $_SESSION['login_lock_until'] = time() + 300;   // lock for 5 minutes
                $_SESSION['login_attempts'] = 0;
            }
            $error = 'Incorrect username or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Log in | <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
</head>
<body>
<div class="login-page">
    <div class="login-card">
        <div class="brand-logo">+</div>
        <h1><?= e(APP_NAME) ?></h1>
        <p class="sub"><?= e(APP_FULL_NAME) ?></p>

        <?= render_flash() ?>
        <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>

        <form method="post" autocomplete="off">
            <?= csrf_field() ?>
            <?= field('Username', 'username', $username, 'text', 'required autofocus') ?>
            <?= field('Password', 'password', '', 'password', 'required') ?>
            <button class="btn btn-primary" type="submit">Log in</button>
        </form>

        <?php if (DEMO_MODE): ?>
            <div class="demo-box">
                <strong>Sample accounts</strong> (password: <code>password123</code>)<br>
                admin &middot; bhw_maria &middot; nurse_ana &middot; mho_reyes &middot; res_juan &middot; res_liza
            </div>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
