<?php
/* =========================================================
   Database & application settings
   Edit these to match your XAMPP setup.
   ========================================================= */

define('DB_HOST', 'localhost');
define('DB_PORT', '3308');
define('DB_NAME', 'bhsms');
define('DB_USER', 'root');
define('DB_PASS', '');                  // XAMPP default is an empty password

define('BASE_URL', '/bhsms');           // folder name inside htdocs -> http://localhost/bhsms
define('APP_NAME', 'BHSMS');
define('APP_FULL_NAME', 'Barangay Health Services and Community Health Monitoring System');
define('BARANGAY_NAME', 'Barangay Health Center');

define('SESSION_TIMEOUT', 1800);        // auto-logout after 30 minutes of no activity
define('DEMO_MODE', true);              // shows sample logins on the login page; set to false for the final demo

date_default_timezone_set('Asia/Manila');

/** Shared PDO connection (created once per request). */
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );
            $pdo->exec("SET time_zone = '+08:00'");
        } catch (PDOException $e) {
            http_response_code(500);
            exit('<h2>Database connection failed</h2>'
                . '<p>Make sure <b>MySQL</b> is running in the XAMPP Control Panel and that you imported <b>database/bhsms.sql</b> in phpMyAdmin.</p>'
                . '<pre>' . htmlspecialchars($e->getMessage()) . '</pre>');
        }
    }
    return $pdo;
}

/** Run a prepared query: q('SELECT * FROM residents WHERE resident_id = ?', [$id]) */
function q(string $sql, array $params = []): PDOStatement
{
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}
