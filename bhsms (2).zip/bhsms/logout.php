<?php
require __DIR__ . '/includes/init.php';

if (current_user()) {
    log_activity('LOGOUT', 'users', user_id(), 'Logged out');
}
$_SESSION = [];
session_destroy();

session_start();
flash('success', 'You have been logged out.');
redirect('login.php');
