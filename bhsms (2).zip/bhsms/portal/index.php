<?php
require __DIR__ . '/common.php';

$rid = (int)get('member', (string)$self_id);
if (!isset($members[$rid])) {
    $rid = $self_id;
}
$r = $members[$rid];
$hp = q('SELECT * FROM health_profiles WHERE resident_id = ?', [$rid])->fetch();

$ids = array_keys($members);
$in = implode(',', array_fill(0, count($ids), '?'));
$upcoming = q("SELECT u.*, r.first_name, r.middle_name, r.last_name, r.suffix FROM v_upcoming_schedules u
               JOIN residents r ON r.resident_id = u.resident_id WHERE u.resident_id IN ($in) ORDER BY u.schedule_date", $ids)->fetchAll();

$page_title = 'My Health Records';
require __DIR__ . '/../includes/header.php';
?>
<?php if (count($members) > 1): ?>
<div class="tabs">
    <?php foreach ($members as $mid => $m): ?>
        <a class="<?= $mid === $rid ? 'active' : '' ?>" href="index.php?member=<?= (int)$mid ?>"><?= $mid === $self_id ? 'Me' : e($m['first_name']) . ' (' . e(age_label($m['birthdate'])) . ')' ?></a>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<div class="page-head">
    <div>
        <h2><?= e(full_name($r)) ?></h2>
        <div class="muted"><?= e($r['sex']) ?> &middot; <?= e(age_label($r['birthdate'])) ?> old &middot; born <?= fmt_date($r['birthdate']) ?></div>
    </div>
    <div class="btn-group">
        <a class="btn btn-primary" href="appointments.php">Request an appointment</a>
        <button class="btn" data-print>Print my records</button>
    </div>
</div>

<div class="grid cols-2 mb">
    <div class="card">
        <h3>Upcoming schedules (family)</h3>
        <?php foreach ($upcoming as $u): ?>
            <div style="margin-bottom:10px">
                <strong><?= fmt_date($u['schedule_date']) ?></strong> — <?= e($u['schedule_type']) ?>: <?= e($u['details']) ?>
                <?php if (count($members) > 1): ?><div class="small muted"><?= e($u['first_name']) ?></div><?php endif; ?>
            </div>
        <?php endforeach; ?>
        <?php if (!$upcoming): ?><p class="muted">No schedules in the next 30 days.</p><?php endif; ?>
    </div>
    <div class="card">
        <h3>Health profile</h3>
        <?php if ($hp): ?>
            <dl class="info">
                <dt>Blood type</dt><dd><?= e($hp['blood_type']) ?></dd>
                <dt>Height / Weight</dt><dd><?= $hp['height_cm'] ? e($hp['height_cm']) . ' cm' : '—' ?> / <?= $hp['weight_kg'] ? e($hp['weight_kg']) . ' kg' : '—' ?></dd>
                <dt>Allergies</dt><dd><?= e($hp['allergies'] ?: 'None recorded') ?></dd>
                <dt>Conditions</dt><dd><?= e($hp['existing_conditions'] ?: 'None recorded') ?></dd>
                <dt>Maintenance meds</dt><dd><?= e($hp['maintenance_meds'] ?: '—') ?></dd>
            </dl>
            <p class="hint">To correct your information, please inform the health center staff.</p>
        <?php else: ?><p class="muted">No health profile on record.</p><?php endif; ?>
    </div>
</div>

<div class="card">
    <?php $is_staff = false; require __DIR__ . '/../includes/partials/resident_records.php'; ?>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
