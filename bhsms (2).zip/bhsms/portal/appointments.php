<?php
require __DIR__ . '/common.php';

$services = ['General Consultation', 'Vaccination', 'Prenatal Check-up', 'Child Check-up', 'Family Planning', 'Medicine Request', 'Other'];
$memberOptions = [];
foreach ($members as $mid => $m) {
    $memberOptions[$mid] = $mid === $self_id ? 'Myself (' . $m['first_name'] . ')' : $m['first_name'] . ' ' . $m['last_name'] . ' (' . age_label($m['birthdate']) . ')';
}
$ids = array_keys($members);
$in = implode(',', array_fill(0, count($ids), '?'));

$a = ['resident_id' => (string)$self_id, 'service_type' => '', 'preferred_date' => '', 'preferred_time' => '08:00', 'reason' => ''];
$errors = [];
$maxDate = date('Y-m-d', strtotime('+60 days'));
$minDate = date('Y-m-d', strtotime('+1 day'));

if (is_post()) {
    $action = input('action');

    if ($action === 'cancel') {
        $aid = (int)input('appointment_id');
        $params = array_merge([$aid], $ids);
        $appt = q("SELECT * FROM appointments WHERE appointment_id = ? AND resident_id IN ($in) AND status IN ('pending', 'approved')", $params)->fetch();
        if ($appt) {
            q("UPDATE appointments SET status = 'cancelled', remarks = 'Cancelled by resident' WHERE appointment_id = ?", [$aid]);
            log_activity('UPDATE', 'appointments', $aid, 'Resident cancelled appointment');
            if ($appt['status'] === 'approved') {
                notify_roles(['bhw', 'nurse'], 'Appointment cancelled by resident',
                    current_user()['full_name'] . ' cancelled the ' . $appt['service_type'] . ' on ' . fmt_date($appt['scheduled_date']) . '.', 'modules/appointments/index.php?status=cancelled');
            }
            flash('success', 'Appointment cancelled.');
        }
        redirect('portal/appointments.php');
    }

    if ($action === 'request') {
        foreach (array_keys($a) as $f) { $a[$f] = input($f); }
        if (!isset($members[(int)$a['resident_id']])) $errors[] = 'Select who the appointment is for.';
        if (!in_array($a['service_type'], $services, true)) $errors[] = 'Select a service.';
        if (!valid_date($a['preferred_date']) || $a['preferred_date'] < $minDate || $a['preferred_date'] > $maxDate) {
            $errors[] = 'Preferred date must be from tomorrow up to 60 days ahead.';
        } elseif ((int)date('N', strtotime($a['preferred_date'])) >= 6) {
            $errors[] = 'The health center is open Monday to Friday only.';
        }
        if (!preg_match('/^\d{2}:\d{2}$/', $a['preferred_time']) || $a['preferred_time'] < '08:00' || $a['preferred_time'] > '16:00') {
            $errors[] = 'Preferred time must be between 8:00 AM and 4:00 PM.';
        }
        if ($a['reason'] === '') $errors[] = 'Briefly tell us the reason for your visit.';
        $pendingCount = (int)q("SELECT COUNT(*) FROM appointments WHERE resident_id IN ($in) AND status = 'pending'", $ids)->fetchColumn();
        if ($pendingCount >= 3) $errors[] = 'You already have 3 pending requests. Please wait for them to be reviewed.';

        if (!$errors) {
            $id = db_insert('appointments', [
                'resident_id' => (int)$a['resident_id'], 'service_type' => $a['service_type'],
                'preferred_date' => $a['preferred_date'], 'preferred_time' => $a['preferred_time'] . ':00',
                'reason' => $a['reason'], 'status' => 'pending', 'requested_by' => user_id(),
            ]);
            log_activity('CREATE', 'appointments', $id, 'Online appointment request: ' . $a['service_type']);
            notify_roles(['bhw', 'nurse'], 'New appointment request',
                $memberOptions[(int)$a['resident_id']] . ' requested ' . $a['service_type'] . ' on ' . fmt_date($a['preferred_date']) . '.', 'modules/appointments/index.php');
            flash('success', 'Request sent. You will be notified once the health center approves it.');
            redirect('portal/appointments.php');
        }
    }
}

$appts = q("SELECT a.*, r.first_name FROM appointments a JOIN residents r ON r.resident_id = a.resident_id
            WHERE a.resident_id IN ($in) ORDER BY FIELD(a.status, 'pending', 'approved') DESC, COALESCE(a.scheduled_date, a.preferred_date) DESC LIMIT 50", $ids)->fetchAll();

$page_title = 'My Appointments';
require __DIR__ . '/../includes/header.php';
?>
<?= render_errors($errors) ?>
<div class="grid cols-2">
    <div class="card">
        <h3>Request an appointment</h3>
        <form method="post">
            <?= csrf_field() ?><input type="hidden" name="action" value="request">
            <div class="form-grid">
                <?= select_field('Appointment for', 'resident_id', $memberOptions, $a['resident_id'], 'required', false, 'full') ?>
                <?= select_field('Service', 'service_type', $services, $a['service_type'], 'required', '-- Select --', 'full') ?>
                <?= field('Preferred date', 'preferred_date', $a['preferred_date'], 'date', 'required min="' . $minDate . '" max="' . $maxDate . '"') ?>
                <?= field('Preferred time', 'preferred_time', $a['preferred_time'], 'time', 'required min="08:00" max="16:00"') ?>
                <?= field('Reason for visit', 'reason', $a['reason'], 'textarea', 'required maxlength="255"', 'full') ?>
            </div>
            <p class="hint">Open Monday–Friday, 8:00 AM – 4:00 PM. The health center will confirm the final schedule.</p>
            <div class="form-actions"><button class="btn btn-primary">Send request</button></div>
        </form>
    </div>
    <div class="card">
        <h3>My appointments</h3>
        <?php foreach ($appts as $ap): $when = $ap['scheduled_date'] ?: $ap['preferred_date']; $time = $ap['scheduled_time'] ?: $ap['preferred_time']; ?>
            <div class="notif">
                <div style="display:flex;justify-content:space-between;gap:10px">
                    <strong><?= e($ap['service_type']) ?></strong><?= badge($ap['status']) ?>
                </div>
                <div><?= fmt_date($when) ?> at <?= fmt_time($time) ?><?= $ap['status'] === 'pending' ? ' <span class="small muted">(preferred)</span>' : '' ?>
                    <?= count($members) > 1 ? ' &middot; ' . e($ap['first_name']) : '' ?></div>
                <?php if ($ap['reason']): ?><div class="small muted"><?= e($ap['reason']) ?></div><?php endif; ?>
                <?php if ($ap['remarks']): ?><div class="small">Note: <?= e($ap['remarks']) ?></div><?php endif; ?>
                <?php if (in_array($ap['status'], ['pending', 'approved'], true)): ?>
                    <div style="margin-top:6px"><?= post_button('appointments.php', 'Cancel', ['action' => 'cancel', 'appointment_id' => $ap['appointment_id']], 'btn btn-sm btn-danger', 'Cancel this appointment?') ?></div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
        <?php if (!$appts): ?><p class="muted">No appointments yet.</p><?php endif; ?>
    </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
