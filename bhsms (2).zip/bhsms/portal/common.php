<?php
/* Shared setup for resident portal pages */
require_once __DIR__ . '/../includes/init.php';
require_role('resident');

$self_id = (int)(current_user()['resident_id'] ?? 0);

/** The resident and their household members under 18 (a parent can view their children's records). */
function portal_members(int $selfId): array
{
    $self = q("SELECT * FROM residents WHERE resident_id = ?", [$selfId])->fetch();
    if (!$self) {
        return [];
    }
    $members = [$selfId => $self];
    if ($self['household_id']) {
        $kids = q("SELECT * FROM residents WHERE household_id = ? AND resident_id <> ? AND status = 'active'
                   AND TIMESTAMPDIFF(YEAR, birthdate, CURDATE()) < 18 ORDER BY birthdate", [$self['household_id'], $selfId])->fetchAll();
        foreach ($kids as $k) {
            $members[$k['resident_id']] = $k;
        }
    }
    return $members;
}

$members = $self_id ? portal_members($self_id) : [];

if (!$members) {
    $page_title = 'My Health Records';
    require __DIR__ . '/../includes/header.php';
    echo '<div class="card"><h3>Your account is not linked to a resident record</h3>'
        . '<p>Please visit the barangay health center so a health worker can link your account to your health records.</p></div>';
    require __DIR__ . '/../includes/footer.php';
    exit;
}
