<?php
require __DIR__ . '/../includes/init.php';
require_perm('users', 'edit');

$id = (int)get('id');
$u = ['username' => '', 'full_name' => '', 'email' => '', 'role' => get('role', 'bhw'), 'resident_id' => get('resident_id'), 'status' => 'active'];
if ($id) {
    $u = q('SELECT * FROM users WHERE user_id = ?', [$id])->fetch();
    if (!$u) {
        flash('danger', 'User not found.');
        redirect('admin/users.php');
    }
}
$isSelf = $id === user_id();

// Pre-fill the name when creating a login for a resident
if (!$id && $u['resident_id'] !== '' && ($res = q('SELECT first_name, last_name FROM residents WHERE resident_id = ?', [$u['resident_id']])->fetch())) {
    $u['full_name'] = $res['first_name'] . ' ' . $res['last_name'];
    $u['username'] = 'res_' . strtolower(preg_replace('/[^a-z]/i', '', $res['first_name']));
}
$errors = [];

if (is_post()) {
    foreach (['username', 'full_name', 'email', 'role', 'resident_id', 'status'] as $f) { $u[$f] = input($f); }
    $password = (string)($_POST['password'] ?? '');
    $confirm = (string)($_POST['confirm_password'] ?? '');

    if ($isSelf) {                      // admins cannot lock themselves out
        $u['role'] = 'admin';
        $u['status'] = 'active';
    }
    if (!preg_match('/^[a-zA-Z0-9_.]{4,50}$/', $u['username'])) $errors[] = 'Username must be 4–50 letters, numbers, dots or underscores.';
    if ($u['full_name'] === '') $errors[] = 'Full name is required.';
    if ($u['email'] !== '' && !filter_var($u['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Email address is not valid.';
    if (!isset(ROLE_LABELS[$u['role']])) $errors[] = 'Select a role.';
    if (!in_array($u['status'], ['active', 'inactive'], true)) $errors[] = 'Select a status.';
    if ($u['role'] === 'resident') {
        if (!q('SELECT 1 FROM residents WHERE resident_id = ?', [$u['resident_id']])->fetchColumn()) {
            $errors[] = 'A resident account must be linked to a resident record.';
        } elseif (q('SELECT 1 FROM users WHERE resident_id = ? AND user_id <> ?', [$u['resident_id'], $id])->fetchColumn()) {
            $errors[] = 'That resident already has a portal account.';
        }
    } else {
        $u['resident_id'] = '';
    }
    if (!$id || $password !== '') {
        if (strlen($password) < 8) $errors[] = 'Password must be at least 8 characters.';
        if ($password !== $confirm) $errors[] = 'Passwords do not match.';
    }

    if (!$errors) {
        $data = ['username' => $u['username'], 'full_name' => $u['full_name'], 'email' => nullable($u['email']),
                 'role' => $u['role'], 'resident_id' => nullable($u['resident_id']), 'status' => $u['status']];
        if ($password !== '') {
            $data['password_hash'] = password_hash($password, PASSWORD_DEFAULT);
        }
        try {
            if ($id) {
                db_update('users', $data, 'user_id', $id);
                log_activity('UPDATE', 'users', $id, 'Updated account ' . $data['username'] . ($password !== '' ? ' (password reset)' : ''));
            } else {
                $id = db_insert('users', $data);
                log_activity('CREATE', 'users', $id, 'Created ' . $data['role'] . ' account ' . $data['username']);
            }
            flash('success', 'Account ' . $data['username'] . ' saved.');
            redirect('admin/users.php');
        } catch (PDOException $e) {
            if (!is_duplicate_error($e)) throw $e;
            $errors[] = 'That username or email is already taken.';
        }
    }
}

$residentOpts = resident_options("TIMESTAMPDIFF(YEAR, birthdate, CURDATE()) >= 13");

$page_title = $id ? 'Edit User' : 'Add User';
require __DIR__ . '/../includes/header.php';
?>
<?= render_errors($errors) ?>
<form method="post" class="card" autocomplete="off">
    <?= csrf_field() ?>
    <div class="form-grid">
        <?= field('Username', 'username', $u['username'], 'text', 'required maxlength="50" pattern="[a-zA-Z0-9_.]{4,50}"') ?>
        <?= field('Full name', 'full_name', $u['full_name'], 'text', 'required maxlength="150"') ?>
        <?= field('Email', 'email', $u['email'], 'email', 'maxlength="150"') ?>
        <?= select_field('Role', 'role', ROLE_LABELS, $u['role'], 'required' . ($isSelf ? ' disabled' : ''), false) ?>
        <?= select_field('Status', 'status', ['active' => 'Active', 'inactive' => 'Inactive (cannot log in)'], $u['status'], $isSelf ? 'disabled' : '', false) ?>
        <div data-show-when="role=resident" class="span-2">
            <?= select_field('Linked resident record', 'resident_id', $residentOpts, $u['resident_id'], 'class="searchable"', '-- Select resident --') ?>
        </div>
    </div>
    <fieldset style="margin-top:18px">
        <legend><?= $id ? 'Reset password (leave blank to keep the current one)' : 'Password' ?></legend>
        <div class="form-grid">
            <?= field('Password', 'password', '', 'password', ($id ? '' : 'required ') . 'minlength="8" autocomplete="new-password"') ?>
            <?= field('Confirm password', 'confirm_password', '', 'password', ($id ? '' : 'required ') . 'minlength="8" autocomplete="new-password"') ?>
        </div>
    </fieldset>
    <?php if ($isSelf): ?><p class="hint">You cannot change your own role or deactivate your own account.</p><?php endif; ?>
    <div class="form-actions">
        <a class="btn" href="users.php">Cancel</a>
        <button class="btn btn-primary">Save account</button>
    </div>
</form>
<?php require __DIR__ . '/../includes/footer.php'; ?>
