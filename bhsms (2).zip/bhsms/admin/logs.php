<?php
require __DIR__ . '/../includes/init.php';
require_perm('users');

$userId = get('user_id');
$action = get('action');
$from = get('from');
$to = get('to');
$where = ['1=1'];
$params = [];
if ($userId !== '')    { $where[] = 'l.user_id = ?'; $params[] = $userId; }
if ($action !== '')    { $where[] = 'l.action = ?'; $params[] = $action; }
if (valid_date($from)) { $where[] = 'DATE(l.created_at) >= ?'; $params[] = $from; }
if (valid_date($to))   { $where[] = 'DATE(l.created_at) <= ?'; $params[] = $to; }
$w = implode(' AND ', $where);
$pg = paginate((int)q("SELECT COUNT(*) FROM activity_logs l WHERE $w", $params)->fetchColumn(), 30);
$rows = q("SELECT l.*, u.username, u.full_name, u.role FROM activity_logs l LEFT JOIN users u ON u.user_id = l.user_id
           WHERE $w ORDER BY l.created_at DESC, l.log_id DESC LIMIT {$pg['per']} OFFSET {$pg['offset']}", $params)->fetchAll();

$users = [];
foreach (q('SELECT user_id, username FROM users ORDER BY username')->fetchAll() as $u) {
    $users[$u['user_id']] = $u['username'];
}
$actions = q('SELECT DISTINCT action FROM activity_logs ORDER BY action')->fetchAll(PDO::FETCH_COLUMN);

$page_title = 'Activity Logs';
require __DIR__ . '/../includes/header.php';
?>
<div class="card">
    <form class="toolbar" method="get">
        <div><label>User</label><select name="user_id"><?= options($users, $userId, 'All') ?></select></div>
        <div><label>Action</label><select name="action"><?= options($actions, $action, 'All') ?></select></div>
        <div><label>From</label><input type="date" name="from" value="<?= e($from) ?>"></div>
        <div><label>To</label><input type="date" name="to" value="<?= e($to) ?>"></div>
        <button class="btn">Filter</button>
        <a class="btn" href="logs.php">Reset</a>
    </form>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Date &amp; time</th><th>User</th><th>Action</th><th>Record</th><th>Details</th><th>IP address</th></tr></thead>
        <tbody>
        <?php foreach ($rows as $l): ?>
            <tr>
                <td class="nowrap small"><?= fmt_datetime($l['created_at']) ?></td>
                <td><?= e($l['username'] ?? 'deleted user') ?><div class="small muted"><?= e(ROLE_LABELS[$l['role'] ?? ''] ?? '') ?></div></td>
                <td><span class="badge badge-<?= ['CREATE' => 'green', 'UPDATE' => 'blue', 'DELETE' => 'red', 'LOGIN' => 'gray', 'LOGOUT' => 'gray', 'EXPORT' => 'purple'][$l['action']] ?? 'gray' ?>"><?= e($l['action']) ?></span></td>
                <td class="small"><?= e($l['table_name'] ?? '') ?><?= $l['record_id'] ? ' #' . (int)$l['record_id'] : '' ?></td>
                <td><?= e($l['details']) ?></td>
                <td class="small muted"><?= e($l['ip_address']) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="6" class="empty">No activity found.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
    <?= pagination_links($pg) ?>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
