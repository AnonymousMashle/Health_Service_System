<?php
require __DIR__ . '/../includes/init.php';
require_perm('users');

$role = get('role');
$status = get('status');
$search = get('q');
$where = ['1=1'];
$params = [];
if ($role !== '')   { $where[] = 'u.role = ?'; $params[] = $role; }
if ($status !== '') { $where[] = 'u.status = ?'; $params[] = $status; }
if ($search !== '') { $where[] = '(u.username LIKE ? OR u.full_name LIKE ? OR u.email LIKE ?)'; array_push($params, "%$search%", "%$search%", "%$search%"); }
$w = implode(' AND ', $where);
$pg = paginate((int)q("SELECT COUNT(*) FROM users u WHERE $w", $params)->fetchColumn(), 20);
$rows = q("SELECT u.*, r.first_name, r.middle_name, r.last_name, r.suffix FROM users u LEFT JOIN residents r ON r.resident_id = u.resident_id
           WHERE $w ORDER BY FIELD(u.role, 'admin', 'mho', 'nurse', 'bhw', 'resident'), u.full_name LIMIT {$pg['per']} OFFSET {$pg['offset']}", $params)->fetchAll();

$page_title = 'User Accounts';
require __DIR__ . '/../includes/header.php';
?>
<div class="card">
    <div class="card-header">
        <h3>System users</h3>
        <a class="btn btn-primary" href="user_form.php">+ Add user</a>
    </div>
    <form class="toolbar" method="get">
        <div class="grow"><label>Search</label><input type="search" name="q" value="<?= e($search) ?>" placeholder="Username, name or email"></div>
        <div><label>Role</label><select name="role"><?= options(ROLE_LABELS, $role, 'All') ?></select></div>
        <div><label>Status</label><select name="status"><?= options(['active', 'inactive'], $status, 'All') ?></select></div>
        <button class="btn">Filter</button>
    </form>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Username</th><th>Full name</th><th>Role</th><th>Linked resident</th><th>Last login</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $u): ?>
            <tr>
                <td><strong><?= e($u['username']) ?></strong><?= (int)$u['user_id'] === user_id() ? ' <span class="badge badge-blue">You</span>' : '' ?></td>
                <td><?= e($u['full_name']) ?><div class="small muted"><?= e($u['email']) ?></div></td>
                <td><?= e(ROLE_LABELS[$u['role']] ?? $u['role']) ?></td>
                <td><?= $u['last_name'] ? '<a href="' . e(url('modules/residents/view.php?id=' . $u['resident_id'])) . '">' . e(full_name($u)) . '</a>' : '—' ?></td>
                <td class="small"><?= $u['last_login'] ? fmt_datetime($u['last_login']) : 'Never' ?></td>
                <td><?= badge($u['status']) ?></td>
                <td class="actions"><a class="btn btn-sm" href="user_form.php?id=<?= (int)$u['user_id'] ?>">Edit</a></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="7" class="empty">No users found.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
    <?= pagination_links($pg) ?>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
