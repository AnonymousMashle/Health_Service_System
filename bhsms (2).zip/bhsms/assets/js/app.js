/* BHSMS - small UI helpers (no libraries needed) */
(function () {
    'use strict';

    // Mobile sidebar toggle
    document.querySelectorAll('[data-toggle-sidebar]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            document.getElementById('sidebar').classList.toggle('open');
        });
    });

    // Confirm before submitting forms / following links marked with data-confirm
    document.addEventListener('submit', function (e) {
        var msg = e.target.getAttribute('data-confirm');
        if (msg && !window.confirm(msg)) { e.preventDefault(); }
    });
    document.addEventListener('click', function (e) {
        var a = e.target.closest('a[data-confirm]');
        if (a && !window.confirm(a.getAttribute('data-confirm'))) { e.preventDefault(); }
        if (e.target.closest('[data-print]')) { window.print(); }
    });

    // Tabs: <div class="tabs" data-tabs><button data-tab="x"> ... <div class="tab-panel" id="tab-x">
    document.querySelectorAll('[data-tabs]').forEach(function (tabs) {
        var scope = tabs.parentElement;
        function show(name) {
            tabs.querySelectorAll('[data-tab]').forEach(function (b) { b.classList.toggle('active', b.getAttribute('data-tab') === name); });
            Array.prototype.forEach.call(scope.children, function (p) {
                if (p.classList.contains('tab-panel')) { p.classList.toggle('active', p.id === 'tab-' + name); }
            });
        }
        tabs.addEventListener('click', function (e) {
            var b = e.target.closest('[data-tab]');
            if (!b) { return; }
            e.preventDefault();
            show(b.getAttribute('data-tab'));
            history.replaceState(null, '', '#' + b.getAttribute('data-tab'));
        });
        var hash = location.hash.replace('#', '');
        if (hash && tabs.querySelector('[data-tab="' + hash + '"]')) { show(hash); }
    });

    // Searchable dropdowns: <select class="searchable">
    document.querySelectorAll('select.searchable').forEach(function (sel) {
        var box = document.createElement('input');
        box.type = 'search';
        box.placeholder = 'Type a name to search...';
        box.className = 'search-select';
        sel.parentNode.insertBefore(box, sel);
        var opts = Array.prototype.slice.call(sel.options);
        box.addEventListener('input', function () {
            var term = box.value.toLowerCase(), first = null;
            opts.forEach(function (o) {
                var show = !o.value || o.text.toLowerCase().indexOf(term) !== -1;
                o.hidden = !show;
                if (show && o.value && !first) { first = o; }
            });
            if (term && first) { sel.value = first.value; sel.dispatchEvent(new Event('change')); }
        });
    });

    // Pregnancy form: EDD = LMP + 280 days (Naegele's rule)
    var lmp = document.querySelector('input[name="lmp"]');
    var edd = document.querySelector('input[name="edd"]');
    if (lmp && edd) {
        lmp.addEventListener('change', function () {
            if (!lmp.value) { return; }
            var d = new Date(lmp.value + 'T00:00:00');
            d.setDate(d.getDate() + 280);
            var p = function (n) { return String(n).padStart(2, '0'); };
            edd.value = d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
        });
    }

    // Show/hide blocks based on a select value: <div data-show-when="role=resident">
    document.querySelectorAll('[data-show-when]').forEach(function (block) {
        var parts = block.getAttribute('data-show-when').split('=');
        var ctrl = document.querySelector('[name="' + parts[0] + '"]');
        if (!ctrl) { return; }
        var values = parts[1].split('|');
        var shownDisplay = block.style.display === 'none' ? '' : block.style.display;
        function update() { block.style.display = values.indexOf(ctrl.value) !== -1 ? shownDisplay : 'none'; }
        ctrl.addEventListener('change', update);
        update();
    });
})();
