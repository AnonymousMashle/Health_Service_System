<?php
/* =========================================================
   Helper functions used by every page
   ========================================================= */

/* ---------- Output & navigation ---------- */

/** Escape output (prevents XSS). Use on EVERYTHING printed from the database or user input. */
function e($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function url(string $path = ''): string
{
    return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
}

function redirect(string $path): void
{
    header('Location: ' . (preg_match('#^(https?://|/)#', $path) ? $path : url($path)));
    exit;
}

/** Hidden field that remembers the current page, so an action can return here. */
function back_field(): string
{
    return '<input type="hidden" name="back" value="' . e($_SERVER['REQUEST_URI'] ?? '') . '">';
}

/** Page to return to after a POST action (only pages inside this app are allowed). */
function back_url(string $fallback): string
{
    $back = $_POST['back'] ?? '';
    return (is_string($back) && strpos($back, rtrim(BASE_URL, '/') . '/') === 0) ? $back : url($fallback);
}

/* ---------- Flash messages ---------- */

function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = [$type, $message];
}

function render_flash(): string
{
    $html = '';
    foreach ($_SESSION['flash'] ?? [] as $f) {
        $html .= '<div class="alert alert-' . e($f[0]) . '">' . e($f[1]) . '</div>';
    }
    unset($_SESSION['flash']);
    return $html;
}

function render_errors(array $errors): string
{
    if (!$errors) {
        return '';
    }
    $items = '';
    foreach ($errors as $err) {
        $items .= '<li>' . e($err) . '</li>';
    }
    return '<div class="alert alert-danger"><strong>Please fix the following:</strong><ul>' . $items . '</ul></div>';
}

/* ---------- Request input & CSRF ---------- */

/** True on a POST request; also checks the CSRF token. */
function is_post(): bool
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        return false;
    }
    verify_csrf();
    return true;
}

function input(string $key, $default = '')
{
    $v = $_POST[$key] ?? $default;
    return is_string($v) ? trim($v) : $v;
}

function get(string $key, $default = '')
{
    $v = $_GET[$key] ?? $default;
    return is_string($v) ? trim($v) : $default;
}

/** Empty string -> NULL (for optional database columns). */
function nullable($v)
{
    return ($v === '' || $v === null) ? null : $v;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . csrf_token() . '">';
}

function verify_csrf(): void
{
    if (!hash_equals($_SESSION['csrf'] ?? '', (string)($_POST['csrf'] ?? ''))) {
        http_response_code(400);
        exit('Your session expired or the form is invalid. Go back, refresh the page and try again.');
    }
}

/* ---------- Database helpers ---------- */

/** Insert an associative array into a table. Column names come from code, never from users. */
function db_insert(string $table, array $data): int
{
    $cols = implode(', ', array_keys($data));
    $ph   = implode(', ', array_fill(0, count($data), '?'));
    q("INSERT INTO $table ($cols) VALUES ($ph)", array_values($data));
    return (int)db()->lastInsertId();
}

function db_update(string $table, array $data, string $keyCol, $keyVal): void
{
    $set = implode(', ', array_map(function ($c) { return "$c = ?"; }, array_keys($data)));
    $values = array_values($data);
    $values[] = $keyVal;
    q("UPDATE $table SET $set WHERE $keyCol = ?", $values);
}

function is_duplicate_error(PDOException $e): bool
{
    return (int)($e->errorInfo[1] ?? 0) === 1062;
}

function is_fk_error(PDOException $e): bool
{
    return in_array((int)($e->errorInfo[1] ?? 0), [1451, 1452], true);
}

/* ---------- Audit log & notifications ---------- */

function log_activity(string $action, ?string $table = null, $recordId = null, string $details = ''): void
{
    q(
        'INSERT INTO activity_logs (user_id, action, table_name, record_id, details, ip_address) VALUES (?, ?, ?, ?, ?, ?)',
        [user_id(), $action, $table, $recordId, mb_substr($details, 0, 255), $_SERVER['REMOTE_ADDR'] ?? null]
    );
}

function notify(int $userId, string $title, string $message, ?string $link = null, bool $skipIfUnreadSame = false): void
{
    if ($skipIfUnreadSame) {
        $exists = q('SELECT 1 FROM notifications WHERE user_id = ? AND is_read = 0 AND title = ? AND message = ?', [$userId, $title, $message])->fetchColumn();
        if ($exists) {
            return;
        }
    }
    q('INSERT INTO notifications (user_id, title, message, link) VALUES (?, ?, ?, ?)', [$userId, $title, mb_substr($message, 0, 255), $link]);
}

function notify_roles(array $roles, string $title, string $message, ?string $link = null, bool $skipIfUnreadSame = false): void
{
    $in = implode(',', array_fill(0, count($roles), '?'));
    $ids = q("SELECT user_id FROM users WHERE status = 'active' AND role IN ($in)", $roles)->fetchAll(PDO::FETCH_COLUMN);
    foreach ($ids as $id) {
        notify((int)$id, $title, $message, $link, $skipIfUnreadSame);
    }
}

/** Notify the portal account of a resident (if they have one). */
function notify_resident(int $residentId, string $title, string $message, ?string $link = 'portal/index.php'): void
{
    $uid = q("SELECT user_id FROM users WHERE resident_id = ? AND status = 'active'", [$residentId])->fetchColumn();
    if ($uid) {
        notify((int)$uid, $title, $message, $link);
    }
}

/* ---------- Dates & ages ---------- */

function today(): string
{
    return date('Y-m-d');
}

function valid_date($d): bool
{
    if (!is_string($d) || $d === '') {
        return false;
    }
    $dt = DateTime::createFromFormat('Y-m-d', $d);
    return $dt && $dt->format('Y-m-d') === $d;
}

function fmt_date($d, string $format = 'M j, Y'): string
{
    return $d ? date($format, strtotime($d)) : '—';
}

function fmt_datetime($d): string
{
    return fmt_date($d, 'M j, Y g:i A');
}

function fmt_time($t): string
{
    return $t ? date('g:i A', strtotime($t)) : '—';
}

function age_years(?string $birthdate): int
{
    return $birthdate ? (new DateTime($birthdate))->diff(new DateTime('today'))->y : 0;
}

function age_months(?string $birthdate): int
{
    if (!$birthdate) {
        return 0;
    }
    $d = (new DateTime($birthdate))->diff(new DateTime('today'));
    return $d->y * 12 + $d->m;
}

/** "34 yrs", "8 mos", "12 days" */
function age_label(?string $birthdate): string
{
    if (!$birthdate) {
        return '';
    }
    $d = (new DateTime($birthdate))->diff(new DateTime('today'));
    if ($d->y >= 2) {
        return $d->y . ' yrs';
    }
    $months = $d->y * 12 + $d->m;
    if ($months >= 1) {
        return $months . ' mo' . ($months > 1 ? 's' : '');
    }
    return $d->days . ' day' . ($d->days == 1 ? '' : 's');
}

/** Age of gestation in weeks from the last menstrual period. */
function aog_weeks(?string $lmp, ?string $onDate = null): int
{
    if (!$lmp) {
        return 0;
    }
    $days = (new DateTime($lmp))->diff(new DateTime($onDate ?: 'today'))->days;
    return intdiv($days, 7);
}

/* ---------- Names & lookups ---------- */

function full_name(array $r): string
{
    $mi = !empty($r['middle_name']) ? ' ' . substr($r['middle_name'], 0, 1) . '.' : '';
    $suffix = !empty($r['suffix']) ? ' ' . $r['suffix'] : '';
    return $r['last_name'] . ', ' . $r['first_name'] . $mi . $suffix;
}

/** [resident_id => "Dela Cruz, Juan (41 yrs)"] for dropdowns. */
function resident_options(string $where = '1=1', array $params = []): array
{
    $rows = q("SELECT resident_id, first_name, middle_name, last_name, suffix, birthdate FROM residents
               WHERE status = 'active' AND ($where) ORDER BY last_name, first_name", $params)->fetchAll();
    $out = [];
    foreach ($rows as $r) {
        $out[$r['resident_id']] = full_name($r) . ' (' . age_label($r['birthdate']) . ')';
    }
    return $out;
}

function household_options(): array
{
    $out = [];
    foreach (q('SELECT household_id, household_no, street_address, purok FROM households ORDER BY household_no')->fetchAll() as $h) {
        $out[$h['household_id']] = $h['household_no'] . ' — ' . $h['street_address'] . ' (' . $h['purok'] . ')';
    }
    return $out;
}

function staff_options(array $roles = ['bhw', 'nurse']): array
{
    $in = implode(',', array_fill(0, count($roles), '?'));
    $out = [];
    foreach (q("SELECT user_id, full_name, role FROM users WHERE status = 'active' AND role IN ($in) ORDER BY full_name", $roles)->fetchAll() as $u) {
        $out[$u['user_id']] = $u['full_name'] . ' (' . strtoupper($u['role']) . ')';
    }
    return $out;
}

/* ---------- Pagination ---------- */

function paginate(int $total, int $perPage = 15): array
{
    $pages = max(1, (int)ceil($total / $perPage));
    $page  = min($pages, max(1, (int)get('page', '1')));
    return ['page' => $page, 'pages' => $pages, 'per' => $perPage, 'offset' => ($page - 1) * $perPage, 'total' => $total];
}

function pagination_links(array $p): string
{
    if ($p['pages'] <= 1) {
        return '';
    }
    $qs = $_GET;
    $html = '<div class="pagination"><span class="muted small">' . $p['total'] . ' records</span>';
    for ($i = 1; $i <= $p['pages']; $i++) {
        if ($i != 1 && $i != $p['pages'] && abs($i - $p['page']) > 2) {
            if ($i == 2 || $i == $p['pages'] - 1) {
                $html .= '<span class="muted">…</span>';
            }
            continue;
        }
        $qs['page'] = $i;
        $html .= '<a class="' . ($i == $p['page'] ? 'active' : '') . '" href="?' . e(http_build_query($qs)) . '">' . $i . '</a>';
    }
    return $html . '</div>';
}

/* ---------- UI helpers ---------- */

function badge(?string $status): string
{
    $colors = [
        'active' => 'green', 'completed' => 'green', 'complete' => 'green', 'done' => 'green', 'delivered' => 'green',
        'in stock' => 'green', 'normal' => 'green', 'low' => 'green', 'read' => 'gray',
        'approved' => 'blue', 'ongoing' => 'blue', 'scheduled' => 'blue',
        'pending' => 'amber', 'waiting' => 'amber', 'incomplete' => 'amber', 'low stock' => 'amber', 'moderate' => 'amber',
        'underweight' => 'amber', 'stunted' => 'amber', 'overweight' => 'amber', 'due soon' => 'amber',
        'rejected' => 'red', 'no-show' => 'red', 'missed' => 'red', 'out of stock' => 'red', 'high' => 'red',
        'severely underweight' => 'red', 'wasted' => 'red', 'overdue' => 'red', 'expired' => 'red',
        'referred' => 'purple',
    ];
    $s = (string)$status;
    $color = $colors[strtolower($s)] ?? 'gray';
    return '<span class="badge badge-' . $color . '">' . e(ucfirst($s)) . '</span>';
}

/** <option> tags. $items can be a list ['A','B'] or a map [value => label]. */
function options(array $items, $selected = null, $blank = '-- Select --'): string
{
    $isList = $items && array_keys($items) === range(0, count($items) - 1);
    $html = ($blank !== false) ? '<option value="">' . e($blank) . '</option>' : '';
    foreach ($items as $k => $label) {
        $v = $isList ? $label : $k;
        $sel = ((string)$v === (string)$selected) ? ' selected' : '';
        $html .= '<option value="' . e($v) . '"' . $sel . '>' . e($label) . '</option>';
    }
    return $html;
}

function field(string $label, string $name, $value = '', string $type = 'text', string $attrs = '', string $class = ''): string
{
    $id = 'f_' . preg_replace('/\W/', '_', $name);
    $req = strpos($attrs, 'required') !== false ? ' required' : '';
    if ($type === 'textarea') {
        $control = '<textarea id="' . $id . '" name="' . e($name) . '" ' . $attrs . '>' . e($value) . '</textarea>';
    } else {
        $control = '<input id="' . $id . '" type="' . e($type) . '" name="' . e($name) . '" value="' . e($value) . '" ' . $attrs . '>';
    }
    return '<div class="field' . $req . ' ' . e($class) . '"><label for="' . $id . '">' . e($label) . '</label>' . $control . '</div>';
}

function select_field(string $label, string $name, array $items, $selected = null, string $attrs = '', $blank = '-- Select --', string $class = ''): string
{
    $id = 'f_' . preg_replace('/\W/', '_', $name);
    $req = strpos($attrs, 'required') !== false ? ' required' : '';
    return '<div class="field' . $req . ' ' . e($class) . '"><label for="' . $id . '">' . e($label) . '</label>'
        . '<select id="' . $id . '" name="' . e($name) . '" ' . $attrs . '>' . options($items, $selected, $blank) . '</select></div>';
}

function checkbox(string $label, string $name, $checked): string
{
    return '<label class="check"><input type="checkbox" name="' . e($name) . '" value="1"' . ($checked ? ' checked' : '') . '> ' . e($label) . '</label>';
}

/** Small POST button (for delete / status changes). */
function post_button(string $action, string $label, array $hidden = [], string $class = 'btn btn-sm', string $confirm = ''): string
{
    $html = '<form method="post" action="' . e($action) . '" class="inline"' . ($confirm ? ' data-confirm="' . e($confirm) . '"' : '') . '>' . csrf_field() . back_field();
    foreach ($hidden as $k => $v) {
        $html .= '<input type="hidden" name="' . e($k) . '" value="' . e($v) . '">';
    }
    return $html . '<button type="submit" class="' . e($class) . '">' . e($label) . '</button></form>';
}

function pending_appointments_count(): int
{
    return (int)q("SELECT COUNT(*) FROM appointments WHERE status = 'pending'")->fetchColumn();
}

/* ---------- Shared query: vaccinations whose next dose is not yet recorded ---------- */

function due_vaccinations_sql(): string
{
    return "SELECT v.vaccination_id, v.resident_id, v.vaccine_id, v.dose_no, v.date_given, v.next_schedule,
                   vc.vaccine_name, vc.doses_required, r.first_name, r.middle_name, r.last_name, r.suffix, r.birthdate, r.contact_no
            FROM vaccinations v
            JOIN vaccines vc ON vc.vaccine_id = v.vaccine_id
            JOIN residents r ON r.resident_id = v.resident_id
            WHERE v.next_schedule IS NOT NULL AND r.status = 'active'
              AND NOT EXISTS (SELECT 1 FROM vaccinations v2
                              WHERE v2.resident_id = v.resident_id AND v2.vaccine_id = v.vaccine_id AND v2.dose_no > v.dose_no)";
}
