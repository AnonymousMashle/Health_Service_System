<?php
/*
 * Page layout (top). Before including, a page may set:
 *   $page_title  - text shown in the top bar
 *   $use_charts  - true to load Chart.js
 */
$u = current_user();
$page_title = $page_title ?? APP_NAME;
$unread = $u ? (int)q('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0', [$u['user_id']])->fetchColumn() : 0;

// Build the sidebar menu for the current role
$menu = [];
if ($u) {
    if ($u['role'] === 'resident') {
        $menu['My Health'] = [
            ['My Health Records', 'portal/index.php'],
            ['My Appointments', 'portal/appointments.php'],
        ];
    } else {
        $menu['Main'] = [['Dashboard', 'dashboard.php']];
        $sec = [];
        if (can('residents')) {
            $sec[] = ['Residents', 'modules/residents/index.php'];
            $sec[] = ['Households', 'modules/residents/households.php'];
        }
        if (can('consultations')) {
            $sec[] = ['Consultations', 'modules/consultations/index.php'];
        }
        if (can('vaccinations')) {
            $sec[] = ['Vaccinations', 'modules/vaccinations/index.php'];
        }
        if (can('maternal')) {
            $sec[] = ['Maternal Health', 'modules/maternal/index.php'];
            $sec[] = ['Child Health', 'modules/maternal/children.php'];
            $sec[] = ['Scheduled Visits', 'modules/maternal/schedules.php'];
        }
        $menu['Health Services'] = $sec;

        $ops = [];
        if (can('inventory')) {
            $ops[] = ['Medicine Inventory', 'modules/inventory/index.php'];
        }
        if (can('appointments')) {
            $ops[] = ['Appointments', 'modules/appointments/index.php', pending_appointments_count()];
        }
        if (can('reports')) {
            $ops[] = ['Reports & Analytics', 'modules/reports/index.php'];
        }
        $menu['Operations'] = $ops;

        if (can('users')) {
            $menu['Administration'] = [
                ['User Accounts', 'admin/users.php'],
                ['Activity Logs', 'admin/logs.php'],
            ];
        }
    }
    $menu['Account'] = [
        ['Notifications', 'notifications.php', $unread],
        ['My Account', 'profile.php'],
        ['Log out', 'logout.php'],
    ];
}

// Highlight the menu item for this page (exact file first, otherwise same folder)
$script = $_SERVER['SCRIPT_NAME'] ?? '';
$activePath = null;
foreach ($menu as $items) {
    foreach ($items as $it) {
        if (substr($script, -strlen('/' . $it[1])) === '/' . $it[1]) {
            $activePath = $it[1];
        }
    }
}
if ($activePath === null) {
    foreach ($menu as $items) {
        foreach ($items as $it) {
            $dir = dirname($it[1]);
            if ($activePath === null && $dir !== '.' && strpos($script, '/' . $dir . '/') !== false) {
                $activePath = $it[1];
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($page_title) ?> | <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
    <?php if (!empty($use_charts)): ?>
        <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <?php endif; ?>
</head>
<body>
<div class="layout">
    <aside class="sidebar" id="sidebar">
        <div class="brand">
            <div class="brand-logo">+</div>
            <div><strong><?= e(APP_NAME) ?></strong><small><?= e(BARANGAY_NAME) ?></small></div>
        </div>
        <nav>
            <?php foreach ($menu as $section => $items): if (!$items) continue; ?>
                <div class="nav-section"><?= e($section) ?></div>
                <?php foreach ($items as $it): ?>
                    <a href="<?= e(url($it[1])) ?>" class="<?= $it[1] === $activePath ? 'active' : '' ?>">
                        <span><?= e($it[0]) ?></span>
                        <?php if (!empty($it[2])): ?><span class="nav-count"><?= (int)$it[2] ?></span><?php endif; ?>
                    </a>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </nav>
    </aside>

    <div class="main">
        <header class="topbar">
            <button class="menu-toggle" type="button" data-toggle-sidebar aria-label="Menu">&#9776;</button>
            <h1><?= e($page_title) ?></h1>
            <?php if ($u): ?>
                <div class="topbar-user">
                    <a class="bell" href="<?= e(url('notifications.php')) ?>">Notifications<?php if ($unread): ?> <span class="nav-count"><?= $unread ?></span><?php endif; ?></a>
                    <div class="who">
                        <strong><?= e($u['full_name']) ?></strong>
                        <small><?= e(ROLE_LABELS[$u['role']] ?? $u['role']) ?></small>
                    </div>
                </div>
            <?php endif; ?>
        </header>
        <main class="content">
            <?= render_flash() ?>
