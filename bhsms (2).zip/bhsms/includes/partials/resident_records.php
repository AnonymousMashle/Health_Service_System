<?php
/*
 * Health record tabs for one resident. Used by the staff resident page and the resident portal.
 * Expects:  $rid (int resident_id), $is_staff (bool)
 */
$rec_consults = q('SELECT c.*, u.full_name AS recorder FROM consultations c LEFT JOIN users u ON u.user_id = c.recorded_by
                   WHERE c.resident_id = ? ORDER BY c.consultation_date DESC', [$rid])->fetchAll();
$rec_vstatus  = q('SELECT * FROM v_vaccination_status WHERE resident_id = ? ORDER BY vaccine_name', [$rid])->fetchAll();
$rec_vaccs    = q('SELECT v.*, vc.vaccine_name, u.full_name AS given_by FROM vaccinations v
                   JOIN vaccines vc ON vc.vaccine_id = v.vaccine_id LEFT JOIN users u ON u.user_id = v.administered_by
                   WHERE v.resident_id = ? ORDER BY v.date_given DESC, v.dose_no DESC', [$rid])->fetchAll();
$rec_pregs    = q('SELECT p.*, (SELECT COUNT(*) FROM prenatal_visits pv WHERE pv.pregnancy_id = p.pregnancy_id) AS visits,
                          (SELECT MAX(next_visit) FROM prenatal_visits pv WHERE pv.pregnancy_id = p.pregnancy_id) AS next_visit
                   FROM pregnancies p WHERE p.resident_id = ? ORDER BY p.lmp DESC', [$rid])->fetchAll();
$rec_child    = q('SELECT * FROM child_monitoring WHERE resident_id = ? ORDER BY visit_date DESC', [$rid])->fetchAll();
$rec_appts    = q('SELECT * FROM appointments WHERE resident_id = ? ORDER BY COALESCE(scheduled_date, preferred_date) DESC', [$rid])->fetchAll();
$rec_meds     = q('SELECT d.*, m.generic_name, m.strength, m.dosage_form, m.unit FROM medicine_distribution d
                   JOIN medicines m ON m.medicine_id = d.medicine_id WHERE d.resident_id = ? ORDER BY d.distribution_date DESC', [$rid])->fetchAll();
?>
<div>
    <div class="tabs" data-tabs>
        <button class="active" data-tab="consultations">Consultations (<?= count($rec_consults) ?>)</button>
        <button data-tab="vaccinations">Vaccinations (<?= count($rec_vaccs) ?>)</button>
        <?php if ($rec_pregs): ?><button data-tab="maternal">Pregnancies (<?= count($rec_pregs) ?>)</button><?php endif; ?>
        <?php if ($rec_child): ?><button data-tab="child">Child monitoring (<?= count($rec_child) ?>)</button><?php endif; ?>
        <button data-tab="medicines">Medicines received (<?= count($rec_meds) ?>)</button>
        <button data-tab="appointments">Appointments (<?= count($rec_appts) ?>)</button>
    </div>

    <div class="tab-panel active" id="tab-consultations">
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Date</th><th>Complaint</th><th>Vitals</th><th>Assessment</th><th>Treatment / advice</th><th>Status</th></tr></thead>
            <tbody>
            <?php foreach ($rec_consults as $c): ?>
                <tr>
                    <td class="nowrap">
                        <?php if ($is_staff): ?><a href="<?= e(url('modules/consultations/view.php?id=' . $c['consultation_id'])) ?>"><?= fmt_date($c['consultation_date']) ?></a>
                        <?php else: ?><?= fmt_date($c['consultation_date']) ?><?php endif; ?>
                    </td>
                    <td><?= e($c['chief_complaint']) ?></td>
                    <td class="small nowrap">
                        <?= $c['blood_pressure'] ? 'BP ' . e($c['blood_pressure']) . '<br>' : '' ?>
                        <?= $c['temperature_c'] ? 'Temp ' . e($c['temperature_c']) . '&deg;C' : '' ?>
                    </td>
                    <td><?= e($c['assessment'] ?: '—') ?></td>
                    <td><?= e($c['treatment_plan'] ?: '—') ?><?= $c['referred_to'] ? '<br><span class="small muted">Referred to ' . e($c['referred_to']) . '</span>' : '' ?></td>
                    <td><?= badge($c['status']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$rec_consults): ?><tr><td colspan="6" class="empty">No consultations recorded.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>

    <div class="tab-panel" id="tab-vaccinations">
        <h3>Vaccination card</h3>
        <div class="table-wrap mb"><table class="table">
            <thead><tr><th>Vaccine</th><th class="num">Doses</th><th>Last dose</th><th>Next schedule</th><th>Status</th></tr></thead>
            <tbody>
            <?php foreach ($rec_vstatus as $v): ?>
                <tr>
                    <td><?= e($v['vaccine_name']) ?></td>
                    <td class="num"><?= (int)$v['doses_received'] ?> / <?= (int)$v['doses_required'] ?></td>
                    <td><?= fmt_date($v['last_dose_date']) ?></td>
                    <td><?= $v['completion_status'] === 'Complete' ? '—' : fmt_date($v['next_schedule']) ?></td>
                    <td><?= badge($v['completion_status']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$rec_vstatus): ?><tr><td colspan="5" class="empty">No vaccinations recorded.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
        <?php if ($rec_vaccs): ?>
            <h3>All doses</h3>
            <div class="table-wrap"><table class="table">
                <thead><tr><th>Date given</th><th>Vaccine</th><th>Dose</th><th>Lot no.</th><th>Site</th><th>Given by</th><th>Remarks</th></tr></thead>
                <tbody>
                <?php foreach ($rec_vaccs as $v): ?>
                    <tr>
                        <td><?= fmt_date($v['date_given']) ?></td>
                        <td><?= e($v['vaccine_name']) ?></td>
                        <td><?= (int)$v['dose_no'] ?></td>
                        <td><?= e($v['batch_lot_no'] ?: '—') ?></td>
                        <td><?= e($v['site_given'] ?: '—') ?></td>
                        <td><?= e($v['given_by'] ?: '—') ?></td>
                        <td class="small"><?= e($v['remarks']) ?>
                            <?php if ($is_staff && can('vaccinations', 'edit')): ?><a class="btn btn-sm" href="<?= e(url('modules/vaccinations/form.php?id=' . $v['vaccination_id'])) ?>">Edit</a><?php endif; ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table></div>
        <?php endif; ?>
    </div>

    <?php if ($rec_pregs): ?>
    <div class="tab-panel" id="tab-maternal">
        <div class="table-wrap"><table class="table">
            <thead><tr><th>LMP</th><th>EDD</th><th>G / P</th><th>Risk</th><th>Prenatal visits</th><th>Next visit</th><th>Status</th></tr></thead>
            <tbody>
            <?php foreach ($rec_pregs as $p): ?>
                <tr>
                    <td><?php if ($is_staff): ?><a href="<?= e(url('modules/maternal/pregnancy_view.php?id=' . $p['pregnancy_id'])) ?>"><?= fmt_date($p['lmp']) ?></a><?php else: ?><?= fmt_date($p['lmp']) ?><?php endif; ?></td>
                    <td><?= fmt_date($p['edd']) ?></td>
                    <td>G<?= (int)$p['gravida'] ?> P<?= (int)$p['para'] ?></td>
                    <td><?= badge($p['risk_level']) ?></td>
                    <td><?= (int)$p['visits'] ?></td>
                    <td><?= $p['status'] === 'ongoing' ? fmt_date($p['next_visit']) : '—' ?></td>
                    <td><?= badge($p['status']) ?><?= $p['delivery_date'] ? '<br><span class="small muted">' . fmt_date($p['delivery_date']) . '</span>' : '' ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
    </div>
    <?php endif; ?>

    <?php if ($rec_child): ?>
    <div class="tab-panel" id="tab-child">
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Visit date</th><th class="num">Weight (kg)</th><th class="num">Height (cm)</th><th class="num">MUAC (cm)</th><th>Nutrition status</th><th>Milestones / remarks</th><th>Next visit</th></tr></thead>
            <tbody>
            <?php foreach ($rec_child as $c): ?>
                <tr>
                    <td><?= fmt_date($c['visit_date']) ?></td>
                    <td class="num"><?= e($c['weight_kg']) ?></td>
                    <td class="num"><?= e($c['height_cm']) ?></td>
                    <td class="num"><?= e($c['muac_cm'] ?? '—') ?></td>
                    <td><?= $c['nutrition_status'] ? badge($c['nutrition_status']) : '—' ?></td>
                    <td class="small"><?= e(trim($c['milestones'] . ' ' . $c['remarks'])) ?></td>
                    <td><?= fmt_date($c['next_visit']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
    </div>
    <?php endif; ?>

    <div class="tab-panel" id="tab-medicines">
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Date</th><th>Medicine</th><th class="num">Quantity</th><th>Instructions</th></tr></thead>
            <tbody>
            <?php foreach ($rec_meds as $m): ?>
                <tr>
                    <td><?= fmt_date($m['distribution_date']) ?></td>
                    <td><?= e($m['generic_name']) ?> <span class="muted small"><?= e($m['strength']) ?> <?= e($m['dosage_form']) ?></span></td>
                    <td class="num"><?= (int)$m['quantity'] ?> <?= e($m['unit']) ?></td>
                    <td><?= e($m['instructions']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$rec_meds): ?><tr><td colspan="4" class="empty">No medicines received.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>

    <div class="tab-panel" id="tab-appointments">
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Date</th><th>Service</th><th>Reason</th><th>Status</th><th>Remarks</th></tr></thead>
            <tbody>
            <?php foreach ($rec_appts as $a): ?>
                <tr>
                    <td class="nowrap"><?= fmt_date($a['scheduled_date'] ?: $a['preferred_date']) ?> <span class="small muted"><?= fmt_time($a['scheduled_time'] ?: $a['preferred_time']) ?></span></td>
                    <td><?= e($a['service_type']) ?></td>
                    <td><?= e($a['reason']) ?></td>
                    <td><?= badge($a['status']) ?></td>
                    <td class="small"><?= e($a['remarks']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$rec_appts): ?><tr><td colspan="5" class="empty">No appointments.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>
</div>
