<?php
/* Loaded at the top of every page:  require __DIR__ . '/includes/init.php'; */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}

// Auto-logout after a period of inactivity
if (isset($_SESSION['user'])) {
    if (time() - ($_SESSION['last_activity'] ?? time()) > SESSION_TIMEOUT) {
        session_unset();
        flash('warning', 'You were logged out after 30 minutes of inactivity.');
    } else {
        $_SESSION['last_activity'] = time();
    }
}
