<?php
/* =========================================================
   Roles and permissions
   ========================================================= */

const ROLE_LABELS = [
    'admin'    => 'System Administrator',
    'bhw'      => 'Barangay Health Worker',
    'nurse'    => 'Health Center Nurse',
    'mho'      => 'Municipal Health Officer',
    'resident' => 'Resident',
];

const STAFF = ['admin', 'bhw', 'nurse', 'mho'];

/*
 * Who can do what. 'view' = open the module, 'edit' = add/update records.
 * Change this table to change access for the whole system.
 */
const PERMISSIONS = [
    'residents'     => ['view' => STAFF, 'edit' => ['admin', 'bhw', 'nurse']],
    'consultations' => ['view' => STAFF, 'edit' => ['bhw', 'nurse'], 'assess' => ['nurse'], 'delete' => ['nurse']],
    'vaccinations'  => ['view' => STAFF, 'edit' => ['bhw', 'nurse'], 'manage' => ['admin', 'nurse']],
    'maternal'      => ['view' => STAFF, 'edit' => ['bhw', 'nurse']],
    'inventory'     => ['view' => STAFF, 'edit' => ['admin', 'nurse'], 'distribute' => ['bhw', 'nurse']],
    'appointments'  => ['view' => ['admin', 'bhw', 'nurse'], 'edit' => ['bhw', 'nurse']],
    'reports'       => ['view' => STAFF],
    'users'         => ['view' => ['admin'], 'edit' => ['admin']],
];

function current_user(): ?array
{
    return $_SESSION['user'] ?? null;
}

function user_id(): ?int
{
    return isset($_SESSION['user']) ? (int)$_SESSION['user']['user_id'] : null;
}

function user_role(): ?string
{
    return $_SESSION['user']['role'] ?? null;
}

function has_role(string ...$roles): bool
{
    return in_array(user_role(), $roles, true);
}

function can(string $module, string $action = 'view'): bool
{
    return in_array(user_role(), PERMISSIONS[$module][$action] ?? [], true);
}

function home_path(): string
{
    return user_role() === 'resident' ? 'portal/index.php' : 'dashboard.php';
}

/** Must be logged in. Re-reads the account each request so deactivated users are logged out. */
function require_login(): void
{
    if (!current_user()) {
        flash('warning', 'Please log in first.');
        redirect('login.php');
    }
    $u = q('SELECT user_id, username, full_name, email, role, resident_id, status FROM users WHERE user_id = ?', [user_id()])->fetch();
    if (!$u || $u['status'] !== 'active') {
        session_unset();
        flash('danger', 'Your account is inactive. Contact the administrator.');
        redirect('login.php');
    }
    $_SESSION['user'] = $u;
}

function require_perm(string $module, string $action = 'view'): void
{
    require_login();
    if (!can($module, $action)) {
        deny();
    }
}

function require_role(string ...$roles): void
{
    require_login();
    if (!has_role(...$roles)) {
        deny();
    }
}

function deny(): void
{
    http_response_code(403);
    $page_title = 'Access denied';
    require __DIR__ . '/header.php';
    echo '<div class="card"><h2>Access denied</h2><p>Your role (' . e(ROLE_LABELS[user_role()] ?? '') . ') cannot open this page.</p>'
        . '<a class="btn btn-primary" href="' . e(url(home_path())) . '">Go to home</a></div>';
    require __DIR__ . '/footer.php';
    exit;
}
