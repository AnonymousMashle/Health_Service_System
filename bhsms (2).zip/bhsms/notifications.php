<?php
require __DIR__ . '/includes/init.php';
require_login();

$uid = user_id();

// Open one notification: mark as read, then go to its link
if (($open = (int)get('open')) > 0) {
    $n = q('SELECT * FROM notifications WHERE notification_id = ? AND user_id = ?', [$open, $uid])->fetch();
    if ($n) {
        q('UPDATE notifications SET is_read = 1 WHERE notification_id = ?', [$open]);
        // only follow links inside this app
        if ($n['link'] && !preg_match('#^[a-z]+:|^//#i', $n['link'])) {
            redirect($n['link']);
        }
    }
    redirect('notifications.php');
}

if (is_post() && input('action') === 'read_all') {
    q('UPDATE notifications SET is_read = 1 WHERE user_id = ?', [$uid]);
    flash('success', 'All notifications marked as read.');
    redirect('notifications.php');
}

$pg = paginate((int)q('SELECT COUNT(*) FROM notifications WHERE user_id = ?', [$uid])->fetchColumn(), 20);
$rows = q("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC, notification_id DESC LIMIT {$pg['per']} OFFSET {$pg['offset']}", [$uid])->fetchAll();

$page_title = 'Notifications';
require __DIR__ . '/includes/header.php';
?>
<div class="card">
    <div class="card-header">
        <h3>Your notifications</h3>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="read_all"><button class="btn btn-sm">Mark all as read</button></form>
    </div>
    <?php foreach ($rows as $n): ?>
        <a class="notif <?= $n['is_read'] ? '' : 'unread' ?>" href="<?= e(url('notifications.php?open=' . $n['notification_id'])) ?>">
            <strong><?= e($n['title']) ?></strong>
            <span class="muted small" style="float:right"><?= fmt_datetime($n['created_at']) ?></span>
            <div><?= e($n['message']) ?></div>
        </a>
    <?php endforeach; ?>
    <?php if (!$rows): ?><p class="empty">You have no notifications.</p><?php endif; ?>
    <?= pagination_links($pg) ?>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
