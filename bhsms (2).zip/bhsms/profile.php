<?php
require __DIR__ . '/includes/init.php';
require_login();

$u = current_user();
$errors = [];

if (is_post()) {
    $action = input('action');

    if ($action === 'details') {
        $fullName = input('full_name');
        $email = input('email');
        if ($fullName === '') {
            $errors[] = 'Full name is required.';
        }
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Email address is not valid.';
        }
        if (!$errors) {
            try {
                q('UPDATE users SET full_name = ?, email = ? WHERE user_id = ?', [$fullName, nullable($email), $u['user_id']]);
                log_activity('UPDATE', 'users', $u['user_id'], 'Updated own account details');
                flash('success', 'Account details saved.');
                redirect('profile.php');
            } catch (PDOException $e) {
                if (!is_duplicate_error($e)) throw $e;
                $errors[] = 'That email address is already used by another account.';
            }
        }
    }

    if ($action === 'password') {
        $current = (string)($_POST['current_password'] ?? '');
        $new = (string)($_POST['new_password'] ?? '');
        $confirm = (string)($_POST['confirm_password'] ?? '');
        $hash = q('SELECT password_hash FROM users WHERE user_id = ?', [$u['user_id']])->fetchColumn();

        if (!password_verify($current, $hash)) {
            $errors[] = 'Your current password is incorrect.';
        }
        if (strlen($new) < 8) {
            $errors[] = 'New password must be at least 8 characters.';
        }
        if ($new !== $confirm) {
            $errors[] = 'New passwords do not match.';
        }
        if (!$errors) {
            q('UPDATE users SET password_hash = ? WHERE user_id = ?', [password_hash($new, PASSWORD_DEFAULT), $u['user_id']]);
            log_activity('UPDATE', 'users', $u['user_id'], 'Changed own password');
            flash('success', 'Password changed.');
            redirect('profile.php');
        }
    }
}

$page_title = 'My Account';
require __DIR__ . '/includes/header.php';
?>
<?= render_errors($errors) ?>
<div class="grid cols-2">
    <div class="card">
        <h3>Account details</h3>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="details">
            <div class="form-grid">
                <?= field('Username', 'username_display', $u['username'], 'text', 'disabled') ?>
                <?= field('Role', 'role_display', ROLE_LABELS[$u['role']], 'text', 'disabled') ?>
                <?= field('Full name', 'full_name', $u['full_name'], 'text', 'required maxlength="150"') ?>
                <?= field('Email', 'email', $u['email'], 'email', 'maxlength="150"') ?>
            </div>
            <div class="form-actions"><button class="btn btn-primary">Save details</button></div>
        </form>
    </div>
    <div class="card">
        <h3>Change password</h3>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="password">
            <div class="form-grid">
                <?= field('Current password', 'current_password', '', 'password', 'required', 'full') ?>
                <?= field('New password', 'new_password', '', 'password', 'required minlength="8"') ?>
                <?= field('Confirm new password', 'confirm_password', '', 'password', 'required minlength="8"') ?>
            </div>
            <div class="form-actions"><button class="btn btn-primary">Change password</button></div>
        </form>
    </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
